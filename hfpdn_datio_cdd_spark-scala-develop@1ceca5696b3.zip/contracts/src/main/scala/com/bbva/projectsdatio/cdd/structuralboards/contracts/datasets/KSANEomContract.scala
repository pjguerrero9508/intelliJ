package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, CDDStructuralMainBoardDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit}

import scala.collection.JavaConverters._

case class KSANEomContract(original: DataFrame, config: Config)
  extends CDDStructuralMainBoardDataset[KSANEomContract] {

  val datasetParams: DatasetParams = KSAN_EOM_CONTRACT_CONSTANTS

  TechnicalValidation.configStringListParamValidator(datasetParams.dataSetSelectOutputFields.get, config)
  val selectTablonFields = config.getStringList(datasetParams.dataSetSelectOutputFields.get).asScala.map(col)

  override def dataSetTransformations(outputSchema: DatioSchema): KSANEomContract = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.addOriginType()
  }

  override def dataSetEmptyTransformations(): KSANEomContract = {
    val renamedData = super.dataSetEmptyTransformations()
    renamedData.addOriginTypeEmpty()
  }

  /**
   * Add the column g_contract_origin_type with the value 'D'
   * given that we are working with Contracts Skelet
   *
   * @return Dataframe with the new column
   */
  def addOriginType(): KSANEomContract = {

    val transformed: DataFrame = original
      .withColumn("g_contract_origin_type", lit("D"))

    wrap(transformed)

  }

  /**
   * Add the column g_contract_origin_type with the value NULL_VALUE
   * given that we are working with the empty Contracts Skelet
   *
   * @return Dataframe with the new column
   */
  def addOriginTypeEmpty(): KSANEomContract = {

    val transformed: DataFrame = original
      .withColumn("g_contract_origin_type", lit(NULL_VALUE))

    wrap(transformed)

  }

  /**
   * Gets the final contracts boards PKs in order to allow the union between markets and domestic contracts boards
   *
   * @return
   */
  def getFinalContractsPk(): Array[String] = {
    TechnicalValidation.configStringListParamValidator(CONF_FINAL_CONTRACTS_PK, config)
    config.getStringList(CONF_FINAL_CONTRACTS_PK).asScala.toArray
  }

  /**
   * left join between two tables with the given columns for the join
   *
   * @param right dataframe, enriches the information in the Contracts table
   * @return Dataframe with the interest columns' selection
   */

  def join(right: CDDStructuralBoardsDataset[_]): KSANEomContract = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    if (joinColumns.head.contains("=")) joinDifferentKeys(right) else classicJoin(right)
  }

  def classicJoin(right: CDDStructuralBoardsDataset[_]): KSANEomContract = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    dataSetsColumnsChecker(right, joinColumns)
    val transformed: DataFrame = original.join(right.getDataFrame(), joinColumns, "left")
    wrap(transformed)
  }

  def joinDifferentKeys(right: CDDStructuralBoardsDataset[_]): KSANEomContract = {
    val joinColumns: List[(String, String)] = right.globalParameterSetter().getJoinFields
      .toList.map(fields => (fields.split("=").head, fields.split("=").last))
    TechnicalValidation.listStringValidator(joinColumns.map(_._1), getDataFrame().columns.toSeq,
      s"MainBoard Dataset - has not join columns: ${joinColumns.map(_._1).mkString(", ")}")
    TechnicalValidation.listStringValidator(joinColumns.map(_._2), right.getDataFrame().columns.toSeq,
      s"Right Dataset - has not join columns: ${joinColumns.map(_._2).mkString(", ")}")
    val transformed: DataFrame = original.join(right.getDataFrame(),
      original.col(joinColumns.map(_._1).head).equalTo(right.getDataFrame().col(joinColumns.map(_._2).head)), "left")
    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KSANEomContract = {
    copy(original = transformed)
  }

  /**
   * selection of columns for contract structural board
   *
   * @return Dataframe with the interest contract board columns' selection
   */

  def selectTablonColumns(): KSANEomContract = {
    val tablon: DataFrame = original.select(selectTablonFields: _*)
    this.wrap(tablon)
  }

  override def globalParameterSetter(): KSANEomContract = {
    this.globalParameter = setterDatasetConfiguration(config)
    this
  }

}
