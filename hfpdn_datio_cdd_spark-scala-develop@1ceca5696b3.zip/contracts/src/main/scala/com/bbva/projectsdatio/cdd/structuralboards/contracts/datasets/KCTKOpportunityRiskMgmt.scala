package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KCTKOpportunityRiskMgmt(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KCTKOpportunityRiskMgmt] {

  val datasetParams : DatasetParams = KCTK_OPPORTUNITY_RISK_MGMT_CONSTANTS

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KCTKOpportunityRiskMgmt = {
    copy(original = transformed)
  }
}
