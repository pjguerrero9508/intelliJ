package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import java.time.LocalDate

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.JavaConverters._

case class KSANEomInstallmentPlan(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KSANEomInstallmentPlan] {

  val datasetParams : DatasetParams = KSAN_EOM_INSTALLMENT_PLAN_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("gf_installment_maturity_date",
    "g_installment_plan_id",
    "gf_instlmt_interest_bc_amount",
    "gf_instlmt_total_bc_amount",
    "gf_instlmt_principal_bc_amount"
  )
  override val fieldsNotInInput: Seq[String] = Seq("gf_nxt_instlmt_int_bc_amount",
    "gf_nxt_instlmt_tot_bc_amount",
    "gf_nxt_instlmt_amort_bc_amount",
    "gf_pv_instlmt_int_bc_amount",
    "gf_pv_instlmt_tot_bc_amount",
    "gf_pv_instlmt_amort_bc_amount",
    "gf_lst_instlmt_int_bc_amount",
    "gf_lst_instlmt_tot_bc_amount",
    "gf_lst_instlmt_amort_bc_amount"
  )

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_LOCAL_CONTRACT_ID, config)
  lazy val localContractId: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_LOCAL_CONTRACT_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_MATURITY_DATE, config)
  lazy val maturityDate: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_MATURITY_DATE)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT, config)
  lazy val interestAmount: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT, config)
  lazy val totalAmount: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT, config)
  lazy val principalAmount: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT_LAST, config)
  lazy val totalAmountLast: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT_LAST, config)
  lazy val principalAmountLast: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT_LAST, config)
  lazy val interestAmountLast: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT_ACTUAL, config)
  lazy val totalAmountActual: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT_ACTUAL)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT_ACTUAL, config)
  lazy val principalAmountActual: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT_ACTUAL)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT_ACTUAL, config)
  lazy val interestAmountActual: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT_ACTUAL)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT_PREVIOUS, config)
  lazy val totalAmountPrevious: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_TOTAL_AMOUNT_PREVIOUS)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT_PREVIOUS, config)
  lazy val principalAmountPrevious: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_PRINCIPAL_AMOUNT_PREVIOUS)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT_PREVIOUS, config)
  lazy val interestAmountPrevious: String = config.getString(CONF_COLUMNS_KSAN_EOM_INSTALLMENT_PLAN_INTEREST_AMOUNT_PREVIOUS)
  lazy val isLastRecordColumnName: String = "is_last_record_flag"

  override def applyEmpty(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): KSANEomInstallmentPlan = {
    val relevantColumns: Seq[String] = config.getStringList(CONF_KSAN_EOM_INSTALLMENT_PLAN_RELEVANT_FIELDS).asScala

    val ksanEomInstallmentPlanFieldsColumns: Seq[String] = Seq(totalAmountLast, principalAmountLast, interestAmountLast)
    // Excepcion a DatioSchema ya que es un esquema construido dinamicamente
    val schemaOfEmptyDataFrame: StructType = StructType(
      outputSchema.getStructType
        .filter(
          f => relevantColumns.contains(f.name) || ksanEomInstallmentPlanFieldsColumns.contains(f.name))
    )
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val df: DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(emptyRdd, schemaOfEmptyDataFrame)
      .withColumnRenamed(interestAmountLast, interestAmount)
      .withColumnRenamed(totalAmountLast, totalAmount)
      .withColumnRenamed(principalAmountLast, principalAmount)
    KSANEomInstallmentPlan(df, config).globalParameterSetter()
  }

  /**
   * Create nine calculated columns for enrich the table
   *
   * @param today actual date
   * @return Dataframe with the new columns
   */

  def calculateQuotas(today: String): KSANEomInstallmentPlan = {
    val contractAndCutoffByDate = Window.partitionBy(localContractId)
      .orderBy(col(maturityDate))

    val maturityMonth: String = "maturity_month"
    val contractAndCutoffByMonth = Window.partitionBy(localContractId)
      .orderBy(col(maturityMonth))

    val contractAndCutoffByDateUnbounded = Window.partitionBy(localContractId)
      .orderBy(col(maturityDate))
      .rowsBetween(Window.currentRow, Window.unboundedFollowing)
    val currentMonth: LocalDate = LocalDate.parse(today)
    val currentMonthString: String = currentMonth.toString.substring(CONSTANT_ZERO, CONSTANT_SEVEN)
    val nextMonth: LocalDate = currentMonth.plusMonths(1L)
    val nextMonthString: String = nextMonth.toString.substring(CONSTANT_ZERO, CONSTANT_SEVEN)
    val transformed: DataFrame = original
      .withColumn(isLastRecordColumnName, when(
        last(col(maturityDate)).over(contractAndCutoffByDateUnbounded) === col(maturityDate), 1)
        .otherwise(0))
      .filter(
        original.col(maturityDate).contains(currentMonthString) ||
          original.col(maturityDate).contains(nextMonthString) ||
          col(isLastRecordColumnName) === 1
      )
      .drop(isLastRecordColumnName)
      .withColumn(maturityMonth, lit(col(maturityDate).substr(SUBSTRING_POSITION_0, SUBSTRING_POSITION_7)))
      .withColumn(isLastRecordColumnName, when(
        last(col(maturityDate)).over(contractAndCutoffByMonth) === col(maturityDate), 1)
        .otherwise(0))
      .filter(col(isLastRecordColumnName) === 1)
      .drop(maturityMonth)
      .drop(isLastRecordColumnName)
      .withColumn(interestAmountLast, last(col(interestAmount)).over(contractAndCutoffByDateUnbounded))
      .withColumn(interestAmountActual, lead(col(interestAmount), 1).over(contractAndCutoffByDate))
      .withColumn(interestAmountPrevious, col(interestAmount))
      .withColumn(totalAmountLast, last(col(totalAmount)).over(contractAndCutoffByDateUnbounded))
      .withColumn(totalAmountActual, lead(col(totalAmount), 1).over(contractAndCutoffByDate))
      .withColumn(totalAmountPrevious, col(totalAmount))
      .withColumn(principalAmountLast, last(col(principalAmount)).over(contractAndCutoffByDateUnbounded))
      .withColumn(principalAmountActual, lead(col(principalAmount), 1).over(contractAndCutoffByDate))
      .withColumn(principalAmountPrevious, col(principalAmount))
      .filter(original.col(maturityDate).contains(currentMonthString))

      wrap(transformed)
  }

  def calculateQuotasEmpty(): KSANEomInstallmentPlan = {
    val transformed: DataFrame = original
      .withColumn(interestAmountLast, col(interestAmount))
      .withColumn(interestAmountActual, col(interestAmount))
      .withColumn(interestAmountPrevious, col(interestAmount))
      .withColumn(totalAmountLast, col(totalAmount))
      .withColumn(totalAmountActual, col(totalAmount))
      .withColumn(totalAmountPrevious, col(totalAmount))
      .withColumn(principalAmountLast, col(principalAmount))
      .withColumn(principalAmountActual, col(principalAmount))
      .withColumn(principalAmountPrevious, col(principalAmount))

    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KSANEomInstallmentPlan = {
    copy(original = transformed)
  }

  def getCustomizedDataSet(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema)(emptyInitializeMode: Boolean)(dateIngestion: String)
    : KSANEomInstallmentPlan = {
    this.globalParameter = setterDatasetConfiguration(config)
    if (emptyInitializeMode){
      val applyResult = applyEmpty(datioSparkSession, outputSchema)
      applyResult.asInstanceOf[KSANEomInstallmentPlan].dataSetEmptyTransformations()
    }else{
      val applyResult = apply(datioSparkSession, outputSchema)
      applyResult.asInstanceOf[KSANEomInstallmentPlan].dataSetTransformations(outputSchema)(dateIngestion)
    }
  }

  def dataSetTransformations(outputSchema: DatioSchema)(dateIngestion: String): KSANEomInstallmentPlan = {
    val cleanedData = super.globalParameterSetter().dataSetTransformations(outputSchema)
    cleanedData.globalParameterSetter().calculateQuotas(dateIngestion)
  }

  override def dataSetEmptyTransformations(): KSANEomInstallmentPlan = {
    val cleanedData = super.dataSetEmptyTransformations()
    cleanedData.globalParameterSetter().calculateQuotasEmpty()
  }

  override def globalParameterSetter(): KSANEomInstallmentPlan ={
    super.globalParameterSetter().asInstanceOf[KSANEomInstallmentPlan]
  }
}
