package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit

case class NZTGTradeCoreInfBoEom(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[NZTGTradeCoreInfBoEom] {

  val datasetParams: DatasetParams = NZTG_TRADE_CORE_INF_BO_EOM_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("gf_trd_date", "gf_trd_trmnt_original_date",
    "gf_trd_adj_trmnt_date", "g_customer_id")
  override val fieldsNotInInput: Seq[String] = Seq("gf_contract_register_date", "gf_original_expiry_date",
    "gf_current_expiration_date", "g_cont_main_holder_cust_id")


  override def dataSetTransformations(outputSchema: DatioSchema): NZTGTradeCoreInfBoEom = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.addOriginType()
  }

  override def dataSetEmptyTransformations(): NZTGTradeCoreInfBoEom = {
    val renamedData = super.dataSetEmptyTransformations()
    renamedData.addOriginTypeEmpty()
  }

  /**
   * Add the column g_contract_origin_type with the value 'M'
   * given that we are working with Markets Skelet
   *
   * @return Dataframe with the new column
   */
  def addOriginType(): NZTGTradeCoreInfBoEom = {

    val transformed: DataFrame = original
      .withColumn("g_contract_origin_type", lit("M"))

    wrap(transformed)

  }

  /**
   * Add the column g_contract_origin_type with the value NULL_VALUE
   * given that we are working with the empty Markets Skelet
   *
   * @return Dataframe with the new column
   */
  def addOriginTypeEmpty(): NZTGTradeCoreInfBoEom = {

    val transformed: DataFrame = original
      .withColumn("g_contract_origin_type", lit(NULL_VALUE))

    wrap(transformed)

  }

  /**
   * left join between two tables with the given columns for the join
   *
   * @param right dataframe, enriches the information in the Contracts table
   * @return Dataframe with the interest columns' selection
   */
  def join(right: CDDStructuralBoardsDataset[_]): NZTGTradeCoreInfBoEom = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    if (joinColumns.head.contains("=")) joinDifferentKeys(right) else classicJoin(right)
  }

  def classicJoin(right: CDDStructuralBoardsDataset[_]): NZTGTradeCoreInfBoEom = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    dataSetsColumnsChecker(right, joinColumns)
    val transformed: DataFrame = original.join(right.getDataFrame(), joinColumns, "left")
    wrap(transformed)
  }

  def joinDifferentKeys(right: CDDStructuralBoardsDataset[_]): NZTGTradeCoreInfBoEom = {
    val joinColumns: List[(String, String)] = right.globalParameterSetter().getJoinFields
      .toList.map(fields => (fields.split("=").head, fields.split("=").last))
    TechnicalValidation.listStringValidator(joinColumns.map(_._1), getDataFrame().columns.toSeq,
      s"MainBoard Dataset - has not join columns: ${joinColumns.map(_._1).mkString(", ")}")
    TechnicalValidation.listStringValidator(joinColumns.map(_._2), right.getDataFrame().columns.toSeq,
      s"Right Dataset - has not join columns: ${joinColumns.map(_._2).mkString(", ")}")
    val transformed: DataFrame = original.join(right.getDataFrame(),
      original.col(joinColumns.map(_._1).head).equalTo(right.getDataFrame().col(joinColumns.map(_._2).head)), "left")
    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): NZTGTradeCoreInfBoEom = {
    copy(original = transformed)
  }

  /**
   * selection of columns for contract structural board
   *
   * @return Dataframe with the interest contract board columns' selection
   */

  def selectTablonColumns(): NZTGTradeCoreInfBoEom = {
    this
  }

  override def globalParameterSetter(): NZTGTradeCoreInfBoEom = {
    this.globalParameter = setterDatasetConfiguration(config)
    this
  }
}

