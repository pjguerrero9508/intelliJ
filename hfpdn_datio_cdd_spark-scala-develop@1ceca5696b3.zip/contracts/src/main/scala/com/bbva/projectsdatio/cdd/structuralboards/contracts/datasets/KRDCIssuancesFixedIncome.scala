package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.BadPartitionColumnsNameException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{ReadUtils, SchemaReaderBoards}
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{StringType, StructType}

case class KRDCIssuancesFixedIncome(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KRDCIssuancesFixedIncome] {

  val datasetParams: DatasetParams = KRDC_ISSUANCES_FIXED_INCOME_CONSTANTS

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KRDCIssuancesFixedIncome = {
    copy(original = transformed)
  }

  /**
   *
   * @param datioSparkSession : DatioSparkSession
   * @param outputSchema
   * @return
   */

  override def apply(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): KRDCIssuancesFixedIncome = {
    val initial_schema: StructType = createRelevantSchema(outputSchema)
    // Caso especifico, el campo de filtrado no se encuentra en el esquema de salida ni hay acceso al esquema de entrada
    val schema = initial_schema.add(globalParameter.previousFilterAppliedFields.head, StringType, FALSE_VALUE)
    val df: DataFrame = {
      globalParameter.previousFilterAppliedFields match {
        case seq if seq.nonEmpty =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription}" +
            s" will be previously filtered using [${seq.mkString(", ")}] field")
          val valuesPartition: Seq[(String, String, String)] = buildValuesPartitionParam()
          ReadUtils.safeReader(globalParameter.pathData, SchemaReaderBoards.readSchema(globalParameter.schemaPath, includeDeleted = TRUE_VALUE),
            valuesPartition, fieldsNotInOutput, fieldsNotInInput)(datioSparkSession)(schema, outputSchema)(TRUE_VALUE)
        case _ =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription} won't be previously filtered")
          ReadUtils
            .readParquetWithSchema(datioSparkSession, globalParameter.pathData, outputSchema)
      }
    }
    wrap(df)
  }

  override def buildValuesPartitionParam(): Seq[(String, String, String)] = {
    val dateColumnValue: String = globalParameter.dateColumnValue
      .substring(SUBSTRING_POSITION_0, SUBSTRING_POSITION_4) + globalParameter.dateColumnValue
      .substring(SUBSTRING_POSITION_5, SUBSTRING_POSITION_7) + globalParameter.dateColumnValue
      .substring(SUBSTRING_POSITION_8, SUBSTRING_POSITION_10)
    globalParameter.previousFilterAppliedFields
      .map(fieldName =>
        if (fieldName.equals("gf_odate_date_id")) {
          ("gf_odate_date_id", dateColumnValue, FIELD_TO_FILTER_FLAG)
        } else if (fieldName.equals(globalParameter.entificColumnName)) {
          (globalParameter.entificColumnName, globalParameter.entificColumnValue, FIELD_TO_FILTER_FLAG)
        } else {
          throw new
              BadPartitionColumnsNameException(globalParameter.entificColumnName, this.getClass.toString)
        }
      )
  }
}
