package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, max}
import org.apache.spark.sql.DataFrame

case class KSANEomRenumerations(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KSANEomRenumerations] {

  val datasetParams : DatasetParams = KSAN_EOM_RENUMERATIONS_CONSTANTS

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_RENUMERATIONS_LOCAL_CONTRACT_ID, config)
  lazy val localContractId: String = config.getString(CONF_COLUMNS_KSAN_EOM_RENUMERATIONS_LOCAL_CONTRACT_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_RENUMERATIONS_CONTRACT_ID_INIT_DATE, config)
  lazy val contractIdInitDate: String = config.getString(CONF_COLUMNS_KSAN_EOM_RENUMERATIONS_CONTRACT_ID_INIT_DATE)
  lazy val contractIdInitDateNew: String = "gf_new_contract_id_init_date_new"

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */
  def wrap(transformed: DataFrame): KSANEomRenumerations = {
    copy(original = transformed)
  }

  /**
   * Window function to get max date
   *
   * @return Dataframe with maxi date by local contract id
   */
  def filterMaxInitDate(): KSANEomRenumerations = {
    val w = Window.partitionBy(localContractId)
      .orderBy(col(contractIdInitDate))
      .rowsBetween(Window.currentRow, Window.unboundedFollowing)
    val transformed: DataFrame = original
      .withColumn(contractIdInitDateNew, max(contractIdInitDate).over(w))
    val transformed_filter = transformed.where(transformed.col(contractIdInitDate) === transformed.col(contractIdInitDateNew))
      .drop(contractIdInitDateNew)
    wrap(transformed_filter)
  }

  override def dataSetTransformations(outputSchema: DatioSchema): KSANEomRenumerations = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.filterMaxInitDate()
  }
}
