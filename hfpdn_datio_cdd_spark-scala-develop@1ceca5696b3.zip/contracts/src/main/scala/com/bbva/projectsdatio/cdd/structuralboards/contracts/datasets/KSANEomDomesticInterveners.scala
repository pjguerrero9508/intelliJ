package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KSANEomDomesticInterveners(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KSANEomDomesticInterveners] {

  val datasetParams : DatasetParams = KSAN_EOM_DOMESTIC_INTERVENERS_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("g_main_holder_customer_type", "g_customer_id")
  override val fieldsNotInInput: Seq[String] = Seq("g_cont_main_holder_cust_id")

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_DOMESTIC_INTERVENERS_HOLDER_CUSTOMER_TYPE, config)
  lazy val holderCustomerType: String = config.getString(CONF_COLUMNS_KSAN_EOM_DOMESTIC_INTERVENERS_HOLDER_CUSTOMER_TYPE)

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAN_EOM_DOMESTIC_INTERVENERS_HOLDER_CUSTOMER_TYPE_VAL, config)
  lazy val holderCustomerTypeAllowedValue: String = config.getString(CONF_COLUMNS_KSAN_EOM_DOMESTIC_INTERVENERS_HOLDER_CUSTOMER_TYPE_VAL)

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */
  def wrap(transformed: DataFrame): KSANEomDomesticInterveners = {
    copy(original = transformed)
  }

  /**
   * Select interest column, filter result and change column name
   *
   * @return Dataframe with the filter and columns desired
   */
  def filterCustomerType(): KSANEomDomesticInterveners = {
    val transformed: DataFrame = original
      .where(original.col(holderCustomerType) === holderCustomerTypeAllowedValue)
      .drop(holderCustomerType)
    wrap(transformed)
  }

  override def dataSetTransformations(outputSchema: DatioSchema): KSANEomDomesticInterveners = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.filterCustomerType()
  }
}
