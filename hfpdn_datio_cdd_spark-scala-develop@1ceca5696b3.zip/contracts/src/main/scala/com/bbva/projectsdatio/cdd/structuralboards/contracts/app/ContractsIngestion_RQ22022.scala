package com.bbva.projectsdatio.cdd.structuralboards.contracts.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GenericUtils, GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets._
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.commons.lang.exception.ExceptionUtils
import org.apache.spark.sql.{DataFrame, Row}

import scala.util.{Failure, Success, Try}

/**
 * Main file for Contract Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsContracts_RQ22022_Trait extends CDDStructuralBoardsApp {
  this: CDDStructuralBoardsApp =>

  val mainEntity: String = CONTRACTS_BOARD_TABLE_EOM_CONTRACT
  val configId : String = "CDDContractsBoard_RQ22022"
  val structuralBoard : String = "Contracts"
  val boardTables: Seq[String] = CONTRACTS_BOARD_TABLES_RQ22022
  val defaultAverageKBPerRecord : Int = DEFAULT_AVERAGE_KB_PER_RECORD_BOARDS_CONTRACTS
  val defaultRepartitionBase : Int = DEFAULT_REPARTITION_BASE_BOARDS_CONTRACTS

  /**
   * Override trait run process method due to the necessity to set new Datasets from the
   * union of types of contracts with contractsUnion method (KSANUnionData and KSTMUnionData)
   * @param runtimeContext        RuntimeContext
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info(s"CDDStructuralboards: Init process $structuralBoard")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val config = runtimeContext.getConfig.getConfig(configId)
    Try {
      // Get global parameter
      val globalParameterReaded: GlobalConfigurationReaded =
        setterGlobalConfigurationReadedParamsReader(config)
      val globalParameterTranslated: GlobalConfigurationTranslated =
        setterGlobalConfigurationReadedParamsTranslator(globalParameterReaded)
      val cddDataSetsToJoin: Map[String, CDDStructuralBoardsDataset[_]] =
        dataSetsMapper(globalParameterReaded, globalParameterTranslated, config, datioSparkSession)
      val unionDataset = contractsUnion(cddDataSetsToJoin, config, globalParameterReaded)
      val cddDatasetsIncludeUnions = cddDataSetsToJoin
        . +(CONTRACTS_BOARD_UNION_KSAN -> unionDataset._1.asInstanceOf[KSANUnionData].globalParameterSetter())
        . +(CONTRACTS_BOARD_UNION_KSTM -> unionDataset._2.asInstanceOf[KSTMUnionData].globalParameterSetter())
      val tablon: DataFrame = joinTablon(cddDatasetsIncludeUnions, globalParameterReaded, globalParameterTranslated, datioSparkSession)
        .selectTablonColumns()
        .getDataFrame()
      logger.info(s"CDDStructuralboards: $structuralBoard structural board generated")
      writerCDDBoard(datioSparkSession, tablon, globalParameterReaded, globalParameterTranslated)
      /*
      setCompactorReportIntoProcessFinalReport(
        buildAndLaunchCompactor(
          setCompactorParams(datioSparkSession, globalParameterTranslated),
          datioSparkSession)
      )
       */
    } match {
      case Success(_) =>
        logger.info(s"CDDStructuralboards: Process $structuralBoard successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.info(s"CDDStructuralboards: Something went wrong during $structuralBoard process")
        logger.error(s"CDDStructuralboards: Input Args: ${config.toString}")
        logger.error(s"Exception: {}", ExceptionUtils.getStackTrace(ex))
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        CDDExecutionStats
          .addUnKnownExceptionMessage(new Exception(ex),
            "ContractsIngestion",
            "runProcess")
        logger.info(s"CDDStructuralboards: Finished process $structuralBoard")
        1
    }
  }

  /**
   * This method generates, for the dataset informed in entityName param, a Tuple with its name in the first value
   * and the dataset that will be used in the board calculation in the second value. If emptyInitializeMode is set as "true",
   * the dataset that will be returned will have all it's values set to null. If any of the needed column is not informed
   * in input dataset, it will be initialized with null value as long as output schema contains that column.
   * @param entityName: String
   * @param globalConfigurationReaded: GlobalConfigurationReaded
   * @param globalConfigurationTranslated: GlobalConfigurationTranslated
   * @param config: Config
   * @param emptyInitializeMode: Boolean = false
   * @return
   */
  def dataSetCollectionMapper (entityName: String,
                               globalConfigurationReaded: GlobalConfigurationReaded,
                               globalConfigurationTranslated: GlobalConfigurationTranslated,
                               config: Config,
                               datioSparkSession: DatioSparkSession,
                               emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])] = {

    logger.info(s"CDDStructuralboards: Read output schema")
    val emptyDataframe : DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row], globalConfigurationTranslated.datioOutputSchema.getStructType)
    logger.info(s"CDDStructuralboards: entityName $entityName")
    entityName match {
      case CONTRACTS_BOARD_TABLE_EOM_CONTRACT =>
        Some(CONTRACTS_BOARD_TABLE_EOM_CONTRACT,
          KSANEomContract(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES =>
        Some(CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES,
          KSANEomAssetsLiabilities(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS =>
          Some(CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS,
            KSANEomOutBalanceItems(emptyDataframe, config)
              .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO =>
          Some(CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO,
            KSANEomInternalDepo(emptyDataframe, config)
              .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES =>
        Some(CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES,
          KSTMAssetsLiabilities(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS =>
        Some(CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS,
          KSTMOffBalanceItems(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_INTERNAL_DEPO =>
        Some(CONTRACTS_BOARD_TABLE_INTERNAL_DEPO,
          KSTMInternalDepo(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_RISK_SCORING_ATRB =>
        Some(CONTRACTS_BOARD_TABLE_RISK_SCORING_ATRB,
          KCTKRiskScoringAtrb(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN =>
        Some(CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN,
          KDEOInapprtContSitutn(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_EOM_CONT_SEGMENTATION =>
        Some(CONTRACTS_BOARD_TABLE_EOM_CONT_SEGMENTATION,
          KSANEomContSegmentation(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_EOM_RENUMERATIONS =>
        Some(CONTRACTS_BOARD_TABLE_EOM_RENUMERATIONS,
          KSANEomRenumerations(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_EOM_INSTALLMENT_PLAN =>
        Some(CONTRACTS_BOARD_TABLE_EOM_INSTALLMENT_PLAN,
          KSANEomInstallmentPlan(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode)(globalConfigurationReaded.dateIngestion))
      case CONTRACTS_BOARD_TABLE_EOM_DOMESTIC_INTERVENERS =>
        Some(CONTRACTS_BOARD_TABLE_EOM_DOMESTIC_INTERVENERS,
          KSANEomDomesticInterveners(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_TRADE_CORE_INF_BO_EOM =>
        Some(CONTRACTS_BOARD_TABLE_TRADE_CORE_INF_BO_EOM,
          NZTGTradeCoreInfBoEom(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_WRONG_WAY_RISK =>
        Some(CONTRACTS_BOARD_TABLE_WRONG_WAY_RISK,
          XCTKWrongWayRisk(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_WRITEOFF_CONTRACT =>
        Some(CONTRACTS_BOARD_TABLE_WRITEOFF_CONTRACT,
          KDEOWriteoffContract(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_ISSUANCES_FIXED_INCOME =>
        Some(CONTRACTS_BOARD_TABLE_ISSUANCES_FIXED_INCOME,
          KRDCIssuancesFixedIncome(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_OPPORTUNITY_RISK_MGMT =>
        Some(CONTRACTS_BOARD_TABLE_OPPORTUNITY_RISK_MGMT,
          KCTKOpportunityRiskMgmt(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_REGULATORY_INF_AGGR_CL =>
        Some(CONTRACTS_BOARD_TABLE_REGULATORY_INF_AGGR_CL,
          KREIRegulatoryInfAggrCl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_CREDIT_RISK_AGGR_CL =>
        Some(CONTRACTS_BOARD_TABLE_CREDIT_RISK_AGGR_CL,
          KCTKCreditRiskAggrCl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_ECON_DATA_ORIGIN =>
        Some(CONTRACTS_BOARD_TABLE_ECON_DATA_ORIGIN,
          DX42EconDataOrigin(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CONTRACTS_BOARD_TABLE_FINANCED_ASSET_INF =>
        Some(CONTRACTS_BOARD_TABLE_FINANCED_ASSET_INF,
          LTCEFinancedAssetInf(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case _ => None
    }
  }

  /**
   * This method join with all tables required for contracts board
   *
   * @param dataSetMap        All case class of tables
   * @return KSANEomContract with contracts board
   */
  def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                 globalConfigurationReaded: GlobalConfigurationReaded,
                 globalConfigurationTranslated: GlobalConfigurationTranslated,
                 datioSparkSession: DatioSparkSession): KSANEomContract = {
    logger.info(s"CDDStructuralboards: Init method joinTablon")
    val markets: NZTGTradeCoreInfBoEom = joinMarkets(dataSetMap, datioSparkSession)(globalConfigurationTranslated.checkpointTempPath)
    val domestic: KSANEomContract = joinDomestic(dataSetMap, datioSparkSession)(globalConfigurationTranslated.checkpointTempPath)
    val outputJoinBoardPks: Array[String] = domestic.getFinalContractsPk()
    domestic
      .wrap(
        GenericUtils
          .unionData(domestic.getDataFrame(),
            markets.getDataFrame(),
            outputJoinBoardPks.toList,
            globalConfigurationTranslated.datioOutputSchema)(isSoft = TRUE_VALUE)
      )
  }

  /**
   * Generates the union of assets an liabilities, out of balance and internal depo both for KSAN and KSTM entities
   * @param dataSetMap : Map[String, CDDStructuralBoardsDataset[_]]
   * @param config : Config
   * @param globalParameter : GlobalConfigurationReaded
   * @return
   */
  def contractsUnion(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                     config: Config, globalParameter: GlobalConfigurationReaded):
  (CDDStructuralBoardsDataset[_], CDDStructuralBoardsDataset[_]) = {
    val outputSchema: DatioSchema = SchemaReaderBoards.readSchema(globalParameter.fullNameSchemaBoard)
    val unionKsanData: DataFrame = GenericUtils
      .unionData(
        dataSetMap(CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES).getDataFrame(),
        GenericUtils.unionData(dataSetMap(CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS).getDataFrame(),
          dataSetMap(CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO).getDataFrame(),
          dataSetMap(CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS).asInstanceOf[KSANEomOutBalanceItems].globalParameterSetter().getJoinFields.toList,
          outputSchema)(isSoft = FALSE_VALUE),
        dataSetMap(CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES).asInstanceOf[KSANEomAssetsLiabilities].globalParameterSetter().getJoinFields.toList,
        outputSchema)(isSoft = FALSE_VALUE)
    logger.info(s"CDDStructuralboards: ksan tables union performed")
    val unionKstmData: DataFrame = GenericUtils
      .unionData(
        dataSetMap(CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES).getDataFrame(),
        GenericUtils.unionData(dataSetMap(CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS).getDataFrame(),
          dataSetMap(CONTRACTS_BOARD_TABLE_INTERNAL_DEPO).getDataFrame(),
          dataSetMap(CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS).asInstanceOf[KSTMOffBalanceItems].globalParameterSetter().getJoinFields.toList,
          outputSchema)(isSoft = FALSE_VALUE),
        dataSetMap(CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES).asInstanceOf[KSTMAssetsLiabilities].globalParameterSetter().getJoinFields.toList,
        outputSchema)(isSoft = FALSE_VALUE)
    logger.info(s"CDDStructuralboards: kstm tables union performed")
    (KSANUnionData(unionKsanData, config).globalParameterSetter(),
      KSTMUnionData(unionKstmData, config).globalParameterSetter())
  }

  /**
   * Executes the necessary joins to build domestic contracts board dataset
   * @param dataSetMap : Map[String, CDDStructuralBoardsDataset[_]]
   * @param checkpointTempPath : String)
   * @return
   */
  def joinDomestic(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                   datioSparkSession: DatioSparkSession)
                   (checkpointTempPath: String): KSANEomContract = {
    dataSetMap(mainEntity).asInstanceOf[KSANEomContract].globalParameterSetter()
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_EOM_DOMESTIC_INTERVENERS))// Table Join 4
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_EOM_RENUMERATIONS))       // Table Join 12
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_EOM_CONT_SEGMENTATION))   // Table Join 5
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_OPPORTUNITY_RISK_MGMT))   // Table Join 10
      .checkpoint(datioSparkSession, checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_RISK_SCORING_ATRB))       // Table Join 11
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_EOM_INSTALLMENT_PLAN))    // Table Join 13
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN))     // Table Join 14
      .checkpoint(datioSparkSession, checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CONTRACTS_BOARD_UNION_KSAN))                    // Table Join 1, 2 y 3
      .join(dataSetMap(CONTRACTS_BOARD_UNION_KSTM))                    // Table Join 6, 7 y 8
      .checkpoint(datioSparkSession, checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_WRITEOFF_CONTRACT))       // Table Join 9
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_ECON_DATA_ORIGIN))        // Table Join 15
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_FINANCED_ASSET_INF))      // Table Join 16
      .checkpoint(datioSparkSession, checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_CREDIT_RISK_AGGR_CL))     // Table Join 17
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_REGULATORY_INF_AGGR_CL))  // Table Join 18
  }

  /**
   * Executes the necessary joins to build markets contracts board dataset
   * @param dataSetMap : Map[String, CDDStructuralBoardsDataset[_]]
   * @param checkpointTempPath : String)
   * @return
   */
  def joinMarkets(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                  datioSparkSession: DatioSparkSession)
                  (checkpointTempPath: String) : NZTGTradeCoreInfBoEom = {
    dataSetMap(CONTRACTS_BOARD_TABLE_TRADE_CORE_INF_BO_EOM).asInstanceOf[NZTGTradeCoreInfBoEom].globalParameterSetter()
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_WRONG_WAY_RISK))            // Table Join 1
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_ISSUANCES_FIXED_INCOME))    // Table Join 3
      .join(dataSetMap(CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN))       // Table Join 4
  }
}

class StructuralboardsContracts_RQ22022 extends StructuralboardsContracts_RQ22022_Trait
