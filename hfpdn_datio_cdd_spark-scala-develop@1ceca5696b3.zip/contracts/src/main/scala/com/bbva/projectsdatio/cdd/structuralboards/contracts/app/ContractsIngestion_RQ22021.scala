package com.bbva.projectsdatio.cdd.structuralboards.contracts.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GenericUtils, GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SparkCompactorController.{buildAndLaunchCompactor, setCompactorReportIntoProcessFinalReport}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets._
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.commons.lang.exception.ExceptionUtils
import org.apache.spark.sql.{DataFrame, Row}

import scala.util.{Failure, Success, Try}

/**
 * Main file for Contract Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsContracts_RQ22021_Trait extends StructuralboardsContracts_RQ42021_Trait {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDContractsBoard_RQ22021"
  override val boardTables: Seq[String] = CONTRACTS_BOARD_TABLES_RQ22021

  /**
   * Override trait run process method due to the necessity to set new Datasets from the
   * union of types of contracts with contractsUnion method (KSANUnionData and KSTMUnionData)
   * @param runtimeContext        RuntimeContext
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info(s"CDDStructuralboards: Init process $structuralBoard")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val config = runtimeContext.getConfig.getConfig(configId)
    Try {
      // Get global parameter
      val globalParameterReaded: GlobalConfigurationReaded =
        setterGlobalConfigurationReadedParamsReader(config)
      val globalParameterTranslated: GlobalConfigurationTranslated =
        setterGlobalConfigurationReadedParamsTranslator(globalParameterReaded)
      val cddDataSetsToJoin: Map[String, CDDStructuralBoardsDataset[_]] =
        dataSetsMapper(globalParameterReaded, globalParameterTranslated, config, datioSparkSession)
      val unionDataset = contractsUnion(cddDataSetsToJoin, config, globalParameterReaded)
      val cddDatasetsIncludeUnions = cddDataSetsToJoin
        . +(CONTRACTS_BOARD_UNION_KSAN -> unionDataset._1.asInstanceOf[KSANUnionData].globalParameterSetter())
        . +(CONTRACTS_BOARD_UNION_KSTM -> unionDataset._2.asInstanceOf[KSTMUnionData].globalParameterSetter())
      val tablon: DataFrame = joinTablon(cddDatasetsIncludeUnions, globalParameterReaded, globalParameterTranslated, datioSparkSession)
        .selectTablonColumns()
        .getDataFrame()
      logger.info(s"CDDStructuralboards: $structuralBoard structural board generated")
      writerCDDBoard(datioSparkSession, tablon, globalParameterReaded, globalParameterTranslated)
      /*
      setCompactorReportIntoProcessFinalReport(
        buildAndLaunchCompactor(
          setCompactorParams(datioSparkSession, globalParameterTranslated),
          datioSparkSession)
      )
       */
    } match {
      case Success(_) =>
        logger.info(s"CDDStructuralboards: Process $structuralBoard successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.info(s"CDDStructuralboards: Something went wrong during $structuralBoard process")
        logger.error(s"CDDStructuralboards: Input Args: ${config.toString}")
        logger.error(s"Exception: {}", ExceptionUtils.getStackTrace(ex))
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        CDDExecutionStats
          .addUnKnownExceptionMessage(new Exception(ex),
            "ContractsIngestion",
            "runProcess")
        logger.info(s"CDDStructuralboards: Finished process $structuralBoard")
        1
    }
  }
}

class StructuralboardsContracts_RQ22021 extends StructuralboardsContracts_RQ22021_Trait
