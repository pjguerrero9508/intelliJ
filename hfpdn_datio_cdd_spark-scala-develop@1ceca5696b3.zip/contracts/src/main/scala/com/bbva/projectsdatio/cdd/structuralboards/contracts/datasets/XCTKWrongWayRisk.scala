package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.BadPartitionColumnsNameException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{ReadUtils, SchemaReaderBoards}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.sql.functions.{col, count, when}
import org.apache.spark.sql.types.StructType

case class XCTKWrongWayRisk(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[XCTKWrongWayRisk] {

  val datasetParams : DatasetParams = XCTK_WRONG_WAY_RISK_CONSTANTS

  TechnicalValidation.configStringParamValidator(CONF_XCTK_WRONG_WAY_RISK_WWR_COLUMN_IF_DUPLICATE, config)
  lazy val wwrTypeColumnName: String = config.getString(CONF_XCTK_WRONG_WAY_RISK_WWR_COLUMN_IF_DUPLICATE)

  TechnicalValidation.configStringParamValidator(CONF_XCTK_WRONG_WAY_RISK_WWR_VALUE_IF_DUPLICATE, config)
  lazy val wwrTypeDefaultValueIfDup: String = config.getString(CONF_XCTK_WRONG_WAY_RISK_WWR_VALUE_IF_DUPLICATE)

  /**
   *
   * @param datioSparkSession : DatioSparkSession
   * @param outputSchema
   *  @return
   */
  override def apply (datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): XCTKWrongWayRisk = {
    val schema: StructType = createRelevantSchema(outputSchema)
    val df: DataFrame = {
      globalParameter.previousFilterAppliedFields match {
        case seq if seq.nonEmpty =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription}" +
            s" will be previously filtered using [${seq.mkString(", ")}] field")
          val valuesPartition: Seq[(String, String, String)] = buildValuesPartitionParam()
          ReadUtils.safeReader(globalParameter.pathData, SchemaReaderBoards.readSchema(globalParameter.schemaPath, includeDeleted = TRUE_VALUE),
            valuesPartition, fieldsNotInOutput, fieldsNotInInput)(datioSparkSession)(schema, outputSchema)(TRUE_VALUE)
        case _ =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription} won't be previously filtered")
          ReadUtils.readParquetWithSchema(datioSparkSession, globalParameter.pathData,outputSchema)
      }
    }
    wrap(df)
  }

  def calculateWwrFromJoinResult(): XCTKWrongWayRisk = {
    val pks: Seq[String] = this.getJoinFields
    val columnsPks: Seq[Column] = pks.map(col)
    val windowPks = Window.partitionBy(columnsPks:_*)
    val treatedDataFrame: DataFrame = this
      .getDataFrame()
      .withColumn("calculated_wwr_type", when(
        count(col(wwrTypeColumnName)).over(windowPks) > 1, wwrTypeDefaultValueIfDup)
        .otherwise(col(wwrTypeColumnName)))
      .drop(wwrTypeColumnName)
      .withColumnRenamed("calculated_wwr_type", wwrTypeColumnName)
      .dropDuplicates(pks)
    wrap(treatedDataFrame)
  }

  override def globalParameterSetter(): XCTKWrongWayRisk = {
    this.globalParameter = setterDatasetConfiguration(config)
    this.asInstanceOf[XCTKWrongWayRisk]
  }

  override def dataSetTransformations(outputSchema: DatioSchema): XCTKWrongWayRisk = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.globalParameterSetter().calculateWwrFromJoinResult()
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): XCTKWrongWayRisk = {
    copy(original = transformed)
  }
}
