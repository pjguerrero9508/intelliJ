package com.bbva.projectsdatio.cdd.structuralboards.contracts.utils

import java.net.URI

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.SchemaReadingException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.datio.dataproc.sdk.schema.{DatioSchema, DatioSchemaForTesting}
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import org.mockito.Mockito.spy

trait TestContractsSchemas {

  //PATHS
  lazy val schemaPath: String = "src/test/resources/schemas/contracts/t_ktae_contract_struc_board.json"

  //SCHEMAS
  lazy val outputSchema: StructType = DatioSchema.getBuilder.fromURI(URI.create(schemaPath)).build().getStructType
  lazy val testingDataSchema: StructType = StructType(List(
    StructField("String",    DataTypes.StringType, TRUE_VALUE),
    StructField("Int",       DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double",    DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date",      DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))
  lazy val testingDataDatioSchema: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema))

  lazy val ksanEomContract_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_contract_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomContract_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomContract_complete_input_testing_schema))

  lazy val ksanEomContract_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_contract_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                              DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                               DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomContract_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomContract_customized_testing_schema))

  lazy val kctkRiskScoringAtrb_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_risk_scoring_atrb_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkRiskScoringAtrb_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkRiskScoringAtrb_complete_input_testing_schema))
  lazy val kctkRiskScoringAtrb_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_risk_scoring_atrb_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkRiskScoringAtrb_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkRiskScoringAtrb_customized_testing_schema))

  lazy val kdeoInapprtContSitutn_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_not_relevant",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant_to_rename",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoInapprtContSitutn_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoInapprtContSitutn_complete_input_testing_schema))
  lazy val kdeoInapprtContSitutn_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoInapprtContSitutn_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoInapprtContSitutn_customized_testing_schema))

  lazy val kdeoWriteoffContract_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_writeoff_contract_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoWriteoffContract_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoWriteoffContract_complete_input_testing_schema))
  lazy val kdeoWriteoffContract_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_writeoff_contract_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoWriteoffContract_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoWriteoffContract_customized_testing_schema))

  lazy val krdcIssuancesFixedIncome_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_security_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_krdc_issuances_fixed_income_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_not_relevant",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_relevant_to_rename", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                      DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val krdcIssuancesFixedIncome_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(krdcIssuancesFixedIncome_complete_input_testing_schema))
  lazy val krdcIssuancesFixedIncome_customized_testing_schema: StructType = StructType(List(
    StructField("g_security_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_krdc_issuances_fixed_income_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val krdcIssuancesFixedIncome_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(krdcIssuancesFixedIncome_customized_testing_schema))

  lazy val ksanEomAssetsLiabilities_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_assets_liabilities_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_not_relevant",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_to_rename",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomAssetsLiabilities_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomAssetsLiabilities_complete_input_testing_schema))
  lazy val ksanEomAssetsLiabilities_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_assets_liabilities_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomAssetsLiabilities_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomAssetsLiabilities_customized_testing_schema))

  lazy val ksanEomContSegmentation_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_cont_segmentation_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomContSegmentation_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomContSegmentation_complete_input_testing_schema))
  lazy val ksanEomContSegmentation_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_cont_segmentation_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomContSegmentation_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomContSegmentation_customized_testing_schema))

  lazy val ksanEomDomesticInterveners_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_customer_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_main_holder_customer_type",                           DataTypes.StringType, TRUE_VALUE),
    StructField("g_party_type",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_domestic_interveners_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_not_relevant",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_relevant_to_rename",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomDomesticInterveners_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomDomesticInterveners_complete_input_testing_schema))
  lazy val ksanEomDomesticInterveners_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_cont_main_holder_cust_id",                            DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_party_type",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_domestic_interveners_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_relevant_renamed",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_relevant_initialized",DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomDomesticInterveners_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomDomesticInterveners_customized_testing_schema))

  lazy val ksanEomInstallmentPlan_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_installment_maturity_date",                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_instlmt_interest_bc_amount",                     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_instlmt_total_bc_amount",                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_instlmt_principal_bc_amount",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomInstallmentPlan_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomInstallmentPlan_complete_input_testing_schema))
  lazy val ksanEomInstallmentPlan_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_installment_maturity_date",                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_instlmt_interest_bc_amount",                     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_instlmt_total_bc_amount",                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_instlmt_principal_bc_amount",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_lst_instlmt_int_bc_amount",                      DataTypes.StringType, TRUE_VALUE),
    StructField("gf_nxt_instlmt_int_bc_amount",                      DataTypes.StringType, TRUE_VALUE),
    StructField("gf_pv_instlmt_int_bc_amount",                       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_lst_instlmt_tot_bc_amount",                      DataTypes.StringType, TRUE_VALUE),
    StructField("gf_nxt_instlmt_tot_bc_amount",                      DataTypes.StringType, TRUE_VALUE),
    StructField("gf_pv_instlmt_tot_bc_amount",                       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_lst_instlmt_amort_bc_amount",                    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_nxt_instlmt_amort_bc_amount",                    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_pv_instlmt_amort_bc_amount",                     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomInstallmentPlan_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomInstallmentPlan_customized_testing_schema))

  lazy val ksanEomInternalDepo_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_internal_depo_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomInternalDepo_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomInternalDepo_complete_input_testing_schema))
  lazy val ksanEomInternalDepo_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_internal_depo_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomInternalDepo_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomInternalDepo_customized_testing_schema))

  lazy val ksanEomOutBalanceItems_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_out_of_bal_items_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomOutBalanceItems_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomOutBalanceItems_complete_input_testing_schema))
  lazy val ksanEomOutBalanceItems_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_out_of_bal_items_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomOutBalanceItems_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomOutBalanceItems_customized_testing_schema))

  lazy val ksanEomRenumerations_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_cust_view_lcl_contract_id",                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_new_contract_id_init_date",                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_renumerations_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_not_relevant",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_relevant_to_rename", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                 DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomRenumerations_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomRenumerations_complete_input_testing_schema))
  lazy val ksanEomRenumerations_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_cust_view_lcl_contract_id",                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_new_contract_id_init_date",                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksan_eom_renumerations_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksanEomRenumerations_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksanEomRenumerations_customized_testing_schema))

  lazy val kstmAssetsLiabilities_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_assets_liabilities_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmAssetsLiabilities_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmAssetsLiabilities_complete_input_testing_schema))
  lazy val kstmAssetsLiabilities_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_assets_liabilities_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmAssetsLiabilities_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmAssetsLiabilities_customized_testing_schema))

  lazy val kstmInternalDepo_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_internal_depo_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmInternalDepo_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmInternalDepo_complete_input_testing_schema))
  lazy val kstmInternalDepo_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_internal_depo_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmInternalDepo_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmInternalDepo_customized_testing_schema))

  lazy val kstmOffBalanceItems_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_off_balance_items_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmOffBalanceItems_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmOffBalanceItems_complete_input_testing_schema))
  lazy val kstmOffBalanceItems_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_off_balance_items_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmOffBalanceItems_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmOffBalanceItems_customized_testing_schema))

  lazy val nztgTradeCoreInfBoEom_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_back_sys_trd_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_origin_application_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_security_id",                                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_front_sys_trd_id",                                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_management_portfolio_id",                           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val nztgTradeCoreInfBoEom_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(nztgTradeCoreInfBoEom_complete_input_testing_schema))
  lazy val nztgTradeCoreInfBoEom_customized_testing_schema: StructType = StructType(List(
    StructField("gf_back_sys_trd_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_origin_application_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_security_id",                                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_front_sys_trd_id",                                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_management_portfolio_id",                           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val nztgTradeCoreInfBoEom_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(nztgTradeCoreInfBoEom_customized_testing_schema))

  lazy val xctkWrongWayRisk_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_front_sys_trd_id",                            DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_origin_application_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_trd_wwr_ind_type",                            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                  DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val xctkWrongWayRisk_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(xctkWrongWayRisk_complete_input_testing_schema))
  lazy val xctkWrongWayRisk_customized_testing_schema: StructType = StructType(List(
    StructField("gf_front_sys_trd_id",                            DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_origin_application_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_trd_wwr_ind_type",                            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                  DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val xctkWrongWayRisk_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(xctkWrongWayRisk_customized_testing_schema))

  lazy val kctkOpportunityRiskMgmt_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_not_relevant",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant_to_rename",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                      DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkOpportunityRiskMgmt_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkOpportunityRiskMgmt_complete_input_testing_schema))
  lazy val kctkOpportunityRiskMgmt_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkOpportunityRiskMgmt_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkOpportunityRiskMgmt_customized_testing_schema))

  lazy val kdeoCovidMeasure_complete_input_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_covid_measure_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_not_relevant",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_relevant_to_rename",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoCovidMeasure_complete_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoCovidMeasure_complete_input_testing_schema))
  lazy val kdeoCovidMeasure_customized_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_covid_measure_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoCovidMeasure_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoCovidMeasure_customized_testing_schema))

  lazy val ksan_contracts_union_schema: StructType = StructType(List(
    StructField("g_t_ksan_eom_internal_depo_relevant",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_renamed",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_local_contract_number_id",                          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_initialized",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksan_contracts_union_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksan_contracts_union_schema))

  lazy val kstm_contracts_union_schema: StructType = StructType(List(
    StructField("g_t_kstm_s_internal_depo_relevant",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_initialized",DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_initialized",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_local_contract_number_id",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_renamed",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_renamed",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstm_contracts_union_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstm_contracts_union_schema))

  lazy val ktae_contracts_mercados_after_join_pks_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id", DataTypes.StringType, TRUE_VALUE),
    StructField("g_security_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_management_portfolio_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_origin_application_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_front_sys_trd_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_back_sys_trd_id", DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ktae_contracts_mercados_after_join_pks_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_contracts_mercados_after_join_pks_schema))

  lazy val ktae_contracts_domesticos_after_join_pks_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id", DataTypes.StringType, TRUE_VALUE),
    StructField("g_cont_main_holder_cust_id", DataTypes.StringType, TRUE_VALUE),
    StructField("g_party_type", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cust_view_lcl_contract_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_installment_maturity_date", DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ktae_contracts_domesticos_after_join_pks_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_contracts_domesticos_after_join_pks_schema))

  lazy val ktae_contracts_after_join_pks_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id"      ,              DataTypes.StringType, TRUE_VALUE),
    StructField("g_cont_main_holder_cust_id"       ,              DataTypes.StringType, TRUE_VALUE),
    StructField("g_party_type"                     ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cust_view_lcl_contract_id"     ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_installment_maturity_date"     ,              DataTypes.StringType, TRUE_VALUE),
    StructField("g_security_id"                    ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_management_portfolio_id"       ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_origin_application_id"         ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_front_sys_trd_id"              ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_back_sys_trd_id"               ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date"                   ,              DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id"                     ,              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date"                    ,              DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ktae_contracts_after_join_pks_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_contracts_after_join_pks_schema))

  lazy val ktae_contracts_after_join_testing_schema: StructType = StructType(List(
    StructField("gf_local_contract_number_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("g_security_id",                                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_cont_main_holder_cust_id",                                DataTypes.StringType, TRUE_VALUE),
    StructField("g_party_type",                                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_installment_maturity_date",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cust_view_lcl_contract_id",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_new_contract_id_init_date",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_back_sys_trd_id",                                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_origin_application_id",                                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_front_sys_trd_id",                                       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_management_portfolio_id",                                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_relevant",                            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_relevant_renamed",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_contract_relevant_initialized",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_relevant",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_relevant_renamed",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_risk_scoring_atrb_relevant_initialized",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant_renamed",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cont_situtn_relevant_initialized",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_relevant",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_relevant_renamed",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_writeoff_contract_relevant_initialized",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_relevant",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_relevant_renamed",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krdc_issuances_fixed_income_relevant_initialized",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_renamed",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_assets_liabilities_relevant_initialized",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_cont_segmentation_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_opportunity_risk_mgmt_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_relevant",                           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_relevant_renamed",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_covid_measure_relevant_initialized",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_relevant",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_relevant_renamed",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_domestic_interveners_relevant_initialized",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_lst_instlmt_tot_bc_amount",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_lst_instlmt_amort_bc_amount",                            DataTypes.StringType, TRUE_VALUE),
    StructField("gf_lst_instlmt_int_bc_amount",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_nxt_instlmt_tot_bc_amount",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_nxt_instlmt_amort_bc_amount",                            DataTypes.StringType, TRUE_VALUE),
    StructField("gf_nxt_instlmt_int_bc_amount",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_pv_instlmt_tot_bc_amount",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_pv_instlmt_amort_bc_amount",                             DataTypes.StringType, TRUE_VALUE),
    StructField("gf_pv_instlmt_int_bc_amount",                               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant_renamed",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_instlmnt_plan_relevant_initialized",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_renamed",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_internal_depo_relevant_initialized",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_renamed",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_out_of_bal_items_relevant_initialized",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_relevant",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_relevant_renamed",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksan_eom_renumerations_relevant_initialized",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_renamed",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liabilities_relevant_initialized",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant",                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_renamed",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_internal_depo_relevant_initialized",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_renamed",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_relevant_initialized",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant",                          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant_renamed",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_xctk_wrong_way_risk_relevant_initialized",              DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ktae_contracts_after_join_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_contracts_after_join_testing_schema))

  lazy val outputjoinMarketsPks: Array[String] = Array("gf_local_contract_number_id",
    "g_security_id",
    "gf_management_portfolio_id",
    "gf_origin_application_id",
    "gf_front_sys_trd_id",
    "gf_back_sys_trd_id")
  lazy val outputjoinMarketsNotPks: Array[String] = Array(
    "g_t_nztg_trade_core_inf_bo_eom_relevant",
    "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
    "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
    "g_t_xctk_wrong_way_risk_relevant",
    "g_t_xctk_wrong_way_risk_relevant_renamed",
    "g_t_xctk_wrong_way_risk_relevant_initialized",
    "g_t_krdc_issuances_fixed_income_relevant",
    "g_t_krdc_issuances_fixed_income_relevant_renamed",
    "g_t_krdc_issuances_fixed_income_relevant_initialized",
    "g_t_kdeo_inapprt_cont_situtn_relevant",
    "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
    "g_t_kdeo_inapprt_cont_situtn_relevant_initialized")

  lazy val outputJoinDomesticosPks: Array[String] = Array(
    "gf_local_contract_number_id",
    "g_cont_main_holder_cust_id",
    "g_party_type",
    "gf_cust_view_lcl_contract_id",
    "gf_installment_maturity_date")
  lazy val outputJoinDomesticosNotPks: Array[String] = Array(
    "g_t_ksan_eom_contract_relevant",
    "g_t_ksan_eom_contract_relevant_renamed",
    "g_t_ksan_eom_contract_relevant_initialized",
    "g_t_ksan_eom_domestic_interveners_relevant",
    "g_t_ksan_eom_domestic_interveners_relevant_renamed",
    "g_t_ksan_eom_domestic_interveners_relevant_initialized",
    "gf_new_contract_id_init_date",
    "g_t_ksan_eom_renumerations_relevant",
    "g_t_ksan_eom_renumerations_relevant_renamed",
    "g_t_ksan_eom_renumerations_relevant_initialized",
    "g_t_ksan_eom_cont_segmentation_relevant",
    "g_t_ksan_eom_cont_segmentation_relevant_renamed",
    "g_t_ksan_eom_cont_segmentation_relevant_initialized",
    "g_t_kctk_risk_scoring_atrb_relevant",
    "g_t_kctk_risk_scoring_atrb_relevant_renamed",
    "g_t_kctk_risk_scoring_atrb_relevant_initialized",
    "gf_instlmt_interest_bc_amount",
    "gf_instlmt_total_bc_amount",
    "gf_instlmt_principal_bc_amount",
    "g_t_ksan_eom_instlmnt_plan_relevant",
    "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
    "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
    "gf_lst_instlmt_int_bc_amount",
    "gf_nxt_instlmt_int_bc_amount",
    "gf_pv_instlmt_int_bc_amount",
    "gf_lst_instlmt_tot_bc_amount",
    "gf_nxt_instlmt_tot_bc_amount",
    "gf_pv_instlmt_tot_bc_amount",
    "gf_lst_instlmt_amort_bc_amount",
    "gf_nxt_instlmt_amort_bc_amount",
    "gf_pv_instlmt_amort_bc_amount",
    "g_t_kdeo_inapprt_cont_situtn_relevant",
    "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
    "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
    "g_t_ksan_eom_internal_depo_relevant",
    "g_t_ksan_eom_internal_depo_relevant_renamed",
    "g_t_ksan_eom_assets_liabilities_relevant_initialized",
    "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
    "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
    "g_t_ksan_eom_out_of_bal_items_relevant",
    "g_t_ksan_eom_internal_depo_relevant_initialized",
    "g_t_ksan_eom_assets_liabilities_relevant_renamed",
    "g_t_ksan_eom_assets_liabilities_relevant",
    "g_t_kstm_s_internal_depo_relevant",
    "g_t_kstm_s_assets_liabilities_relevant_initialized",
    "g_t_kstm_s_off_balance_items_relevant",
    "g_t_kstm_s_off_balance_items_relevant_renamed",
    "g_t_kstm_s_internal_depo_relevant_initialized",
    "g_t_kstm_s_off_balance_items_relevant_initialized",
    "g_t_kstm_s_internal_depo_relevant_renamed",
    "g_t_kstm_s_assets_liabilities_relevant_renamed",
    "g_t_kstm_s_assets_liabilities_relevant",
    "g_t_kdeo_writeoff_contract_relevant",
    "g_t_kdeo_writeoff_contract_relevant_renamed",
    "g_t_kdeo_writeoff_contract_relevant_initialized")
  lazy val outputJoinBoardPks: Array[String] = Array("gf_local_contract_number_id",
    "g_cont_main_holder_cust_id",
    "g_party_type",
    "gf_cust_view_lcl_contract_id",
    "gf_installment_maturity_date",
    "g_security_id",
    "gf_management_portfolio_id",
    "gf_origin_application_id",
    "gf_front_sys_trd_id",
    "gf_back_sys_trd_id")
  lazy val outputJoinBoardsColumns: Array[String] = Array("g_t_kstm_s_internal_depo_relevant",
    "g_t_kstm_s_assets_liabilities_relevant_initialized",
    "g_t_kdeo_writeoff_contract_relevant_initialized",
    "g_t_ksan_eom_internal_depo_relevant",
    "g_t_ksan_eom_instlmnt_plan_relevant",
    "gf_lst_instlmt_amort_bc_amount",
    "g_t_kstm_s_off_balance_items_relevant",
    "g_t_kstm_s_off_balance_items_relevant_renamed",
    "gf_nxt_instlmt_tot_bc_amount",
    "gf_nxt_instlmt_amort_bc_amount",
    "gf_pv_instlmt_tot_bc_amount",
    "g_t_ksan_eom_internal_depo_relevant_renamed",
    "gf_pv_instlmt_int_bc_amount",
    "g_t_kdeo_inapprt_cont_situtn_relevant",
    "gf_back_sys_trd_id",
    "g_t_ksan_eom_cont_segmentation_relevant",
    "g_t_ksan_eom_domestic_interveners_relevant",
    "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
    "g_t_kdeo_writeoff_contract_relevant_renamed",
    "gf_origin_application_id",
    "g_t_kstm_s_internal_depo_relevant_initialized",
    "g_party_type",
    "g_t_ksan_eom_assets_liabilities_relevant_initialized",
    "g_t_kstm_s_off_balance_items_relevant_initialized",
    "g_security_id",
    "g_t_xctk_wrong_way_risk_relevant_initialized",
    "g_cont_main_holder_cust_id",
    "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
    "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
    "g_t_kctk_risk_scoring_atrb_relevant_renamed",
    "g_t_ksan_eom_renumerations_relevant_renamed",
    "g_t_krdc_issuances_fixed_income_relevant",
    "g_t_krdc_issuances_fixed_income_relevant_renamed",
    "g_t_ksan_eom_out_of_bal_items_relevant",
    "g_t_ksan_eom_contract_relevant",
    "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
    "gf_lst_instlmt_tot_bc_amount",
    "gf_front_sys_trd_id",
    "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
    "gf_local_contract_number_id",
    "g_t_ksan_eom_internal_depo_relevant_initialized",
    "g_t_ksan_eom_cont_segmentation_relevant_renamed",
    "gf_instlmt_total_bc_amount",
    "gf_lst_instlmt_int_bc_amount",
    "g_t_ksan_eom_assets_liabilities_relevant_renamed",
    "g_t_ksan_eom_renumerations_relevant_initialized",
    "g_t_kdeo_writeoff_contract_relevant",
    "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
    "g_t_xctk_wrong_way_risk_relevant_renamed",
    "g_t_ksan_eom_contract_relevant_renamed",
    "g_t_kstm_s_internal_depo_relevant_renamed",
    "g_t_kctk_risk_scoring_atrb_relevant_initialized",
    "gf_instlmt_principal_bc_amount",
    "gf_management_portfolio_id",
    "g_t_kstm_s_assets_liabilities_relevant_renamed",
    "g_t_kstm_s_assets_liabilities_relevant",
    "gf_instlmt_interest_bc_amount",
    "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
    "g_t_kctk_risk_scoring_atrb_relevant",
    "g_t_nztg_trade_core_inf_bo_eom_relevant",
    "g_t_ksan_eom_domestic_interveners_relevant_initialized",
    "gf_pv_instlmt_amort_bc_amount",
    "gf_cust_view_lcl_contract_id",
    "g_t_ksan_eom_cont_segmentation_relevant_initialized",
    "gf_nxt_instlmt_int_bc_amount",
    "gf_installment_maturity_date",
    "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
    "g_t_ksan_eom_assets_liabilities_relevant",
    "g_t_ksan_eom_domestic_interveners_relevant_renamed",
    "g_t_ksan_eom_renumerations_relevant",
    "g_t_ksan_eom_contract_relevant_initialized",
    "gf_new_contract_id_init_date",
    "g_t_xctk_wrong_way_risk_relevant",
    "g_t_krdc_issuances_fixed_income_relevant_initialized")
}
