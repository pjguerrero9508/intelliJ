package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.apache.spark.sql.AnalysisException
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import com.typesafe.config.ConfigException

@RunWith(classOf[JUnitRunner])
class KSANEomContractTest extends TestContracts{

  test("ksanEomContract_wrap") {
    val instancia: KSANEomContract = KSANEomContract(testResources.ksanEomContract_complete_input_testing, testResources.config)
    val result: KSANEomContract = instancia.wrap(testResources.ksanEomContract_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe true
  }

  test("ksanEomContract_selectTablonColumnsBadSelect") {
    assertThrows[AnalysisException] {
      KSANEomContract(testResources.ksanEomContract_complete_input_testing, testResources.configBadSelect).selectTablonColumns().getDataFrame()
    }
  }

  test("ksanEomContract_selectTablonColumnsMissSelect") {
    assertThrows[ConfigException.Missing] {
      KSANEomContract(testResources.ksanEomContract_complete_input_testing, testResources.configMissSelect).selectTablonColumns().getDataFrame()
    }
  }
}
