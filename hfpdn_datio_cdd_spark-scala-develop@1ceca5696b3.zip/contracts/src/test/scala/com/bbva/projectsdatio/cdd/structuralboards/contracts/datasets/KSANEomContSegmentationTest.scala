package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSANEomContSegmentationTest extends TestContracts{
  test("ksanEomContSegmentation_wrap") {
    val instancia: KSANEomContSegmentation = KSANEomContSegmentation(testResources.ksanEomContSegmentation_complete_input_testing, testResources.config)
    val result: KSANEomContSegmentation = instancia.wrap(testResources.ksanEomContSegmentation_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
