package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestUtils
import org.apache.spark.sql.types.{DataTypes, StructType}
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSANEomDomesticIntervenersTest extends TestContracts {

  test("ksanEomDomesticInterveners_wrap") {
    val instancia: KSANEomDomesticInterveners = KSANEomDomesticInterveners(testResources.ksanEomDomesticInterveners_complete_input_testing,
      testResources.config)
    val result: KSANEomDomesticInterveners = instancia.wrap(testResources.ksanEomDomesticInterveners_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("ksanEomDomesticInterveners_filterCustomerType") {
    val result: DataFrame = KSANEomDomesticInterveners(testResources.ksanEomDomesticInterveners_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ksanEomDomesticInterveners_customized_testing, FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("ksanEomDomesticInterveners_filterCustomerTypeBadFields") {
    assertThrows[AnalysisException] {
      KSANEomDomesticInterveners(testResources.ksanEomDomesticInterveners_complete_input_testing, testResources.configBadFields)
        .globalParameterSetter().dataSetTransformations(testResources.ksanEomDomesticInterveners_complete_input_testing_datio_schema).getDataFrame()
    }
  }

  test("ksanEomDomesticInterveners_filterCustomerTypeMissFields") {
    assertThrows[ParamNotInformedException] {
      KSANEomDomesticInterveners(testResources.ksanEomDomesticInterveners_complete_input_testing, testResources.configMissFields)
        .dataSetTransformations(testResources.ksanEomDomesticInterveners_complete_input_testing_datio_schema).getDataFrame()
    }
  }

  test("ksanEomDomesticInterveners_generateEmptyDataSet") {
    val result: DataFrame = KSANEomDomesticInterveners(testResources.testingEmptyDataFrame, testResources.config)
      .globalParameterSetter().applyEmpty(datioSparkSession, testResources.ktae_contracts_after_join_testing_datio_schema).getDataFrame()
    val expectedSize = 0
    var expectedSchema: StructType = new StructType()
    expectedSchema = expectedSchema.add("g_cont_main_holder_cust_id", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_party_type", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_ksan_eom_domestic_interveners_relevant", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_ksan_eom_domestic_interveners_relevant_initialized", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_ksan_eom_domestic_interveners_relevant_renamed", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_local_contract_number_id", DataTypes.StringType, TRUE_VALUE)
    val resultSchema : StructType = StructType.apply(result.schema.sortBy(_.name))
    assert(expectedSchema.simpleString.equals(resultSchema.simpleString))
    assert(result.count().equals(expectedSize.toLong))
  }
}
