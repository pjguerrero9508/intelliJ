package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestUtils
import org.apache.spark.sql.types.{DataTypes, StructType}
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSANEomInstallmentPlanTest extends TestContracts{

  test("ksanEomInstallmentPlan_wrap") {
    val instancia: KSANEomInstallmentPlan = KSANEomInstallmentPlan(testResources.ksanEomInstallmentPlan_complete_input_testing, testResources.config)
    val result: KSANEomInstallmentPlan = instancia.wrap(testResources.ksanEomInstallmentPlan_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("ksanEomInstallmentPlan_calculateQuotas") {
    val result: DataFrame = KSANEomInstallmentPlan(testResources.ksanEomInstallmentPlan_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema)("2021-05-20").getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ksanEomInstallmentPlan_customized_testing, FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("ksanEomInstallmentPlan_calculateQuotasBadFields") {
    assertThrows[AnalysisException] {
      KSANEomInstallmentPlan(testResources.ksanEomInstallmentPlan_complete_input_testing, testResources.configBadFields)
        .calculateQuotas("2021-05-20").getDataFrame()
    }
  }

  test("ksanEomInstallmentPlan_calculateQuotasMissFields") {
    assertThrows[ParamNotInformedException] {
      KSANEomInstallmentPlan(testResources.ksanEomInstallmentPlan_complete_input_testing, testResources.configMissFields)
        .calculateQuotas("2021-05-20").getDataFrame()
    }
  }

  test("ksanEomInstallmentPlan_generateEmptyDataSet") {
    val result: DataFrame = KSANEomInstallmentPlan(testResources.testingEmptyDataFrame, testResources.config)
      .globalParameterSetter()
      .getCustomizedDataSet(datioSparkSession, testResources.ktae_contracts_after_join_testing_datio_schema)(TRUE_VALUE)("2021-05-20")
      .getDataFrame()
    val expectedSize = 0
    var expectedSchema: StructType = new StructType()
    expectedSchema = expectedSchema.add("g_t_ksan_eom_instlmnt_plan_relevant", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_ksan_eom_instlmnt_plan_relevant_initialized", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_ksan_eom_instlmnt_plan_relevant_renamed", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_installment_maturity_date", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_instlmt_interest_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_instlmt_principal_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_instlmt_total_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_local_contract_number_id", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_lst_instlmt_amort_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_lst_instlmt_int_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_lst_instlmt_tot_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_nxt_instlmt_amort_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_nxt_instlmt_int_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_nxt_instlmt_tot_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_pv_instlmt_amort_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_pv_instlmt_int_bc_amount", DataTypes.StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_pv_instlmt_tot_bc_amount", DataTypes.StringType, TRUE_VALUE)
    val resultSchema : StructType = StructType.apply(result.schema.sortBy(_.name))
    assert(expectedSchema.simpleString.equals(resultSchema.simpleString))
    assert(result.count().equals(expectedSize.toLong))
  }
}
