package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSTMInternalDepoTest extends TestContracts{
  test("kstmInternalDepo_wrap") {
    val instancia: KSTMInternalDepo = KSTMInternalDepo(testResources.kstmInternalDepo_complete_input_testing, testResources.config)
    val result: KSTMInternalDepo = instancia.wrap(testResources.kstmInternalDepo_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
