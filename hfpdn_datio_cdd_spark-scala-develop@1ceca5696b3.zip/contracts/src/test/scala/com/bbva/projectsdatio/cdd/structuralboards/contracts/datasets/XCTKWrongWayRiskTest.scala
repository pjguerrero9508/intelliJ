package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class XCTKWrongWayRiskTest extends TestContracts {
  test("xctkWrongWayRisk_wrap") {
    val instancia: XCTKWrongWayRisk = XCTKWrongWayRisk(testResources.xctkWrongWayRisk_complete_input_testing, testResources.config)
    val result: XCTKWrongWayRisk = instancia.wrap(testResources.xctkWrongWayRisk_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("xctkWrongWayRisk_filterCustomerGroupType") {
    val result: DataFrame = XCTKWrongWayRisk(testResources.xctkWrongWayRisk_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.xctkWrongWayRisk_customized_testing.select(result.columns.map(col):_*), false) shouldBe TRUE_VALUE
  }

  test("xctkWrongWayRisk_apply_with_both_partitions") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.xctkPath)
    val pathToWrite = testResources.xctkPath + "g_entific_id=GL/" + "gf_cutoff_date=2020-07-31"
    val dataset: DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(testResources.xctkWrongWayRisk_complete_input_testing_rows_rdd, testResources.xctkWrongWayRisk_complete_input_testing_schema)
      .drop("gf_cutoff_date")
      .drop("g_entific_id")
    WriteUtils.simpleWriteToParquet(datioSparkSession,dataset,pathToWrite)
    val result: DataFrame = XCTKWrongWayRisk(testResources.testingEmptyCDDContractDataFrame, testResources.config)
      .globalParameterSetter()
      .apply(datioSparkSession, testResources.xctkWrongWayRisk_complete_testing_datio_schema).getDataFrame()
      .drop("gf_cutoff_date")
      .drop("g_entific_id")
      .drop("gf_audit_date")
    TestUtils.assertDataFrameEquals(result, testResources.xctkWrongWayRisk_complete_input_testing
      .drop("g_t_xctk_wrong_way_risk_not_relevant")
      .drop("g_t_xctk_wrong_way_risk_relevant_to_rename"), false) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, testResources.xctkPath)
  }

  test("xctkWrongWayRisk_apply_with_one_partition") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.xctkPath)
    val pathToWrite = testResources.xctkPath + "gf_cutoff_date=2020-07-31"
    val dataset: DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(testResources.xctkWrongWayRisk_complete_input_testing_rows_rdd, testResources.xctkWrongWayRisk_complete_input_testing_schema)
      .drop("gf_cutoff_date")
    WriteUtils.simpleWriteToParquet(datioSparkSession,dataset,pathToWrite)
    val result: DataFrame = XCTKWrongWayRisk(testResources.testingEmptyCDDContractDataFrame, testResources.configOnePartition)
      .globalParameterSetter()
      .apply(datioSparkSession, testResources.xctkWrongWayRisk_complete_testing_datio_schema).getDataFrame()
      .drop("gf_cutoff_date")
      .drop("g_entific_id")
      .drop("gf_audit_date")
    TestUtils.assertDataFrameEquals(result, testResources.xctkWrongWayRisk_complete_input_testing
      .drop("g_t_xctk_wrong_way_risk_not_relevant")
      .drop("g_t_xctk_wrong_way_risk_relevant_to_rename"), false) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, testResources.xctkPath)
  }

}
