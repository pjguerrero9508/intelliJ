package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.CDDStructuralBoardsDataset
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.bbva.projectsdatio.cdd.structuralboards.contracts.app.StructuralboardsContracts_RQ42021
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.schema.exception.DataprocSchemaException
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ContractsIngestionTest extends TestContracts {

  test("contractsIngestion_joinDomestic") {
    val ksanEomContract = KSANEomContract(testResources.ksanEomContract_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomAssetsLiabilities = KSANEomAssetsLiabilities(testResources.ksanEomAssetsLiabilities_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomInternalDepo = KSANEomInternalDepo(testResources.ksanEomInternalDepo_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmAssetsLiabilities = KSTMAssetsLiabilities(testResources.kstmAssetsLiabilities_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmOffBalanceItems = KSTMOffBalanceItems(testResources.kstmOffBalanceItems_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kctkRiskScoringAtrb = KCTKRiskScoringAtrb(testResources.kctkRiskScoringAtrb_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoInapprtContSitutn = KDEOInapprtContSitutn(testResources.kdeoInapprtContSitutn_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomContSegmentation = KSANEomContSegmentation(testResources.ksanEomContSegmentation_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomRenumeration = KSANEomRenumerations(testResources.ksanEomRenumerations_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomInstallmentPlan = KSANEomInstallmentPlan(testResources.ksanEomInstallmentPlan_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema)("2021-05-19").globalParameterSetter()
    val ksanEomDomesticInterveners = KSANEomDomesticInterveners(testResources.ksanEomDomesticInterveners_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmInternalDepo = KSTMInternalDepo(testResources.kstmInternalDepo_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomOutBalanceItems = KSANEomOutBalanceItems(testResources.ksanEomOutBalanceItems_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoWriteoffContract = KDEOWriteoffContract(testResources.kdeoWriteoffContract_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoCovidMeasure = KDEOCovidMeasure(testResources.kdeoCovidMeasure_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kctkOpportunityRiskMgmt = KCTKOpportunityRiskMgmt(testResources.kctkOpportunityRiskMgmt_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val datasetMap: Map[String, CDDStructuralBoardsDataset[_]] = Map(
      CONTRACTS_BOARD_TABLE_EOM_CONTRACT -> ksanEomContract,
      CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES -> ksanEomAssetsLiabilities,
      CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO -> ksanEomInternalDepo,
      CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES -> kstmAssetsLiabilities,
      CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS -> kstmOffBalanceItems,
      CONTRACTS_BOARD_TABLE_RISK_SCORING_ATRB -> kctkRiskScoringAtrb,
      CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN -> kdeoInapprtContSitutn,
      CONTRACTS_BOARD_TABLE_EOM_CONT_SEGMENTATION -> ksanEomContSegmentation,
      CONTRACTS_BOARD_TABLE_EOM_RENUMERATIONS -> ksanEomRenumeration,
      CONTRACTS_BOARD_TABLE_EOM_INSTALLMENT_PLAN -> ksanEomInstallmentPlan,
      CONTRACTS_BOARD_TABLE_EOM_DOMESTIC_INTERVENERS -> ksanEomDomesticInterveners,
      CONTRACTS_BOARD_TABLE_INTERNAL_DEPO -> kstmInternalDepo,
      CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS -> ksanEomOutBalanceItems,
      CONTRACTS_BOARD_TABLE_WRITEOFF_CONTRACT -> kdeoWriteoffContract,
      CONTRACTS_BOARD_TABLE_OPPORTUNITY_RISK_MGMT -> kctkOpportunityRiskMgmt,
      CONTRACTS_BOARD_TABLE_COVID_MEASURE -> kdeoCovidMeasure
    )
    val unionDataset = (new StructuralboardsContracts_RQ42021).contractsUnion(datasetMap, testResources.config, testResources.globalReaded)
    val datasetMapComplete: Map[String, CDDStructuralBoardsDataset[_]] = datasetMap
      . +(CONTRACTS_BOARD_UNION_KSAN -> unionDataset._1)
      . +(CONTRACTS_BOARD_UNION_KSTM -> unionDataset._2)
    val result: DataFrame = (new StructuralboardsContracts_RQ42021)
      .joinDomestic(datasetMapComplete, datioSparkSession)(testResources.checkpointPath).getDataFrame()
    TechnicalValidation.listStringValidator(testResources.outputJoinDomesticosNotPks, result.columns, "contractsIngestion_joinDomesticos")
    TestUtils.assertDataFrameEquals(result
      .select(testResources.outputJoinDomesticosPks.map(col):_*), testResources.ktae_contracts_domesticos_after_join, FALSE_VALUE) shouldBe TRUE_VALUE
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("contractsIngestion_joinMarkets") {
    val xctkWrongWayRisk = XCTKWrongWayRisk(testResources.xctkWrongWayRisk_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val nztgTradeCoreInfBoEom = NZTGTradeCoreInfBoEom(testResources.nztgTradeCoreInfBoEom_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoInapprtContSitutn = KDEOInapprtContSitutn(testResources.kdeoInapprtContSitutn_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val krdcIssuancesFixedIncome = KRDCIssuancesFixedIncome(testResources.krdcIssuancesFixedIncome_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()

    val datasetMap: Map[String, CDDStructuralBoardsDataset[_]] = Map(
      CONTRACTS_BOARD_TABLE_WRONG_WAY_RISK -> xctkWrongWayRisk,
      CONTRACTS_BOARD_TABLE_TRADE_CORE_INF_BO_EOM -> nztgTradeCoreInfBoEom,
      CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN -> kdeoInapprtContSitutn,
      CONTRACTS_BOARD_TABLE_ISSUANCES_FIXED_INCOME -> krdcIssuancesFixedIncome
    )
    val result: DataFrame = (new StructuralboardsContracts_RQ42021)
      .joinMarkets(datasetMap, datioSparkSession)(testResources.checkpointPath)
      .getDataFrame()
    TechnicalValidation.listStringValidator(testResources.outputjoinMarketsNotPks, result.columns, "contractsIngestion_joinMarkets")
    TestUtils.assertDataFrameEquals(result
      .select(testResources.outputjoinMarketsPks.map(col):_*), testResources.ktae_contracts_mercados_after_join, FALSE_VALUE) shouldBe TRUE_VALUE
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("contractsIngestion_joinTablon_outputFinal") {
    val ksanEomContract = KSANEomContract(testResources.ksanEomContract_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomAssetsLiabilities = KSANEomAssetsLiabilities(testResources.ksanEomAssetsLiabilities_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomInternalDepo = KSANEomInternalDepo(testResources.ksanEomInternalDepo_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmAssetsLiabilities = KSTMAssetsLiabilities(testResources.kstmAssetsLiabilities_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmOffBalanceItems = KSTMOffBalanceItems(testResources.kstmOffBalanceItems_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kctkRiskScoringAtrb = KCTKRiskScoringAtrb(testResources.kctkRiskScoringAtrb_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoInapprtContSitutn = KDEOInapprtContSitutn(testResources.kdeoInapprtContSitutn_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomContSegmentation = KSANEomContSegmentation(testResources.ksanEomContSegmentation_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomRenumeration = KSANEomRenumerations(testResources.ksanEomRenumerations_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomInstallmentPlan = KSANEomInstallmentPlan(testResources.ksanEomInstallmentPlan_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema)("2021-05-19").globalParameterSetter()
    val ksanEomDomesticInterveners = KSANEomDomesticInterveners(testResources.ksanEomDomesticInterveners_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmInternalDepo = KSTMInternalDepo(testResources.kstmInternalDepo_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomOutBalanceItems = KSANEomOutBalanceItems(testResources.ksanEomOutBalanceItems_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val xctkWrongWayRisk = XCTKWrongWayRisk(testResources.xctkWrongWayRisk_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoWriteoffContract = KDEOWriteoffContract(testResources.kdeoWriteoffContract_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val nztgTradeCoreInfBoEom = NZTGTradeCoreInfBoEom(testResources.nztgTradeCoreInfBoEom_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val krdcIssuancesFixedIncome = KRDCIssuancesFixedIncome(testResources.krdcIssuancesFixedIncome_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoCovidMeasure = KDEOCovidMeasure(testResources.kdeoCovidMeasure_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kctkOpportunityRiskMgmt = KCTKOpportunityRiskMgmt(testResources.kctkOpportunityRiskMgmt_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()

    val datasetMap: Map[String, CDDStructuralBoardsDataset[_]] = Map(
      CONTRACTS_BOARD_TABLE_EOM_CONTRACT -> ksanEomContract,
      CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES -> ksanEomAssetsLiabilities,
      CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO -> ksanEomInternalDepo,
      CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES -> kstmAssetsLiabilities,
      CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS -> kstmOffBalanceItems,
      CONTRACTS_BOARD_TABLE_RISK_SCORING_ATRB -> kctkRiskScoringAtrb,
      CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN -> kdeoInapprtContSitutn,
      CONTRACTS_BOARD_TABLE_EOM_CONT_SEGMENTATION -> ksanEomContSegmentation,
      CONTRACTS_BOARD_TABLE_EOM_RENUMERATIONS -> ksanEomRenumeration,
      CONTRACTS_BOARD_TABLE_EOM_INSTALLMENT_PLAN -> ksanEomInstallmentPlan,
      CONTRACTS_BOARD_TABLE_EOM_DOMESTIC_INTERVENERS -> ksanEomDomesticInterveners,
      CONTRACTS_BOARD_TABLE_INTERNAL_DEPO -> kstmInternalDepo,
      CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS -> ksanEomOutBalanceItems,
      CONTRACTS_BOARD_TABLE_WRONG_WAY_RISK -> xctkWrongWayRisk,
      CONTRACTS_BOARD_TABLE_WRITEOFF_CONTRACT -> kdeoWriteoffContract,
      CONTRACTS_BOARD_TABLE_TRADE_CORE_INF_BO_EOM -> nztgTradeCoreInfBoEom,
      CONTRACTS_BOARD_TABLE_ISSUANCES_FIXED_INCOME -> krdcIssuancesFixedIncome,
      CONTRACTS_BOARD_TABLE_OPPORTUNITY_RISK_MGMT -> kctkOpportunityRiskMgmt,
      CONTRACTS_BOARD_TABLE_COVID_MEASURE -> kdeoCovidMeasure
    )
    val unionDataset = (new StructuralboardsContracts_RQ42021).contractsUnion(datasetMap, testResources.config, testResources.globalReaded)
    val datasetMapComplete: Map[String, CDDStructuralBoardsDataset[_]] = datasetMap
      . +(CONTRACTS_BOARD_UNION_KSAN -> unionDataset._1)
      . +(CONTRACTS_BOARD_UNION_KSTM -> unionDataset._2)
    val result: DataFrame = (new StructuralboardsContracts_RQ42021)
      .joinTablon(datasetMapComplete, testResources.globalReaded, testResources.globalTranslated, datioSparkSession).getDataFrame()
    TechnicalValidation.listStringValidator(testResources.outputJoinBoardsColumns, result.columns, "contractsIngestion_joinFinal")
    TestUtils.assertDataFrameEquals(result
      .select(testResources.outputJoinBoardPks.map(col):_*), testResources.ktae_contracts_after_join, FALSE_VALUE) shouldBe TRUE_VALUE
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("contractsIngestion_unionContracts") {
    val ksanEomAssetsLiabilities = KSANEomAssetsLiabilities(testResources.ksanEomAssetsLiabilities_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomInternalDepo = KSANEomInternalDepo(testResources.ksanEomInternalDepo_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val ksanEomOutBalanceItems = KSANEomOutBalanceItems(testResources.ksanEomOutBalanceItems_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmAssetsLiabilities = KSTMAssetsLiabilities(testResources.kstmAssetsLiabilities_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmInternalDepo = KSTMInternalDepo(testResources.kstmInternalDepo_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()
    val kstmOffBalanceItems = KSTMOffBalanceItems(testResources.kstmOffBalanceItems_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).globalParameterSetter()

    val datasetMap: Map[String,CDDStructuralBoardsDataset[_]] = Map(
      CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES -> ksanEomAssetsLiabilities,
      CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS -> ksanEomOutBalanceItems,
      CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO -> ksanEomInternalDepo,
      CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES -> kstmAssetsLiabilities,
      CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS -> kstmOffBalanceItems,
      CONTRACTS_BOARD_TABLE_INTERNAL_DEPO -> kstmInternalDepo
    )
    val result = (new StructuralboardsContracts_RQ42021).contractsUnion(datasetMap, testResources.config, testResources.globalReaded)
    TestUtils.assertDataFrameEquals(result._1.getDataFrame(), testResources.ksan_contracts_union, FALSE_VALUE) shouldBe TRUE_VALUE
    TestUtils.assertDataFrameEquals(result._2.getDataFrame(), testResources.kstm_contracts_union, FALSE_VALUE) shouldBe TRUE_VALUE
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("contractsIngestion_dataSetCollectorMapper_KCTKRiskScoringAtrbEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_RISK_SCORING_ATRB
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKRiskScoringAtrb])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KDEOInapprtContSitutnEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_INAPPRT_CONT_SITUTN
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KDEOInapprtContSitutn])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomAssetsLiabilitiesEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_ASSETS_LIABILITIES
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomAssetsLiabilities])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomContSegmentationEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_CONT_SEGMENTATION
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomContSegmentation])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomDomesticIntervenersEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_DOMESTIC_INTERVENERS
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomDomesticInterveners])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomInstallmentPlanEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_INSTALLMENT_PLAN
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomInstallmentPlan])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomInternalDepoEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_INTERNAL_DEPO
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomInternalDepo])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomOutBalanceItemsEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_OUT_BALANCE_ITEMS
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomOutBalanceItems])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSANEomRenumerationsEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_EOM_RENUMERATIONS
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSANEomRenumerations])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSTMAssetsLiabilitiesEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_ASSETS_LIABILITIES
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSTMAssetsLiabilities])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSTMInternalDepoEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_INTERNAL_DEPO
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSTMInternalDepo])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_KSTMOffBalanceItemsEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_OFF_BALANCE_ITEMS
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSTMOffBalanceItems])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("contractsIngestion_dataSetCollectorMapper_NZTGTradeCoreInfBoEomTestEmpty") {
    val testInputEntityName : String = CONTRACTS_BOARD_TABLE_TRADE_CORE_INF_BO_EOM
    val result = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[NZTGTradeCoreInfBoEom])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  /*
  test("contractsIngestion_dataSetCollectorMapperMissSchema"){
    assertThrows[DataprocSchemaException] {
      (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper(testResources.emptyString,
        testResources.globalReadedWithoutSchema,
        testResources.globalTranslated,
        testResources.config,
        datioSparkSession,
        TRUE_VALUE)
    }
  }
  */

  test("contractsIngestion_dataSetCollectorMapperNoMatch"){
    val testInputBadFullNameSchemaBoard : String = "test"
    val resultEmpty = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper (testResources.emptyString,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    val resultBad = (new StructuralboardsContracts_RQ42021).dataSetCollectionMapper (testInputBadFullNameSchemaBoard,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    resultEmpty.isEmpty shouldBe TRUE_VALUE
    resultBad.isEmpty shouldBe TRUE_VALUE
  }
}
