package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KRDCIssuancesFixedIncomeTest extends TestContracts{
  test("krdcIssuancesFixedIncome_wrap") {
    val instancia: KRDCIssuancesFixedIncome = KRDCIssuancesFixedIncome(testResources.krdcIssuancesFixedIncome_complete_input_testing, testResources.config)
    val result: KRDCIssuancesFixedIncome = instancia.wrap(testResources.krdcIssuancesFixedIncome_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("krdcIssuancesFixedIncome_apply") {
    val result: DataFrame = KRDCIssuancesFixedIncome(testResources.krdcIssuancesFixedIncome_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).getDataFrame()
    TestUtils.assertDataFrameEquals(result,
      testResources.krdcIssuancesFixedIncome_customized_testing.select(result.columns.map(col):_*), false) shouldBe TRUE_VALUE
  }

  test("krdcIssuancesFixedIncome_apply_with_both_partitions") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.krdcPath)
    val pathToWrite = testResources.krdcPath + "g_entific_id=GL/" + "gf_odate_date_id=20200731"
    val dataset: DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(testResources.krdcIssuancesFixedIncome_complete_input_testing_rows_rdd, testResources.krdcIssuancesFixedIncome_complete_input_testing_schema)
      .drop("gf_odate_date_id")
      .drop("g_entific_id")
    WriteUtils.simpleWriteToParquet(datioSparkSession,dataset,pathToWrite)
    val result: DataFrame = KRDCIssuancesFixedIncome(testResources.testingEmptyCDDContractDataFrame, testResources.config)
      .globalParameterSetter()
      .apply(datioSparkSession, testResources.krdcIssuancesFixedIncome_complete_testing_datio_schema).getDataFrame()
      .drop("gf_odate_date_id")
      .drop("gf_cutoff_date")
      .drop("g_entific_id")
      .drop("gf_audit_date")
    TestUtils.assertDataFrameEquals(result, testResources.krdcIssuancesFixedIncome_complete_input_testing
      .drop("g_t_krdc_issuances_fixed_income_not_relevant")
      .drop("g_t_krdc_issuances_fixed_income_relevant_to_rename"), false) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, testResources.krdcPath)
  }

  test("krdcIssuancesFixedIncome_apply_with_one_partition") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.krdcPath)
    val pathToWrite = testResources.krdcPath + "gf_odate_date_id=20200731"
    val dataset: DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(testResources.krdcIssuancesFixedIncome_complete_input_testing_rows_rdd, testResources.krdcIssuancesFixedIncome_complete_input_testing_schema)
      .drop("gf_odate_date_id")
    WriteUtils.simpleWriteToParquet(datioSparkSession,dataset,pathToWrite)
    val result: DataFrame = KRDCIssuancesFixedIncome(testResources.testingEmptyCDDContractDataFrame, testResources.configOnePartition)
      .globalParameterSetter()
      .apply(datioSparkSession, testResources.krdcIssuancesFixedIncome_complete_testing_datio_schema).getDataFrame()
      .drop("gf_odate_date_id")
      .drop("gf_cutoff_date")
      .drop("g_entific_id")
      .drop("gf_audit_date")
    TestUtils.assertDataFrameEquals(result, testResources.krdcIssuancesFixedIncome_complete_input_testing
      .drop("g_t_krdc_issuances_fixed_income_not_relevant")
      .drop("g_t_krdc_issuances_fixed_income_relevant_to_rename"), false) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, testResources.krdcPath)
  }

}
