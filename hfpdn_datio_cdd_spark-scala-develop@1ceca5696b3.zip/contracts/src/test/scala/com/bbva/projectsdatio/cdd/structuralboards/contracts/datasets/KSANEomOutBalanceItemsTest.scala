package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSANEomOutBalanceItemsTest extends TestContracts{
  test("ksanEomOutBalanceItems_wrap") {
    val instancia: KSANEomOutBalanceItems = KSANEomOutBalanceItems(testResources.ksanEomOutBalanceItems_complete_input_testing, testResources.config)
    val result: KSANEomOutBalanceItems = instancia.wrap(testResources.ksanEomOutBalanceItems_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
