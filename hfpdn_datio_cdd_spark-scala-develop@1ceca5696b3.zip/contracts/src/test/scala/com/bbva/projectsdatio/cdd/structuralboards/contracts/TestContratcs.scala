package com.bbva.projectsdatio.cdd.structuralboards.contracts

import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestContractsCommonResources
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

object TestSuiteContextProvider {
  @transient var _spark: SparkSession = _

  def getOptSparkContext: Option[SparkContext] = getOptSparkSession.map(_.sparkContext)

  def getOptSparkSession: Option[SparkSession] = Option(_spark)
}

trait TestContracts extends FunSuite with BeforeAndAfterAll with Matchers {

  implicit lazy val spark: SparkSession = TestSuiteContextProvider.getOptSparkSession.get
  lazy val testResources = new TestContractsCommonResources(DatioSparkSession.getOrCreate())
  implicit lazy val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()

  override protected def afterAll(): Unit = {
    super.afterAll()

    if (TestSuiteContextProvider.getOptSparkContext.isDefined) {
      TestSuiteContextProvider.getOptSparkContext.get.stop()
    }
  }

  override protected def beforeAll(): Unit = {
    super.beforeAll()

    val sConf = new SparkConf()
      .setMaster("local[*]")
      .setAppName("TestContracts")
      .set("spark.sql.shuffle.partitions", "1")
      .set("spark.default.parallelism", "1")

    SparkContext.getOrCreate(sConf)

    TestSuiteContextProvider._spark = SparkSession
      .builder().master("local[*]").appName("UnitTestsTalentAndCulture").getOrCreate()

    spark.sparkContext.setLogLevel("INFO")

  }

}
