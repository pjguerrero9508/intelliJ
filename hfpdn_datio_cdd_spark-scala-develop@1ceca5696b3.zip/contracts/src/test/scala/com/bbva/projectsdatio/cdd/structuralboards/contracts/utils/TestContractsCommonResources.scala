package com.bbva.projectsdatio.cdd.structuralboards.contracts.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession

class TestContractsCommonResources (datioSparkSession: DatioSparkSession) extends TestContractsDataframes(datioSparkSession) with TestContractsConfigs {

    //CONSTANTS
    val emptyString: String = ""

    //PATHS
    lazy val checkpointPath: String = "src/test/resources/data/contractsIngestion/temporal/checkpoint"
    lazy val xctkPath: String = "src/test/resources/data/xctkWrongWayRisk/parquet/"
    lazy val krdcPath: String = "src/test/resources/data/krdcIssuancesFixedIncome/parquet/"

    //CONFIGURATIONS
    val globalReaded : GlobalConfigurationReaded =
        GlobalConfigurationReaded(dateIngestion = "2021-04-01",
            dateColumnName = "gf_cutoff_date",
            dateColumnValue = "2021-04-12",
            entificColumnName = "g_entific_id",
            entificColumnValue = "ES",
            auditColumnName = "gf_audit_date",
            averageKBPerRecord = 1,
            fullNameSchemaBoard = "src/test/resources/schemas/contracts/full_contract_schema.json",
            pathTemporal = "",
            pathOutputBoard = "",
            repartitionBase = 1,
            notInformedDatasets = Seq.empty[String])
    val globalReadedWithoutSchema : GlobalConfigurationReaded =
        GlobalConfigurationReaded(dateIngestion = "2021-04-01",
            dateColumnName = "gf_cutoff_date",
            dateColumnValue = "2021-04-12",
            entificColumnName = "g_entific_id",
            entificColumnValue = "ES",
            auditColumnName = "gf_audit_date",
            averageKBPerRecord = 1,
            fullNameSchemaBoard = "",
            pathTemporal = "",
            pathOutputBoard = "",
            repartitionBase = 1,
            notInformedDatasets = Seq.empty[String])
    val globalTranslated : GlobalConfigurationTranslated =
        GlobalConfigurationTranslated(datioOutputSchema = ktae_contracts_after_join_testing_datio_schema,
            checkpointTempPath = checkpointPath,
            backupTempPath = "",
            actualPrincipalPath = "",
            actualPrincipalPathWithPartitions = "")
}
