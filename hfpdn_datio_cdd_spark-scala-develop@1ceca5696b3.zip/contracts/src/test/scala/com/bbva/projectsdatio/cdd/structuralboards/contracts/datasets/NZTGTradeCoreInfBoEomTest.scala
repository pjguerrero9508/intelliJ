package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class NZTGTradeCoreInfBoEomTest extends TestContracts{
  test("nztgTradeCoreInfBoEom_wrap") {
    val instancia: NZTGTradeCoreInfBoEom = NZTGTradeCoreInfBoEom(testResources.nztgTradeCoreInfBoEom_complete_input_testing, testResources.config)
    val result: NZTGTradeCoreInfBoEom = instancia.wrap(testResources.nztgTradeCoreInfBoEom_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
