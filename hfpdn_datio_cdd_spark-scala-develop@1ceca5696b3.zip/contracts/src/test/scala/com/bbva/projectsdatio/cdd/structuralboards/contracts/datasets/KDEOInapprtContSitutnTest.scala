package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KDEOInapprtContSitutnTest extends TestContracts{
  test("kdeoInapprtContSitutn_wrap") {
    val instancia: KDEOInapprtContSitutn = KDEOInapprtContSitutn(testResources.kdeoInapprtContSitutn_complete_input_testing, testResources.config)
    val result: KDEOInapprtContSitutn = instancia.wrap(testResources.kdeoInapprtContSitutn_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
