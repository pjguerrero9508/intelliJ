package com.bbva.projectsdatio.cdd.structuralboards.contracts.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.NULL_VALUE
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.{DataFrame, Row}

class TestContractsDataframes(datioSparkSession: DatioSparkSession) extends TestContractsSchemas {

  //CDD DATASETS
  val testingEmptyDataRows: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
  val testingEmptyDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, testingDataSchema)
  val testingEmptyCDDContractDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, outputSchema)

  lazy val ksanEomContract_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_contract_relevant ,  g_t_ksan_eom_contract_not_relevant ,  g_t_ksan_eom_contract_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_not_relevant", "g_t_ksan_eom_contract_relevant_to_rename" , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_not_relevant", "g_t_ksan_eom_contract_relevant_to_rename" , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_not_relevant", "g_t_ksan_eom_contract_relevant_to_rename" , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_not_relevant", "g_t_ksan_eom_contract_relevant_to_rename" , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_not_relevant", "g_t_ksan_eom_contract_relevant_to_rename" , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_complete_input_testing_schema)
  )
  lazy val ksanEomContract_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_contract_relevant ,  g_t_ksan_eom_contract_relevant_renamed    , g_t_ksan_eom_contract_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_ksan_eom_contract_relevant", "g_t_ksan_eom_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContract_customized_testing_schema)
  )
  lazy val ksanEomContract_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomContract_complete_input_testing_rows, 1)
  lazy val ksanEomContract_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomContract_customized_testing_rows, 1)
  lazy val ksanEomContract_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomContract_complete_input_testing_rows_rdd, ksanEomContract_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomContract_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomContract_customized_testing_rows_rdd, ksanEomContract_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkRiskScoringAtrb_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kctk_risk_scoring_atrb_relevant ,  g_t_kctk_risk_scoring_atrb_not_relevant ,  g_t_kctk_risk_scoring_atrb_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_not_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_not_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_not_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_not_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_not_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_complete_input_testing_schema)
  )
  lazy val kctkRiskScoringAtrb_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kctk_risk_scoring_atrb_relevant ,  g_t_kctk_risk_scoring_atrb_relevant_renamed    , g_t_kctk_risk_scoring_atrb_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_kctk_risk_scoring_atrb_relevant", "g_t_kctk_risk_scoring_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkRiskScoringAtrb_customized_testing_schema)
  )
  lazy val kctkRiskScoringAtrb_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkRiskScoringAtrb_complete_input_testing_rows, 1)
  lazy val kctkRiskScoringAtrb_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkRiskScoringAtrb_customized_testing_rows, 1)
  lazy val kctkRiskScoringAtrb_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkRiskScoringAtrb_complete_input_testing_rows_rdd, kctkRiskScoringAtrb_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkRiskScoringAtrb_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkRiskScoringAtrb_customized_testing_rows_rdd, kctkRiskScoringAtrb_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kdeoInapprtContSitutn_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kdeo_inapprt_cont_situtn_relevant ,  g_t_kdeo_inapprt_cont_situtn_not_relevant ,  g_t_kdeo_inapprt_cont_situtn_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractCIBId0001"   , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractCIBId0002"   , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_not_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_complete_input_testing_schema)
  )
  lazy val kdeoInapprtContSitutn_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kdeo_inapprt_cont_situtn_relevant ,  g_t_kdeo_inapprt_cont_situtn_relevant_renamed    , g_t_kdeo_inapprt_cont_situtn_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractCIBId0001"   , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractCIBId0002"   , "g_t_kdeo_inapprt_cont_situtn_relevant", "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtContSitutn_customized_testing_schema)
  )
  lazy val kdeoInapprtContSitutn_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoInapprtContSitutn_complete_input_testing_rows, 1)
  lazy val kdeoInapprtContSitutn_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoInapprtContSitutn_customized_testing_rows, 1)
  lazy val kdeoInapprtContSitutn_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoInapprtContSitutn_complete_input_testing_rows_rdd, kdeoInapprtContSitutn_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kdeoInapprtContSitutn_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoInapprtContSitutn_customized_testing_rows_rdd, kdeoInapprtContSitutn_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kdeoWriteoffContract_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kdeo_writeoff_contract_relevant ,  g_t_kdeo_writeoff_contract_not_relevant ,  g_t_kdeo_writeoff_contract_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_not_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_not_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_not_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_not_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_not_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_complete_input_testing_schema)
  )
  lazy val kdeoWriteoffContract_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kdeo_writeoff_contract_relevant ,  g_t_kdeo_writeoff_contract_relevant_renamed    , g_t_kdeo_writeoff_contract_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_kdeo_writeoff_contract_relevant", "g_t_kdeo_writeoff_contract_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoWriteoffContract_customized_testing_schema)
  )
  lazy val kdeoWriteoffContract_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoWriteoffContract_complete_input_testing_rows, 1)
  lazy val kdeoWriteoffContract_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoWriteoffContract_customized_testing_rows, 1)
  lazy val kdeoWriteoffContract_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoWriteoffContract_complete_input_testing_rows_rdd, kdeoWriteoffContract_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kdeoWriteoffContract_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoWriteoffContract_customized_testing_rows_rdd, kdeoWriteoffContract_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val krdcIssuancesFixedIncome_complete_input_testing_rows = Seq(
    //                             g_security_id   ,  g_t_krdc_issuances_fixed_income_relevant ,  g_t_krdc_issuances_fixed_income_not_relevant ,  g_t_krdc_issuances_fixed_income_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("securityId0001", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_not_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_complete_input_testing_schema),
    new GenericRowWithSchema(Array("securityId0002", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_not_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_complete_input_testing_schema),
    new GenericRowWithSchema(Array("securityId0003", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_not_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_complete_input_testing_schema),
    new GenericRowWithSchema(Array("securityId0004", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_not_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_complete_input_testing_schema),
    new GenericRowWithSchema(Array("securityId0005", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_not_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_complete_input_testing_schema)
  )
  lazy val krdcIssuancesFixedIncome_customized_testing_rows = Seq(
    //                             g_security_id   ,  g_t_krdc_issuances_fixed_income_relevant ,  g_t_krdc_issuances_fixed_income_relevant_renamed    , g_t_krdc_issuances_fixed_income_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("securityId0001", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_customized_testing_schema),
    new GenericRowWithSchema(Array("securityId0002", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_customized_testing_schema),
    new GenericRowWithSchema(Array("securityId0003", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_customized_testing_schema),
    new GenericRowWithSchema(Array("securityId0004", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_customized_testing_schema),
    new GenericRowWithSchema(Array("securityId0005", "g_t_krdc_issuances_fixed_income_relevant", "g_t_krdc_issuances_fixed_income_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), krdcIssuancesFixedIncome_customized_testing_schema)
  )
  lazy val krdcIssuancesFixedIncome_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(krdcIssuancesFixedIncome_complete_input_testing_rows, 1)
  lazy val krdcIssuancesFixedIncome_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(krdcIssuancesFixedIncome_customized_testing_rows, 1)
  lazy val krdcIssuancesFixedIncome_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(krdcIssuancesFixedIncome_complete_input_testing_rows_rdd, krdcIssuancesFixedIncome_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val krdcIssuancesFixedIncome_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(krdcIssuancesFixedIncome_customized_testing_rows_rdd, krdcIssuancesFixedIncome_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomAssetsLiabilities_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_assets_liabilities_relevant ,  g_t_ksan_eom_assets_liabilities_not_relevant ,  g_t_ksan_eom_assets_liabilities_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_ksan_eom_assets_liabilities_relevant", "g_t_ksan_eom_assets_liabilities_not_relevant", "g_t_ksan_eom_assets_liabilities_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomAssetsLiabilities_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_ksan_eom_assets_liabilities_relevant", "g_t_ksan_eom_assets_liabilities_not_relevant", "g_t_ksan_eom_assets_liabilities_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomAssetsLiabilities_complete_input_testing_schema)
  )
  lazy val ksanEomAssetsLiabilities_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_assets_liabilities_relevant ,  g_t_ksan_eom_assets_liabilities_relevant_renamed    , g_t_ksan_eom_assets_liabilities_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_ksan_eom_assets_liabilities_relevant", "g_t_ksan_eom_assets_liabilities_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomAssetsLiabilities_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_ksan_eom_assets_liabilities_relevant", "g_t_ksan_eom_assets_liabilities_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomAssetsLiabilities_customized_testing_schema)
  )
  lazy val ksanEomAssetsLiabilities_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomAssetsLiabilities_complete_input_testing_rows, 1)
  lazy val ksanEomAssetsLiabilities_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomAssetsLiabilities_customized_testing_rows, 1)
  lazy val ksanEomAssetsLiabilities_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomAssetsLiabilities_complete_input_testing_rows_rdd, ksanEomAssetsLiabilities_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomAssetsLiabilities_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomAssetsLiabilities_customized_testing_rows_rdd, ksanEomAssetsLiabilities_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomContSegmentation_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_cont_segmentation_relevant ,  g_t_ksan_eom_cont_segmentation_not_relevant ,  g_t_ksan_eom_cont_segmentation_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_not_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_not_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_not_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_not_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_not_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_complete_input_testing_schema)
  )
  lazy val ksanEomContSegmentation_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_cont_segmentation_relevant ,  g_t_ksan_eom_cont_segmentation_relevant_renamed    , g_t_ksan_eom_cont_segmentation_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_ksan_eom_cont_segmentation_relevant", "g_t_ksan_eom_cont_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomContSegmentation_customized_testing_schema)
  )
  lazy val ksanEomContSegmentation_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomContSegmentation_complete_input_testing_rows, 1)
  lazy val ksanEomContSegmentation_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomContSegmentation_customized_testing_rows, 1)
  lazy val ksanEomContSegmentation_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomContSegmentation_complete_input_testing_rows_rdd, ksanEomContSegmentation_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomContSegmentation_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomContSegmentation_customized_testing_rows_rdd, ksanEomContSegmentation_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomDomesticInterveners_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id, g_customer_id, g_main_holder_customer_type,  g_party_type ,  g_t_ksan_eom_domestic_interveners_relevant ,  g_t_ksan_eom_domestic_interveners_not_relevant ,  g_t_ksan_eom_domestic_interveners_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "customerId01", "Y"                        , "0001"        , "g_t_ksan_eom_domestic_interveners_relevant" , "g_t_ksan_eom_domestic_interveners_not_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "customerId02", "Y"                        , "0002"        , "g_t_ksan_eom_domestic_interveners_relevant" , "g_t_ksan_eom_domestic_interveners_not_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "customerId03", "Y"                        , "0003"        , "g_t_ksan_eom_domestic_interveners_relevant" , "g_t_ksan_eom_domestic_interveners_not_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "customerId04", "Y"                        , "0004"        , "g_t_ksan_eom_domestic_interveners_relevant" , "g_t_ksan_eom_domestic_interveners_not_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "customerId05", "Y"                        , "0005"        , "g_t_ksan_eom_domestic_interveners_relevant" , "g_t_ksan_eom_domestic_interveners_not_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0006"     , "customerId06", "N"                        , "0006"        , "g_t_ksan_eom_domestic_interveners_relevant" , "g_t_ksan_eom_domestic_interveners_not_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_complete_input_testing_schema)
  )
  lazy val ksanEomDomesticInterveners_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,g_cont_main_holder_cust_id,  g_party_type ,  g_t_ksan_eom_domestic_interveners_relevant ,  g_t_ksan_eom_domestic_interveners_relevant_renamed    , g_t_ksan_eom_domestic_interveners_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "customerId01"            , "0001"        , "g_t_ksan_eom_domestic_interveners_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "customerId02"            , "0002"        , "g_t_ksan_eom_domestic_interveners_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "customerId03"            , "0003"        , "g_t_ksan_eom_domestic_interveners_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "customerId04"            , "0004"        , "g_t_ksan_eom_domestic_interveners_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "customerId05"            , "0005"        , "g_t_ksan_eom_domestic_interveners_relevant", "g_t_ksan_eom_domestic_interveners_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomDomesticInterveners_customized_testing_schema)
  )
  lazy val ksanEomDomesticInterveners_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomDomesticInterveners_complete_input_testing_rows, 1)
  lazy val ksanEomDomesticInterveners_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomDomesticInterveners_customized_testing_rows, 1)
  lazy val ksanEomDomesticInterveners_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomDomesticInterveners_complete_input_testing_rows_rdd, ksanEomDomesticInterveners_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomDomesticInterveners_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomDomesticInterveners_customized_testing_rows_rdd, ksanEomDomesticInterveners_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomInstallmentPlan_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  gf_installment_maturity_date ,  gf_instlmt_interest_bc_amount ,  gf_instlmt_total_bc_amount ,  gf_instlmt_principal_bc_amount ,  g_t_ksan_eom_instlmnt_plan_relevant ,  g_t_ksan_eom_instlmnt_plan_not_relevant ,  g_t_ksan_eom_instlmnt_plan_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-04-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-04-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-04-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-04-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-04-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-05-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-05-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-05-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-05-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-05-17"                  , "1.0"                          , "2.0"                       , "1.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-05-18"                  , "3.0"                          , "4.0"                       , "3.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-05-18"                  , "3.0"                          , "4.0"                       , "3.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-05-18"                  , "3.0"                          , "4.0"                       , "3.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-05-18"                  , "3.0"                          , "4.0"                       , "3.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-05-18"                  , "3.0"                          , "4.0"                       , "3.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-05-19"                  , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-05-19"                  , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-05-19"                  , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-05-19"                  , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-05-19"                  , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-06-19"                  , "9.0"                          , "10.0"                      , "9.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-06-19"                  , "9.0"                          , "10.0"                      , "9.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-06-19"                  , "9.0"                          , "10.0"                      , "9.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-06-19"                  , "9.0"                          , "10.0"                      , "9.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-06-19"                  , "9.0"                          , "10.0"                      , "9.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-07-19"                  , "7.0"                          , "8.0"                       , "7.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-07-19"                  , "7.0"                          , "8.0"                       , "7.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-07-19"                  , "7.0"                          , "8.0"                       , "7.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-07-19"                  , "7.0"                          , "8.0"                       , "7.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-07-19"                  , "7.0"                          , "8.0"                       , "7.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_not_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_complete_input_testing_schema)
  )
  lazy val ksanEomInstallmentPlan_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  gf_installment_maturity_date,  gf_instlmt_interest_bc_amount ,  gf_instlmt_total_bc_amount ,  gf_instlmt_principal_bc_amount ,  g_t_ksan_eom_instlmnt_plan_relevant ,  g_t_ksan_eom_instlmnt_plan_relevant_renamed   , g_t_ksan_eom_instlmnt_plan_relevant_initialized,gf_lst_instlmt_int_bc_amount,gf_nxt_instlmt_int_bc_amount , gf_pv_instlmt_int_bc_amount , gf_lst_instlmt_tot_bc_amount , gf_nxt_instlmt_tot_bc_amount , gf_pv_instlmt_tot_bc_amount , gf_lst_instlmt_amort_bc_amount , gf_nxt_instlmt_amort_bc_amount , gf_pv_instlmt_amort_bc_amount , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "2021-05-19"                 , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", NULL_VALUE                                     ,"7.0"                       ,"9.0"                        ,"5.0"                        ,"8.0"                         ,"10.0"                        ,"6.0"                        ,"7.5"                           ,"9.5"                           ,"5.5"                          , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "2021-05-19"                 , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", NULL_VALUE                                     ,"7.0"                       ,"9.0"                        ,"5.0"                        ,"8.0"                         ,"10.0"                        ,"6.0"                        ,"7.5"                           ,"9.5"                           ,"5.5"                          , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "2021-05-19"                 , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", NULL_VALUE                                     ,"7.0"                       ,"9.0"                        ,"5.0"                        ,"8.0"                         ,"10.0"                        ,"6.0"                        ,"7.5"                           ,"9.5"                           ,"5.5"                          , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "2021-05-19"                 , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", NULL_VALUE                                     ,"7.0"                       ,"9.0"                        ,"5.0"                        ,"8.0"                         ,"10.0"                        ,"6.0"                        ,"7.5"                           ,"9.5"                           ,"5.5"                          , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "2021-05-19"                 , "5.0"                          , "6.0"                       , "5.5"                           , "g_t_ksan_eom_instlmnt_plan_relevant", "g_t_ksan_eom_instlmnt_plan_relevant_to_rename", NULL_VALUE                                     ,"7.0"                       ,"9.0"                        ,"5.0"                        ,"8.0"                         ,"10.0"                        ,"6.0"                        ,"7.5"                           ,"9.5"                           ,"5.5"                          , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInstallmentPlan_customized_testing_schema)
  )
  lazy val ksanEomInstallmentPlan_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomInstallmentPlan_complete_input_testing_rows, 1)
  lazy val ksanEomInstallmentPlan_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomInstallmentPlan_customized_testing_rows, 1)
  lazy val ksanEomInstallmentPlan_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomInstallmentPlan_complete_input_testing_rows_rdd, ksanEomInstallmentPlan_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomInstallmentPlan_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomInstallmentPlan_customized_testing_rows_rdd, ksanEomInstallmentPlan_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomInternalDepo_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_internal_depo_relevant ,  g_t_ksan_eom_internal_depo_not_relevant ,  g_t_ksan_eom_internal_depo_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_ksan_eom_internal_depo_relevant", "g_t_ksan_eom_internal_depo_not_relevant", "g_t_ksan_eom_internal_depo_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInternalDepo_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0006"     , "g_t_ksan_eom_internal_depo_relevant", "g_t_ksan_eom_internal_depo_not_relevant", "g_t_ksan_eom_internal_depo_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInternalDepo_complete_input_testing_schema)
  )
  lazy val ksanEomInternalDepo_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_internal_depo_relevant ,  g_t_ksan_eom_internal_depo_relevant_renamed    , g_t_ksan_eom_internal_depo_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_ksan_eom_internal_depo_relevant", "g_t_ksan_eom_internal_depo_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInternalDepo_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0006"     , "g_t_ksan_eom_internal_depo_relevant", "g_t_ksan_eom_internal_depo_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomInternalDepo_customized_testing_schema)
  )
  lazy val ksanEomInternalDepo_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomInternalDepo_complete_input_testing_rows, 1)
  lazy val ksanEomInternalDepo_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomInternalDepo_customized_testing_rows, 1)
  lazy val ksanEomInternalDepo_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomInternalDepo_complete_input_testing_rows_rdd, ksanEomInternalDepo_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomInternalDepo_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomInternalDepo_customized_testing_rows_rdd, ksanEomInternalDepo_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomOutBalanceItems_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_out_of_bal_items_relevant ,  g_t_ksan_eom_out_of_bal_items_not_relevant ,  g_t_ksan_eom_out_of_bal_items_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_ksan_eom_out_of_bal_items_relevant", "g_t_ksan_eom_out_of_bal_items_not_relevant", "g_t_ksan_eom_out_of_bal_items_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomOutBalanceItems_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_ksan_eom_out_of_bal_items_relevant", "g_t_ksan_eom_out_of_bal_items_not_relevant", "g_t_ksan_eom_out_of_bal_items_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomOutBalanceItems_complete_input_testing_schema)
  )
  lazy val ksanEomOutBalanceItems_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_ksan_eom_out_of_bal_items_relevant ,  g_t_ksan_eom_out_of_bal_items_relevant_renamed    , g_t_ksan_eom_out_of_bal_items_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_ksan_eom_out_of_bal_items_relevant", "g_t_ksan_eom_out_of_bal_items_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomOutBalanceItems_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_ksan_eom_out_of_bal_items_relevant", "g_t_ksan_eom_out_of_bal_items_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomOutBalanceItems_customized_testing_schema)
  )
  lazy val ksanEomOutBalanceItems_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomOutBalanceItems_complete_input_testing_rows, 1)
  lazy val ksanEomOutBalanceItems_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomOutBalanceItems_customized_testing_rows, 1)
  lazy val ksanEomOutBalanceItems_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomOutBalanceItems_complete_input_testing_rows_rdd, ksanEomOutBalanceItems_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomOutBalanceItems_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomOutBalanceItems_customized_testing_rows_rdd, ksanEomOutBalanceItems_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksanEomRenumerations_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  gf_cust_view_lcl_contract_id , gf_new_contract_id_init_date  ,  g_t_ksan_eom_renumerations_relevant ,  g_t_ksan_eom_renumerations_not_relevant ,  g_t_ksan_eom_renumerations_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "custViewLclContract0001"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "custViewLclContract0001"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "custViewLclContract0001"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "custViewLclContract0001"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "custViewLclContract0001"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "custViewLclContract0002"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "custViewLclContract0002"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "custViewLclContract0002"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "custViewLclContract0002"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "custViewLclContract0002"     , "2021-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0001"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_not_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_complete_input_testing_schema)
  )
  lazy val ksanEomRenumerations_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  gf_cust_view_lcl_contract_id ,  gf_new_contract_id_init_date ,  g_t_ksan_eom_renumerations_relevant ,  g_t_ksan_eom_renumerations_relevant_renamed    , g_t_ksan_eom_renumerations_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "custViewLclContract0001"     , "2022-05-18"                  , "g_t_ksan_eom_renumerations_relevant", "g_t_ksan_eom_renumerations_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksanEomRenumerations_customized_testing_schema)
  )
  lazy val ksanEomRenumerations_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomRenumerations_complete_input_testing_rows, 1)
  lazy val ksanEomRenumerations_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksanEomRenumerations_customized_testing_rows, 1)
  lazy val ksanEomRenumerations_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomRenumerations_complete_input_testing_rows_rdd, ksanEomRenumerations_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksanEomRenumerations_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksanEomRenumerations_customized_testing_rows_rdd, ksanEomRenumerations_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kstmAssetsLiabilities_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kstm_s_assets_liabilities_relevant ,  g_t_kstm_s_assets_liabilities_not_relevant ,  g_t_kstm_s_assets_liabilities_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_kstm_s_assets_liabilities_relevant", "g_t_kstm_s_assets_liabilities_not_relevant", "g_t_kstm_s_assets_liabilities_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabilities_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_kstm_s_assets_liabilities_relevant", "g_t_kstm_s_assets_liabilities_not_relevant", "g_t_kstm_s_assets_liabilities_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabilities_complete_input_testing_schema)
  )
  lazy val kstmAssetsLiabilities_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kstm_s_assets_liabilities_relevant ,  g_t_kstm_s_assets_liabilities_relevant_renamed    , g_t_kstm_s_assets_liabilities_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_kstm_s_assets_liabilities_relevant", "g_t_kstm_s_assets_liabilities_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabilities_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_kstm_s_assets_liabilities_relevant", "g_t_kstm_s_assets_liabilities_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabilities_customized_testing_schema)
  )
  lazy val kstmAssetsLiabilities_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmAssetsLiabilities_complete_input_testing_rows, 1)
  lazy val kstmAssetsLiabilities_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmAssetsLiabilities_customized_testing_rows, 1)
  lazy val kstmAssetsLiabilities_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmAssetsLiabilities_complete_input_testing_rows_rdd, kstmAssetsLiabilities_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kstmAssetsLiabilities_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmAssetsLiabilities_customized_testing_rows_rdd, kstmAssetsLiabilities_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")


  lazy val kstmInternalDepo_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kstm_s_internal_depo_relevant ,  g_t_kstm_s_internal_depo_not_relevant ,  g_t_kstm_s_internal_depo_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0005"      , "g_t_kstm_s_internal_depo_relevant", "g_t_kstm_s_internal_depo_not_relevant", "g_t_kstm_s_internal_depo_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmInternalDepo_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0006"      , "g_t_kstm_s_internal_depo_relevant", "g_t_kstm_s_internal_depo_not_relevant", "g_t_kstm_s_internal_depo_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmInternalDepo_complete_input_testing_schema)
  )
  lazy val kstmInternalDepo_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kstm_s_internal_depo_relevant ,  g_t_kstm_s_internal_depo_relevant_renamed    , g_t_kstm_s_internal_depo_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0005"      , "g_t_kstm_s_internal_depo_relevant", "g_t_kstm_s_internal_depo_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmInternalDepo_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0006"      , "g_t_kstm_s_internal_depo_relevant", "g_t_kstm_s_internal_depo_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmInternalDepo_customized_testing_schema)
  )
  lazy val kstmInternalDepo_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmInternalDepo_complete_input_testing_rows, 1)
  lazy val kstmInternalDepo_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmInternalDepo_customized_testing_rows, 1)
  lazy val kstmInternalDepo_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmInternalDepo_complete_input_testing_rows_rdd, kstmInternalDepo_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kstmInternalDepo_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmInternalDepo_customized_testing_rows_rdd, kstmInternalDepo_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kstmOffBalanceItems_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kstm_s_off_balance_items_relevant ,  g_t_kstm_s_off_balance_items_not_relevant ,  g_t_kstm_s_off_balance_items_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0003"      , "g_t_kstm_s_off_balance_items_relevant", "g_t_kstm_s_off_balance_items_not_relevant", "g_t_kstm_s_off_balance_items_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmOffBalanceItems_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "g_t_kstm_s_off_balance_items_relevant", "g_t_kstm_s_off_balance_items_not_relevant", "g_t_kstm_s_off_balance_items_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmOffBalanceItems_complete_input_testing_schema)
  )
  lazy val kstmOffBalanceItems_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kstm_s_off_balance_items_relevant ,  g_t_kstm_s_off_balance_items_relevant_renamed    , g_t_kstm_s_off_balance_items_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0003"      , "g_t_kstm_s_off_balance_items_relevant", "g_t_kstm_s_off_balance_items_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmOffBalanceItems_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "g_t_kstm_s_off_balance_items_relevant", "g_t_kstm_s_off_balance_items_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmOffBalanceItems_customized_testing_schema)
  )
  lazy val kstmOffBalanceItems_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmOffBalanceItems_complete_input_testing_rows, 1)
  lazy val kstmOffBalanceItems_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmOffBalanceItems_customized_testing_rows, 1)
  lazy val kstmOffBalanceItems_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmOffBalanceItems_complete_input_testing_rows_rdd, kstmOffBalanceItems_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kstmOffBalanceItems_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmOffBalanceItems_customized_testing_rows_rdd, kstmOffBalanceItems_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val nztgTradeCoreInfBoEom_complete_input_testing_rows = Seq(
    //                             gf_back_sys_trd_id, gf_origin_application_id,  g_security_id  ,  gf_front_sys_trd_id , gf_management_portfolio_id  ,  gf_local_contract_number_id ,  g_t_nztg_trade_core_inf_bo_eom_relevant ,  g_t_nztg_trade_core_inf_bo_eom_not_relevant ,  g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("backSysTrdId0001", "originApplication03"   , NULL_VALUE      , "frontSysTrd0002"    , NULL_VALUE                  , "localContractCIBId0001"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_not_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_complete_input_testing_schema),
    new GenericRowWithSchema(Array("backSysTrdId0002", "originApplication03"   , NULL_VALUE      , "frontSysTrd0001"    , NULL_VALUE                  , "localContractCIBId0002"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_not_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_complete_input_testing_schema),
    new GenericRowWithSchema(Array( NULL_VALUE       , "originApplication03"   , NULL_VALUE      , NULL_VALUE           , NULL_VALUE                  , "localContractCIBId0003"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_not_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_complete_input_testing_schema),
    new GenericRowWithSchema(Array( NULL_VALUE       , "originApplication03"   , "securityId0001", NULL_VALUE           , "managementPortfolioId0002" , "localContractCIBId0004"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_not_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_complete_input_testing_schema),
    new GenericRowWithSchema(Array( NULL_VALUE       , "originApplication03"   , "securityId0002", NULL_VALUE           , "managementPortfolioId0003" , "localContractCIBId0005"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_not_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_complete_input_testing_schema)
  )
  lazy val nztgTradeCoreInfBoEom_customized_testing_rows = Seq(
    //                             gf_back_sys_trd_id, gf_origin_application_id,  g_security_id  ,  gf_front_sys_trd_id , gf_management_portfolio_id  ,  gf_local_contract_number_id ,  g_t_nztg_trade_core_inf_bo_eom_relevant ,  g_t_nztg_trade_core_inf_bo_eom_relevant_renamed    , g_t_nztg_trade_core_inf_bo_eom_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("backSysTrdId0001", "originApplication03"   , NULL_VALUE      , "frontSysTrd0002"    , NULL_VALUE                  , "localContractCIBId0001"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_customized_testing_schema),
    new GenericRowWithSchema(Array("backSysTrdId0002", "originApplication03"   , NULL_VALUE      , "frontSysTrd0001"    , NULL_VALUE                  , "localContractCIBId0002"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_customized_testing_schema),
    new GenericRowWithSchema(Array( NULL_VALUE       , "originApplication03"   , NULL_VALUE      , NULL_VALUE           , NULL_VALUE                  , "localContractCIBId0003"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_customized_testing_schema),
    new GenericRowWithSchema(Array( NULL_VALUE       , "originApplication03"   , "securityId0001", NULL_VALUE           , "managementPortfolioId0002" , "localContractCIBId0004"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_customized_testing_schema),
    new GenericRowWithSchema(Array( NULL_VALUE       , "originApplication03"   , "securityId0002", NULL_VALUE           , "managementPortfolioId0003" , "localContractCIBId0005"     , "g_t_nztg_trade_core_inf_bo_eom_relevant", "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), nztgTradeCoreInfBoEom_customized_testing_schema)
  )
  lazy val nztgTradeCoreInfBoEom_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(nztgTradeCoreInfBoEom_complete_input_testing_rows, 1)
  lazy val nztgTradeCoreInfBoEom_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(nztgTradeCoreInfBoEom_customized_testing_rows, 1)
  lazy val nztgTradeCoreInfBoEom_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(nztgTradeCoreInfBoEom_complete_input_testing_rows_rdd, nztgTradeCoreInfBoEom_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val nztgTradeCoreInfBoEom_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(nztgTradeCoreInfBoEom_customized_testing_rows_rdd, nztgTradeCoreInfBoEom_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val xctkWrongWayRisk_complete_input_testing_rows = Seq(
    //                             gf_front_sys_trd_id, gf_origin_application_id, gf_trd_wwr_ind_type ,   g_t_xctk_wrong_way_risk_relevant ,  g_t_xctk_wrong_way_risk_not_relevant ,  g_t_xctk_wrong_way_risk_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("frontSysTrd0001"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0002"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0003"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0004"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0005"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0006"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0006"  , "originApplication01"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0001"  , "originApplication02"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0002"  , "originApplication02"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0003"  , "originApplication02"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0004"  , "originApplication02"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0005"  , "originApplication02"   , "A"                 ,  "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_not_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_complete_input_testing_schema)
  )
  lazy val xctkWrongWayRisk_customized_testing_rows = Seq(
    //                             gf_front_sys_trd_id, gf_origin_application_id, gf_trd_wwr_ind_type ,   g_t_xctk_wrong_way_risk_relevant ,  g_t_xctk_wrong_way_risk_relevant_renamed   , g_t_xctk_wrong_way_risk_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("frontSysTrd0001"  , "originApplication01"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0002"  , "originApplication01"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0003"  , "originApplication01"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0004"  , "originApplication01"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0005"  , "originApplication01"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0006"  , "originApplication01"   , "N"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0001"  , "originApplication02"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0002"  , "originApplication02"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0003"  , "originApplication02"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0004"  , "originApplication02"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema),
    new GenericRowWithSchema(Array("frontSysTrd0005"  , "originApplication02"   , "A"                 , "g_t_xctk_wrong_way_risk_relevant", "g_t_xctk_wrong_way_risk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), xctkWrongWayRisk_customized_testing_schema)
  )
  lazy val xctkWrongWayRisk_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(xctkWrongWayRisk_complete_input_testing_rows, 1)
  lazy val xctkWrongWayRisk_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(xctkWrongWayRisk_customized_testing_rows, 1)
  lazy val xctkWrongWayRisk_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(xctkWrongWayRisk_complete_input_testing_rows_rdd, xctkWrongWayRisk_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val xctkWrongWayRisk_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(xctkWrongWayRisk_customized_testing_rows_rdd, xctkWrongWayRisk_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkOpportunityRiskMgmt_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kctk_opportunity_risk_mgmt_relevant ,  g_t_kctk_opportunity_risk_mgmt_not_relevant ,  g_t_kctk_opportunity_risk_mgmt_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_not_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_not_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_not_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_not_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_not_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_complete_input_testing_schema)
  )
  lazy val kctkOpportunityRiskMgmt_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kctk_opportunity_risk_mgmt_relevant ,  g_t_kctk_opportunity_risk_mgmt_relevant_renamed    , g_t_kctk_opportunity_risk_mgmt_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"     , "g_t_kctk_opportunity_risk_mgmt_relevant", "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkOpportunityRiskMgmt_customized_testing_schema)
  )
  lazy val kctkOpportunityRiskMgmt_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkOpportunityRiskMgmt_complete_input_testing_rows, 1)
  lazy val kctkOpportunityRiskMgmt_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkOpportunityRiskMgmt_customized_testing_rows, 1)
  lazy val kctkOpportunityRiskMgmt_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkOpportunityRiskMgmt_complete_input_testing_rows_rdd, kctkOpportunityRiskMgmt_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkOpportunityRiskMgmt_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkOpportunityRiskMgmt_customized_testing_rows_rdd, ksanEomContSegmentation_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kdeoCovidMeasure_complete_input_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kdeo_covid_measure_relevant ,  g_t_kdeo_covid_measure_not_relevant ,  g_t_kdeo_covid_measure_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_not_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_not_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_not_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_not_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_complete_input_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_not_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_complete_input_testing_schema)
  )
  lazy val kdeoCovidMeasure_customized_testing_rows = Seq(
    //                             gf_local_contract_number_id,  g_t_kdeo_covid_measure_relevant ,  g_t_kdeo_covid_measure_relevant_renamed    , g_t_ksan_eom_cont_segmentation_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0002"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0003"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0004"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_customized_testing_schema),
    new GenericRowWithSchema(Array("localContractId0005"      , "g_t_kdeo_covid_measure_relevant", "g_t_kdeo_covid_measure_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoCovidMeasure_customized_testing_schema)
  )
  lazy val kdeoCovidMeasure_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoCovidMeasure_complete_input_testing_rows, 1)
  lazy val kdeoCovidMeasure_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoCovidMeasure_customized_testing_rows, 1)
  lazy val kdeoCovidMeasure_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoCovidMeasure_complete_input_testing_rows_rdd, kdeoCovidMeasure_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kdeoCovidMeasure_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoCovidMeasure_customized_testing_rows_rdd, kdeoCovidMeasure_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksan_contracts_union_rows = Seq(
    //                              g_t_ksan_eom_internal_depo_relevant",  g_t_ksan_eom_internal_depo_relevant_renamed   , g_t_ksan_eom_assets_liabilities_relevant_initialized,  g_t_ksan_eom_out_of_bal_items_relevant_renamed   , g_t_ksan_eom_out_of_bal_items_relevant_initialized,  g_t_ksan_eom_out_of_bal_items_relevant , "gf_local_contract_number_id", g_t_ksan_eom_internal_depo_relevant_initialized,  g_t_ksan_eom_assets_liabilities_relevant_renamed   ,  g_t_ksan_eom_assets_liabilities_relevant ,
    new GenericRowWithSchema(Array( NULL_VALUE                          ,  NULL_VALUE                                    , NULL_VALUE                                          ,  NULL_VALUE                                       , NULL_VALUE                                        ,  NULL_VALUE                             , "localContractId0001"        , NULL_VALUE                                     , "g_t_ksan_eom_assets_liabilities_relevant_to_rename", "g_t_ksan_eom_assets_liabilities_relevant", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ksan_contracts_union_schema),
    new GenericRowWithSchema(Array( NULL_VALUE                          ,  NULL_VALUE                                    , NULL_VALUE                                          ,  NULL_VALUE                                       , NULL_VALUE                                        ,  NULL_VALUE                             , "localContractId0002"        , NULL_VALUE                                     , "g_t_ksan_eom_assets_liabilities_relevant_to_rename", "g_t_ksan_eom_assets_liabilities_relevant", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ksan_contracts_union_schema),
    new GenericRowWithSchema(Array( NULL_VALUE                          ,  NULL_VALUE                                    , NULL_VALUE                                          , "g_t_ksan_eom_out_of_bal_items_relevant_to_rename", NULL_VALUE                                        , "g_t_ksan_eom_out_of_bal_items_relevant", "localContractId0003"        , NULL_VALUE                                     ,  NULL_VALUE                                         ,  NULL_VALUE                               , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ksan_contracts_union_schema),
    new GenericRowWithSchema(Array( NULL_VALUE                          ,  NULL_VALUE                                    , NULL_VALUE                                          , "g_t_ksan_eom_out_of_bal_items_relevant_to_rename", NULL_VALUE                                        , "g_t_ksan_eom_out_of_bal_items_relevant", "localContractId0004"        , NULL_VALUE                                     ,  NULL_VALUE                                         ,  NULL_VALUE                               , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ksan_contracts_union_schema),
    new GenericRowWithSchema(Array("g_t_ksan_eom_internal_depo_relevant", "g_t_ksan_eom_internal_depo_relevant_to_rename", NULL_VALUE                                          ,  NULL_VALUE                                       , NULL_VALUE                                        ,  NULL_VALUE                             , "localContractId0005"        , NULL_VALUE                                     ,  NULL_VALUE                                         ,  NULL_VALUE                               , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ksan_contracts_union_schema),
    new GenericRowWithSchema(Array("g_t_ksan_eom_internal_depo_relevant", "g_t_ksan_eom_internal_depo_relevant_to_rename", NULL_VALUE                                          ,  NULL_VALUE                                       , NULL_VALUE                                        ,  NULL_VALUE                             , "localContractId0006"        , NULL_VALUE                                     ,  NULL_VALUE                                         ,  NULL_VALUE                               , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ksan_contracts_union_schema)
  )
  lazy val ksan_contracts_union_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksan_contracts_union_rows, 1)
  lazy val ksan_contracts_union: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksan_contracts_union_rows_rdd, ksan_contracts_union_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")


  lazy val kstm_contracts_union_rows = Seq(
    //                              g_t_kstm_s_internal_depo_relevant ,  g_t_kstm_s_assets_liabilities_relevant_initialized ,  g_t_kstm_s_off_balance_items_relevant ,  g_t_kstm_s_off_balance_items_relevant_renamed   ,  g_t_kstm_s_internal_depo_relevant_initialized ,  g_t_kstm_s_off_balance_items_relevant_initialized , "gf_local_contract_number_id",  g_t_kstm_s_internal_depo_relevant_renamed   ,  g_t_kstm_s_assets_liabilities_relevant_renamed   , "g_t_kstm_s_assets_liabilities_relevant",
    new GenericRowWithSchema(Array( NULL_VALUE                        ,  NULL_VALUE                                         ,  NULL_VALUE                            ,  NULL_VALUE                                      ,  NULL_VALUE                                    ,  NULL_VALUE                                        , "localContractId0001"        ,  NULL_VALUE                                  , "g_t_kstm_s_assets_liabilities_relevant_to_rename", "g_t_kstm_s_assets_liabilities_relevant", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_contracts_union_schema),
    new GenericRowWithSchema(Array( NULL_VALUE                        ,  NULL_VALUE                                         ,  NULL_VALUE                            ,  NULL_VALUE                                      ,  NULL_VALUE                                    ,  NULL_VALUE                                        , "localContractId0002"        ,  NULL_VALUE                                  , "g_t_kstm_s_assets_liabilities_relevant_to_rename", "g_t_kstm_s_assets_liabilities_relevant", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_contracts_union_schema),
    new GenericRowWithSchema(Array( NULL_VALUE                        ,  NULL_VALUE                                         , "g_t_kstm_s_off_balance_items_relevant", "g_t_kstm_s_off_balance_items_relevant_to_rename",  NULL_VALUE                                    ,  NULL_VALUE                                        , "localContractId0003"        ,  NULL_VALUE                                  ,  NULL_VALUE                                       ,  NULL_VALUE                             , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_contracts_union_schema),
    new GenericRowWithSchema(Array( NULL_VALUE                        ,  NULL_VALUE                                         , "g_t_kstm_s_off_balance_items_relevant", "g_t_kstm_s_off_balance_items_relevant_to_rename",  NULL_VALUE                                    ,  NULL_VALUE                                        , "localContractId0004"        ,  NULL_VALUE                                  ,  NULL_VALUE                                       ,  NULL_VALUE                             , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_contracts_union_schema),
    new GenericRowWithSchema(Array("g_t_kstm_s_internal_depo_relevant",  NULL_VALUE                                         ,  NULL_VALUE                            ,  NULL_VALUE                                      ,  NULL_VALUE                                    ,  NULL_VALUE                                        , "localContractId0005"        , "g_t_kstm_s_internal_depo_relevant_to_rename",  NULL_VALUE                                       ,  NULL_VALUE                             , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_contracts_union_schema),
    new GenericRowWithSchema(Array("g_t_kstm_s_internal_depo_relevant",  NULL_VALUE                                         ,  NULL_VALUE                            ,  NULL_VALUE                                      ,  NULL_VALUE                                    ,  NULL_VALUE                                        , "localContractId0006"        , "g_t_kstm_s_internal_depo_relevant_to_rename",  NULL_VALUE                                       ,  NULL_VALUE                             , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_contracts_union_schema)
  )
  lazy val kstm_contracts_union_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstm_contracts_union_rows, 1)
  lazy val kstm_contracts_union: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstm_contracts_union_rows_rdd, kstm_contracts_union_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ktae_contracts_mercados_after_join_rows = Seq(
    //                              gf_local_contract_number_id    ,  g_security_id  ,  gf_management_portfolio_id ,  gf_origin_application_id ,  gf_front_sys_trd_id ,  gf_back_sys_trd_id nt_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractCIBId0001"        , NULL_VALUE      , NULL_VALUE                  , "originApplication03"     , "frontSysTrd0002"    , "backSysTrdId0001"                , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_mercados_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0002"        , NULL_VALUE      , NULL_VALUE                  , "originApplication03"     , "frontSysTrd0001"    , "backSysTrdId0002"                , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_mercados_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0003"        , NULL_VALUE      , NULL_VALUE                  , "originApplication03"     , NULL_VALUE           ,  NULL_VALUE                       , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_mercados_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0004"        , "securityId0001", "managementPortfolioId0002" , "originApplication03"     , NULL_VALUE           ,  NULL_VALUE                       , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_mercados_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0005"        , "securityId0002", "managementPortfolioId0003" , "originApplication03"     , NULL_VALUE           ,  NULL_VALUE                       , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_mercados_after_join_pks_schema)
  )
  lazy val ktae_contracts_mercados_after_join_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ktae_contracts_mercados_after_join_rows, 1)
  lazy val ktae_contracts_mercados_after_join: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ktae_contracts_mercados_after_join_rows_rdd, ktae_contracts_mercados_after_join_pks_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ktae_contracts_domesticos_after_join_rows = Seq(
    //                              gf_local_contract_number_id ,  g_cont_main_holder_cust_id ,  g_party_type ,  gf_cust_view_lcl_contract_id ,  gf_installment_maturity_date, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"        , "customerId01"              , "0001"        , "custViewLclContract0001"     , "2021-05-19"                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_domesticos_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0002"        , "customerId02"              , "0002"        , "custViewLclContract0001"     , "2021-05-19"                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_domesticos_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0003"        , "customerId03"              , "0003"        , "custViewLclContract0001"     , "2021-05-19"                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_domesticos_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0004"        , "customerId04"              , "0004"        , "custViewLclContract0001"     , "2021-05-19"                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_domesticos_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0005"        , "customerId05"              , "0005"        , "custViewLclContract0001"     , "2021-05-19"                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), ktae_contracts_domesticos_after_join_pks_schema)
  )
  lazy val ktae_contracts_domesticos_after_join_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ktae_contracts_domesticos_after_join_rows, 1)
  lazy val ktae_contracts_domesticos_after_join: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ktae_contracts_domesticos_after_join_rows_rdd, ktae_contracts_domesticos_after_join_pks_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ktae_contracts_after_join_rows = Seq(
    //                              gf_local_contract_number_id,"g_cont_main_holder_cust_id,"g_party_type,"gf_cust_view_lcl_contract_id,"gf_installment_maturity_date,"g_security_id  ,"gf_management_portfolio_id,"gf_origin_application_id,"gf_front_sys_trd_id,"gf_back_sys_trd_id,gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("localContractId0001"       ,"customerId01"             ,"0001"       ,"custViewLclContract0001"    ,"2021-05-19"                 , NULL_VALUE     , NULL_VALUE                , NULL_VALUE              , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0002"       ,"customerId02"             ,"0002"       ,"custViewLclContract0001"    ,"2021-05-19"                 , NULL_VALUE     , NULL_VALUE                , NULL_VALUE              , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0003"       ,"customerId03"             ,"0003"       ,"custViewLclContract0001"    ,"2021-05-19"                 , NULL_VALUE     , NULL_VALUE                , NULL_VALUE              , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0004"       ,"customerId04"             ,"0004"       ,"custViewLclContract0001"    ,"2021-05-19"                 , NULL_VALUE     , NULL_VALUE                , NULL_VALUE              , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractId0005"       ,"customerId05"             ,"0005"       ,"custViewLclContract0001"    ,"2021-05-19"                 , NULL_VALUE     , NULL_VALUE                , NULL_VALUE              , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0001"    , NULL_VALUE                , NULL_VALUE  , NULL_VALUE                  , NULL_VALUE                  , NULL_VALUE     , NULL_VALUE                ,"originApplication03"    ,"frontSysTrd0002"   ,"backSysTrdId0001" ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0002"    , NULL_VALUE                , NULL_VALUE  , NULL_VALUE                  , NULL_VALUE                  , NULL_VALUE     , NULL_VALUE                ,"originApplication03"    ,"frontSysTrd0001"   ,"backSysTrdId0002" ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0003"    , NULL_VALUE                , NULL_VALUE  , NULL_VALUE                  , NULL_VALUE                  , NULL_VALUE     , NULL_VALUE                ,"originApplication03"    , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0004"    , NULL_VALUE                , NULL_VALUE  , NULL_VALUE                  , NULL_VALUE                  ,"securityId0001","managementPortfolioId0002","originApplication03"    , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema),
    new GenericRowWithSchema(Array("localContractCIBId0005"    , NULL_VALUE                , NULL_VALUE  , NULL_VALUE                  , NULL_VALUE                  ,"securityId0002","managementPortfolioId0003","originApplication03"    , NULL_VALUE         , NULL_VALUE        ,"2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ktae_contracts_after_join_pks_schema)
  )
  lazy val ktae_contracts_after_join_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ktae_contracts_after_join_rows, 1)
  lazy val ktae_contracts_after_join: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ktae_contracts_after_join_rows_rdd, ktae_contracts_after_join_pks_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
}
