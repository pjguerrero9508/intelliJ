package com.bbva.projectsdatio.cdd.structuralboards.contracts.utils

import com.typesafe.config.{Config, ConfigFactory}

trait TestContractsConfigs {

  //CONSTANTS
  val confStruct: String = "CDDContractsBoard"

  //CONFIG FILES
  lazy val config: Config = rootConfig.getConfig(confStruct)
  lazy val configBadSelect: Config = rootConfigBadSelect.getConfig(confStruct)
  lazy val configMissSelect: Config = rootConfigMissSelect.getConfig(confStruct)
  lazy val configBadJoinFields: Config = rootConfigBadJoinFields.getConfig(confStruct)
  lazy val configBadFields: Config = rootConfigBadFields.getConfig(confStruct)
  lazy val configMissFields: Config = rootConfigMissFields.getConfig(confStruct)
  lazy val configOnePartition: Config = rootConfigOnePartition.getConfig(confStruct)


  lazy val ktaeContractsBoardRoot_complete : String =
    """CDDContractsBoard {
      |  dateIngestion = "2020-08-08"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 4
      |  schemaPath = "src/test/resources/schemas/contracts/t_ktae_contract_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/contractsIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/contractsIngestion/principal"
      |  }"""

  lazy val ksanEomContract_correct : String =
    """|  ksanEomContract = {
       |    dataPath = "src/test/resources/data/ksanEomContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_contract_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_contract_relevant_renamed"
       |    }
       |    selectTablonFields = [
       |      "gf_local_contract_number_id",
       |      "g_security_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "gf_installment_maturity_date",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "gf_back_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_front_sys_trd_id",
       |      "gf_management_portfolio_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized",
       |      "g_t_kctk_risk_scoring_atrb_relevant",
       |      "g_t_kctk_risk_scoring_atrb_relevant_renamed",
       |      "g_t_kctk_risk_scoring_atrb_relevant_initialized",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
       |      "g_t_kdeo_writeoff_contract_relevant",
       |      "g_t_kdeo_writeoff_contract_relevant_renamed",
       |      "g_t_kdeo_writeoff_contract_relevant_initialized",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized",
       |      "g_t_ksan_eom_assets_liabilities_relevant",
       |      "g_t_ksan_eom_assets_liabilities_relevant_renamed",
       |      "g_t_ksan_eom_assets_liabilities_relevant_initialized",
       |      "g_t_ksan_eom_cont_segmentation_relevant",
       |      "g_t_ksan_eom_cont_segmentation_relevant_renamed",
       |      "g_t_ksan_eom_cont_segmentation_relevant_initialized",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
       |      "g_t_ksan_eom_internal_depo_relevant",
       |      "g_t_ksan_eom_internal_depo_relevant_renamed",
       |      "g_t_ksan_eom_internal_depo_relevant_initialized",
       |      "g_t_ksan_eom_out_of_bal_items_relevant",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized",
       |      "g_t_kstm_s_assets_liabilities_relevant",
       |      "g_t_kstm_s_assets_liabilities_relevant_renamed",
       |      "g_t_kstm_s_assets_liabilities_relevant_initialized",
       |      "g_t_kstm_s_internal_depo_relevant",
       |      "g_t_kstm_s_internal_depo_relevant_renamed",
       |      "g_t_kstm_s_internal_depo_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_relevant",
       |      "g_t_kstm_s_off_balance_items_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_relevant_initialized",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized",
       |      "g_t_xdrd_portfolio_data_relevant",
       |      "g_t_xdrd_portfolio_data_relevant_renamed",
       |      "g_t_xdrd_portfolio_data_relevant_initialized"]
       |    fields = {
       |      finalBoardPks = ["gf_local_contract_number_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_installment_maturity_date",
       |      "g_security_id",
       |      "gf_management_portfolio_id",
       |      "gf_origin_application_id",
       |      "gf_front_sys_trd_id",
       |      "gf_back_sys_trd_id"]
       |    }
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomContract_badSelect : String =
    """|  ksanEomContract = {
       |    dataPath = "src/test/resources/data/ksanEomContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_contract_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_contract_relevant_renamed"
       |    }
       |    selectTablonFields = [
       |      "gf_local_contract_number_id",
       |      "g_security_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "gf_installment_maturity_date",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "gf_back_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_front_sys_trd_id",
       |      "gf_management_portfolio_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized",
       |      "g_t_kctk_risk_scoring_atrb_relevant",
       |      "g_t_kctk_risk_scoring_atrb_relevant_renamed",
       |      "g_t_kctk_risk_scoring_atrb_relevant_initialized",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
       |      "g_t_kdeo_writeoff_contract_relevant",
       |      "g_t_kdeo_writeoff_contract_relevant_renamed",
       |      "g_t_kdeo_writeoff_contract_relevant_initialized",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized",
       |      "g_t_ksan_eom_assets_liabilities_relevant",
       |      "g_t_ksan_eom_assets_liabilities_relevant_renamed",
       |      "g_t_ksan_eom_assets_liabilities_relevant_initialized",
       |      "g_t_ksan_eom_cont_segmentation_relevant",
       |      "g_t_ksan_eom_cont_segmentation_relevant_renamed",
       |      "g_t_ksan_eom_cont_segmentation_relevant_initialized",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
       |      "g_t_ksan_eom_internal_depo_relevant",
       |      "g_t_ksan_eom_internal_depo_relevant_renamed",
       |      "g_t_ksan_eom_internal_depo_relevant_initialized",
       |      "g_t_ksan_eom_out_of_bal_items_relevant",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized",
       |      "g_t_kstm_s_assets_liabilities_relevant",
       |      "g_t_kstm_s_assets_liabilities_relevant_renamed",
       |      "g_t_kstm_s_assets_liabilities_relevant_initialized",
       |      "g_t_kstm_s_internal_depo_relevant",
       |      "g_t_kstm_s_internal_depo_relevant_renamed",
       |      "g_t_kstm_s_internal_depo_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_relevant",
       |      "g_t_kstm_s_off_balance_items_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_relevant_initialized",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized",
       |      "g_t_xdrd_portfolio_data_relevant",
       |      "g_t_xdrd_portfolio_data_relevant_renamed",
       |      "g_t_xdrd_portfolio_data_relevant_initialized",
       |      "aaaaaaaaaaaaaa"]
       |    fields = {
       |      finalBoardPks = ["gf_local_contract_number_id",
       |        "g_cont_main_holder_cust_id",
       |        "g_party_type",
       |        "gf_cust_view_lcl_contract_id",
       |        "gf_installment_maturity_date",
       |        "g_security_id",
       |        "gf_management_portfolio_id",
       |        "gf_origin_application_id",
       |        "gf_front_sys_trd_id",
       |        "gf_back_sys_trd_id"]
       |    }
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomContract_missSelect : String =
    """|  ksanEomContract = {
       |    dataPath = "src/test/resources/data/ksanEomContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_contract_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_contract_relevant_renamed"
       |    }
       |    fields = {
       |      finalBoardPks = ["gf_local_contract_number_id",
       |        "g_cont_main_holder_cust_id",
       |        "g_party_type",
       |        "gf_cust_view_lcl_contract_id",
       |        "gf_installment_maturity_date",
       |        "g_security_id",
       |        "gf_management_portfolio_id",
       |        "gf_origin_application_id",
       |        "gf_front_sys_trd_id",
       |        "gf_back_sys_trd_id"]
       |    }
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomContract_badJoinFields : String =
    """|  ksanEomContract = {
       |    dataPath = "src/test/resources/data/ksanEomContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_contract_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_contract_relevant_renamed"
       |    }
       |    selectTablonFields = [
       |      "gf_local_contract_number_id",
       |      "g_security_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "gf_installment_maturity_date",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "gf_back_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_front_sys_trd_id",
       |      "gf_management_portfolio_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized",
       |      "g_t_kctk_risk_scoring_atrb_relevant",
       |      "g_t_kctk_risk_scoring_atrb_relevant_renamed",
       |      "g_t_kctk_risk_scoring_atrb_relevant_initialized",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
       |      "g_t_kdeo_writeoff_contract_relevant",
       |      "g_t_kdeo_writeoff_contract_relevant_renamed",
       |      "g_t_kdeo_writeoff_contract_relevant_initialized",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized",
       |      "g_t_ksan_eom_assets_liabilities_relevant",
       |      "g_t_ksan_eom_assets_liabilities_relevant_renamed",
       |      "g_t_ksan_eom_assets_liabilities_relevant_initialized",
       |      "g_t_ksan_eom_cont_segmentation_relevant",
       |      "g_t_ksan_eom_cont_segmentation_relevant_renamed",
       |      "g_t_ksan_eom_cont_segmentation_relevant_initialized",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
       |      "g_t_ksan_eom_internal_depo_relevant",
       |      "g_t_ksan_eom_internal_depo_relevant_renamed",
       |      "g_t_ksan_eom_internal_depo_relevant_initialized",
       |      "g_t_ksan_eom_out_of_bal_items_relevant",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized",
       |      "g_t_kstm_s_assets_liabilities_relevant",
       |      "g_t_kstm_s_assets_liabilities_relevant_renamed",
       |      "g_t_kstm_s_assets_liabilities_relevant_initialized",
       |      "g_t_kstm_s_internal_depo_relevant",
       |      "g_t_kstm_s_internal_depo_relevant_renamed",
       |      "g_t_kstm_s_internal_depo_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_relevant",
       |      "g_t_kstm_s_off_balance_items_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_relevant_initialized",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized",
       |      "g_t_xdrd_portfolio_data_relevant",
       |      "g_t_xdrd_portfolio_data_relevant_renamed",
       |      "g_t_xdrd_portfolio_data_relevant_initialized"]
       |    fields = {
       |      finalBoardPks = ["gf_local_contract_number_id",
       |        "g_cont_main_holder_cust_id",
       |        "g_party_type",
       |        "gf_cust_view_lcl_contract_id",
       |        "gf_installment_maturity_date",
       |        "g_security_id",
       |        "gf_management_portfolio_id",
       |        "gf_origin_application_id",
       |        "gf_front_sys_trd_id",
       |        "gf_back_sys_trd_id"]
       |    }
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomContract_badFields : String =
    """|  ksanEomContract = {
       |    dataPath = "src/test/resources/data/ksanEomContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_contract_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_contract_relevant_renamed"
       |    }
       |    selectTablonFields = [
       |      "gf_local_contract_number_id",
       |      "g_security_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "gf_installment_maturity_date",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "gf_back_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_front_sys_trd_id",
       |      "gf_management_portfolio_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized",
       |      "g_t_kctk_risk_scoring_atrb_relevant",
       |      "g_t_kctk_risk_scoring_atrb_relevant_renamed",
       |      "g_t_kctk_risk_scoring_atrb_relevant_initialized",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
       |      "g_t_kdeo_writeoff_contract_relevant",
       |      "g_t_kdeo_writeoff_contract_relevant_renamed",
       |      "g_t_kdeo_writeoff_contract_relevant_initialized",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized",
       |      "g_t_ksan_eom_assets_liabilities_relevant",
       |      "g_t_ksan_eom_assets_liabilities_relevant_renamed",
       |      "g_t_ksan_eom_assets_liabilities_relevant_initialized",
       |      "g_t_ksan_eom_cont_segmentation_relevant",
       |      "g_t_ksan_eom_cont_segmentation_relevant_renamed",
       |      "g_t_ksan_eom_cont_segmentation_relevant_initialized",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
       |      "g_t_ksan_eom_internal_depo_relevant",
       |      "g_t_ksan_eom_internal_depo_relevant_renamed",
       |      "g_t_ksan_eom_internal_depo_relevant_initialized",
       |      "g_t_ksan_eom_out_of_bal_items_relevant",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized",
       |      "g_t_kstm_s_assets_liabilities_relevant",
       |      "g_t_kstm_s_assets_liabilities_relevant_renamed",
       |      "g_t_kstm_s_assets_liabilities_relevant_initialized",
       |      "g_t_kstm_s_internal_depo_relevant",
       |      "g_t_kstm_s_internal_depo_relevant_renamed",
       |      "g_t_kstm_s_internal_depo_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_relevant",
       |      "g_t_kstm_s_off_balance_items_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_relevant_initialized",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized",
       |      "g_t_xdrd_portfolio_data_relevant",
       |      "g_t_xdrd_portfolio_data_relevant_renamed",
       |      "g_t_xdrd_portfolio_data_relevant_initialized"]
       |    fields = {
       |      finalBoardPks = ["gf_local_contract_number_id",
       |        "g_cont_main_holder_cust_id",
       |        "g_party_type",
       |        "gf_cust_view_lcl_contract_id",
       |        "gf_installment_maturity_date",
       |        "g_security_id",
       |        "gf_management_portfolio_id",
       |        "gf_origin_application_id",
       |        "gf_front_sys_trd_id",
       |        "gf_back_sys_trd_id"]
       |    }
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomContract_missFields : String =
    """|  ksanEomContract = {
       |    dataPath = "src/test/resources/data/ksanEomContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_contract_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_contract_relevant_renamed"
       |    }
       |    selectTablonFields = [
       |      "gf_local_contract_number_id",
       |      "g_security_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "gf_installment_maturity_date",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "gf_back_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_front_sys_trd_id",
       |      "gf_management_portfolio_id",
       |      "g_t_ksan_eom_contract_relevant",
       |      "g_t_ksan_eom_contract_relevant_renamed",
       |      "g_t_ksan_eom_contract_relevant_initialized",
       |      "g_t_kctk_risk_scoring_atrb_relevant",
       |      "g_t_kctk_risk_scoring_atrb_relevant_renamed",
       |      "g_t_kctk_risk_scoring_atrb_relevant_initialized",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_initialized",
       |      "g_t_kdeo_writeoff_contract_relevant",
       |      "g_t_kdeo_writeoff_contract_relevant_renamed",
       |      "g_t_kdeo_writeoff_contract_relevant_initialized",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized",
       |      "g_t_ksan_eom_assets_liabilities_relevant",
       |      "g_t_ksan_eom_assets_liabilities_relevant_renamed",
       |      "g_t_ksan_eom_assets_liabilities_relevant_initialized",
       |      "g_t_ksan_eom_cont_segmentation_relevant",
       |      "g_t_ksan_eom_cont_segmentation_relevant_renamed",
       |      "g_t_ksan_eom_cont_segmentation_relevant_initialized",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized",
       |      "g_t_ksan_eom_internal_depo_relevant",
       |      "g_t_ksan_eom_internal_depo_relevant_renamed",
       |      "g_t_ksan_eom_internal_depo_relevant_initialized",
       |      "g_t_ksan_eom_out_of_bal_items_relevant",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_initialized",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized",
       |      "g_t_kstm_s_assets_liabilities_relevant",
       |      "g_t_kstm_s_assets_liabilities_relevant_renamed",
       |      "g_t_kstm_s_assets_liabilities_relevant_initialized",
       |      "g_t_kstm_s_internal_depo_relevant",
       |      "g_t_kstm_s_internal_depo_relevant_renamed",
       |      "g_t_kstm_s_internal_depo_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_relevant",
       |      "g_t_kstm_s_off_balance_items_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_relevant_initialized",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized",
       |      "g_t_xdrd_portfolio_data_relevant",
       |      "g_t_xdrd_portfolio_data_relevant_renamed",
       |      "g_t_xdrd_portfolio_data_relevant_initialized"]
       |    fields = {
       |      finalBoardPks = ["gf_local_contract_number_id",
       |        "g_cont_main_holder_cust_id",
       |        "g_party_type",
       |        "gf_cust_view_lcl_contract_id",
       |        "gf_installment_maturity_date",
       |        "g_security_id",
       |        "gf_management_portfolio_id",
       |        "gf_origin_application_id",
       |        "gf_front_sys_trd_id",
       |        "gf_back_sys_trd_id"]
       |    }
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkRiskScoringAtrb_correct : String =
    """|  kctkRiskScoringAtrb = {
       |    dataPath = "src/test/resources/data/kctkRiskScoringAtrb/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kctk_risk_scoring_atrb.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kctk_risk_scoring_atrb_relevant",
       |      "g_t_kctk_risk_scoring_atrb_relevant_renamed",
       |      "g_t_kctk_risk_scoring_atrb_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_risk_scoring_atrb_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_risk_scoring_atrb_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kdeoInapprtContSitutn_correct : String =
    """|  kdeoInapprtContSitutn = {
       |    dataPath = "src/test/resources/data/kdeoInapprtContSitutn/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kdeo_inapprt_cont_situtn.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cont_situtn_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kdeo_inapprt_cont_situtn_relevant_to_rename"
       |      newFieldNames = "g_t_kdeo_inapprt_cont_situtn_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kdeoWriteoffContract_correct : String =
    """|  kdeoWriteoffContract = {
       |    dataPath = "src/test/resources/data/kdeoWriteoffContract/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kdeo_writeoff_contract.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kdeo_writeoff_contract_relevant",
       |      "g_t_kdeo_writeoff_contract_relevant_renamed",
       |      "g_t_kdeo_writeoff_contract_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kdeo_writeoff_contract_relevant_to_rename"
       |      newFieldNames = "g_t_kdeo_writeoff_contract_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val krdcIssuancesFixedIncome_one_partition : String =
    """|  krdcIssuancesFixedIncome = {
       |    dataPath = "src/test/resources/data/krdcIssuancesFixedIncome/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_krdc_issuances_fixed_income_one_partition.json"
       |    relevantFields = ["g_security_id",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_krdc_issuances_fixed_income_relevant_to_rename"
       |      newFieldNames = "g_t_krdc_issuances_fixed_income_relevant_renamed"
       |    }
       |    joinFields = ["g_security_id"]
       |    previousFilterAppliedFields = ["gf_odate_date_id"]
       |  }"""

  lazy val krdcIssuancesFixedIncome_correct : String =
    """|  krdcIssuancesFixedIncome = {
       |    dataPath = "src/test/resources/data/krdcIssuancesFixedIncome/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_krdc_issuances_fixed_income_one_partition.json"
       |    relevantFields = ["g_security_id",
       |      "g_t_krdc_issuances_fixed_income_relevant",
       |      "g_t_krdc_issuances_fixed_income_relevant_renamed",
       |      "g_t_krdc_issuances_fixed_income_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_krdc_issuances_fixed_income_relevant_to_rename"
       |      newFieldNames = "g_t_krdc_issuances_fixed_income_relevant_renamed"
       |    }
       |    joinFields = ["g_security_id"]
       |    previousFilterAppliedFields = ["gf_odate_date_id",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomAssetsLiabilities_correct : String =
    """|  ksanEomAssetsLiabilities = {
       |    dataPath = "src/test/resources/data/ksanEomAssetsLiabilities/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_assets_liabilities.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_assets_liabilities_relevant",
       |      "g_t_ksan_eom_assets_liabilities_relevant_renamed",
       |      "g_t_ksan_eom_assets_liabilities_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_assets_liabilities_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_assets_liabilities_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomContSegmentation_correct : String =
    """|  ksanEomContSegmentation = {
       |    dataPath = "src/test/resources/data/ksanEomContSegmentation/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_cont_segmentation.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_cont_segmentation_relevant",
       |      "g_t_ksan_eom_cont_segmentation_relevant_renamed",
       |      "g_t_ksan_eom_cont_segmentation_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_cont_segmentation_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_cont_segmentation_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomDomesticInterveners_correct : String =
    """|  ksanEomDomesticInterveners = {
       |    dataPath = "src/test/resources/data/ksanEomDomesticInterveners/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_domestic_interveners.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_main_holder_customer_type",
       |      "g_party_type",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_domestic_interveners_relevant_to_rename;g_customer_id"
       |      newFieldNames = "g_t_ksan_eom_domestic_interveners_relevant_renamed;g_cont_main_holder_cust_id"
       |    }
       |    fields = {
       |      holderCustomerType = "g_main_holder_customer_type"
       |      holderCustomerTypeAllowedValue = "Y"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomDomesticInterveners_badFields : String =
    """|  ksanEomDomesticInterveners = {
       |    dataPath = "src/test/resources/data/ksanEomDomesticInterveners/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_domestic_interveners.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_domestic_interveners_relevant_to_rename;g_customer_id"
       |      newFieldNames = "g_t_ksan_eom_domestic_interveners_relevant_renamed;g_cont_main_holder_cust_id"
       |    }
       |    fields = {
       |      holderCustomerType = "bad_g_main_holder_customer_type"
       |      holderCustomerTypeAllowedValue = "Y"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomDomesticInterveners_missFields : String =
    """|  ksanEomDomesticInterveners = {
       |    dataPath = "src/test/resources/data/ksanEomDomesticInterveners/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_domestic_interveners.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_party_type",
       |      "g_t_ksan_eom_domestic_interveners_relevant",
       |      "g_t_ksan_eom_domestic_interveners_relevant_renamed",
       |      "g_t_ksan_eom_domestic_interveners_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_domestic_interveners_relevant_to_rename;g_customer_id"
       |      newFieldNames = "g_t_ksan_eom_domestic_interveners_relevant_renamed;g_cont_main_holder_cust_id"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomInstlmntPlan_correct : String =
    """|  ksanEomInstlmntPlan = {
       |    dataPath = "src/test/resources/data/ksanEomInstlmntPlan/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_instlmnt_plan.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "gf_installment_maturity_date",
       |      "gf_instlmt_interest_bc_amount",
       |      "gf_instlmt_total_bc_amount",
       |      "gf_instlmt_principal_bc_amount",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_instlmnt_plan_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_instlmnt_plan_relevant_renamed"
       |    }
       |    fields = {
       |      localContractId = "gf_local_contract_number_id"
       |      maturityDate = "gf_installment_maturity_date"
       |      interestAmount = "gf_instlmt_interest_bc_amount"
       |      totalAmount = "gf_instlmt_total_bc_amount"
       |      principalAmount = "gf_instlmt_principal_bc_amount"
       |      totalAmountLast = "gf_lst_instlmt_tot_bc_amount"
       |      principalAmountLast = "gf_lst_instlmt_amort_bc_amount"
       |      interestAmountLast = "gf_lst_instlmt_int_bc_amount"
       |      totalAmountActual = "gf_nxt_instlmt_tot_bc_amount"
       |      principalAmountActual = "gf_nxt_instlmt_amort_bc_amount"
       |      interestAmountActual = "gf_nxt_instlmt_int_bc_amount"
       |      totalAmountPrevious = "gf_pv_instlmt_tot_bc_amount"
       |      principalAmountPrevious = "gf_pv_instlmt_amort_bc_amount"
       |      interestAmountPrevious = "gf_pv_instlmt_int_bc_amount"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val ksanEomInstlmntPlan_badFields : String =
    """|  ksanEomInstlmntPlan = {
       |    dataPath = "src/test/resources/data/ksanEomInstlmntPlan/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_instlmnt_plan.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "gf_installment_maturity_date",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_instlmnt_plan_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_instlmnt_plan_relevant_renamed"
       |    }
       |    fields = {
       |      localContractId = "bad_gf_local_contract_number_id"
       |      maturityDate = "gf_installment_maturity_date"
       |      interestAmount = "gf_instlmt_interest_bc_amount"
       |      totalAmount = "gf_instlmt_total_bc_amount"
       |      principalAmount = "gf_instlmt_principal_bc_amount"
       |      totalAmountLast = "gf_lst_instlmt_tot_bc_amount"
       |      principalAmountLast = "gf_lst_instlmt_amort_bc_amount"
       |      interestAmountLast = "gf_lst_instlmt_int_bc_amount"
       |      totalAmountActual = "gf_nxt_instlmt_tot_bc_amount"
       |      principalAmountActual = "gf_nxt_instlmt_amort_bc_amount"
       |      interestAmountActual = "gf_nxt_instlmt_int_bc_amount"
       |      totalAmountPrevious = "gf_pv_instlmt_tot_bc_amount"
       |      principalAmountPrevious = "gf_pv_instlmt_amort_bc_amount"
       |      interestAmountPrevious = "gf_pv_instlmt_int_bc_amount"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val ksanEomInstlmntPlan_missFields : String =
    """|  ksanEomInstlmntPlan = {
       |    dataPath = "src/test/resources/data/ksanEomInstlmntPlan/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_instlmnt_plan.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "gf_installment_maturity_date",
       |      "g_t_ksan_eom_instlmnt_plan_relevant",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_renamed",
       |      "g_t_ksan_eom_instlmnt_plan_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_instlmnt_plan_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_instlmnt_plan_relevant_renamed"
       |    }
       |    fields = {
       |      maturityDate = "gf_installment_maturity_date"
       |      interestAmount = "gf_instlmt_interest_bc_amount"
       |      totalAmount = "gf_instlmt_total_bc_amount"
       |      principalAmount = "gf_instlmt_principal_bc_amount"
       |      totalAmountLast = "gf_lst_instlmt_tot_bc_amount"
       |      principalAmountLast = "gf_lst_instlmt_amort_bc_amount"
       |      interestAmountLast = "gf_lst_instlmt_int_bc_amount"
       |      totalAmountActual = "gf_nxt_instlmt_tot_bc_amount"
       |      principalAmountActual = "gf_nxt_instlmt_amort_bc_amount"
       |      interestAmountActual = "gf_nxt_instlmt_int_bc_amount"
       |      totalAmountPrevious = "gf_pv_instlmt_tot_bc_amount"
       |      principalAmountPrevious = "gf_pv_instlmt_amort_bc_amount"
       |      interestAmountPrevious = "gf_pv_instlmt_int_bc_amount"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomInternalDepo_correct : String =
    """|  ksanEomInternalDepo = {
       |    dataPath = "src/test/resources/data/ksanEomInternalDepo/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_internal_depo.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_internal_depo_relevant",
       |      "g_t_ksan_eom_internal_depo_relevant_renamed",
       |      "g_t_ksan_eom_internal_depo_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_internal_depo_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_internal_depo_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomOutBalanceItems_correct : String =
    """|  ksanEomOutBalanceItems = {
       |    dataPath = "src/test/resources/data/ksanEomOutBalanceItems/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_out_of_bal_items.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_ksan_eom_out_of_bal_items_relevant",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_renamed",
       |      "g_t_ksan_eom_out_of_bal_items_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_out_of_bal_items_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_out_of_bal_items_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomRenumerations_correct : String =
    """|  ksanEomRenumerations = {
       |    dataPath = "src/test/resources/data/ksanEomRenumerations/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_renumerations.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_renumerations_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_renumerations_relevant_renamed"
       |    }
       |    fields = {
       |      localContractId = "gf_local_contract_number_id"
       |      contractIdInitDate = "gf_new_contract_id_init_date"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomRenumerations_badFields : String =
    """|  ksanEomRenumerations = {
       |    dataPath = "src/test/resources/data/ksanEomRenumerations/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_renumerations.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_renumerations_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_renumerations_relevant_renamed"
       |    }
       |    fields = {
       |      localContractId = "bad_gf_local_contract_number_id"
       |      contractIdInitDate = "gf_new_contract_id_init_date"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksanEomRenumerations_missFields : String =
    """|  ksanEomRenumerations = {
       |    dataPath = "src/test/resources/data/ksanEomRenumerations/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_ksan_eom_renumerations.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "gf_cust_view_lcl_contract_id",
       |      "gf_new_contract_id_init_date",
       |      "g_t_ksan_eom_renumerations_relevant",
       |      "g_t_ksan_eom_renumerations_relevant_renamed",
       |      "g_t_ksan_eom_renumerations_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksan_eom_renumerations_relevant_to_rename"
       |      newFieldNames = "g_t_ksan_eom_renumerations_relevant_renamed"
       |    }
       |    fields = {
       |      contractIdInitDate = "gf_new_contract_id_init_date"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kstmAssetsLiabilities_correct : String =
    """|  kstmAssetsLiabilities = {
       |    dataPath = "src/test/resources/data/kstmAssetsLiabilities/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kstm_s_assets_liabilities.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kstm_s_assets_liabilities_relevant",
       |      "g_t_kstm_s_assets_liabilities_relevant_renamed",
       |      "g_t_kstm_s_assets_liabilities_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kstm_s_assets_liabilities_relevant_to_rename"
       |      newFieldNames = "g_t_kstm_s_assets_liabilities_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val kstmInternalDepo_correct : String =
    """|  kstmInternalDepo = {
       |    dataPath = "src/test/resources/data/kstmInternalDepo/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kstm_s_internal_depo.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kstm_s_internal_depo_relevant",
       |      "g_t_kstm_s_internal_depo_relevant_renamed",
       |      "g_t_kstm_s_internal_depo_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kstm_s_internal_depo_relevant_to_rename"
       |      newFieldNames = "g_t_kstm_s_internal_depo_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val kstmOffBalanceItems_correct : String =
    """|  kstmOffBalanceItems = {
       |    dataPath = "src/test/resources/data/kstmOffBalanceItems/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kstm_s_off_balance_items.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kstm_s_off_balance_items_relevant",
       |      "g_t_kstm_s_off_balance_items_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kstm_s_off_balance_items_relevant_to_rename"
       |      newFieldNames = "g_t_kstm_s_off_balance_items_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val nztgTradeCoreInfBoEom_correct : String =
    """|  nztgTradeCoreInfBoEom = {
       |    dataPath = "src/test/resources/data/nztgTradeCoreInfBoEom/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_nztg_trade_core_inf_bo_eom.json"
       |    relevantFields = ["gf_back_sys_trd_id",
       |      "gf_origin_application_id",
       |      "g_security_id",
       |      "gf_front_sys_trd_id",
       |      "gf_management_portfolio_id",
       |      "gf_local_contract_number_id",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed",
       |      "g_t_nztg_trade_core_inf_bo_eom_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_nztg_trade_core_inf_bo_eom_relevant_to_rename"
       |      newFieldNames = "g_t_nztg_trade_core_inf_bo_eom_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val xctkWrongWayRisk_onePartition : String =
    """|  xctkWrongWayRisk = {
       |    dataPath = "src/test/resources/data/xctkWrongWayRisk/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_xctk_wrong_way_risk_one_partition.json"
       |    relevantFields = ["gf_front_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_trd_wwr_ind_type",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_xctk_wrong_way_risk_relevant_to_rename"
       |      newFieldNames = "g_t_xctk_wrong_way_risk_relevant_renamed"
       |    }
       |    fields = {
       |      wwrColumnIfDuplicate = "gf_trd_wwr_ind_type"
       |      wwrValueIfDuplicate = "N"
       |    }
       |    joinFields = ["gf_origin_application_id","gf_front_sys_trd_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val xctkWrongWayRisk_correct : String =
    """|  xctkWrongWayRisk = {
       |    dataPath = "src/test/resources/data/xctkWrongWayRisk/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_xctk_wrong_way_risk_one_partition.json"
       |    relevantFields = ["gf_front_sys_trd_id",
       |      "gf_origin_application_id",
       |      "gf_trd_wwr_ind_type",
       |      "g_t_xctk_wrong_way_risk_relevant",
       |      "g_t_xctk_wrong_way_risk_relevant_renamed",
       |      "g_t_xctk_wrong_way_risk_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_xctk_wrong_way_risk_relevant_to_rename"
       |      newFieldNames = "g_t_xctk_wrong_way_risk_relevant_renamed"
       |    }
       |    fields = {
       |      wwrColumnIfDuplicate = "gf_trd_wwr_ind_type"
       |      wwrValueIfDuplicate = "N"
       |    }
       |    joinFields = ["gf_origin_application_id","gf_front_sys_trd_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkOpportunityRiskMgmt_correct : String =
    """|  kctkOpportunityRiskMgmt = {
       |    dataPath = "src/test/resources/data/kctkOpportunityRiskMgmt/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kctk_opportunity_risk_mgmt.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kctk_opportunity_risk_mgmt_relevant",
       |      "g_t_kctk_opportunity_risk_mgmt_relevant_renamed",
       |      "g_t_kctk_opportunity_risk_mgmt_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_opportunity_risk_mgmt_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_opportunity_risk_mgmt_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kdeoCovidMeasure_correct : String =
    """|  kdeoCovidMeasure = {
       |    dataPath = "src/test/resources/data/kdeoCovidMeasure/parquet/"
       |    schemaPath = "src/test/resources/schemas/contracts/RQ42021/t_kdeo_covid_measure.json"
       |    relevantFields = ["gf_local_contract_number_id",
       |      "g_t_kdeo_covid_measure_relevant",
       |      "g_t_kdeo_covid_measure_relevant_renamed",
       |      "g_t_kdeo_covid_measure_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kdeo_covid_measure_relevant_to_rename"
       |      newFieldNames = "g_t_kdeo_covid_measure_relevant_renamed"
       |    }
       |    joinFields = ["gf_local_contract_number_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val rootConfig: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin + """
      """.stripMargin + ksanEomContract_correct.stripMargin + """
      """.stripMargin + kctkRiskScoringAtrb_correct.stripMargin + """
      """.stripMargin + kdeoInapprtContSitutn_correct.stripMargin + """
      """.stripMargin + kdeoWriteoffContract_correct.stripMargin + """
      """.stripMargin + krdcIssuancesFixedIncome_correct.stripMargin + """
      """.stripMargin + ksanEomAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + ksanEomContSegmentation_correct.stripMargin + """
      """.stripMargin + ksanEomDomesticInterveners_correct.stripMargin + """
      """.stripMargin + ksanEomInstlmntPlan_correct.stripMargin + """
      """.stripMargin + ksanEomInternalDepo_correct.stripMargin + """
      """.stripMargin + ksanEomOutBalanceItems_correct.stripMargin + """
      """.stripMargin + ksanEomRenumerations_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + kstmInternalDepo_correct.stripMargin + """
      """.stripMargin + kstmOffBalanceItems_correct.stripMargin + """
      """.stripMargin + nztgTradeCoreInfBoEom_correct.stripMargin + """
      """.stripMargin + xctkWrongWayRisk_correct.stripMargin + """
      """.stripMargin + kctkOpportunityRiskMgmt_correct.stripMargin + """
      """.stripMargin + kdeoCovidMeasure_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigBadSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin + """
      """.stripMargin + ksanEomContract_badSelect.stripMargin + """
                                                                   |}
                                                                   |""".stripMargin)

  lazy val rootConfigMissSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin + """
      """.stripMargin + ksanEomContract_missSelect.stripMargin + """
      """.stripMargin + kctkRiskScoringAtrb_correct.stripMargin + """
      """.stripMargin + kdeoInapprtContSitutn_correct.stripMargin + """
      """.stripMargin + kdeoWriteoffContract_correct.stripMargin + """
      """.stripMargin + krdcIssuancesFixedIncome_correct.stripMargin + """
      """.stripMargin + ksanEomAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + ksanEomContSegmentation_correct.stripMargin + """
      """.stripMargin + ksanEomDomesticInterveners_correct.stripMargin + """
      """.stripMargin + ksanEomInstlmntPlan_correct.stripMargin + """
      """.stripMargin + ksanEomInternalDepo_correct.stripMargin + """
      """.stripMargin + ksanEomOutBalanceItems_correct.stripMargin + """
      """.stripMargin + ksanEomRenumerations_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + kstmInternalDepo_correct.stripMargin + """
      """.stripMargin + kstmOffBalanceItems_correct.stripMargin + """
      """.stripMargin + nztgTradeCoreInfBoEom_correct.stripMargin + """
      """.stripMargin + xctkWrongWayRisk_correct.stripMargin + """
      """.stripMargin + kctkOpportunityRiskMgmt_correct.stripMargin + """
      """.stripMargin + kdeoCovidMeasure_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigBadJoinFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin  + """
      """.stripMargin + ksanEomContract_badJoinFields.stripMargin + """
      """.stripMargin + kctkRiskScoringAtrb_correct.stripMargin + """
      """.stripMargin + kdeoInapprtContSitutn_correct.stripMargin + """
      """.stripMargin + kdeoWriteoffContract_correct.stripMargin + """
      """.stripMargin + krdcIssuancesFixedIncome_correct.stripMargin + """
      """.stripMargin + ksanEomAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + ksanEomContSegmentation_correct.stripMargin + """
      """.stripMargin + ksanEomDomesticInterveners_correct.stripMargin + """
      """.stripMargin + ksanEomInstlmntPlan_correct.stripMargin + """
      """.stripMargin + ksanEomInternalDepo_correct.stripMargin + """
      """.stripMargin + ksanEomOutBalanceItems_correct.stripMargin + """
      """.stripMargin + ksanEomRenumerations_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + kstmInternalDepo_correct.stripMargin + """
      """.stripMargin + kstmOffBalanceItems_correct.stripMargin + """
      """.stripMargin + nztgTradeCoreInfBoEom_correct.stripMargin + """
      """.stripMargin + xctkWrongWayRisk_correct.stripMargin + """
      """.stripMargin + kctkOpportunityRiskMgmt_correct.stripMargin + """
      """.stripMargin + kdeoCovidMeasure_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigBadFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin  + """
      """.stripMargin + ksanEomContract_badFields.stripMargin + """
      """.stripMargin + kctkRiskScoringAtrb_correct.stripMargin + """
      """.stripMargin + kdeoInapprtContSitutn_correct.stripMargin + """
      """.stripMargin + kdeoWriteoffContract_correct.stripMargin + """
      """.stripMargin + krdcIssuancesFixedIncome_correct.stripMargin + """
      """.stripMargin + ksanEomAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + ksanEomContSegmentation_correct.stripMargin + """
      """.stripMargin + ksanEomDomesticInterveners_badFields.stripMargin + """
      """.stripMargin + ksanEomInstlmntPlan_badFields.stripMargin + """
      """.stripMargin + ksanEomInternalDepo_correct.stripMargin + """
      """.stripMargin + ksanEomOutBalanceItems_correct.stripMargin + """
      """.stripMargin + ksanEomRenumerations_badFields.stripMargin + """
      """.stripMargin + kstmAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + kstmInternalDepo_correct.stripMargin + """
      """.stripMargin + kstmOffBalanceItems_correct.stripMargin + """
      """.stripMargin + nztgTradeCoreInfBoEom_correct.stripMargin + """
      """.stripMargin + xctkWrongWayRisk_correct.stripMargin + """
      """.stripMargin + kctkOpportunityRiskMgmt_correct.stripMargin + """
      """.stripMargin + kdeoCovidMeasure_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigMissFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin  + """
      """.stripMargin + ksanEomContract_missFields.stripMargin + """
      """.stripMargin + kctkRiskScoringAtrb_correct.stripMargin + """
      """.stripMargin + kdeoInapprtContSitutn_correct.stripMargin + """
      """.stripMargin + kdeoWriteoffContract_correct.stripMargin + """
      """.stripMargin + krdcIssuancesFixedIncome_correct.stripMargin + """
      """.stripMargin + ksanEomAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + ksanEomContSegmentation_correct.stripMargin + """
      """.stripMargin + ksanEomDomesticInterveners_missFields.stripMargin + """
      """.stripMargin + ksanEomInstlmntPlan_missFields.stripMargin + """
      """.stripMargin + ksanEomInternalDepo_correct.stripMargin + """
      """.stripMargin + ksanEomOutBalanceItems_correct.stripMargin + """
      """.stripMargin + ksanEomRenumerations_missFields.stripMargin + """
      """.stripMargin + kstmAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + kstmInternalDepo_correct.stripMargin + """
      """.stripMargin + kstmOffBalanceItems_correct.stripMargin + """
      """.stripMargin + nztgTradeCoreInfBoEom_correct.stripMargin + """
      """.stripMargin + xctkWrongWayRisk_correct.stripMargin + """
      """.stripMargin + kctkOpportunityRiskMgmt_correct.stripMargin + """
      """.stripMargin + kdeoCovidMeasure_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigOnePartition: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeContractsBoardRoot_complete.stripMargin + """
      """.stripMargin + ksanEomContract_correct.stripMargin + """
      """.stripMargin + kctkRiskScoringAtrb_correct.stripMargin + """
      """.stripMargin + kdeoInapprtContSitutn_correct.stripMargin + """
      """.stripMargin + kdeoWriteoffContract_correct.stripMargin + """
      """.stripMargin + krdcIssuancesFixedIncome_one_partition.stripMargin + """
      """.stripMargin + ksanEomAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + ksanEomContSegmentation_correct.stripMargin + """
      """.stripMargin + ksanEomDomesticInterveners_correct.stripMargin + """
      """.stripMargin + ksanEomInstlmntPlan_correct.stripMargin + """
      """.stripMargin + ksanEomInternalDepo_correct.stripMargin + """
      """.stripMargin + ksanEomOutBalanceItems_correct.stripMargin + """
      """.stripMargin + ksanEomRenumerations_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabilities_correct.stripMargin + """
      """.stripMargin + kstmInternalDepo_correct.stripMargin + """
      """.stripMargin + kstmOffBalanceItems_correct.stripMargin + """
      """.stripMargin + nztgTradeCoreInfBoEom_correct.stripMargin + """
      """.stripMargin + xctkWrongWayRisk_onePartition.stripMargin + """
      """.stripMargin + kctkOpportunityRiskMgmt_correct.stripMargin + """
      """.stripMargin + kdeoCovidMeasure_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)
}
