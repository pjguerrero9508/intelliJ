package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSANEomAssetsLiabilitiesTest extends TestContracts{
  test("ksanEomAssetsLiabilities_wrap") {
    val instancia: KSANEomAssetsLiabilities = KSANEomAssetsLiabilities(testResources.ksanEomAssetsLiabilities_complete_input_testing, testResources.config)
    val result: KSANEomAssetsLiabilities = instancia.wrap(testResources.ksanEomAssetsLiabilities_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
