package com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.contracts.TestContracts
import com.bbva.projectsdatio.cdd.structuralboards.contracts.utils.TestUtils
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSANEomRenumerationsTest extends TestContracts{
  test("ksanEomRenumerations_wrap") {
    val instancia: KSANEomRenumerations = KSANEomRenumerations(testResources.ksanEomRenumerations_complete_input_testing, testResources.config)
    val result: KSANEomRenumerations = instancia.wrap(testResources.ksanEomRenumerations_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("ksanEomRenumerations_filterMaxInitDate") {
    val result: DataFrame = KSANEomRenumerations(testResources.ksanEomRenumerations_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_contracts_after_join_testing_datio_schema).getDataFrame()
   TestUtils.assertDataFrameEquals(result, testResources.ksanEomRenumerations_customized_testing, FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("ksanEomRenumerations_filterMaxInitDateBadFields") {
    assertThrows[AnalysisException] {
      KSANEomRenumerations(testResources.ksanEomRenumerations_complete_input_testing, testResources.configBadFields).filterMaxInitDate().getDataFrame()
    }
  }

  test("ksanEomRenumerations_filterMaxInitDateMissFields") {
    assertThrows[ParamNotInformedException] {
      KSANEomRenumerations(testResources.ksanEomRenumerations_complete_input_testing, testResources.configMissFields).filterMaxInitDate().getDataFrame()
    }
  }
}
