package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{SchemaReadingException, StructuralBoardsExceptionsController}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SparkCompactorController.{CompactorParams, buildAndLaunchCompactor, setCompactorReportIntoProcessFinalReport}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{SchemaReaderBoards, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GenericUtils, GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.api.SparkProcess
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

trait CDDStructuralBoardsApp extends SparkProcess {
  val mainEntity: String
  val configId: String
  val structuralBoard: String
  val boardTables: Seq[String]
  val defaultAverageKBPerRecord: Int
  val defaultRepartitionBase: Int
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  @throws[Exception]
  /**
   * @param runtimeContext RuntimeContext
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info(s"CDDStructuralboards: Init process $structuralBoard")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val config = runtimeContext.getConfig.getConfig(configId)
    Try {
      val globalParameterReaded: GlobalConfigurationReaded = setterGlobalConfigurationReadedParamsReader(config)
      val globalParameterTranslated: GlobalConfigurationTranslated =
        setterGlobalConfigurationReadedParamsTranslator(globalParameterReaded)
      val cddDataSetsToJoin: Map[String, CDDStructuralBoardsDataset[_]] =
        dataSetsMapper(globalParameterReaded, globalParameterTranslated, config, datioSparkSession)
      val tablon: DataFrame = joinTablon(cddDataSetsToJoin, globalParameterReaded, globalParameterTranslated, datioSparkSession)
        .selectTablonColumns()
        .getDataFrame()
      logger.info(s"CDDStructuralboards: $structuralBoard structural board generated")
      writerCDDBoard(datioSparkSession, tablon, globalParameterReaded, globalParameterTranslated)
    } match {
      case Success(_) =>
        logger.info(s"CDDStructuralboards: Process $structuralBoard successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.info(s"CDDStructuralboards: Something went wrong during $structuralBoard process")
        logger.error(s"CDDStructuralboards: Input Args: ${config.toString}")
        StructuralBoardsExceptionsController(exception = new Exception(ex),
          fileError = "CDDStructuralBoardsApp", methodError = "runProcess", exceptionMessage = ex.getMessage).exceptionTreatment
        logger.error(ex.getMessage)
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        logger.info(s"CDDStructuralboards: Finished process $structuralBoard")
        1
    }
  }

  @throws[SchemaReadingException]
  @throws[Exception]
  /**
   * This function creates a temporal backup, build the structural board.
   *
   * @param datioSparkSession Initialized DatioSparkSession
   * @param globalParameter   GlobalConfigurationReaded for Guarantee Structural Board
   * @return
   */
  def writerCDDBoard(datioSparkSession: DatioSparkSession,
                     df: DataFrame,
                     globalParameter: GlobalConfigurationReaded,
                     globalParameterTranslated: GlobalConfigurationTranslated): Unit = {
    logger.info(s"CDDStructuralboards: Init method writerCDDBoard")
    Try {
      logger.info(s"CDDStructuralboards: Read output schema")
      val outputSchema: DatioSchema = SchemaReaderBoards.readSchema(globalParameter.fullNameSchemaBoard)
      logger.info(s"CDDStructuralboards: Set Audit Date")
      val auditDf = GenericUtils.setActualAuditDate(df, globalParameter.auditColumnName)
      logger.info(s"CDDStructuralboards: Validate output schema in finish DataFrame")
      logger.info(s"CDDStructuralboards: Write the final dataframe")
      WriteUtils.dataprocSdkAppendWriter(datioSparkSession, auditDf, globalParameterTranslated.actualPrincipalPath,
        globalParameter, Seq("g_entific_id", "gf_cutoff_date"), outputSchema)
      logger.info(s"CDDStructuralboards: Started compactor process over final df")
      setCompactorReportIntoProcessFinalReport(
        buildAndLaunchCompactor(setCompactorParams(datioSparkSession, globalParameterTranslated, globalParameter), datioSparkSession))
      logger.info(s"CDDStructuralboards: DataFrame written in path ${globalParameterTranslated.actualPrincipalPath}")
    } match {
      case Success(_) =>
        logger.info(s"CDDStructuralboards: $structuralBoard Structural Board written successfully")
      case Failure(exception: SchemaReadingException) =>
        logger.info(s"CDDStructuralboards: $structuralBoard Structural Board not written, neither deleted")
        logger.info(s"CDDStructuralboards: Finished process $structuralBoard")
        StructuralBoardsExceptionsController(exception = exception,
          fileError = "CDDStructuralBoardsApp", methodError = "runProcess",
          exceptionMessage = exception.getMessage).exceptionTreatment
        throw exception
      case Failure(ex: Exception) =>
        logger.info(s"CDDStructuralboards: Read output schema")
        logger.info(s"CDDStructuralboards: Something went wrong during $structuralBoard Board generation")
        StructuralBoardsExceptionsController(exception = ex, fileError = "CDDStructuralBoardsApp", methodError = "writerCDDBoard",
          exceptionMessage = ex.getMessage).exceptionTreatment
        throw ex
    }
  }

  /**
   * Method that manages needed compactor params
   */
  val setCompactorParams: (DatioSparkSession, GlobalConfigurationTranslated, GlobalConfigurationReaded) => CompactorParams =
    (datioSparkSession: DatioSparkSession, globalParameterTranslated: GlobalConfigurationTranslated, globalConfiguration: GlobalConfigurationReaded) => {
      val compactor = CompactorParams(
        withSparkSession = datioSparkSession.getSparkSession,
        withCompactionMode = (TRUE_VALUE, Some("coalesce")),
        withOverwrite = (TRUE_VALUE, TRUE_VALUE),
        withRepartitionColumns = (FALSE_VALUE, List("gf_cutoff_date", "g_entific_id")),
        withPartitionsFilter = (TRUE_VALUE, List("g_entific_id=" + globalConfiguration.entificColumnValue
           + VAL_SLASH + "gf_cutoff_date=" + globalConfiguration.dateColumnValue)),
        sourcePath = globalParameterTranslated.actualPrincipalPath,
        targetPath = None)
      logger.info(s"Compactor params: ${compactor.toString}")
      compactor
    }

  /**
   * Checks if not informed dataset param is valid
   *
   * @param notInformedDatasets : Seq[String]
   */
  def checkNotInformedDataSets(notInformedDatasets: Seq[String]): Unit = {
    TechnicalValidation.stringNotInList(mainEntity, notInformedDatasets)
    if (!notInformedDatasets.head.equals("") || !notInformedDatasets.size.equals(1)) {
      TechnicalValidation.listStringValidator(notInformedDatasets, boardTables, CONF_NOT_INFORMED_DATASETS)
    }
  }

  /**
   * This method creates a Map using as Keys the dataset name and as Value its dataset content. If the dataset name
   * is informed in CONF_NOT_INFORMED_DATASETS, the dataset value will be an empty dataset with all its columns
   * values initialized with null.
   *
   * @param globalConfigurationReaded     : GlobalConfigurationReaded
   * @param globalConfigurationTranslated : GlobalConfigurationTranslated
   * @param config                        : Config
   * @return
   */
  def dataSetsMapper(globalConfigurationReaded: GlobalConfigurationReaded,
                     globalConfigurationTranslated: GlobalConfigurationTranslated,
                     config: Config,
                     datioSparkSession: DatioSparkSession): Map[String, CDDStructuralBoardsDataset[_]] = {
    val dataSetsToOperate: Seq[String] = boardTables
      .filterNot(globalConfigurationReaded.notInformedDatasets.contains(_))
    val cddDataSetsToJoinBuffered: ListBuffer[(String, CDDStructuralBoardsDataset[_])] = new ListBuffer()
    dataSetsToOperate.foreach(a => logger.info(s"CDDStructuralboards: $a ready"))
    // Add Datasets that will be read
    dataSetsToOperate
      .foldLeft(cddDataSetsToJoinBuffered)(
        (agg, dataset) => {
          cddDataSetsToJoinBuffered
            .append(
              dataSetCollectionMapper(dataset,
                globalConfigurationReaded,
                globalConfigurationTranslated,
                config,
                datioSparkSession)
                .get)
          logger.info(s"CDDStructuralboards: $dataset DONE")
          cddDataSetsToJoinBuffered
        })

    // Add Datasets that won't be read
    if (globalConfigurationReaded.notInformedDatasets.nonEmpty && (!globalConfigurationReaded.notInformedDatasets.toList.head.isEmpty)) {
      logger.info(s"CDDStructuralboards: notInformed ${globalConfigurationReaded.notInformedDatasets} ")
      globalConfigurationReaded.notInformedDatasets
        .foldLeft(cddDataSetsToJoinBuffered)(
          (agg, dataset) => {
            cddDataSetsToJoinBuffered
              .append(
                dataSetCollectionMapper(dataset,
                  globalConfigurationReaded,
                  globalConfigurationTranslated,
                  config,
                  datioSparkSession,
                  TRUE_VALUE)
                  .get)
            logger.info(s"CDDStructuralboards: $dataset initialized as Empty DataFrame DONE")
            cddDataSetsToJoinBuffered
          })
    }
    cddDataSetsToJoinBuffered.toMap.foreach(a =>
      logger.info(s"CDDStructuralboards: mapped ${a._1} -> ${a._2.getClass.toString}"))
    cddDataSetsToJoinBuffered.toMap
  }


  /**
   * This method setter global configurations read of config input
   *
   * @param config Config retrieved from args
   * @return CaseClass with all global parameter
   */
  def setterGlobalConfigurationReadedParamsReader(config: Config): GlobalConfigurationReaded = {
    logger.info(s"CDDStructuralboards: Init method setterGlobalConfigurationReadedParamsReader")
    TechnicalValidation.configStringParamValidator(CONF_DATE_INGESTION, config)
    val dateIngestion: String = config.getString(CONF_DATE_INGESTION)
    TechnicalValidation.dateValidator(dateIngestion, CONF_DATE_INGESTION)
    logger.info(s"CDDStructuralboards: Value of dateIngestion: $dateIngestion")
    CDDExecutionStats.addInputParamMessage("dateIngestion",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", dateIngestion)
    TechnicalValidation.configStringParamValidator(CONF_DATE_COLUMN_NAME, config)
    val dateColumnName: String = config.getString(CONF_DATE_COLUMN_NAME)
    logger.info(s"CDDStructuralboards: Name of dateColumn: $dateColumnName")
    CDDExecutionStats.addInputParamMessage("dateColumnName",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", dateColumnName)
    TechnicalValidation.configStringParamValidator(CONF_DATE_COLUMN_VALUE, config)
    val dateColumnValue: String = config.getString(CONF_DATE_COLUMN_VALUE)
    TechnicalValidation.dateValidator(dateColumnValue, CONF_DATE_COLUMN_VALUE)
    logger.info(s"CDDStructuralboards: Value of dateColumn: $dateColumnValue")
    CDDExecutionStats.addInputParamMessage("dateColumnValue",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", dateColumnValue)
    TechnicalValidation.configStringParamValidator(CONF_ENTIFIC_COLUMN_NAME, config)
    val entificColumnName: String = config.getString(CONF_ENTIFIC_COLUMN_NAME)
    logger.info(s"CDDStructuralboards: Name of entificColumn: $entificColumnName")
    CDDExecutionStats.addInputParamMessage("entificColumnName",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", entificColumnName)
    TechnicalValidation.configStringParamValidator(CONF_ENTIFIC_COLUMN_VALUE, config)
    val entificColumnValue: String = config.getString(CONF_ENTIFIC_COLUMN_VALUE)
    logger.info(s"CDDStructuralboards: Value of entificColumn: $entificColumnValue")
    CDDExecutionStats.addInputParamMessage("entificColumnValue",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", entificColumnValue)
    TechnicalValidation.configStringParamValidator(CONF_AUDIT_COLUMN_NAME, config)
    val auditColumnName: String = config.getString(CONF_AUDIT_COLUMN_NAME)
    logger.info(s"CDDStructuralboards: Name of auditDateColumn: $auditColumnName")
    CDDExecutionStats.addInputParamMessage("auditColumnName",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", auditColumnName)
    val averageKBPerRecord: Int = Try(config.getInt(CONF_AVERAGE_KB_PER_RECORD)).getOrElse(defaultAverageKBPerRecord)
    logger.info(s"CDDStructuralboards: Value of averageKBPerRecord: $averageKBPerRecord")
    CDDExecutionStats.addInputParamMessage("averageKBPerRecord",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", averageKBPerRecord.toString)
    TechnicalValidation.configStringParamValidator(CONF_SCHEMA_PATH, config)
    val fullNameSchema: String = config.getString(CONF_SCHEMA_PATH)
    logger.info(s"CDDStructuralboards: Value of fullNameSchema: $fullNameSchema")
    CDDExecutionStats.addInputParamMessage("fullNameSchema",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", fullNameSchema)
    TechnicalValidation.configStringParamValidator(CONF_TEMPORAL_PATH, config)
    val temporalPath: String = config.getString(CONF_TEMPORAL_PATH)
    logger.info(s"CDDStructuralboards: Value of temporalPath: $temporalPath")
    CDDExecutionStats.addInputParamMessage("temporalPath",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", temporalPath)
    TechnicalValidation.configStringParamValidator(CONF_PATH_OUTPUT_PRINCIPAL, config)
    val pathOutputPrincipal: String = config.getString(CONF_PATH_OUTPUT_PRINCIPAL)
    logger.info(s"CDDStructuralboards: Value of pathOutputPrincipal: $pathOutputPrincipal")
    CDDExecutionStats.addInputParamMessage("pathOutputPrincipal",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", pathOutputPrincipal)
    val repartitionBase: Int = Try(config.getInt(CONF_REPARTITION_BASE)).getOrElse(defaultRepartitionBase)
    logger.info(s"CDDStructuralboards: Value of repartitionBase: $repartitionBase")
    CDDExecutionStats.addInputParamMessage("repartitionBase",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", repartitionBase.toString)
    val notInformedDatasets: Seq[String] = Try(config.getString(CONF_NOT_INFORMED_DATASETS).split(BOARDS_SPLIT_CHAR).toSeq).getOrElse(Nil)
    logger.info(s"CDDStructuralboards: Value of notInformedDatasets: $notInformedDatasets")
    checkNotInformedDataSets(notInformedDatasets)
    CDDExecutionStats.addInputParamMessage("notInformedDatasets",
      "CDDStructuralBoardsApp", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_NOT_INFORMED_DATASETS))
    GlobalConfigurationReaded(dateIngestion,
      dateColumnName,
      dateColumnValue,
      entificColumnName,
      entificColumnValue,
      auditColumnName,
      averageKBPerRecord,
      fullNameSchema,
      temporalPath,
      pathOutputPrincipal,
      repartitionBase,
      notInformedDatasets)
  }

  def setterGlobalConfigurationReadedParamsTranslator(globalConfigurationReaded: GlobalConfigurationReaded): GlobalConfigurationTranslated = {
    val datioOutputSchema: DatioSchema = SchemaReaderBoards.readSchema(globalConfigurationReaded.fullNameSchemaBoard)
    val checkpointTempPath: String = globalConfigurationReaded.pathTemporal + VAL_CHECKPOINT
    logger.info(s"CDDStructuralboards: temporal checkpoint path is: $checkpointTempPath")
    val backupTempPath: String = globalConfigurationReaded.pathTemporal + VAL_BACKUP
    val actualPrincipalPath: String = globalConfigurationReaded.pathOutputBoard
    val actualPrincipalPathWithPartitions: String = globalConfigurationReaded.pathOutputBoard +
      VAL_SLASH + globalConfigurationReaded.entificColumnName + PARTITION_SPLIT_CHAR + globalConfigurationReaded.entificColumnValue +
      VAL_SLASH + globalConfigurationReaded.dateColumnName + PARTITION_SPLIT_CHAR + globalConfigurationReaded.dateColumnValue
    GlobalConfigurationTranslated(datioOutputSchema, checkpointTempPath, backupTempPath, actualPrincipalPath, actualPrincipalPathWithPartitions)
  }

  /**
   * This method generates, for the dataset informed in entityName param, a Tuple with its name in the first value
   * and the dataset that will be used in the board calculation in the second value. If emptyInitializeMode is set as "true",
   * the dataset that will be returned will have all it's values set to null
   *
   * @param entityName                    : String
   * @param globalConfigurationReaded     : GlobalConfigurationReaded
   * @param globalConfigurationTranslated : GlobalConfigurationTranslated
   * @param config                        : Config
   * @param emptyInitializeMode           : Boolean = false
   * @return
   */
  def dataSetCollectionMapper(entityName: String,
                              globalConfigurationReaded: GlobalConfigurationReaded,
                              globalConfigurationTranslated: GlobalConfigurationTranslated,
                              config: Config,
                              datioSparkSession: DatioSparkSession,
                              emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])]

  def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                 globalConfigurationReaded: GlobalConfigurationReaded,
                 globalConfigurationTranslated: GlobalConfigurationTranslated,
                 datioSparkSession: DatioSparkSession): CDDStructuralMainBoardDataset[_]

  override def getProcessId: String = configId
}
