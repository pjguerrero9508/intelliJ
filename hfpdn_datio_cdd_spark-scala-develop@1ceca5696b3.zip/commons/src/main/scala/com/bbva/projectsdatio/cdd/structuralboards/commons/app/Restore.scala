package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.appManager.RestorerManager
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{SchemaValidationException, StructuralBoardsExceptionsController, ValueParameterException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils.pathExists
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SparkCompactorController.CompactorParams
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{SchemaReaderBoards, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.api.SparkProcess
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.datio.dataproc.sdk.schema.exception.DataprocSchemaException
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConverters
import scala.util.{Failure, Success, Try}

/**
 * Main file for Restore process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * RestoreProcess {
 * ...
 * }
 *
 */
trait RestoreTrait extends SparkProcess {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  @throws[SchemaValidationException]
  @throws[ValueParameterException]
  @throws[Exception]
  /**
   * @param runtimeContext RuntimeContext
   * @return value 0 if process finished successfully; otherwise value 1
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info(s"CDDCommons: Init process Restore")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val dfs = DatioFileSystem.get()
    val config = runtimeContext.getConfig.getConfig("CDDRestore")
    Try {
      val globalParameter = setterGlobalConfigurationReadedParamsReader(config)
      if (pathExists(dfs, globalParameter.historicalPath)) {
        val outputSchema: DatioSchema = SchemaReaderBoards.readSchema(globalParameter.principalSchema)
        val filteredDf: DataFrame = RestorerManager
          .readSelectedPartition(datioSparkSession, globalParameter.historicalPath,
            globalParameter.histColumnsName, globalParameter.histColumnsValue, outputSchema)
        GenericUtils.emptyDfValidation(filteredDf, globalParameter.failIfNullDf)
        try {
          outputSchema.validate(filteredDf)
        } catch {
          case e: DataprocSchemaException.InvalidDatasetException =>
            val errors = JavaConverters.asScalaIteratorConverter(e.getErrors.iterator()).asScala.map(err => err.toString).mkString(", ")
            StructuralBoardsExceptionsController(exception = new SchemaValidationException(globalParameter.principalSchema),
              fileError = "Restore", methodError = "runProcess",
              exceptionMessage = s"DataprocSchemaException: schema validation errors " + s"${errors.mkString(", ")}").exceptionTreatment
            throw new SchemaValidationException(globalParameter.principalSchema)
        }
        logger.info(s"CDDRestore: Deleting corrupted information in principal path")
        RestorerManager
          .deleteBadPrincData(datioSparkSession, globalParameter.principalPath, globalParameter.princColumnsName, globalParameter.princColumnsValue)
        WriteUtils.restorePrincipalParquet(datioSparkSession, filteredDf, globalParameter.principalPath,
          globalParameter.repartitionBase, globalParameter.princColumnsName, outputSchema, globalParameter.averageKBPerRecord)
      } else {
        StructuralBoardsExceptionsController(exception = new ValueParameterException(globalParameter.historicalPath),
          fileError = "Restore", methodError = "runProcess",
          exceptionMessage = s"CDDRestore: historical path ${globalParameter.historicalPath} does not exist, there is no data to restore").exceptionTreatment
        throw new ValueParameterException(globalParameter.historicalPath)
      }
    } match {
      case Success(_) =>
        logger.info(s"CDDRestore: Process Restore successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.error(s"CDDRestore: Input Args: ${config.toString}")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        StructuralBoardsExceptionsController(exception = new Exception(ex), fileError = "Restore", methodError = "runProcess",
          exceptionMessage = s"CDDRestore: Something went wrong during restore process").exceptionTreatment
        logger.info(s"CDDRestore: Finished process Restore")
        1
    }
  }

  /**
   * Method that manages needed compactor params
   */
  val setCompactorParams: (DatioSparkSession, RestoreConfiguration) => CompactorParams =
    (datioSparkSession: DatioSparkSession, globalParameter: RestoreConfiguration) =>
      CompactorParams(
        withSparkSession = datioSparkSession.getSparkSession,
        withCompactionMode = (TRUE_VALUE, Some("coalesce")),
        withOverwrite = (TRUE_VALUE, TRUE_VALUE),
        withRepartitionColumns = (FALSE_VALUE, List()),
        sourcePath = globalParameter.principalPath,
        targetPath = None)

  /**
   * This method setter global configurations read from input config file
   *
   * @param config Config retrieved from args
   * @return CaseClass whit all global parameter
   */
  def setterGlobalConfigurationReadedParamsReader(config: Config): RestoreConfiguration = {
    logger.info(s"CDDRestore: Init method setterGlobalConfigurationReadedParamsReader")
    // Getter parameter from config file and validate required
    TechnicalValidation.configStringParamValidator(CONF_RESTORE_PATH_HISTORICAL, config)
    val historicalPath: String = config.getString(CONF_RESTORE_PATH_HISTORICAL)
    logger.info(s"CDDRestore: Value of pathHistorical: $historicalPath")
    CDDExecutionStats.addInputParamMessage("historicalPath",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", historicalPath)
    TechnicalValidation.configStringParamValidator(CONF_RESTORE_PATH_PRINCIPAL, config)
    val principalPath: String = config.getString(CONF_RESTORE_PATH_PRINCIPAL)
    logger.info(s"CDDRestore: Value of pathPrincipal: $principalPath")
    CDDExecutionStats.addInputParamMessage("principalPath",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", principalPath)
    TechnicalValidation.configStringParamValidator(CONF_RESTORE_PATH_SCHEMA_PRINCIPAL, config)
    val principalSchema: String = config.getString(CONF_RESTORE_PATH_SCHEMA_PRINCIPAL)
    logger.info(s"CDDRestore: Value of pathPrincipal: $principalSchema")
    CDDExecutionStats.addInputParamMessage("principalSchema",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", principalSchema)
    TechnicalValidation.configStringParamValidator(CONF_RESTORE_HIST_COLUMNS_NAME, config)
    val histColumnsName: Seq[String] = config.getString(CONF_RESTORE_HIST_COLUMNS_NAME).split(RESTORE_SPLIT_CHAR).toSeq
    logger.info(s"CDDRestore: Name of hist. partition columns: $histColumnsName")
    CDDExecutionStats.addInputParamMessage("histColumnsName",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_RESTORE_HIST_COLUMNS_NAME))
    TechnicalValidation.configStringParamValidator(CONF_RESTORE_HIST_COLUMNS_VALUE, config)
    val histColumnsValue: Seq[String] = config.getString(CONF_RESTORE_HIST_COLUMNS_VALUE).split(RESTORE_SPLIT_CHAR).toSeq
    logger.info(s"CDDRestore: Value of hist. partition columns: $histColumnsValue")
    CDDExecutionStats.addInputParamMessage("histColumnsValue",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_RESTORE_HIST_COLUMNS_VALUE))
    val princColumnsName: Seq[String] = Try(config.getString(CONF_RESTORE_PRINC_COLUMNS_NAME).split(RESTORE_SPLIT_CHAR).toSeq).getOrElse(Seq(""))
    logger.info(s"CDDRestore: Name of princ. partition columns: $princColumnsName")
    CDDExecutionStats.addInputParamMessage("princColumnsName",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_RESTORE_PRINC_COLUMNS_NAME))
    val princColumnsValue: Seq[String] = Try(config.getString(CONF_RESTORE_PRINC_COLUMNS_VALUE).split(RESTORE_SPLIT_CHAR).toSeq).getOrElse(Seq(""))
    logger.info(s"CDDRestore: Value of princ. partition columns: $princColumnsValue")
    CDDExecutionStats.addInputParamMessage("princColumnsValue",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_RESTORE_PRINC_COLUMNS_VALUE))
    val repartitionBase: Int = Try(config.getInt(CONF_RESTORE_REPARTITION_BASE))
      .getOrElse(DEFAULT_RESTORE_REPARTITION_BASE)
    logger.info(s"CDDRestore: Value of repartitionBase: $repartitionBase")
    CDDExecutionStats.addInputParamMessage("repartitionBase",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", repartitionBase.toString)
    val averageKBPerRecord: Int = Try(config.getInt(CONF_RESTORE_AVERAGE_KB_PER_RECORD))
      .getOrElse(DEFAULT_RESTORE_AVERAGE_KB_PER_RECORD)
    logger.info(s"CDDRestore: Value of averageKBPerRecord: $averageKBPerRecord")
    CDDExecutionStats.addInputParamMessage("averageKBPerRecord",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", averageKBPerRecord.toString)
    val failIfNullDf: Int = Try(config.getInt(CONF_RESTORE_FAIL_NULL_DATAFRAME))
      .getOrElse(DEFAULT_RESTORE_FAIL_NULL_DATAFRAME)
    logger.info(s"CDDRestore: Fail process if dataFrame has 0 rows: $failIfNullDf")
    CDDExecutionStats.addInputParamMessage("failIfNullDf",
      "CDDRestore", "setterGlobalConfigurationReadedParamsReader", failIfNullDf.toString)
    TechnicalValidation.listSameLengthValidator(CONF_HISTORIFICADOR_LISTS_BLOCK, histColumnsName, histColumnsValue)
    // Setter parameter in case class
    RestoreConfiguration(principalPath,
      principalSchema,
      historicalPath,
      histColumnsName,
      histColumnsValue,
      princColumnsName,
      princColumnsValue,
      repartitionBase,
      averageKBPerRecord,
      failIfNullDf)
  }

  override def getProcessId: String = "CDDRestore"
}

class Restore extends RestoreTrait
