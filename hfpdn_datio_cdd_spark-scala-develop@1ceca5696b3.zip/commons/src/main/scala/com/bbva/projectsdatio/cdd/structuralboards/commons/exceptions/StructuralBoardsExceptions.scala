package com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions

class StructuralBoardsExceptions extends Exception {

  val generalStructuralBoardsExceptionMessage: String =
    "Exception produced by Structural Boards business rules"
}

class SchemaReadingException(message: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Error reading the schema for: [$message]"

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class SchemaValidationException(message: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Error validation the schema for: [$message]"

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ParamNotInformedException(var message: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Param '$message' in custom transformation '$customTransformation' needs to be informed."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ParamMalformedException(var message: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Param '$message' in custom transformation '$customTransformation' is malformed."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ParamEmptyException(var message: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Param '$message' in custom transformation '$customTransformation' needs to be initialized."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class EmptyParameterPath(var emptyPath: String = "")
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Empty path in parameter: $emptyPath "

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class NotExistParameterPath(var emptyPath: String = "")
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Path in parameter does not exist: $emptyPath "

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class NotExistMonthPartitionInParameterPath(var path: String = "", var month: String, var year: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Path $path has not any partition for month $year - $month.  "

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ValueParameterException(var parameter: String = "", var tempType: String = "")
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Don´t include valid value $parameter in parameter: $tempType "

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class StringInListException(var parameter: String = "", var stringSeq: Seq[String] = Nil)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Value $parameter should not be in: $stringSeq "

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class UnionDuplicates(customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Duplicates generated in custom transformation '$customTransformation' during union process, every operation must appear in single input DataFrame "

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ListLengthException(var message: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Param '$message' in custom transformation '$customTransformation' has more length than allowed."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ListLengthElementException(var message: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Param '$message' in custom transformation '$customTransformation' different number of elements than expected."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class ListSameLengthException(var message: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Param '$message' lists in custom transformation '$customTransformation' have not the same number of elements."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class DateFormatException(var message: String = "", var valor: String = "", customTransformation: String)
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Given format '$message' in '$customTransformation' is not the same as partition field value '$valor' in hdfs."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class BadColumnsNameException(var name: String = "", var parameter: String = "")
  extends StructuralBoardsExceptions {
  val customExceptionMessage =
    s": Given column name $name in parameter $parameter does not exist in dataFrame, it should be wrong."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class BadStringNameException(var name: String = "", var parameter: String = "", val validList: Seq[String] = Seq(""))
  extends StructuralBoardsExceptions {
  val customExceptionMessage =
    s": Given string name $name in parameter $parameter does not exist in collection {${validList.mkString(",")}}, it should be wrong."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class MandatoryNotInformedException(var columnsToInitialize: Seq[String] = Seq(""))
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": One of the following columns: ${columnsToInitialize.mkString(",")} is not in its corresponding input dataset." +
      s"As a mandatory column, it should be informed."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class BadPartitionColumnsNameException(var name: String = "", var parameter: String = "")
  extends StructuralBoardsExceptions {

  val customExceptionMessage =
    s": Given column name $name in parameter $parameter is not a valid partition field, it should be wrong."

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(customExceptionMessage)
}

class DeleteErrorException(message: String)
  extends StructuralBoardsExceptions {

  override def getMessage: String = generalStructuralBoardsExceptionMessage.concat(message)
}
