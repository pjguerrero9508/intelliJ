package com.bbva.projectsdatio.cdd.structuralboards.commons.validation

import java.text.SimpleDateFormat
import java.util.Date
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{BadStringNameException, StructuralBoardsExceptionsController, _}
import com.typesafe.config.{Config, ConfigException}
import org.apache.spark.sql.functions.col
import scala.util.{Failure, Success, Try}
import org.slf4j.{Logger, LoggerFactory}

object TechnicalValidation {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  @throws[ParamNotInformedException]
  @throws[ParamMalformedException]
  @throws[StructuralBoardsExceptions]
  /**
   * Validator for parameters that need an Int in config file
   *
   * @param paramName  param to validate
   * @param configFile config input in to flow
   * @return path as a String
   * @throws ParamNotInformedException exception to throws
   * @throws ParamMalformedException   exception to throws
   */
  def configIntParamValidator(paramName: String, configFile: Config): Unit = {
    Try(configFile.getInt(paramName))
    match {
      case Failure(_: ConfigException.Missing) =>
        StructuralBoardsExceptionsController(exception = new ParamNotInformedException(paramName, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "configIntParamValidator",
          exceptionMessage = s"TechnicalValidation: configIntParamValidator, missing parameter.").exceptionTreatment
        throw new ParamNotInformedException(paramName, this.getClass.toString)
      case Failure(_: ConfigException.WrongType) =>
        StructuralBoardsExceptionsController(exception = new ParamMalformedException(paramName, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "configIntParamValidator",
          exceptionMessage = s"TechnicalValidation: configIntParamValidator, malformed parameter.").exceptionTreatment
        throw new ParamMalformedException(paramName, this.getClass.toString)
      case Success(_) =>
        configFile.getInt(paramName)
      case _ =>
        StructuralBoardsExceptionsController(exception = new StructuralBoardsExceptions,
          fileError = "TechnicalValidation", methodError = "configIntParamValidator",
          exceptionMessage = s"TechnicalValidation: configIntParamValidator.").exceptionTreatment
        throw new StructuralBoardsExceptions
    }
  }

  @throws[ParamNotInformedException]
  @throws[ParamMalformedException]
  @throws[StructuralBoardsExceptions]
  /**
   * Validator for parameters that need a String in config file
   *
   * @param paramName  param to validate
   * @param configFile config input in to flow
   * @return path as a String
   * @throws ParamNotInformedException exception to throws
   * @throws ParamMalformedException   exception to throws
   * @throws ParamEmptyException       exception to throws
   */
  def configStringParamValidator(paramName: String, configFile: Config): Unit = {
    val paramContent = Try(configFile.getString(paramName))
    match {
      case Failure(_: ConfigException.Missing) =>
        StructuralBoardsExceptionsController(exception = new ParamNotInformedException(paramName, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "configStringParamValidator",
          exceptionMessage = s"TechnicalValidation: configStringParamValidator, missing parameter.").exceptionTreatment
        throw new ParamNotInformedException(paramName, this.getClass.toString)
      case Failure(_: ConfigException.WrongType) =>
        StructuralBoardsExceptionsController(exception = new ParamMalformedException(paramName, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "configStringParamValidator",
          exceptionMessage = s"TechnicalValidation: configStringParamValidator, malformed parameter.").exceptionTreatment
        throw new ParamMalformedException(paramName, this.getClass.toString)
      case Success(_) =>
        configFile.getString(paramName)
      case _ =>
        StructuralBoardsExceptionsController(exception = new StructuralBoardsExceptions,
          fileError = "TechnicalValidation", methodError = "configStringParamValidator",
          exceptionMessage = s"TechnicalValidation: configStringParamValidator.").exceptionTreatment
        throw new StructuralBoardsExceptions
    }
    if (paramContent.isEmpty) throw new ParamEmptyException(paramName, this.getClass.toString)
  }

  /**
   * Validator for parameters that need a List of Strings in config file
   *
   * @param paramName  param to validate
   * @param configFile config input in to flow
   * @return path as a String
   * @throws ParamNotInformedException exception to throws
   * @throws ParamMalformedException   exception to throws
   * @throws ParamEmptyException       exception to throws
   */
  @throws[ParamNotInformedException]
  @throws[ParamMalformedException]
  @throws[ParamEmptyException]
  @throws[Exception]
  def configStringListParamValidator(paramName: String, configFile: Config): Unit = {
    import collection.JavaConverters._
    Try(configFile
      .getStringList(paramName)
      .asScala
      .map(col))
    match {
      case Failure(ex: ConfigException.Missing) =>
        StructuralBoardsExceptionsController(exception = new ParamNotInformedException(paramName, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "configStringListParamValidator",
          exceptionMessage = s"CDDCommons: configStringListParamValidator $paramName has not been informed").exceptionTreatment
        throw ex
      case Failure(ex: ConfigException.WrongType) =>
        StructuralBoardsExceptionsController(exception = new ParamMalformedException(paramName, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "configStringListParamValidator",
          exceptionMessage = s"CDDCommons: configStringListParamValidator $paramName is malformed").exceptionTreatment
        throw ex
      case Failure(ex: Throwable) =>
        StructuralBoardsExceptionsController(exception = new Exception(ex),
          fileError = "TechnicalValidation", methodError = "configStringListParamValidator",
          exceptionMessage = s"CDDCommons: configStringListParamValidator not captured exception").exceptionTreatment
        throw ex
      case Success(_) =>
        val result = configFile.getStringList(paramName).asScala.map(col)
        if (result.isEmpty) {
          StructuralBoardsExceptionsController(exception = new ParamEmptyException(paramName, this.getClass.toString),
            fileError = "TechnicalValidation", methodError = "configStringListParamValidator",
            exceptionMessage = s"CDDCommons: configStringListParamValidator: paramContent is empty").exceptionTreatment
          throw new ParamEmptyException(paramName, this.getClass.toString)
        } else {
          result
        }
    }
  }

  /**
   * It is responsible for validating that one list contains all elements of another one
   *
   * @param elemsList   list with values to validate
   * @param validValues sea of valid values
   * @param param       param to validate
   * @throws BadColumnsNameException exception to throws
   */
  @throws[BadColumnsNameException]
  def listElemValidator(elemsList: Seq[String], validValues: Seq[String], param: String): Unit = {
    elemsList.foreach(elem =>
      if (!validValues.contains(elem)) {
        StructuralBoardsExceptionsController(exception = new BadColumnsNameException(elem, param),
          fileError = "TechnicalValidation", methodError = "listElemValidator",
          exceptionMessage = s"CDDCommons: listElemValidator: not all elements in " +
            s"${elemsList.mkString(",")} are in ${validValues.mkString(",")}").exceptionTreatment
        throw new BadColumnsNameException(elem, param)
      })
  }

  /**
   * It is responsible for validating that a value entered is a valid date
   *
   * @param date  date to validate
   * @param param param to validate
   * @throws ParamMalformedException exception to throws
   */
  @throws[ParamMalformedException]
  def dateValidator(date: String, param: String): Unit = {
    Try {
      val dateFormat: SimpleDateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd")
      val dateAsDate: Date = dateFormat.parse(date)
      val dateToString: String = dateFormat.format(dateAsDate)
      if (date != dateToString) {
        StructuralBoardsExceptionsController(exception = new ParamMalformedException(param, this.getClass.toString),
          fileError = "TechnicalValidation", methodError = "dateValidator",
          exceptionMessage = s"CDDCommons: dateValidator: invalid date $date in parameter $param").exceptionTreatment
        throw new ParamMalformedException(param, this.getClass.toString)
      }
    } match {
      case Success(_) =>
        logger.info(s"CDDCommons: dateValidator: valid date $date in parameter $param")
      case Failure(ex: ParamMalformedException) =>
        logger.info(s"CDDCommons: Exception controlled in TechnicalValidation.dateValidator")
        StructuralBoardsExceptionsController(exception = ex,
          fileError = "CDDCommons", methodError = "dateValidator",
          exceptionMessage = s"CDDCommons: dateValidator: Exception controlled in TechnicalValidation.dateValidator" +
            s"with parameters $date ; $param").exceptionTreatment
        throw ex
      case _ =>
        logger.info(s"CDDCommons: Exception not controlled in TechnicalValidation.dateValidator")
        throw new ParamMalformedException(param, this.getClass.toString)
    }
  }

  @throws[ListSameLengthException]
  /**
   * It is responsible for validating if three lists have the same number of elements
   *
   * @param blockName config file block of the lists
   * @param list1     first list to validate
   * @param list2     first list to validate
   * @param list3     first list to validate
   * @throws ListSameLengthException exception to throws
   */
  def listSameLengthValidator(blockName: String, list1: Seq[String], list2: Seq[String], list3: Seq[String]): Unit = {
    if (!(list1.length == list2.length && list1.length == list3.length)) {
      logger.info(s"CDDCommons: listSameLengthValidator: $blockName lists have not the same number of elements")
      StructuralBoardsExceptionsController(exception = new ListSameLengthException(blockName, this.getClass.toString),
        fileError = "TechnicalValidation", methodError = "listSameLengthValidator",
        exceptionMessage = s"CDDCommons: listSameLengthValidator: $blockName lists have not the same number of elements").exceptionTreatment
      throw new ListSameLengthException(blockName, this.getClass.toString)
    }
  }

  @throws[ListSameLengthException]
  def listSameLengthValidator(blockName: String, list1: Seq[String], list2: Seq[String]): Unit = {
    if (!(list1.length == list2.length)) {
      logger.info(s"CDDCommons: listSameLengthValidator: $blockName lists have not the same number of elements")
      StructuralBoardsExceptionsController(exception = new ListSameLengthException(blockName, this.getClass.toString),
        fileError = "TechnicalValidation", methodError = "listSameLengthValidator",
        exceptionMessage = s"CDDCommons: listSameLengthValidator: $blockName lists have not the same number of elements").exceptionTreatment
      throw new ListSameLengthException(blockName, this.getClass.toString)
    }
  }

  @throws[StringInListException]
  def stringNotInList(string: String, stringSeq: Seq[String]): Unit = {
    if (stringSeq.contains(string)) {
      StructuralBoardsExceptionsController(exception = new StringInListException(string, stringSeq),
        fileError = "TechnicalValidation", methodError = "stringNotInList",
        exceptionMessage = s"CDDCommons: stringNotInList: element $string has to" +
          s" be on ${stringSeq.mkString(",")}").exceptionTreatment
      throw new StringInListException(string, stringSeq)
    }
  }

  @throws[BadStringNameException]
  /**
   * It is responsible for validating that one list contains all elements of another one
   *
   * @param elemsList   list with values to validate
   * @param validValues sea of valid values
   * @param param       param to validate
   * @throws BadStringNameException exception to throws
   */
  def listStringValidator(elemsList: Seq[String], validValues: Seq[String], param: String): Unit = {
    elemsList.foreach(elem =>
      if (!validValues.contains(elem)) {
        StructuralBoardsExceptionsController(exception = new BadStringNameException(elem, param, validValues),
          fileError = "TechnicalValidation", methodError = "listStringValidator",
          exceptionMessage = s"CDDCommons: listStringValidator: elemsList ${validValues.mkString(",")} has to" +
            s" contain every value on  ${elemsList.mkString(",")}").exceptionTreatment
        throw new BadStringNameException(elem, param, validValues)
      })
  }
}
