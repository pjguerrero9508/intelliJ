package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{DateFormatException, StructuralBoardsExceptionsController,
  UnionDuplicates, ValueParameterException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaValidatorBoards.columnInitializer
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, Dataset, Row}
import org.slf4j.{Logger, LoggerFactory}

import java.text.SimpleDateFormat
import java.util.Date

object GenericUtils {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * The function adds a column with current timestamp
   *
   * @param df      input dataframe
   * @param colName column name to add
   * @return input dataframe with a column with current timestamp
   */
  def setActualAuditDate(df: DataFrame, colName: String): DataFrame = df.withColumn(colName, current_timestamp())

  @throws[ValueParameterException]
  /**
   * The function validates if a given dataframe has rows
   *
   * @param df           input dataframe
   * @param failIfNullDf value to indicate if stop in case of empty DataFrame
   * @return
   */
  def emptyDfValidation(df: DataFrame, failIfNullDf: Int): Unit = {
    if (df.count() == CONSTANT_ZERO) {
      logger.info(s"CDDCommons: emptyDfValidation Method: Empty DataFrame ")
      logger.info(s"CDDCommons: emptyDfValidation Method: There is no data for given partition parameters")
      logger.info(s"CDDCommons: emptyDfValidation Method: Columns parameters information could be wrong")
      if (failIfNullDf == CONSTANT_ONE) {
        StructuralBoardsExceptionsController(exception = new ValueParameterException,
          fileError = "GenericUtils", methodError = "emptyDfValidation",
          exceptionMessage = s"GenericUtils: emptyDfValidation: DataFrame is empty and failIfNullDf is $failIfNullDf").exceptionTreatment
        throw new ValueParameterException
      }
    }
  }

  /**
   * It performs the union of three DataFrames with common and non common columns
   * It also checks that the union result has not any duplicate records with the
   * "groupCols" PKs. If there are any duplicates then:
   * > if isSoft only WARN logger will be set.
   * > if !isSoft UnionDuplicates will be risen.
   *
   * @param df_1      input DataFrame
   * @param df_2      input DataFrame
   * @param groupCols list of groupBy columns to validate
   * @param schema    DatioSchema
   * @param isSoft    Boolean
   * @return union DataFrame if it pass the validation
   */
  def unionData(df_1: DataFrame, df_2: DataFrame, groupCols: List[String], schema: DatioSchema)(isSoft: Boolean = FALSE_VALUE): DataFrame = {
    logger.info(s"CDDCommons: Init method unionData")
    val cols_1: Set[String] = df_1.columns.toSet
    val cols_2: Set[String] = df_2.columns.toSet
    val totalColumns: List[String] = (cols_1 ++ cols_2).toList.distinct
    val finalUnionDF: DataFrame = df_1.select(returnIfColumnInDatasetOrInitialize(cols_1.toList, totalColumns, schema): _*)
      .union(df_2.select(returnIfColumnInDatasetOrInitialize(cols_2.toList, totalColumns, schema): _*))
    logger.info(s"CDDCommons: unionData Method: DataFrame union performed")
    validateDuplicatesByPK(finalUnionDF, groupCols)(isSoft)
  }

  /**
   * It adds null columns from in a list of columns from other list if it does not have it
   * For every column in allCols that exists on tableCols, itself is added to return List
   * if it is not, new column its initialized with its name using columnInitializer
   *
   * @param tableCols list of columns of one table
   * @param allCols   list of common and non common columns of three tables
   * @return list of columns from a table with non common columns added and initialized as null or default value
   */
  def returnIfColumnInDatasetOrInitialize(tableCols: List[String], allCols: List[String], schema: DatioSchema): List[Column] = {
    allCols.map(elem => {
      if (tableCols.contains(elem)) col(elem) else columnInitializer(elem, schema.getStructType)
    }
    )
  }

  @throws[UnionDuplicates]("There are duplicated records on datasets")
  /**
   * It is responsible for validating that a given DataFrame has no duplicates by PK columns
   *
   * @param df        DataFrame to validate
   * @param groupCols list of groupBy columns to validate
   * @return input DataFrame if it pass the validation
   * @throws UnionDuplicates exception to throws
   */
  def validateDuplicatesByPK(df: DataFrame, groupCols: List[String])(isSoft: Boolean = FALSE_VALUE): DataFrame = {
    logger.info(s"CDDCommons: Init method validateDuplicates")
    val columns: List[Column] = groupCols.map(col)
    val duplicatedRows: Dataset[Row] = df.groupBy(columns: _*).count()
      .filter(col(VAL_COUNT) >= CONSTANT_TWO)
    if (duplicatedRows.count() > CONSTANT_ZERO) {
      logger.info(s"CDDCommons: validateDuplicates Method: Pk columns $groupCols")
      if (!isSoft) {
        CDDExecutionStats
          .addErrorMessage("Duplicated Records", "GenericUtils", "validateDuplicatesByPK",
            s"CDDCommons: validateDuplicates Method: ${duplicatedRows.count()} duplicate records have been detected")
        CDDExecutionStats
          .addErrorMessage("Duplicated Records", "GenericUtils", "validateDuplicatesByPK",
            s"CDDCommons: validateDuplicates Method: ids catalogued in multiple disjoint input DataFrames")
        StructuralBoardsExceptionsController(exception = new UnionDuplicates(this.getClass.toString),
          fileError = "GenericUtils", methodError = "validateDuplicatesByPK",
          exceptionMessage = s"GenericUtils: validateDuplicatesByPK: ids catalogued in multiple disjoint input DataFrames").exceptionTreatment
        throw new UnionDuplicates(this.getClass.toString)
      } else {
        CDDExecutionStats
          .addWarnMessage("Duplicated Records", "GenericUtils", "validateDuplicatesByPK",
            s"CDDCommons: validateDuplicates Method: ${duplicatedRows.count()} duplicate records have been detected")
        CDDExecutionStats
          .addWarnMessage("Duplicated Records", "GenericUtils", "validateDuplicatesByPK",
            s"CDDCommons: validateDuplicates Method: ids catalogued in multiple disjoint input DataFrames")
        df
      }
    } else {
      logger.info(s"CDDCommons: validateDuplicates Method: no duplicates rows detected")
      df
    }
  }

  @throws[DateFormatException]
  /**
   * The function change a date from one format to another.
   *
   * @param dateFormat    actual format for date
   * @param oldDateString actual date value
   * @return date with new format
   */
  def changeDateFormat(dateFormat: String, oldDateString: String): String = {
    if (dateFormat.length == oldDateString.length) {
      val datePartitionFormat: SimpleDateFormat = new SimpleDateFormat(dateFormat)
      val oldDateDate: Date = datePartitionFormat.parse(oldDateString)
      val oldDateNewFormat: String = new SimpleDateFormat(CLEAN_BOARDS_DEFAULT_DATE_FORMAT).format(oldDateDate)
      oldDateNewFormat
    } else {
      StructuralBoardsExceptionsController(exception = new DateFormatException(dateFormat, oldDateString, this.getClass.toString),
        fileError = "GenericUtils", methodError = "changeDateFormat",
        exceptionMessage = s"GenericUtils: changeDateFormat: process was not able to format " +
          s"$oldDateString into $dateFormat").exceptionTreatment
      throw new DateFormatException(dateFormat, oldDateString, this.getClass.toString)
    }
  }
}
