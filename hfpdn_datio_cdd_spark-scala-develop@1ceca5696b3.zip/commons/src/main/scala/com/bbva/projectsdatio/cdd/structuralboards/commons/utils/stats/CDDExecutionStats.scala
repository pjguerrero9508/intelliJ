package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.StructuralBoardsExceptions
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import scala.collection.immutable.ListMap
import scala.collection.mutable
import scala.util.Try

object CDDExecutionStats {
  var warnMessagesCounter: Int = 0
  var errorMessagesCounter: Int = 0
  var knownExceptionsCounter: Int = 0
  var unknownExceptionsCounter: Int = 0
  var compactorHasBeenExecuted: Boolean = false
  var compactorSummary: String = ""

  val generalExecutionInfo: String = "General Execution info"
  val compactorExecutionInfo: String = "Compactor Execution info"
  val knownExceptionCode: String = "Controlled CDD exception"
  val unknownExceptionCode: String = "Uncontrolled CDD exception"
  val warnCode: String = "Detected CDD warning"
  val errorCode: String = "Detected CDD error"

  val headerDataBase: mutable.Map[String, String] = mutable.Map.empty[String, String]
  headerDataBase+=((knownExceptionCode, "CDD KNOWN EXCEPTIONS -- Please check 'Exception produced by Structural Boards business rules' in logger."))
  headerDataBase+=((unknownExceptionCode, "CDD UNKNOWN EXCEPTIONS -- Please check stacktrace in logger"))
  headerDataBase+=((generalExecutionInfo, "GENERAL EXECUTION INFO -- Please check if is the intended configuration."))
  headerDataBase+=((compactorExecutionInfo, "FINAL SPARK COMPACTOR -- Datio Spark Compactor execution Report"))
  headerDataBase+=((warnCode, "WARNING MESSAGES -- Please check WARN messages"))
  headerDataBase+=((errorCode, "ERROR MESSAGES -- Please check ERROR messages"))

  val warnList: mutable.Map[String, (String, String, String)] =
    mutable.Map.empty[String, (String, String, String)]
  val errorList: mutable.Map[String, (String, String, String)] =
    mutable.Map.empty[String, (String, String, String)]
  val knownExceptionsList: mutable.Map[String, (String, String, String)] =
    mutable.Map.empty[String, (String, String, String)]
  val unknownExceptionsList: mutable.Map[String, (String, String, String)] =
    mutable.Map.empty[String, (String, String, String)]
  val inputParamList: mutable.Map[String, (String, String, String)] =
    mutable.Map.empty[String, (String, String, String)]
  val inputDatasetList: mutable.Map[String, (String, String, String, Seq[String])] =
    mutable.Map.empty[String, (String, String, String, Seq[String])]

  def createLine (title: String, content: String): String = {
    "|-> " +s"$title: " + s"$content" + "\n"
  }

  def addInputParamMessage(inputParamName: String, fileWarn: String, methodWarn: String, inputParamValue: String): Unit = {
    inputParamList
      .put(inputParamName, (fileWarn, methodWarn, inputParamValue))
  }
  def addInputDatasetMessage(inputDatasetName: String, filePath: String, parquetFilesNumber: Int,
                             parquetFilesAverageSize: Long, physicalFilesGenerationTimestamps: Seq[String]): Unit = {
    inputDatasetList
      .put(inputDatasetName, (filePath, parquetFilesNumber.toString, parquetFilesAverageSize.toString, physicalFilesGenerationTimestamps))
  }
  def addWarnMessage(warnType: String, fileWarn: String, methodWarn: String, logMessage: String): Unit = {
    warnMessagesCounter+=1
    warnList
      .put(warnMessagesCounter.toString.concat("_" + warnType), (fileWarn, methodWarn, logMessage))
  }
  def addErrorMessage(errorType: String, fileError: String, methodError: String, logMessage: String): Unit = {
    errorMessagesCounter+=1
    errorList
      .put(errorMessagesCounter.toString.concat("_" + errorType), (fileError, methodError, logMessage))
  }
  def addKnownExceptionMessage(exception: StructuralBoardsExceptions, fileError: String, methodError: String): Unit = {
    knownExceptionsCounter+=1
    knownExceptionsList
      .put(knownExceptionsCounter.toString.concat("_" + exception.getClass.toString), (fileError, methodError, exception.getMessage))
  }
  def addUnKnownExceptionMessage(exception: Exception, fileError: String, methodError: String): Unit = {
    unknownExceptionsCounter+=1
    unknownExceptionsList
      .put(knownExceptionsCounter.toString.concat("_" + exception.getClass.toString), (fileError, methodError, exception.getMessage))
  }
  def addCompactorSummary(summaryContent: String): Unit = {
    compactorHasBeenExecuted = TRUE_VALUE
    compactorSummary = summaryContent
  }
  def generateWarnReport(): String = {
    val warnReport: mutable.StringBuilder = StringBuilder.newBuilder
    warnReport.append(headerDataBase.get(warnCode)).append("\n")
    ListMap(warnList.toSeq.sortWith(_._1.split("_").head.toInt < _._1.split("_").head.toInt):_*)
      .foldLeft(warnReport)((agg, warnElement) =>
      agg.append(createLine(warnElement._1,
        "Warn message in file " + warnElement._2._1
          + " in method " + warnElement._2._2
          + " with message " + warnElement._2._3))).append("\n")
    warnReport.mkString
  }
  def generateErrorReport(): String = {
    val errorReport: mutable.StringBuilder = StringBuilder.newBuilder
    errorReport.append(headerDataBase.get(errorCode)).append("\n")
    ListMap(errorList.toSeq.sortWith(_._1.split("_").head.toInt < _._1.split("_").head.toInt):_*)
      .foldLeft(errorReport)((agg, errorElement) =>
      agg.append(createLine(errorElement._1,
        "Error message in file " + errorElement._2._1
          + " in method " + errorElement._2._2
          + " with message " + errorElement._2._3))).append("\n")
    errorReport.mkString
  }
  def generateKnownExceptionReport(): String = {
    val knownExceptionsReport: mutable.StringBuilder = StringBuilder.newBuilder
    knownExceptionsReport.append(headerDataBase.get(knownExceptionCode)).append("\n")
    ListMap(knownExceptionsList.toSeq.sortWith(_._1.split("_").head.toInt < _._1.split("_").head.toInt):_*)
      .foldLeft(knownExceptionsReport)((agg, knownExceptionsElement) =>
      agg.append(createLine(knownExceptionsElement._1,
        "Exception in file " + knownExceptionsElement._2._1
          + " in method " + knownExceptionsElement._2._2
          + " with message " + knownExceptionsElement._2._3))).append("\n")
    knownExceptionsReport.mkString
  }
  def generateUnKnownExceptionReport(): String = {
    val unknownExceptionsReport: mutable.StringBuilder = StringBuilder.newBuilder
    unknownExceptionsReport.append(headerDataBase.get(unknownExceptionCode)).append("\n")
    ListMap(unknownExceptionsList.toSeq.sortWith(_._1.split("_").head.toInt < _._1.split("_").head.toInt):_*)
      .foldLeft(unknownExceptionsReport)((agg, unknownExceptionsElement) =>
      agg.append(createLine(unknownExceptionsElement._1,
        "Exception in file " + unknownExceptionsElement._2._1
          + " in method " + unknownExceptionsElement._2._2
          + " with message " + unknownExceptionsElement._2._3))).append("\n")
    unknownExceptionsReport.mkString
  }
  def generateGeneralExecutionReport(): String = {
    val generalExecutionReport: mutable.StringBuilder = StringBuilder.newBuilder
    generalExecutionReport.append(headerDataBase.get(generalExecutionInfo)).append("\n")
    generalExecutionReport.append("Input params: \n")
    inputParamList.foldLeft(generalExecutionReport)((agg, generalExecutionElement) =>
      agg.append(createLine(generalExecutionElement._1,
        "Succesfully validated in code file " + generalExecutionElement._2._1
          + " in method " + generalExecutionElement._2._2
          + " with value " + generalExecutionElement._2._3))).append("\n")
    generalExecutionReport.append("Input datasets: \n")
    inputDatasetList.foldLeft(generalExecutionReport)((agg, generalExecutionElement) =>
      agg.append(createLine(generalExecutionElement._1,
        "In path " + generalExecutionElement._2._1
          + " which has " + generalExecutionElement._2._2 + " physical files"
          + " with an average size of " + generalExecutionElement._2._3
          + " which were generated between timestamps " + Try(generalExecutionElement._2._4.max).getOrElse("NOT FOUND")
        + " and " + Try(generalExecutionElement._2._4.min).getOrElse("NOT FOUND") ))).append("\n")
    if (compactorHasBeenExecuted) {
      generalExecutionReport.append(headerDataBase.get(compactorExecutionInfo)).append("\n")
      generalExecutionReport.append(compactorSummary)
    }
    generalExecutionReport.mkString
  }
  def cleaner (): Unit = {
    inputParamList.clear
    inputDatasetList.clear
    warnList.clear
    errorList.clear
    knownExceptionsList.clear
    unknownExceptionsList.clear
    warnMessagesCounter = 0
    errorMessagesCounter = 0
    knownExceptionsCounter = 0
    unknownExceptionsCounter = 0
  }
  def generateFinalReport(): String = {
    val report: mutable.StringBuilder = StringBuilder.newBuilder
    report.append("CDD Final execution report:").append("\n")
    report.append(generateGeneralExecutionReport())
    if (warnMessagesCounter >= 1) report.append(generateWarnReport())
    if (errorMessagesCounter >= 1) report.append(generateErrorReport())
    if (knownExceptionsCounter >= 1) report.append(generateKnownExceptionReport())
    if (unknownExceptionsCounter >= 1) report.append(generateUnKnownExceptionReport())
    report.append("CDD Final execution report end.").append("\n")
    cleaner()
    report.mkString
  }
}
