package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.StructuralBoardsExceptionsController
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StructField, StructType}
import org.apache.spark.sql.{Column, DataFrame, Row}
import org.slf4j.{Logger, LoggerFactory}

import scala.util.Try

object ReadUtils {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * Function to read the parquet file with schema. Only used in cache method (with no schema).
   *
   * @param datioSparkSession DatioSparkSession
   * @param path              String of the file to read
   * @return DataFrame read
   */
  def simpleReadParquet(datioSparkSession: DatioSparkSession, path: String): DataFrame = {
    datioSparkSession.read
      .option("mode", "FAILFAST")
      .option("charset", "UTF-8")
      .parquet(path)
  }

  /**
   * Function to read the parquet file with schema
   *
   * @param datioSparkSession DatioSparkSession
   * @param path              String of the file to read
   * @param datioSchema       DatioSchema whith the schema to read.
   * @return DataFrame read
   */
  def readParquetWithSchema(datioSparkSession: DatioSparkSession, path: String, datioSchema: DatioSchema): DataFrame = {
    datioSparkSession.read
      .option("mode", "FAILFAST")
      .option("charset", "UTF-8")
      .option("overrideSchema", "true")
      .datioSchema(datioSchema)
      .parquet(path)
  }

  /**
   *
   */
  val createEmptyDataFrame: (StructType, DatioSparkSession) => DataFrame =
    (schema: StructType, datioSparkSession: DatioSparkSession) => {
      datioSparkSession.getSparkSession
        .createDataFrame(datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row], schema)
    }

  /**
   *
   */
  val datasetSelectOrInitializeIfNotFound: (DataFrame, Array[Column], Array[Column], StructType) => DataFrame =
    (completeDataToAppend: DataFrame, columnsInData: Array[Column], selectedColumns: Array[Column], schema: StructType) => {
      Try(completeDataToAppend.select(columnsInData: _*))
        .getOrElse(SchemaValidatorBoards
          .initializeNotInformedColumns(completeDataToAppend, schema, selectedColumns.map(_.toString())))
    }

  /**
   *
   * @param path
   * @param schema
   * @param columns
   * @param fieldsToKeepButNotInSchema
   * @param datioSparkSession
   * @return
   */
  def dataFrameSelector(path: String,
                        schemaDatio: DatioSchema,
                        schema: StructType,
                        columns: Array[Column],
                        fieldsToKeepButNotInSchema: Seq[String] = Seq())(datioSparkSession: DatioSparkSession): DataFrame = {
    val partitionsAndItsValue: Map[StructField, String] = FileSystemUtils.getPartitionsAndValueOfTheField(path, schema)
    val dataToAppend: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, path, schemaDatio)
    val completeDataToAppend: DataFrame = FileSystemUtils.includePartitionColumnsAndTheirValue(partitionsAndItsValue, dataToAppend)
    val columnsToKeepStructFields: Array[Column] = getColumnsToKeepVariable(completeDataToAppend, fieldsToKeepButNotInSchema)
    val selectedColumns: Array[Column] = columns ++ columnsToKeepStructFields
    SchemaValidatorBoards
      .initializeNotInformedColumns(completeDataToAppend, schema, selectedColumns.map(_.toString())).select(selectedColumns: _*)
  }

  /**
   * Dynamically reads just the partitions that are identified with key-value map keyValuePartitions param
   * This allows to read data that has incoherent schemas in different partitions*.
   * This method has no limitation to read just one partition.
   * If there are more than one partition that can be identified with those values, all partitions will be read
   * and added as just one dataset.
   * *Despite this method allows to read several partitions, it is compulsory that those identified partitions are coherent in
   * their schema and coherent with selected output schema.
   *
   * @param pathData
   * @param schemaData
   * @param partitionRelevantInfo
   * @param schema
   * @param datioSparkSession
   * @return
   */
  def flexibleSchemaSeveralPartitionsFilteredDataRead(pathData: String,
                                                      schemaData: DatioSchema,
                                                      partitionRelevantInfo: Seq[(String, String, String)],
                                                      schema: StructType,
                                                      fieldsToKeepButNotInSchema: Seq[String] = Seq(),
                                                      fieldsNotInData: Seq[String] = Seq())
                                                     (datioSparkSession: DatioSparkSession): DataFrame = {
    val keyValuePartitions: Map[String, String] = partitionRelevantInfo
      .filter(_._3.equals(FIELD_TO_FILTER_FLAG))
      .map(partitionValue => (partitionValue._1, partitionValue._2)).toMap
    val initialResult: DataFrame = createEmptyDataFrame(schema, datioSparkSession)
    val columns: Array[Column] = initialResult.columns.map(col)
      .filterNot(column => fieldsNotInData.contains(column.toString()))
    if (keyValuePartitions.nonEmpty) {
      logger.info("Full parent path will be readed and then filtered")
      val readedDF = dataFrameSelector(pathData, schemaData, schema, columns, fieldsToKeepButNotInSchema)(datioSparkSession)
      val result = keyValuePartitions.foldLeft(readedDF)((agg, field) => {
        agg.filter(col(field._1) === field._2)
          .withColumn("aux_".concat(field._1),
            col(field._1).cast(SchemaValidatorBoards.getColumnTypeTryFromSchemaThenFromDataframe(field._1, schema, agg)))
          .drop(col(field._1))
          .withColumnRenamed("aux_".concat(field._1), field._1)
      })
      result
    } else {
      logger.warn("No path was found with the selected partitions, full base path will be read instead")
      CDDExecutionStats
        .addWarnMessage("File paths", "ReadUtils", "flexibleSchemaSeveralPartitionsFilteredDataRead",
          s"No path was found with the selected partitions, full base path will be read instead")
      ReadUtils.simpleReadParquet(datioSparkSession, pathData)
    }
  }

  /**
   *
   * @param pathData
   * @param partitionRelevantInfo
   * @param schema
   * @param datioSparkSession
   * @return
   */
  def flexibleSchemaSeveralPartitionsFilteredDataReadHist(pathData: String,
                                                          partitionRelevantInfo: Seq[(String, String, String)],
                                                          schema: DatioSchema)
                                                         (datioSparkSession: DatioSparkSession): DataFrame = {
    val keyValuePartitions: Map[String, String] = partitionRelevantInfo
      .filter(_._3.equals(FIELD_TO_FILTER_FLAG))
      .map(partitionValue => (partitionValue._1, partitionValue._2)).toMap
    val initialResult: DataFrame = createEmptyDataFrame(schema.getStructType, datioSparkSession)
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, pathData)) {
      logger.info("Full parent path will be readed and filtered")
      val readedDF = ReadUtils.readParquetWithSchema(datioSparkSession, pathData, schema)
      val result = keyValuePartitions.foldLeft(readedDF)((agg, field) => {
        agg.filter(col(field._1) === field._2)
          .withColumn("aux_".concat(field._1), col(field._1).cast(schema.getStructType.fields.filter(_.name.equals(field._1)).head.dataType))
          .drop(col(field._1))
          .withColumnRenamed("aux_".concat(field._1), field._1)
      })
      result
    } else {
      logger.warn("No path was found with that partition filter")
      CDDExecutionStats
        .addWarnMessage("File paths", "ReadUtils", "flexibleSchemaSeveralPartitionsFilteredDataReadHist",
          s"No path was found with that partition filter")
      initialResult
    }
  }


  def readFlexibleParquetFileParams(path: String,
                                    fieldsToKeepButNotInSchema: Seq[String],
                                    columnsInData: Array[Column])
                                   (datioSparkSession: DatioSparkSession)
                                   (schema: StructType): (DataFrame, Array[Column], Array[Column]) = {
    val partitionsAndItsValue: Map[StructField, String] = FileSystemUtils.getPartitionsAndValueOfTheField(path, schema)
    val dataToAppend: DataFrame = ReadUtils.simpleReadParquet(datioSparkSession, path)
    val completeDataToAppend: DataFrame = FileSystemUtils.includePartitionColumnsAndTheirValue(partitionsAndItsValue, dataToAppend)
    val columnsToKeepStructFields: Array[Column] = getColumnsToKeepVariable(completeDataToAppend, fieldsToKeepButNotInSchema)
    val selectedColumns: Array[Column] = columnsInData ++ columnsToKeepStructFields
    (completeDataToAppend, selectedColumns, columnsToKeepStructFields)
  }


  /**
   * Returns the columns that must be kept from the input dataset despite not being in the schema
   *
   * @param completeDataToAppend       DataFrame
   * @param fieldsToKeepButNotInSchema Seq[String])
   * @return
   */
  def getColumnsToKeepVariable(completeDataToAppend: DataFrame,
                               fieldsToKeepButNotInSchema: Seq[String]): Array[Column] = {
    completeDataToAppend
      .schema.fields.filter(field => fieldsToKeepButNotInSchema.contains(field.name))
      .map(_.name).map(col)
  }

  def safeReader(pathData: String,
                 schemaData: DatioSchema,
                 partitionRelevantInfo: Seq[(String, String, String)],
                 fieldsToKeepButNotInSchema: Seq[String] = Seq(),
                 fieldsNotInData: Seq[String] = Seq())
                (datioSparkSession: DatioSparkSession)
                (schema: StructType,
                 datioSchema: DatioSchema,
                 isHistorifier: Boolean = FALSE_VALUE)(canBeEmpty: Boolean = TRUE_VALUE): DataFrame = {
    try {
      val fullReadedDF: DataFrame = if (isHistorifier) {
        flexibleSchemaSeveralPartitionsFilteredDataReadHist(pathData, partitionRelevantInfo, datioSchema)(datioSparkSession)
      } else {
        flexibleSchemaSeveralPartitionsFilteredDataRead(pathData, schemaData, partitionRelevantInfo,
          schema, fieldsToKeepButNotInSchema, fieldsNotInData)(datioSparkSession)
      }
      fullReadedDF
    } catch {
      case ex: Exception => {
        CDDExecutionStats.addErrorMessage("Reader", "ReadUtils", "safeReader",
          s"Exception reading full entity in path $pathData")
        CDDExecutionStats.addUnKnownExceptionMessage(ex, "ReadUtils", "safeReader")
        StructuralBoardsExceptionsController(ex,
          fileError = "ReadUtils", methodError = "safeReader",
          exceptionMessage = s"Exception reading full entity in path $pathData").exceptionTreatment
        throw ex
      }
      case ex: Throwable => {
        CDDExecutionStats.addErrorMessage("Reader", "ReadUtils", "safeReader",
          s"Unknown throwable reading full entity in path $pathData, Check StackTrace ${ex.getStackTrace.mkString(" | ")}")
        throw ex
      }
    }
  }
}
