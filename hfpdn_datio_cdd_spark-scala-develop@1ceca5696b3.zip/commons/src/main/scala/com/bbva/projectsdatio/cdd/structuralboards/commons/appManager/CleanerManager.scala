package com.bbva.projectsdatio.cdd.structuralboards.commons.appManager

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{StructuralBoardsExceptionsController, ValueParameterException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, ReadUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.hadoop.fs.{FileSystem, Path}
import org.slf4j.{Logger, LoggerFactory}


object CleanerManager {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)


  @throws[ValueParameterException]
  /**
   * The function deletes path partitions that exceed persistence limit time.
   *
   * @param datioSparkSession      Initialized DatioSparkSession
   * @param givenPath              Path taken from globalParameter
   * @param today                  dateIngestion taken from globalParameter
   * @param monthDifference        maximum persistence limit of partitions
   * @param partitionDateFieldName name of date partition (first or second)
   * @param dateFormat             format of date partition value as string
   * @return
   */
  def cleanMainPath(datioSparkSession: DatioSparkSession, givenPath: String, today: String, monthDifference: Int,
                    partitionDateFieldName: String, dateFormat: String, failIfNullDf: Int = 1): Unit = {
    logger.info(s"CDDCleanBoards: Init Method cleanMainPath")
    val dfs = DatioFileSystem.get()
    val path: Path =dfs.qualify(givenPath).path()
    val fs: FileSystem = dfs.qualify(givenPath).fileSystem()
    val messageIfFail: String = s"CDDCleanBoards: Path $givenPath does not exist, there is no data to clean"
    if (FileSystemUtils.pathExists(dfs, givenPath)  &&
      FileSystemUtils.fullPathsFinder(fs, path)(TRUE_VALUE).map(FileSystemUtils.isAPhysicalFile).reduce(_ || _)) {
      logger.info(s"CDDCleanBoards: Method cleanMainPath: Path $givenPath exists")
      val dfColumns: List[String] = ReadUtils.simpleReadParquet(datioSparkSession, givenPath).columns.toList
      logger.info(s"CDDCleanBoards: Method cleanMainPath: Validating if datePartitionName column is in dataFrame")
      TechnicalValidation.listStringValidator(Seq(partitionDateFieldName), dfColumns, CONF_CLEAN_BOARDS_DATE_NAME)
      logger.info(s"CDDCleanBoards: Method cleanMainPath: Validated datePartitionName parameter")
      val partitionsDateLevel = FileSystemUtils.recursivePathFinder(fs, path, partitionDateFieldName).toArray
      val olderPartitions = FileSystemUtils.selectOlderPartitions(partitionsDateLevel, dateFormat)(today, monthDifference)
      for (op <- olderPartitions) {
        FileSystemUtils.delete(dfs, op.toString)
      }
      logger.info(s"CDDCleanBoards: Method cleanMainPath: Deleted old data in path $givenPath")
    } else if (failIfNullDf.equals(1)) {
      StructuralBoardsExceptionsController(exception = new ValueParameterException(givenPath),
        fileError = "CleanerManager", methodError = "cleanMainPath",
        exceptionMessage = messageIfFail).exceptionTreatment
      throw new ValueParameterException(givenPath)
    } else {
      CDDExecutionStats
        .addWarnMessage("Input entities warn", "CleanerManager", "cleanMainPath", messageIfFail)
    }
    logger.info(s"CDDCleanBoards: Method cleanMainPath finished")
  }

}
