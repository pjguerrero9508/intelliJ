package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{DECIMAL_LENGTH_DECIMAL_2,
  DECIMAL_LENGTH_DECIMAL_6, DECIMAL_LENGTH_INTEGER_20, DECIMAL_LENGTH_INTEGER_26}
import org.apache.spark.sql.types.{DataType, DataTypes, DecimalType}

object BoardFieldVsDefaultDataType {
  val dataTypeMap: Map[String, DataType] = Map(
    ("gf_installment_maturity_date", DataTypes.DateType),
    ("g_installment_plan_id", DataTypes.StringType),
    ("gf_instlmt_interest_bc_amount", DecimalType(DECIMAL_LENGTH_INTEGER_26, DECIMAL_LENGTH_DECIMAL_6)),
    ("gf_instlmt_total_bc_amount", DecimalType(DECIMAL_LENGTH_INTEGER_26, DECIMAL_LENGTH_DECIMAL_6)),
    ("gf_instlmt_principal_bc_amount", DecimalType(DECIMAL_LENGTH_INTEGER_26, DECIMAL_LENGTH_DECIMAL_6)),
    ("g_main_holder_customer_type", DataTypes.StringType),
    ("g_customer_main_group_ind_type", DataTypes.StringType),
    ("g_record_rating_type", DataTypes.StringType),
    ("gf_rating_generation_date", DataTypes.DateType),
    ("gf_appraisal_date", DataTypes.DateType),
    ("gf_appraisal_amount", DecimalType(DECIMAL_LENGTH_INTEGER_20, DECIMAL_LENGTH_DECIMAL_2))
  )
}
