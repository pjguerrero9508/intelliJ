package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{MandatoryNotInformedException, StructuralBoardsExceptionsController}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.BoardFieldVsDefaultDataType
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.NULL_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{DataType, DataTypes, StructField, StructType}
import org.apache.spark.sql.{Column, DataFrame}
import org.slf4j.{Logger, LoggerFactory}

import scala.util.Try

object SchemaValidatorBoards {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * @param df          DataFrame
   * @param schema      StructType
   * @param columnNames Seq[String]
   * @return
   */
  def initializeNotInformedColumns(df: DataFrame,
                                   schema: StructType,
                                   columnNames: Seq[String]): DataFrame = {
    val dataFrameColumnNames: Seq[String] = df.columns.toSeq
    val columnsToInitialize: Seq[String] = columnNames.filterNot(dataFrameColumnNames.contains(_))
    if (columnsToInitialize.nonEmpty) {
      logger.warn(s"CDDStructuralBoards: initializeNotInformedColumns -" +
        s"The columns that need to be initialized are $columnsToInitialize")
      CDDExecutionStats
        .addWarnMessage("Data warn", "SchemaValidator", "initializeNotInformedColumns",
          s"CDDStructuralBoards: initializeNotInformedColumns -" +
            s"The columns that need to be initialized are $columnsToInitialize")
    }
    var result = df
    result = columnsToInitialize.foldLeft(result)(
      (agg, structFieldName) => agg.withColumn(structFieldName, columnInitializer(structFieldName, schema))
    )
    result
  }

  /**
   * This method initializes every column in columnNames: Seq[String] with its corresponding type set in outputSchema: StructType
   * with null values in df: DataFrame. If one of the columns already exist in df, its original value will be kept. If any of
   * the columns that will be initialized is not in outputSchema: StructType an exception will be thrown.
   */
  val columnInitializer: (String, StructType) => Column = (columnName: String, schema: StructType) => {
    if (getFieldFromSchema(schema, columnName).isEmpty) {
      logger.warn(s"Initialize column not in schema, please check $columnName")
      logger.warn(s"$columnName column will be initialized with null value " +
        s"and data type was not recovered from schema, it was " +
        s"recovered from SW aux data. This is not a sustainable solution in time, plese fix it as soon as it is possible.")
      CDDExecutionStats
        .addWarnMessage("Data warn", "SchemaValidator", "columnInitializer",
          s"Initialize column not in schema, please check $columnName. " +
            s"$columnName column will be initialized with null value and data type was not recovered from schema, it was " +
            s"recovered from SW aux data. This is not a sustainable solution in time, plese fix it as soon as it is possible")
      lit(NULL_VALUE).cast(Try(BoardFieldVsDefaultDataType.dataTypeMap(columnName)).getOrElse(DataTypes.StringType)).as(columnName)
    } else if (getFieldFromSchema(schema, columnName).head.nullable) {
      logger.info(s"Initialize column found in schema, not mandatory column, please check $columnName")
      lit(NULL_VALUE).cast(getTypeFromSchema(schema, columnName)).as(columnName)
    } else {
      logger.warn(s"Initialize column found in schema and mandatory, please check $columnName")
      val columnToInit: Column = getDefaultFromSchema(schema, columnName) match {
        case Some(value) =>
          logger.warn(s"$columnName column will be initialized with schema default value: '$value'")
          CDDExecutionStats
            .addWarnMessage("Data warn", "SchemaValidator", "columnInitializer",
              s"Initialize column found in schema and mandatory, please check $columnName. " +
                s"$columnName column will be initialized with schema default value: '$value'")
          lit(value).cast(getTypeFromSchema(schema, columnName))
        case _ =>
          CDDExecutionStats
            .addErrorMessage("Data error", "SchemaValidator", "columnInitializer",
              s"Initialize column found in schema and mandatory, please check $columnName. " +
                s"Mandatory $columnName column has not a default value and has not been informed")
          StructuralBoardsExceptionsController(exception = new MandatoryNotInformedException(Seq(columnName)),
            fileError = "SchemaValidator", methodError = "columnInitializer",
            exceptionMessage = s"Initialize column found in schema and mandatory, please check $columnName. " +
              s"Mandatory $columnName column has not a default value and has not been informed").exceptionTreatment
          throw new MandatoryNotInformedException(Seq(columnName))
      }
      columnToInit.as(columnName)
    }
  }
  val artificialColumnsNullTypeCast: (DataFrame, DatioSchema) => DataFrame = (dataFrame: DataFrame, schema: DatioSchema) => {
    val nullTypeColumns: Array[String] = dataFrame.schema.fields.filter(_.dataType == NULL_VALUE).map(_.name)
    nullTypeColumns match {
      case _ if !nullTypeColumns.isEmpty => CDDExecutionStats
        .addWarnMessage("Data warn", "SchemaValidator", "artificialColumnsNullTypeCast",
          s"Columns ${nullTypeColumns.mkString(",")} had to be initialized without schema reference.")
        nullTypeColumns.foldLeft(dataFrame)((agg, param) => dataFrame.withColumn(param, columnInitializer(param, schema.getStructType)))
      case _ => dataFrame
    }
    dataFrame
  }

  /**
   *
   */
  val getFieldFromSchema: (StructType, String) => Array[StructField] =
    (schema: StructType, fieldName: String) => schema.fields.filter(_.name.equals(fieldName))

  /**
   *
   */
  val getTypeFromSchema: (StructType, String) => DataType =
    (schema: StructType, fieldName: String) => schema.fields.filter(_.name.equals(fieldName)).head.dataType

  /**
   *
   */
  val getDefaultFromSchema: (StructType, String) => Option[String] =
    (schema: StructType, fieldName: String) => {
      Try(Some(schema.fields.filter(_.name.equals(fieldName)).head.metadata.getString("default"))).getOrElse(None)
    }


  val getColumnTypeTryFromSchemaThenFromDataframe: (String, StructType, DataFrame) => DataType =
    (fieldName: String, schema: StructType, dataFrame: DataFrame) => {
      Try(getTypeFromSchema(schema, fieldName))
        .getOrElse(dataFrame.schema.fields.filter(_.name.equals(fieldName)).head.dataType)
    }
}
