package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{NotExistMonthPartitionInParameterPath, StructuralBoardsExceptionsController}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, _}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.GenericUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.hadoop.fs.{FileSystem, GlobPattern, Path}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import org.slf4j.{Logger, LoggerFactory}

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import scala.annotation.tailrec
import scala.collection.mutable.ArrayBuffer
import scala.util.{Failure, Success, Try}

object FileSystemUtils {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)


  /**
   * This method returns all the child paths in a hadoop file system which belongs to a given parent path
   *
   * @param fileSystem : org.apache.hadoop.fs.FileSystem object
   * @param parentPath : org.apache.hadoop.fs.Path object
   * @return : ArrayBuffer[Path]
   */
  def returnPathsSubLevelFunc(fileSystem: FileSystem, parentPath: Path): ArrayBuffer[Path] =
    ArrayBuffer(fileSystem.listStatus(parentPath)
      .filter(_.isDirectory)
      .map(subDir => subDir.getPath): _*)


  /**
   * Calculates the difference between the partitionDate in partitionPath: Path with dateFormat format
   * and date param with "yyyy-MM-dd" format
   *
   * @param partitionPath : org.apache.hadoop.fs.Path object
   * @param dateFormat    : partitionPath date format
   * @param date          : String containing date with "yyyy-MM-dd" format
   * @return
   */
  def calculatePartitionMonthDifference(partitionPath: Path, dateFormat: String)(date: String): Int = {
    val partitionDateAsString: String = partitionPath.getName.split(PARTITION_SPLIT_CHAR).tail.head
    val formattedPartitionDate: String = GenericUtils.changeDateFormat(dateFormat, partitionDateAsString)
    val partitionDate: LocalDate = LocalDate.parse(formattedPartitionDate).withDayOfMonth(1)
    val todayDate: LocalDate = LocalDate.parse(date).withDayOfMonth(1)
    ChronoUnit.MONTHS.between(partitionDate, todayDate).toInt
  }

  /**
   * This method will return all of the paths that are informed in partitionsDateLevel collection and have
   * a partition date older than date param minus monthDifference
   *
   * @param partitionsDateLevel : Collection of Paths at date partition level
   * @param dateFormat          : partition date format
   * @param date                : String containing date with "yyyy-MM-dd" format
   * @param monthDifference     : min months difference to return
   * @return
   */
  def selectOlderPartitions(partitionsDateLevel: Array[Path], dateFormat: String)(date: String, monthDifference: Int): Array[Path] = {
    val result: ArrayBuffer[Path] = ArrayBuffer.empty
    partitionsDateLevel.foreach((path: Path) => if (calculatePartitionMonthDifference(path, dateFormat)(date) >= monthDifference) {
      result.append(path)
    })
    result.toArray
  }


  /**
   * This is a @tailec method to find, inside a parent path, all the child paths that has the partition partitionDateFieldName
   * as its directory name. Does not matter the depth level in which partitionDateFieldName is located inside the parent path.
   *
   * @param fileSystem             : org.apache.hadoop.fs.FileSystem object
   * @param parentPath             : org.apache.hadoop.fs.Path object
   * @param partitionDateFieldName : name of the partition level that will be returned
   * @return
   */
  def recursivePathFinder(fileSystem: FileSystem, parentPath: Path, partitionDateFieldName: String)
  : ArrayBuffer[Path] = {
    @tailrec
    def recursivePathFinderWithAcc(fileSystem: FileSystem, parentPath: ArrayBuffer[Path], acc: ArrayBuffer[Path], partitionDateFieldName: String)
    : ArrayBuffer[Path] = {
      if (parentPath.head.getName.split(PARTITION_SPLIT_CHAR).head.equals(partitionDateFieldName)) {
        parentPath
      } else if (returnPathsSubLevelFunc(fileSystem, parentPath.head).isEmpty) {
        ArrayBuffer.empty[Path]
      } else {
        acc.appendAll(returnPathsSubLevelFunc(fileSystem, parentPath.head))
        recursivePathFinderWithAcc(fileSystem,
          acc.filterNot(_.equals(parentPath.head)),
          acc.tail,
          partitionDateFieldName)
      }
    }

    recursivePathFinderWithAcc(fileSystem, ArrayBuffer.apply(parentPath), ArrayBuffer.empty, partitionDateFieldName)
  }


  /**
   * Returns full sub-paths list of a parent path
   *
   * @param fileSystem      FileSystem
   * @param parentPath      Path
   * @param findForPhysical Boolean
   * @return
   */
  def fullPathsFinder(fileSystem: FileSystem, parentPath: Path)(findForPhysical: Boolean): Array[Path] = {
    val getSubfolders = fileSystem.listStatus(parentPath)
    val getSubfoldersOfSubfolders: Array[Path] = getSubfolders.flatMap(path => {
      if (path.isDirectory) {
        fullPathsFinder(fileSystem, path.getPath)(TRUE_VALUE).distinct
      } else {
        if (findForPhysical) Array(path.getPath) else Array(parentPath)
      }
    })
    if (getSubfolders.isEmpty) Array(parentPath) else getSubfoldersOfSubfolders.distinct
  }


  val getFileSystem: DatioSparkSession => FileSystem = (datioSparkSession: DatioSparkSession) =>
    FileSystem.get(datioSparkSession.getSparkSession.sparkContext.hadoopConfiguration)

  @throws[NotExistMonthPartitionInParameterPath]
  /**
   * Returns the max date of the selected partition column inside the parent path which is inside the selected month and year
   * It is necessary for the partition date column to be in the following format yyyy-MM-dd
   *
   * @param parentPath              : String
   * @param datioSparkSession       : DatioSparkSession
   * @param partitionDateColumnName : String
   * @param month                   : String
   * @param year                    : String
   * @return
   */
  def returnNewerPartitionDateInMonth(parentPath: String, datioSparkSession: DatioSparkSession,
                                      partitionDateColumnName: String, month: String, year: String, separator: String): String = {

    val parentPathObject: Path = new Path(parentPath)
    val hdfs: FileSystem = FileSystem.get(datioSparkSession.getSparkSession.sparkContext.hadoopConfiguration)

    val newerDate = Try(recursivePathFinder(hdfs, parentPathObject, partitionDateColumnName)
      .filter(_.getName.contains(partitionDateColumnName + PARTITION_SPLIT_CHAR + year + separator + month))
      .map(_.getName.split(PARTITION_SPLIT_CHAR).tail.head).max).toOption
    newerDate match {
      case Some(_) => newerDate.get
      case None =>
        StructuralBoardsExceptionsController(exception = new NotExistMonthPartitionInParameterPath(parentPath, month, year),
          fileError = "FileSystemUtils", methodError = "returnNewerPartitionDateInMonth",
          exceptionMessage = s"FileSystemUtils: returnNewerPartitionDateInMonth:" +
            s" failure in method with this input params: $parentPath ; $partitionDateColumnName ; $month ; $year ; $separator").exceptionTreatment
        throw new NotExistMonthPartitionInParameterPath(parentPath, month, year)
    }
  }


  /**
   * Returns a collection of paths that identifies the physical partitions in which partitionsWithValuesMap
   * fields (key in the map) has partitionsWithValuesMap values (value in the map)
   *
   * @param basePath                String
   * @param partitionsWithValuesMap Map[String, String]
   * @param datioSparkSession       Array[String]
   * @return
   */
  def returnFullPartitionPathListFromValues(basePath: String,
                                            partitionsWithValuesMap: Map[String, String])
                                           (datioSparkSession: DatioSparkSession): Array[String] = {

    val fs: FileSystem = DatioFileSystem.get().qualify(basePath).fileSystem()
    val path: Path = DatioFileSystem.get().qualify(basePath).path()

    val fullPathList: Array[String] =
      fullPathsFinder(fs, path)(FALSE_VALUE)
        .map(_.toString)
    val partition_values = partitionsWithValuesMap
      .map(value => value._1.concat(PARTITION_SPLIT_CHAR.toString).concat(value._2))
    val fullPathList_filtered = partition_values
      .foldLeft(fullPathList)(
        (agg, value) => {
          val filteredList = agg.filter(_.contains(value))
          filteredList
        })
    fullPathList_filtered
      .filterNot(_.contains("_SUCCESS"))
  }

  /**
   * Check if file has an allowed physical path extension
   *
   * @param path Boolean
   * @return
   */
  def isAPhysicalFile(path: Path): Boolean =
    ALLOWED_PHYSICAL_PATHS_EXTENSIONS.map(path.getName.contains(_)).reduce(_ || _)

  /**
   * This method gets every level of partitions and their value from a path
   *
   * @param path   String
   * @param schema StructType
   * @return
   */
  def getPartitionsAndValueOfTheField(path: String, schema: StructType): Map[StructField, String] = {
    val partitionsAndValues: Map[String, String] = path
      .split(VAL_SLASH).filter(_.contains(PARTITION_SPLIT_CHAR))
      .map(
        partitionToSplit => (partitionToSplit.split(PARTITION_SPLIT_CHAR).head, partitionToSplit.split(PARTITION_SPLIT_CHAR)(1))
      ).toMap
    if (partitionsAndValues.isEmpty) Map() else {
      partitionsAndValues
        .map(partition => (
          Try(
            schema.fields.filter(_.name.equals(partition._1)).head)
            .getOrElse(StructField.apply(partition._1, DataTypes.StringType, TRUE_VALUE)),
          partition._2)
        )
    }
  }

  /**
   * Include partitions column and its filtered value. Useful after reading data directly from partition path
   *
   * @param partitionsAndItsValue Map[StructField, String]
   * @param dataToAppend          DataFrame
   * @return
   */
  def includePartitionColumnsAndTheirValue(partitionsAndItsValue: Map[StructField, String],
                                           dataToAppend: DataFrame): DataFrame = {
    if (partitionsAndItsValue.nonEmpty) {
      partitionsAndItsValue
        .foldLeft(dataToAppend)((agg, field) => {
          agg.withColumn(field._1.name, lit(field._2).cast(field._1.dataType))
        }
        )
    } else {
      dataToAppend
    }
  }

  /// FUNCIONES DE SMART CLEANER

  /**
   * Delete a directory or file not governed
   *
   * @param dfs  The DatioFileSystem
   * @param path The path to delete
   * @return
   */
  def deleteNonGoverned(dfs: DatioFileSystem, path: String): Boolean = {
    val fs = dfs.qualify(path).fileSystem()
    if (fs.exists(new Path(path))) {
      logger.warn(s"Deleting existing non governed path '$path'")
      Try {
        fs.delete(new Path(path), true)
      } match {
        case Success(true) => TRUE_VALUE
        case Success(false) => logger.error(s"Error deleting non governed: $path without known reason")
          FALSE_VALUE
        case Failure(ex) => logger.error(s"Error deleting non governed: $path ex: ${ex.getMessage}")
          FALSE_VALUE
      }
    } else {
      logger.warn(s"Path: $path did not exist")
      TRUE_VALUE
    }
  }

  /**
   * Delete a partition if path is Governed
   *
   * @param dfs  The DatioFileSystem
   * @param path The path to the table and partition
   * @return
   */
  def deleteGoverned(dfs: DatioFileSystem, path: String): Boolean = {
    val fs = dfs.qualify(path).fileSystem()
    val governedPath = dfs.qualify(path).path()
    if (fs.exists(governedPath)) {
      logger.warn(s"Deleting existing governed path '$governedPath'")
      Try {
        dfs.dropPartition(path)
      } match {
        case Success(true) => TRUE_VALUE
        case Success(false) => logger.error(s"Error deleting governed: $path without known reason")
          FALSE_VALUE
        case Failure(ex) => logger.error(s"Error deleting governed: $path ex: ${ex.getMessage}")
          FALSE_VALUE
      }
    } else {
      logger.warn(s"Governed path: $path did not exist")
      TRUE_VALUE
    }
  }

  /**
   * Delete a directory or file
   *
   * @param dfs  The DatioFileSystem
   * @param path The path to delete as string
   * @return
   */
  def delete(dfs: DatioFileSystem, path: String): Boolean = {
    isPathGoverned(path) match {
      case true => deleteGoverned(dfs, path)
      case false => deleteNonGoverned(dfs, path)
    }
  }

  /**
   * Check if path is in list of governed paths.
   * Governed paths is a list of literal string defined by Dataproc SDK
   *
   * @param path Path to check if it is governed
   * @return if is governed or not
   */
  def isPathGoverned(path: String): Boolean = {
    val governedPathsList = GOVERNED_DATA_PATHS
    val isGoverned = governedPathsList.exists(new GlobPattern(_).matches(path))
    isGoverned
  }

  /**
   * Check if given path exists
   *
   * @param dfs  The DatioFileSystem
   * @param path The path to delete as string
   * @return
   */
  def pathExists(dfs: DatioFileSystem, path: String): Boolean = {
    isPathGoverned(path) match {
      case true =>
        val fs = dfs.qualify(path).fileSystem()
        val governedPath = dfs.qualify(path).path()
        fs.exists(governedPath)
      case false =>
        val fs = dfs.qualify(path).fileSystem()
        fs.exists(new Path(path))
    }
  }

}
