package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, NULL_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.datio.dataproc.compactor.compaction.CompactorBuilder
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.spark.sql.SparkSession
import org.slf4j.{Logger, LoggerFactory}

object SparkCompactorController {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  case class CompactorParams(withSparkSession: SparkSession = NULL_VALUE,
                             withFormat: String = "parquet",
                             withOverwrite: (Boolean, Boolean) = (FALSE_VALUE, TRUE_VALUE),
                             withCompactionMode: (Boolean, Option[String]) = (FALSE_VALUE, Some("coalesce")),
                             withRepartitionColumns: (Boolean, List[String]) = (FALSE_VALUE, List()),
                             withPartitionsFilter: (Boolean, List[String]) = (FALSE_VALUE, List()),
                             sourcePath: String,
                             targetPath: Option[String]) {
    val optionalParams = List("withOverwrite",
      "withCompactionMode",
      "withRepartitionColumns",
      "withPartitionsFilter")
  }

  val buildAndLaunchCompactor: (CompactorParams, DatioSparkSession) => String = (compactorParams: CompactorParams, datioSparkSession: DatioSparkSession) => {
    val dfs = DatioFileSystem.get()

    val withOverwrite = if (compactorParams.withOverwrite._1) compactorParams.withOverwrite._2 else TRUE_VALUE
    val withCompactionMode = if (compactorParams.withCompactionMode._1) compactorParams.withCompactionMode._2 else Some("coelesce")
    val withRepartitionColumns = if (compactorParams.withRepartitionColumns._1) compactorParams.withRepartitionColumns._2 else List()
    val withPartitionsFilter = if (compactorParams.withPartitionsFilter._1) compactorParams.withPartitionsFilter._2 else List()

    val builder = CompactorBuilder()
      .withSparkSession(compactorParams.withSparkSession)
      .withFormat(compactorParams.withFormat)
      .withOverwrite(withOverwrite)
      .withCompactionMode(withCompactionMode)
      .withRepartitionColumns(withRepartitionColumns)
      .withPartitionsFilter(withPartitionsFilter)

    try {
      builder
        .build
        .compactTable(compactorParams.sourcePath, compactorParams.targetPath)
        .getSummary
    } catch {
      case _: java.lang.UnsatisfiedLinkError =>
        logger.warn(s"SparkCompactorController: Something went wrong during compactor process")
        CDDExecutionStats
          .addWarnMessage("Compactor_process", "SparkCompactorController", "buildAndLaunchCompactor",
            "error while trying to compact output, java.lang.UnsatisfiedLinkError is a known local environment execution error. " +
              "Is an error if it's shown on Work/live environment.")
        FileSystemUtils.delete(dfs, compactorParams.sourcePath.concat("_tmp"))
        ""
      case _ =>
        logger.warn(s"SparkCompactorController: Something went wrong during compactor process")
        CDDExecutionStats
          .addWarnMessage("Compactor_process", "SparkCompactorController",
            "buildAndLaunchCompactor", "error while trying to compact output, check ")
        FileSystemUtils.delete(dfs, compactorParams.sourcePath.concat("_tmp"))
        ""
    }
  }
  val setCompactorReportIntoProcessFinalReport: String => Unit =
    (summary: String) =>
      CDDExecutionStats.addCompactorSummary(summary)
}
