package com.bbva.projectsdatio.cdd.structuralboards.commons.appManager

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.ReadUtils
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.spark.sql.DataFrame
import org.slf4j.{Logger, LoggerFactory}

object HistorificadorManager{
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * The function filters data from given path with given partition values
   * Since v2.4.0, those partitions are read independently so that incoherent
   * schemas can be read. This is due to the use of ReadUtils.flexibleSchemaSeveralPartitionsFilteredDataRead method
   *
   * @param datioSparkSession            Initialized DatioSparkSession
   * @param principalPath    principal path taken from globalParameter
   * @param columnsName      partitioning fields
   * @param columnsValue     partitioning fields' values
   * @param applyFilter      geography partitioning field
   * @param auditColumn      audit column name of read dataframe
   * @param schema           output schema
   * @return filtered dataframe
   */
  def filterDfInformation(datioSparkSession: DatioSparkSession,
                          principalPath: String, columnsName: Seq[String],
                          columnsValue: Seq[String], applyFilter: Seq[String], auditColumn: String)(schema: DatioSchema): DataFrame = {
    logger.info(s"CDDHistorificador: Init Method filterDfInformation")
    val partitionRelevantInfo: Seq[(String, String, String)] = (columnsName zip columnsValue) zip applyFilter map {
      case ((x, y), z) => (x, y, z)
    }
    val schemaFields: Array[String] = schema.getStructType.fields.map(_.name)
    logger.info(s"CDDHistorificador: Method filterDfInformation: Validating if columnsName and auditColumnName columns are in dataFrame")
    TechnicalValidation.listElemValidator(columnsName :+ auditColumn, schemaFields, VAL_COLUMNS_NAME + " or auditColumnName")
    logger.info(s"CDDHistorificador: Method filterDfInformation: Validated columnsName and auditColumnName parameters")
    ReadUtils.safeReader(principalPath, schema, partitionRelevantInfo)(datioSparkSession)(schema.getStructType,
      schema, isHistorifier = TRUE_VALUE)(TRUE_VALUE)
  }

}
