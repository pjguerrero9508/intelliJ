package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.appManager.CleanerManager
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.StructuralBoardsExceptionsController
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.api.SparkProcess
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.commons.lang.exception.ExceptionUtils
import org.slf4j.{Logger, LoggerFactory}

import scala.util.{Failure, Success, Try}

/**
 * Main file for CleanBoards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * CleanBoardsProcess {
 * ...
 * }
 *
 */
trait CleanBoardsTrait extends SparkProcess {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)


  @throws[Exception]
  /**
   * @param runtimeContext RuntimeContext
   * @return value 0 if process finished successfully; otherwise value 1
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info(s"CDDCommons: Init process CleanBoards")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val config = runtimeContext.getConfig.getConfig("CDDCleanBoards")
    Try {
      val cleanParameter = setterGlobalConfigurationReadedParamsReader(config)
      CleanerManager.cleanMainPath(datioSparkSession, cleanParameter.cleanPath, cleanParameter.dateIngestion,
        cleanParameter.persistenceLimit, cleanParameter.datePartitionName, cleanParameter.dateFormat, cleanParameter.failIfNullDf)
    } match {
      case Success(_) =>
        logger.info(s"CDDCleanBoards: Process CleanBoard successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.info(s"CDDCleanBoards: Something went wrong during CleanBoards process")
        logger.error(s"CDDCleanBoards: Input Args: ${config.toString}")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        StructuralBoardsExceptionsController(exception = new Exception(ex),
          fileError = "CleanBoards", methodError = "runProcess", exceptionMessage = ex.getMessage).exceptionTreatment
        logger.info(s"CDDCleanBoards: Finished process CleanBoards")
        1
    }
  }

  /**
   * This method setter global configurations read of config input
   *
   * @param config Config retrieved from args
   * @return CaseClass whit all global parameter
   */
  def setterGlobalConfigurationReadedParamsReader(config: Config): CleanConfiguration = {
    logger.info(s"CDDCleanBoards: Init method setterGlobalConfigurationReadedParamsReader")
    TechnicalValidation.configStringParamValidator(CONF_CLEAN_BOARDS_DATE_INGESTION, config)
    val dateIngestion: String = config.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    TechnicalValidation.dateValidator(dateIngestion, CONF_CLEAN_BOARDS_DATE_INGESTION)
    logger.info(s"CDDCleanBoards: Value of dateIngestion: $dateIngestion")
    CDDExecutionStats.addInputParamMessage("dateIngestion",
      "CleanBoards", "setterGlobalConfigurationReadedParamsReader", dateIngestion)
    TechnicalValidation.configStringParamValidator(CONF_CLEAN_BOARDS_PATH, config)
    val cleanPath: String = config.getString(CONF_CLEAN_BOARDS_PATH)
    logger.info(s"CDDCleanBoards: Value of path to clean: $cleanPath")
    CDDExecutionStats.addInputParamMessage("cleanPath",
      "CleanBoards", "setterGlobalConfigurationReadedParamsReader", cleanPath)
    TechnicalValidation.configIntParamValidator(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT, config)
    val persistenceLimit: Int = config.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    logger.info(s"CDDCleanBoards: Value of persistenceLimit: $persistenceLimit")
    CDDExecutionStats.addInputParamMessage("persistenceLimit",
      "CleanBoards", "setterGlobalConfigurationReadedParamsReader", persistenceLimit.toString)
    TechnicalValidation.configStringParamValidator(CONF_CLEAN_BOARDS_DATE_NAME, config)
    val datePartitionName: String = config.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    logger.info(s"CDDCleanBoards: Name of date partition: $datePartitionName")
    CDDExecutionStats.addInputParamMessage("datePartitionName",
      "CleanBoards", "setterGlobalConfigurationReadedParamsReader", datePartitionName)
    TechnicalValidation.configStringParamValidator(CONF_CLEAN_BOARDS_DATE_FORMAT, config)
    val dateFormat: String = config.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    logger.info(s"CDDCleanBoards: Date format of date partition field: $dateFormat")
    CDDExecutionStats.addInputParamMessage("dateFormat",
      "CleanBoards", "setterGlobalConfigurationReadedParamsReader", dateFormat)
    val failIfNullDf: Int = Try(config.getInt(CONF_CLEAN_FAIL_NULL_DATAFRAME))
      .getOrElse(DEFAULT_HISTORIFICADOR_FAIL_NULL_DATAFRAME)
    logger.info(s"CDDCleanBoards: Fail process if dataFrame has 0 rows: $failIfNullDf")
    CDDExecutionStats.addInputParamMessage("failIfNullDf",
      "CleanBoards", "setterGlobalConfigurationReadedParamsReader", failIfNullDf.toString)
    CleanConfiguration(dateIngestion,
      cleanPath,
      persistenceLimit,
      datePartitionName,
      dateFormat,
      failIfNullDf)
  }

  override def getProcessId: String = "CDDCleanBoards"


}

class CleanBoards extends CleanBoardsTrait
