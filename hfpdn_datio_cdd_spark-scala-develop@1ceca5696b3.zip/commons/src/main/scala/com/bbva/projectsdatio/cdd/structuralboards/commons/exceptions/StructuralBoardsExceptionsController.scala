package com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import org.apache.commons.lang.exception.ExceptionUtils
import org.slf4j.{Logger, LoggerFactory}

/**
 * Controller to handle adhoc exceptions
 *
 * @param exception        : Exception Default = new StructuralBoardsExceptions
 * @param fileError        : String Default = "Code file has not been detected."
 * @param methodError      : String Default = "Code function/method has not been detected."
 * @param exceptionMessage : String Default = "Default exception message"
 */
case class StructuralBoardsExceptionsController(
                                                 exception: Exception = new StructuralBoardsExceptions,
                                                 fileError: String = "Code file has not been detected.",
                                                 methodError: String = "Code function/method has not been detected.",
                                                 exceptionMessage: String = "Default exception message.") {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)
  val showOnLogger: Unit => Unit = _ => {
    logger.error(s"Exception message: ", exceptionMessage)
    logger.error(s"Exception stacktrace: ", ExceptionUtils.getStackTrace(exception))
  }
  val setExecutionStatKnownExceptionMessage: Unit => Unit = _ => {
    exception match {
      case exception: StructuralBoardsExceptions => CDDExecutionStats
        .addKnownExceptionMessage(exception, fileError, methodError)
      case _ => CDDExecutionStats
        .addUnKnownExceptionMessage(exception, fileError, methodError)
    }
  }

  val exceptionTreatment: Unit => Unit = {
    showOnLogger andThen
      setExecutionStatKnownExceptionMessage
  }
}
