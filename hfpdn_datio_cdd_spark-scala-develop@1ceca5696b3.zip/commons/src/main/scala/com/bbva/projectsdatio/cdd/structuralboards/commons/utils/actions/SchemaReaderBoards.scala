package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import java.net.URI

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{NotExistParameterPath, SchemaReadingException, StructuralBoardsExceptionsController}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.ConfigException

import scala.util.{Failure, Success, Try}

object SchemaReaderBoards {

  @throws[NotExistParameterPath]
  @throws[SchemaReadingException]
  /**
   * This method reads from a configuration input the schema and maps this into a schema of structType.
   * In the following cases this methods reports a schemaError:
   * - The configuration path is invalid.
   * - The field type attribute cannot be converted into an internal datatype
   * - The fields attribute of a record has an unexpected type.
   * - Some field attribute is unsupported.
   * In case on of these errors occurs the output is invalid, and the schema errors are reported in a list.
   *
   * @param pathSchema      Path to schema.
   * @param mandatory       Flag in order to determine if the schema is mandatory.
   * @param includeDeleted  Flag in order to include deleted fields.
   * @param includeMetadata Flag in order to include metadata fields.
   * @return ReadingResult type with a schema if the output is valid and a schema error list if the output is invalid.
   */
  def readSchema(pathSchema: String,
                 mandatory: Boolean = TRUE_VALUE,
                 includeDeleted: Boolean = FALSE_VALUE,
                 includeMetadata: Boolean = TRUE_VALUE
                ): DatioSchema = {
    Try(schemaReader(pathSchema, includeDeleted, includeMetadata)) match {
      case Failure(_: ConfigException.Missing) if !mandatory =>
        StructuralBoardsExceptionsController(exception = new NotExistParameterPath(pathSchema),
          fileError = "SchemaReaderBoards", methodError = "readSchema",
          exceptionMessage = s"SchemaReaderBoards: readSchema:" +
            s" missing schema in path $pathSchema").exceptionTreatment
        throw new NotExistParameterPath(pathSchema)
      case Failure(_) =>
        StructuralBoardsExceptionsController(exception = new SchemaReadingException(pathSchema),
          fileError = "SchemaReaderBoards", methodError = "readSchema",
          exceptionMessage = s"SchemaReaderBoards: readSchema:" +
            s" exception while reading $pathSchema").exceptionTreatment
        throw new SchemaReadingException(pathSchema)
      case Success(_) => schemaReader(pathSchema, includeDeleted, includeMetadata)
    }
  }

  val schemaReader: (String, Boolean, Boolean) => DatioSchema =
      (pathSchema: String, includeDeleted: Boolean, includeMetadata: Boolean) => {
    DatioSchema.getBuilder
      .withDeletedFields(includeDeleted)
      .withMetadataFields(includeMetadata)
      .fromURI(URI.create(pathSchema))
      .build
  }
}
