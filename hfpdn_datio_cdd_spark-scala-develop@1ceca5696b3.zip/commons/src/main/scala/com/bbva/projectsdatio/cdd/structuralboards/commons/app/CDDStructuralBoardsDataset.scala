package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{BadPartitionColumnsNameException, EmptyParameterPath, ParamNotInformedException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.DatasetConfiguration
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row}
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConverters._
import scala.util.Try

trait CDDStructuralBoardsDataset[T] {
  val original: DataFrame
  val config: Config
  val datasetParams: DatasetParams
  val fieldsNotInOutput: Seq[String] = Seq()
  val fieldsNotInInput: Seq[String] = Seq()
  var globalParameter: DatasetConfiguration = _
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * This method is the entry point in order to initialize every CDDStructuralBoardsDataset[T]. The emptyInitializeMode
   * selector sets if the dataset must be informed in the board construction or not
   *
   * @param datioSparkSession   : DatioSparkSession
   * @param outputSchema        : StructType
   * @param emptyInitializeMode : Boolean
   * @return
   */
  def getCustomizedDataSet(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema)(emptyInitializeMode: Boolean): T = {
    this.globalParameter = setterDatasetConfiguration(config)
    val dfs = DatioFileSystem.get()
    val pathExists: Boolean = FileSystemUtils.pathExists(dfs, this.globalParameter.pathData)
    if (!pathExists) {
      logger.warn(s"CDDStructuralBoards: No path was found for dataset ${datasetParams.dataSetDescription}," +
        "entity will be automatically used as if it were in NOT_INFORMED_DATASET")
    }
    if (emptyInitializeMode || !pathExists) {
      val applyResult = applyEmpty(datioSparkSession, outputSchema)
      anyToCDDStructuralBoardsDataset(applyResult).dataSetEmptyTransformations()
    } else {
      val applyResult = apply(datioSparkSession, outputSchema)
      anyToCDDStructuralBoardsDataset(applyResult).dataSetTransformations(outputSchema)
    }
  }

  def anyToCDDStructuralBoardsDataset(any: Any): CDDStructuralBoardsDataset[T] = {
    any.asInstanceOf[CDDStructuralBoardsDataset[T]].globalParameterSetter()
  }

  def globalParameterSetter(): CDDStructuralBoardsDataset[T] = {
    this.globalParameter = setterDatasetConfiguration(config)
    this.asInstanceOf[CDDStructuralBoardsDataset[T]]
  }

  /**
   * Gets the dataset info from its selected path. Also initializes partition columns so that those can be used if needed.
   * Path must include those partitions columns for reading data
   *
   * @param datioSparkSession : DatioSparkSession
   * @return
   */
  def apply(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): T = {
    val schema: StructType = createRelevantSchema(outputSchema)
    val df: DataFrame = {
      globalParameter.previousFilterAppliedFields match {
        case seq if seq.nonEmpty =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription}" +
            s" will be previously filtered using [${seq.mkString(", ")}] field")
          val valuesPartition: Seq[(String, String, String)] = buildValuesPartitionParam()
          ReadUtils.safeReader(globalParameter.pathData, SchemaReaderBoards.readSchema(globalParameter.schemaPath, includeDeleted = TRUE_VALUE),
            valuesPartition, fieldsNotInOutput, fieldsNotInInput)(datioSparkSession)(schema, outputSchema)(TRUE_VALUE)
        case _ =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription} won't be previously filtered")
          ReadUtils.readParquetWithSchema(datioSparkSession, globalParameter.pathData,
            SchemaReaderBoards.readSchema(globalParameter.schemaPath, includeDeleted = TRUE_VALUE))
      }
    }
    wrap(df)
  }

  /**
   * Includes audit date field, relevant fields and fieldsNotInOutput
   *
   * @param outputSchema
   * @return
   */
  def createRelevantSchema(outputSchema: DatioSchema): StructType = {
    val datasetRelevantColumns: Seq[String] = {
      globalParameter.relevantColumns.:+(globalParameter.auditDateColumnName) ++ globalParameter.previousFilterAppliedFields
    }
    schemaFromRelevantColumns(outputSchema, datasetRelevantColumns)
  }

  /**
   * Select just the relevant fields in the schema and returns a new schema with that columns
   *
   * @param outputSchema
   * @param relevantColumns
   * @return
   */
  def schemaFromRelevantColumns(outputSchema: DatioSchema, relevantColumns: Seq[String]): StructType = {
    StructType(
      outputSchema.getStructType
        .filter(f => relevantColumns.contains(f.name))
    )
  }

  /**
   * Returns partition needed attributes: those are name, value and flag for filtering or not
   *
   * @param partitionsNames
   * @param partitionsValues
   * @param filterValues
   * @return
   */
  def buildValuesPartitionParam(partitionsNames: Seq[String],
                                partitionsValues: Seq[String],
                                filterValues: Seq[String]): Seq[(String, String, String)] = {
    partitionsNames
      .zip(partitionsValues).zip(filterValues).map(value => (value._2, value._1._1, value._1._2))
  }

  def buildValuesPartitionParam(): Seq[(String, String, String)] = {
    globalParameter.previousFilterAppliedFields
      .map(fieldName =>
        if (fieldName.equals(globalParameter.dateColumnName)) {
          (globalParameter.dateColumnName, globalParameter.dateColumnValue, FIELD_TO_FILTER_FLAG)
        } else if (fieldName.equals(globalParameter.entificColumnName)) {
          (globalParameter.entificColumnName, globalParameter.entificColumnValue, FIELD_TO_FILTER_FLAG)
        } else {
          throw new
              BadPartitionColumnsNameException(globalParameter.entificColumnName, this.getClass.toString)
        }
      )
  }

  /**
   * In case that any (not skelet) dataset is set in "NotInformedDataset" param, an empty dataset for
   * this CDDStructuralBoardsDataset[T] will be used in the board construction process. All its columns
   * will be set as null values but will remain at board output layout.
   *
   * @param datioSparkSession : DatioSparkSession
   * @param outputSchema      : StructType
   * @return
   */
  def applyEmpty(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): T = {
    val schemaOfEmptyDataFrame: StructType = StructType(
      outputSchema.getStructType.filter(f => globalParameter.relevantColumns.contains(f.name)))
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaOfEmptyDataFrame)
    wrap(df)
  }

  /**
   * Sets the param DataFrame in original value of the CDDStructuralBoardsDataset[T]
   *
   * @param transformed : DataFrame
   * @return
   */
  def wrap(transformed: DataFrame): T

  /**
   * Writes de original (DataFrame) value of CDDStructuralBoardsDataset[T] in disk
   * and read it back. It is used for dividing transformations DAGs with this intermediate action.
   * Also works as a recovery point for spark executors.
   *
   * @param datioSparkSession : DatioSparkSession
   * @param instantTempPath   : String
   * @return
   */
  def checkpoint(datioSparkSession: DatioSparkSession, instantTempPath: String): T = {
    WriteUtils.simpleWriteToParquet(datioSparkSession, original, instantTempPath)
    wrap(ReadUtils.simpleReadParquet(datioSparkSession, instantTempPath))
  }

  /**
   * Returns the param DataFrame in original value of the CDDStructuralBoardsDataset[T]
   *
   * @return
   */
  def getDataFrame(): DataFrame = {
    original
  }

  /**
   * Gets the joins fields for this dataset that would be used to add its columns to the main board
   *
   * @return
   */
  def getJoinFields: Seq[String] = {
    globalParameter.joinColumns
  }

  /**
   * selection of columns of interest from the table
   *
   * @return Dataframe with the interest columns' selection
   */
  def selectRelevantColumns(): T = {
    val relevantColumns = globalParameter.relevantColumns.map(col)
    logger.info(s"CDDStructuralBoards: selectRelevantColumns - Relevant Columns in ${datasetParams.dataSetDescription} [$relevantColumns]")
    val transformed: DataFrame = original.select(relevantColumns: _*)
    wrap(transformed)
  }

  /**
   * This method initializes every "relevant" column which is not in original dataframe with null values.
   * As far as v1.10.0 the column that is going to be initialized must be part of the output schema.
   *
   * @param outputSchema : StructType
   * @return
   */
  def initializeNotInformedColumns(outputSchema: DatioSchema): T = {
    logger.info(s"CDDStructuralBoards: initializeNotInformedColumns -" +
      s"Relevant Columns in ${datasetParams.dataSetDescription} [$globalParameter.relevantColumns]")
    val initialized: DataFrame = SchemaValidatorBoards
      .initializeNotInformedColumns(original,
        outputSchema.getStructType,
        globalParameter.relevantColumns
      )
    wrap(initialized)
  }

  /**
   * This method gets the old and new columns names in order to rename them in dataframe
   *
   * @return
   */
  def renameDataSetInputFields(): T = {
    if (globalParameter.oldNames.nonEmpty) {
      val renameMap: Map[String, String] = globalParameter.oldNames
        .zip(globalParameter.newNames).toMap
      val new_df = renameMap.foldLeft(original)((acc, column) => acc.withColumnRenamed(column._1, column._2))
      wrap(new_df)
    } else {
      wrap(original)
    }
  }

  /**
   * This method calls the necessary steps to precondition the CDDStructuralBoardsDataset[T] object.
   * As for v2.0.0, those steps are:
   * - renameDataSetInputFields
   * - initializeNotInformedColumns
   * - selectRelevantColumns
   *
   * @param outputSchema : StructType
   * @return
   */
  def dataSetTransformations(outputSchema: DatioSchema): T = {
    val renamed = renameDataSetInputFields()
    val initialized = anyToCDDStructuralBoardsDataset(renamed).initializeNotInformedColumns(outputSchema)
    anyToCDDStructuralBoardsDataset(initialized).selectRelevantColumns()
  }

  /**
   * In case CDDStructuralBoardsDataset[T] object has been selected in NotInformedDataframe, just the
   * renameDataSetInputFields transformation is applied
   *
   * @return
   */
  def dataSetEmptyTransformations(): T = {
    renameDataSetInputFields()
  }

  /**
   * Check if join columns are in datasets
   *
   * @param dataSet  : CDDStructuralBoardsDataset[_]
   * @param joinCols : List[String]
   */
  def dataSetsColumnsChecker(dataSet: CDDStructuralBoardsDataset[_], joinCols: List[String]): Unit = {
    TechnicalValidation.listStringValidator(joinCols, dataSet.getDataFrame().columns.toSeq, s"Right Dataset - has not join columns: ${joinCols.mkString(", ")}")
    TechnicalValidation.listStringValidator(joinCols, getDataFrame().columns.toSeq, s"MainBoard Dataset - has not join columns: ${joinCols.mkString(", ")}")
  }

  /**
   * Returns las partition date. Default value for separator will be "-"
   *
   * @param datioSparkSession
   * @return
   */
  def getLastPartitionDateOfDf(datioSparkSession: DatioSparkSession, separator: String = "-"): String = {
    FileSystemUtils
      .returnNewerPartitionDateInMonth(globalParameter.pathData,
        datioSparkSession, globalParameter.dateColumnName,
        globalParameter.dateColumnValue.substring(SUBSTRING_POSITION_5, SUBSTRING_POSITION_7),
        globalParameter.dateColumnValue.substring(SUBSTRING_POSITION_0, SUBSTRING_POSITION_4),
        separator)
  }

  def setterDatasetConfiguration(config: Config): DatasetConfiguration = {
    TechnicalValidation.configStringParamValidator(datasetParams.dataSetPath, config)
    val pathData: String = Try(config.getString(datasetParams.dataSetPath))
      .getOrElse(throw new ParamNotInformedException(datasetParams.dataSetPath, "setterDatasetConfiguration"))
    TechnicalValidation.configStringParamValidator(datasetParams.dataSetSchemaPath, config)
    val schemaPath: String = Try(config.getString(datasetParams.dataSetSchemaPath))
      .getOrElse(throw new ParamNotInformedException(datasetParams.dataSetPath, "setterDatasetConfiguration"))
    val dateColumnName: String = Try(config.getString(CONF_DATE_COLUMN_NAME))
      .getOrElse(throw new ParamNotInformedException(CONF_DATE_COLUMN_NAME, "setterDatasetConfiguration"))
    val dateColumnValue: String = Try(config.getString(CONF_DATE_COLUMN_VALUE))
      .getOrElse(throw new ParamNotInformedException(CONF_DATE_COLUMN_VALUE, "setterDatasetConfiguration"))
    val entificColumnName: String = Try(config.getString(CONF_ENTIFIC_COLUMN_NAME))
      .getOrElse(throw new ParamNotInformedException(CONF_ENTIFIC_COLUMN_NAME, "setterDatasetConfiguration"))
    val entificColumnValue: String = Try(config.getString(CONF_ENTIFIC_COLUMN_VALUE))
      .getOrElse(throw new ParamNotInformedException(CONF_ENTIFIC_COLUMN_VALUE, "setterDatasetConfiguration"))
    val auditDateColumnName: String = Try(config.getString(CONF_AUDIT_COLUMN_NAME))
      .getOrElse(throw new ParamNotInformedException(CONF_AUDIT_COLUMN_NAME, "setterDatasetConfiguration"))
    TechnicalValidation.configStringListParamValidator(datasetParams.dataSetRelevantFields, config)
    val relevantColumns: Seq[String] = Try(config.getStringList(datasetParams.dataSetRelevantFields).asScala)
      .getOrElse(throw new ParamNotInformedException(datasetParams.dataSetRelevantFields, "setterDatasetConfiguration"))
    TechnicalValidation.configStringListParamValidator(datasetParams.dataSetJoinFields, config)
    val joinColumns: Seq[String] = Try(config.getStringList(datasetParams.dataSetJoinFields).asScala)
      .getOrElse(throw new ParamNotInformedException(datasetParams.dataSetJoinFields, "setterDatasetConfiguration"))
    val oldNames: Seq[String] = Try(config.getString(datasetParams.dataSetRenameOldFields).split(BOARDS_SPLIT_CHAR).toSeq).getOrElse(Nil)
    val newNames: Seq[String] = Try(config.getString(datasetParams.dataSetRenameNewFields).split(BOARDS_SPLIT_CHAR).toSeq).getOrElse(Nil)
    val previousFilterAppliedFields: Seq[String] = Try(config
      .getStringList(datasetParams.previousFilterAppliedFields).asScala).getOrElse(Seq())
    DatasetConfiguration(pathData,
      schemaPath,
      dateColumnName,
      dateColumnValue,
      entificColumnName,
      entificColumnValue,
      auditDateColumnName,
      relevantColumns,
      joinColumns,
      oldNames,
      newNames,
      previousFilterAppliedFields)
  }
}

trait CDDStructuralMainBoardDataset[T] extends CDDStructuralBoardsDataset[T] {
  override def apply(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): T = {
    val schema: StructType = createRelevantSchema(outputSchema)
    val df: DataFrame = {
      globalParameter.previousFilterAppliedFields match {
        case seq if seq.nonEmpty =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription}" +
            s" will be previously filtered using [${seq.mkString(", ")}] field")
          val valuesPartition: Seq[(String, String, String)] = buildValuesPartitionParam()
          ReadUtils.safeReader(globalParameter.pathData, SchemaReaderBoards.readSchema(globalParameter.schemaPath, includeDeleted = TRUE_VALUE),
            valuesPartition, fieldsNotInOutput, fieldsNotInInput)(datioSparkSession)(schema, outputSchema)(FALSE_VALUE)
        case _ =>
          logger.info(s"CDDStructuralBoards: input dataset ${datasetParams.dataSetDescription} won't be previously filtered")
          ReadUtils.readParquetWithSchema(datioSparkSession, globalParameter.pathData,
            SchemaReaderBoards.readSchema(globalParameter.schemaPath, includeDeleted = TRUE_VALUE))

      }
    }
    wrap(df)
  }

  /**
   * This method is the entry point in order to initialize every CDDStructuralBoardsDataset[T]. The emptyInitializeMode
   * selector, in this kind of datasets has not any effect, Main Board Datasets will allways be informed.
   * A warning log will be shown if the user tries to set it as "NotInformedDataset"
   *
   * @param datioSparkSession   : DatioSparkSession
   * @param outputSchema        : StructType
   * @param emptyInitializeMode : Boolean
   * @return
   */
  override def getCustomizedDataSet(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema)(emptyInitializeMode: Boolean): T = {
    this.globalParameter = setterDatasetConfiguration(config)
    if (emptyInitializeMode) {
      CDDExecutionStats
        .addWarnMessage("Input entities warn",
          "CDDStructuralBoardDataset",
          "getCustomizedDataSet",
          s"CDDStructuralBoards: getCustomizedDataSet for root entity ${this.getClass.toString} can" +
            s" not be set as empty dataset.")
      val applyResult = apply(datioSparkSession, outputSchema)
      anyToCDDStructuralBoardsDataset(applyResult).dataSetTransformations(outputSchema)
    } else {
      val applyResult = apply(datioSparkSession, outputSchema)
      anyToCDDStructuralBoardsDataset(applyResult).dataSetTransformations(outputSchema)
    }
  }

  override def applyEmpty(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): T = {
    val schemaOfEmptyDataFrame: StructType = StructType(
      outputSchema.getStructType.filter(f => globalParameter.relevantColumns.contains(f.name)))
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaOfEmptyDataFrame)
    CDDExecutionStats
      .addKnownExceptionMessage(new EmptyParameterPath(globalParameter.pathData), "CDDStructuralBoardDataset", "applyEmpty")
    throw new EmptyParameterPath(globalParameter.pathData)
    wrap(df)
  }

  def selectTablonColumns(): CDDStructuralBoardsDataset[T]

  override def getDataFrame(): DataFrame = super.getDataFrame()

  def join(right: CDDStructuralBoardsDataset[_]): CDDStructuralMainBoardDataset[T]

  override def setterDatasetConfiguration(config: Config): DatasetConfiguration = {
    TechnicalValidation.configStringParamValidator(datasetParams.dataSetPath, config)
    val pathData: String = config.getString(datasetParams.dataSetPath)
    TechnicalValidation.configStringParamValidator(datasetParams.dataSetSchemaPath, config)
    val schemaPath: String = Try(config.getString(datasetParams.dataSetSchemaPath))
      .getOrElse(throw new ParamNotInformedException(datasetParams.dataSetPath, "setterDatasetConfiguration"))
    val dateColumnName: String = config.getString(CONF_DATE_COLUMN_NAME)
    val dateColumnValue: String = config.getString(CONF_DATE_COLUMN_VALUE)
    val entificColumnName: String = config.getString(CONF_ENTIFIC_COLUMN_NAME)
    val entificColumnValue: String = config.getString(CONF_ENTIFIC_COLUMN_VALUE)
    val auditDateColumnName: String = config.getString(CONF_AUDIT_COLUMN_NAME)
    TechnicalValidation.configStringListParamValidator(datasetParams.dataSetRelevantFields, config)
    val relevantColumns: Seq[String] = config.getStringList(datasetParams.dataSetRelevantFields).asScala
    val joinColumns: Seq[String] = Seq()
    val oldNames: Seq[String] = Try(config.getString(datasetParams.dataSetRenameOldFields).split(BOARDS_SPLIT_CHAR).toSeq).getOrElse(Nil)
    val newNames: Seq[String] = Try(config.getString(datasetParams.dataSetRenameNewFields).split(BOARDS_SPLIT_CHAR).toSeq).getOrElse(Nil)
    val previousFilterAppliedFields: Seq[String] = Try(config
      .getStringList(datasetParams.previousFilterAppliedFields).asScala).getOrElse(Seq())
    DatasetConfiguration(pathData,
      schemaPath,
      dateColumnName,
      dateColumnValue,
      entificColumnName,
      entificColumnValue,
      auditDateColumnName,
      relevantColumns,
      joinColumns,
      oldNames,
      newNames,
      previousFilterAppliedFields)
  }
}

case class DatasetParams(dataSetDescription: String,
                         dataSetPath: String,
                         dataSetSchemaPath: String,
                         dataSetRelevantFields: String,
                         dataSetRenameOldFields: String,
                         dataSetRenameNewFields: String,
                         dataSetJoinFields: String,
                         previousFilterAppliedFields: String,
                         dataSetSelectOutputFields: Option[String] = None)

case class DatasetValues(pathData: String,
                         schemaPath: String,
                         dateColumnName: String,
                         dateColumnValue: String,
                         entificColumnName: String,
                         entificColumnValue: String,
                         auditDateColumnName: String,
                         relevantColumns: Seq[String],
                         joinColumns: Seq[String],
                         renameOldNames: Seq[String],
                         renameNewNames: Seq[String])
