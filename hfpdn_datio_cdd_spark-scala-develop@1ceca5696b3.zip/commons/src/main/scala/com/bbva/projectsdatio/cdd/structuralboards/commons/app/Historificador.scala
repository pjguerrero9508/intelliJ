package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.appManager.HistorificadorManager
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{SchemaValidationException, StructuralBoardsExceptionsController, ValueParameterException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils.pathExists
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SparkCompactorController.CompactorParams
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{SchemaReaderBoards, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.api.SparkProcess
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.datio.dataproc.sdk.schema.exception.DataprocSchemaException
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConverters
import scala.util.{Failure, Success, Try}

/**
 * Main file for Historificador process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * HistorificadorProcess {
 * ...
 * }
 *
 */
trait HistorificadorTrait extends SparkProcess {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  @throws[SchemaValidationException]
  @throws[ValueParameterException]
  @throws[Exception]
  /**
   * @param runtimeContext RuntimeContext
   * @return value 0 if process finished successfully; otherwise value 1
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info("CDDCommons: Init process Historificador")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val config = runtimeContext.getConfig.getConfig("CDDHistorificador")
    val dfs = DatioFileSystem.get()
    Try {
      val globalParameter: HistorificadorConfiguration = setterGlobalConfigurationReadedParamsReader(config)
      if (pathExists(dfs, globalParameter.principalPath)) {
        val outputSchema: DatioSchema = SchemaReaderBoards.readSchema(globalParameter.schemaPath)
        val filteredDf: DataFrame = HistorificadorManager
          .filterDfInformation(datioSparkSession, globalParameter.principalPath,
            globalParameter.columnsName, globalParameter.columnsValue,
            globalParameter.applyFilter, globalParameter.auditColumnName)(outputSchema)
        GenericUtils.emptyDfValidation(filteredDf, globalParameter.failIfNullDf)
        try {
          outputSchema.validate(filteredDf)
        } catch {
          case e: DataprocSchemaException.InvalidDatasetException =>
            val errors = JavaConverters
              .asScalaIteratorConverter(e.getErrors.iterator()).asScala.map(err => err.toString).mkString(", ")
            StructuralBoardsExceptionsController(exception = new SchemaValidationException(globalParameter.schemaPath),
              fileError = "Historificador", methodError = "runProcess",
              exceptionMessage = globalParameter.schemaPath + s". Schema validation errors: " + s"$errors").exceptionTreatment
            throw new SchemaValidationException(globalParameter.schemaPath)
        }
        WriteUtils.writeBackupBoardParquet(datioSparkSession, filteredDf, globalParameter.pathOutputBackup,
          globalParameter.repartitionBase, globalParameter.columnsName, globalParameter.auditColumnName, outputSchema, globalParameter.averageKBPerRecord)
      } else if (globalParameter.failIfNullDf.equals(1)) {
        StructuralBoardsExceptionsController(exception = new ValueParameterException(globalParameter.principalPath),
          fileError = "Historificador", methodError = "runProcess",
          exceptionMessage = s"CDDHistorificador: Path ${globalParameter.principalPath} does not exist, there is no data to historify").exceptionTreatment
        throw new ValueParameterException(globalParameter.principalPath)
      } else {
        CDDExecutionStats
          .addWarnMessage("Input entities warn", "Historificador", "runProcess",
            s"CDDHistorificador: Path ${globalParameter.principalPath} does not exist, there is no data to historify")
      }
    } match {
      case Success(_) =>
        logger.info(s"CDDHistorificador: Process Historificador successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.error(s"CDDHistorificador: Input Args: ${config.toString}")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        StructuralBoardsExceptionsController(exception = new Exception(ex),
          fileError = "Historificador", methodError = "runProcess",
          exceptionMessage = s"CDDHistorificador: Something went wrong during historification process").exceptionTreatment
        logger.info(s"CDDHistorificador: Finished process Historificador")
        1
    }
  }

  /**
   * Method that manages needed compactor params
   */
  val setCompactorParams: (DatioSparkSession, HistorificadorConfiguration) => CompactorParams =
    (datioSparkSession: DatioSparkSession, globalParameter: HistorificadorConfiguration) =>
      CompactorParams(
        withSparkSession = datioSparkSession.getSparkSession,
        withCompactionMode = (TRUE_VALUE, Some("coalesce")),
        withOverwrite = (TRUE_VALUE, TRUE_VALUE),
        withRepartitionColumns = (FALSE_VALUE, List()),
        sourcePath = globalParameter.principalPath,
        targetPath = None)

  /**
   * This method setter global configurations read from input config file
   *
   * @param config Config retrieved from args
   * @return CaseClass whit all global parameter
   */
  def setterGlobalConfigurationReadedParamsReader(config: Config): HistorificadorConfiguration = {
    logger.info(s"CDDHistorificador: Init method setterGlobalConfigurationReadedParamsReader")
    TechnicalValidation.configStringParamValidator(CONF_HISTORIFICADOR_PATH_PRINCIPAL, config)
    val principalPath: String = config.getString(CONF_HISTORIFICADOR_PATH_PRINCIPAL)
    logger.info(s"CDDHistorificador: Value of pathPrincipal: $principalPath")
    CDDExecutionStats.addInputParamMessage("principalPath",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", principalPath)
    TechnicalValidation.configStringParamValidator(CONF_HISTORIFICADOR_PATH_HISTORICAL, config)
    val pathOutputBackup: String = config.getString(CONF_HISTORIFICADOR_PATH_HISTORICAL)
    logger.info(s"CDDHistorificador: Value of pathHistorical: $pathOutputBackup")
    CDDExecutionStats.addInputParamMessage("pathOutputBackup",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", pathOutputBackup)
    TechnicalValidation.configStringParamValidator(CONF_HISTORIFICADOR_COLUMNS_NAME, config)
    val columnsName: Seq[String] = config.getString(CONF_HISTORIFICADOR_COLUMNS_NAME).split(HISTORIFICADOR_SPLIT_CHAR).toSeq
    logger.info(s"CDDHistorificador: Name of partition columns: $columnsName")
    CDDExecutionStats.addInputParamMessage("columnsName",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_HISTORIFICADOR_COLUMNS_NAME))
    TechnicalValidation.configStringParamValidator(CONF_HISTORIFICADOR_COLUMNS_VALUE, config)
    val columnsValue: Seq[String] = config.getString(CONF_HISTORIFICADOR_COLUMNS_VALUE).split(HISTORIFICADOR_SPLIT_CHAR).toSeq
    logger.info(s"CDDHistorificador: Value of partition columns: $columnsValue")
    CDDExecutionStats.addInputParamMessage("columnsValue",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_HISTORIFICADOR_COLUMNS_VALUE))
    TechnicalValidation.configStringParamValidator(CONF_HISTORIFICADOR_APPLY_FILTER, config)
    val applyFilter: Seq[String] = config.getString(CONF_HISTORIFICADOR_APPLY_FILTER).split(HISTORIFICADOR_SPLIT_CHAR).toSeq
    logger.info(s"CDDHistorificador: Apply filter by partition columns' value: $applyFilter")
    CDDExecutionStats.addInputParamMessage("applyFilter",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", config.getString(CONF_HISTORIFICADOR_APPLY_FILTER))
    val auditColumnName: String = Try(config.getString(CONF_HISTORIFICADOR_AUDIT_COLUMN_NAME))
      .getOrElse(DEFAULT_HISTORIFICADOR_AUDIT_COLUMN_NAME)
    logger.info(s"CDDHistorificador: Name of auditDateColumn: $auditColumnName")
    CDDExecutionStats.addInputParamMessage("auditColumnName",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", auditColumnName)
    TechnicalValidation.configStringParamValidator(CONF_HISTORIFICADOR_SCHEMA_PATH, config)
    val schemaPath: String = config.getString(CONF_HISTORIFICADOR_SCHEMA_PATH)
    logger.info(s"CDDHistorificador: Value of schemaPath: $schemaPath")
    CDDExecutionStats.addInputParamMessage("schemaPath",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", schemaPath)
    val repartitionBase: Int = Try(config.getInt(CONF_HISTORIFICADOR_REPARTITION_BASE))
      .getOrElse(DEFAULT_HISTORIFICADOR_REPARTITION_BASE)
    logger.info(s"CDDHistorificador: Value of repartitionBase: $repartitionBase")
    CDDExecutionStats.addInputParamMessage("repartitionBase",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", repartitionBase.toString)
    val averageKBPerRecord: Int = Try(config.getInt(CONF_HISTORIFICADOR_AVERAGE_KB_PER_RECORD))
      .getOrElse(DEFAULT_HISTORIFICADOR_AVERAGE_KB_PER_RECORD)
    logger.info(s"CDDHistorificador: Value of averageKBPerRecord: $averageKBPerRecord")
    CDDExecutionStats.addInputParamMessage("averageKBPerRecord",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", averageKBPerRecord.toString)
    val failIfNullDf: Int = Try(config.getInt(CONF_HISTORIFICADOR_FAIL_NULL_DATAFRAME))
      .getOrElse(DEFAULT_HISTORIFICADOR_FAIL_NULL_DATAFRAME)
    logger.info(s"CDDHistorificador: Fail process if dataFrame has 0 rows: $failIfNullDf")
    CDDExecutionStats.addInputParamMessage("failIfNullDf",
      "Historificador", "setterGlobalConfigurationReadedParamsReader", failIfNullDf.toString)
    TechnicalValidation.listSameLengthValidator(CONF_HISTORIFICADOR_LISTS_BLOCK, columnsName, columnsValue, applyFilter)
    HistorificadorConfiguration(principalPath,
      pathOutputBackup,
      columnsName,
      columnsValue,
      applyFilter,
      auditColumnName,
      schemaPath,
      repartitionBase,
      averageKBPerRecord,
      failIfNullDf)
  }

  override def getProcessId: String = "CDDHistorificador"
}

class Historificador extends HistorificadorTrait
