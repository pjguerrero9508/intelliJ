package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{SchemaValidationException, StructuralBoardsExceptionsController}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaValidatorBoards.artificialColumnsNullTypeCast
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{Constant, GlobalConfigurationReaded}
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.datio.dataproc.sdk.schema.exception.DataprocSchemaException
import org.apache.spark.sql.{DataFrame, SaveMode}
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConverters


object WriteUtils {
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * This method write a parquet file in given path. Only used in cache method (with no schema).
   *
   * @param datioSparkSession   datioSparkSessionSession
   * @param df                  DataFrame to write
   * @param targetPath          path to write schema
   * @param averageRecordWeight average record weight (default 8 KByte)
   */

  def simpleWriteToParquet(datioSparkSession: DatioSparkSession, df: DataFrame, targetPath: String,
                           averageRecordWeight: Int = Constant.DEFAULT_AVERAGE_KB_PER_RECORD_BOARDS_CONTRACTS): Unit = {

    val recordPerFile: Int = Constant.KB_PER_FILE_PARTITION / averageRecordWeight
    datioSparkSession.write()
      .option("maxRecordsPerFile", recordPerFile.toString)
      .option("keepPermissions", "true")
      .mode(SaveMode.Overwrite)
      .parquet(df, targetPath)
  }

  @throws[SchemaValidationException]
  def writePrincipalBoardWithPartParquet(datioSparkSession: DatioSparkSession, df: DataFrame, targetPath: String,
                                         globalParameter: GlobalConfigurationReaded, schema: DatioSchema): Unit = {
    val recordPerFile: Int = Constant.KB_PER_FILE_PARTITION / globalParameter.averageKBPerRecord
    val dataFrame = artificialColumnsNullTypeCast(df, schema)
    try {
      schema.validate(dataFrame)
    } catch {
      case e: DataprocSchemaException.InvalidDatasetException =>
        val errors = JavaConverters.asScalaIteratorConverter(e.getErrors.iterator()).asScala.map(err => err.toString).mkString(", ")
        StructuralBoardsExceptionsController(exception = new SchemaValidationException(globalParameter.fullNameSchemaBoard),
          fileError = "WriteUtils", methodError = "writePrincipalBoardParquet",
          exceptionMessage = s"DataprocSchemaException: schema validation errors " + s"$errors").exceptionTreatment
        throw new SchemaValidationException(globalParameter.fullNameSchemaBoard)
    }
    datioSparkSession.write()
      .option("maxRecordsPerFile", recordPerFile.toString)
      .option("keepPermissions", "true")
      .mode(SaveMode.Overwrite)
      .parquet(dataFrame.drop(globalParameter.entificColumnName).drop(globalParameter.dateColumnName)
        .repartition(globalParameter.repartitionBase * datioSparkSession.getSparkSession.sparkContext.defaultParallelism), targetPath)
  }

  /**
   * This method write a parquet file partitioning by geography, date and audit date columns
   *
   * @param datioSparkSession   datioSparkSessionSession
   * @param df                  DataFrame to write
   * @param repartitionBase     repartition factor
   * @param targetPath          path to write schema
   * @param columnsName         partitioning fields
   * @param auditColumnName     audit date partitioning field
   * @param averageRecordWeight average record weight (default 8 KByte)
   */
  def writeBackupBoardParquet(datioSparkSession: DatioSparkSession, df: DataFrame, targetPath: String, repartitionBase: Int,
                              columnsName: Seq[String], auditColumnName: String, schema: DatioSchema,
                              averageRecordWeight: Int = Constant.DEFAULT_HISTORIFICADOR_AVERAGE_KB_PER_RECORD): Unit = {

    val recordPerFile: Int = Constant.KB_PER_FILE_PARTITION / averageRecordWeight
    val partitionColumns: Seq[String] = columnsName :+ auditColumnName
    val dataFrame = artificialColumnsNullTypeCast(df, schema)
    datioSparkSession.write()
      .option("maxRecordsPerFile", recordPerFile.toString)
      .mode(SaveMode.Append)
      .partitionBy(partitionColumns: _*)
      .datioSchema(schema)
      .parquet(dataFrame
        .repartition(repartitionBase * datioSparkSession.getSparkSession.sparkContext.defaultParallelism), targetPath)
  }

  /**
   * This method write a parquet file partitioning by geography and cutoff date columns
   *
   * @param datioSparkSession   datioSparkSessionSession
   * @param df                  DataFrame to write
   * @param repartitionBase     repartition factor
   * @param targetPath          path to write schema
   * @param columnsName         partitioning fields
   * @param averageRecordWeight average record weight (default 8 KByte)
   */
  def restorePrincipalParquet(datioSparkSession: DatioSparkSession, df: DataFrame, targetPath: String,
                              repartitionBase: Int, columnsName: Seq[String], schema: DatioSchema,
                              averageRecordWeight: Int = Constant.DEFAULT_RESTORE_AVERAGE_KB_PER_RECORD): Unit = {
    val recordPerFile: Int = Constant.KB_PER_FILE_PARTITION / averageRecordWeight
    val dataFrame = artificialColumnsNullTypeCast(df, schema)
    columnsName match {
      case columns@Seq(_) if columns == Seq("") =>
        datioSparkSession.write()
          .option("maxRecordsPerFile", recordPerFile.toString)
          .mode(SaveMode.Append)
          .datioSchema(schema)
          .parquet(dataFrame
            .repartition(repartitionBase * datioSparkSession.getSparkSession.sparkContext.defaultParallelism), targetPath)
      case _ =>
        datioSparkSession.write()
          .option("maxRecordsPerFile", recordPerFile.toString)
          .mode(SaveMode.Append)
          .partitionBy(columnsName: _*)
          .datioSchema(schema)
          .parquet(dataFrame
            .repartition(repartitionBase * datioSparkSession.getSparkSession.sparkContext.defaultParallelism), targetPath)
    }
  }

  /**
   * This function reads a parquet file from a path and writes it into another target path
   *
   * @param datioSparkSession   datioSparkSessionSession
   * @param sourcePath          path with the data to copy
   * @param targetPath          path where the data should be copy
   * @param repartitionBase     repartition factor
   * @param averageRecordWeight average record weight (default 8 KByte)
   */
  def copyParquetInBackup(datioSparkSession: DatioSparkSession, sourcePath: String, targetPath: String, repartitionBase: Int,
                          schema: DatioSchema,
                          averageRecordWeight: Int = Constant.DEFAULT_AVERAGE_KB_PER_RECORD_BOARDS_CONTRACTS): Unit = {
    val recordPerFile: Int = Constant.KB_PER_FILE_PARTITION / averageRecordWeight
    val readDf: DataFrame = ReadUtils
      .readParquetWithSchema(datioSparkSession, sourcePath, schema)
      .repartition(repartitionBase * datioSparkSession.getSparkSession.sparkContext.defaultParallelism)
    datioSparkSession.write()
      .option("maxRecordsPerFile", recordPerFile.toString)
      .option("keepPermissions", "true")
      .mode(SaveMode.Overwrite)
      .datioSchema(schema)
      .parquet(readDf, targetPath)
  }

  def dataprocSdkAppendWriter(datioSparkSession: DatioSparkSession, df: DataFrame, targetPath: String,
                              globalParameter: GlobalConfigurationReaded, partitionByColumns: Seq[String], schema: DatioSchema): Unit = {
    val recordPerFile: Int = Constant.KB_PER_FILE_PARTITION / globalParameter.averageKBPerRecord
    try {
      datioSparkSession.write()
        .option("maxRecordsPerFile", recordPerFile.toString)
        .option("partitionOverwriteMode", "dynamic")
        .option("keepPermissions", "true")
        .mode(SaveMode.Overwrite)
        .option("safeOverwrite", "true")
        .partitionBy(partitionByColumns: _*)
        .datioSchema(schema)
        .parquet(schemaEnforcer(df, schema), targetPath)
    } catch {
      case exception: Exception =>
        CDDExecutionStats.addUnKnownExceptionMessage(exception, "WriteUtils", "dataprocSdkAppendWriter")
        throw exception
    }
  }

  val schemaEnforcer: (DataFrame, DatioSchema) => DataFrame = (df: DataFrame, schema: DatioSchema) => {
    schema.setConfig("enforcer.dropleftoverfields", "true")
    schema.enforce(df)
  }
}
