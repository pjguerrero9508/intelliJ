package com.bbva.projectsdatio.cdd.structuralboards.commons.appManager

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, ReadUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.DataFrame
import org.slf4j.{Logger, LoggerFactory}
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem

object RestorerManager{
  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * The function filters data from given path with given partition values
   *
   * @param datioSparkSession            Initialized DatioSparkSession
   * @param historicalPath   historical path taken from globalParameter
   * @param columnsName      partitioning fields
   * @param columnsValue     partitioning fields' values
   * @return filtered dataframe
   */
  def readSelectedPartition(datioSparkSession: DatioSparkSession, historicalPath: String, columnsName: Seq[String],
                          columnsValue: Seq[String], schema: DatioSchema): DataFrame = {
    logger.info(s"CDDRestore: Init Method filterDfInformation")
    val df: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, historicalPath, schema)
    val dfColumns: List[String] = df.columns.toList
    logger.info(s"CDDRestore: Method filterDfInformation: Validating if columnsName columns are in dataframe")
    TechnicalValidation.listElemValidator(columnsName, dfColumns, VAL_COLUMNS_NAME)
    logger.info(s"CDDRestore: Method filterDfInformation: Validated columnsName parameter")
    val filterInformationMap: Seq[(String, String)] = columnsName zip columnsValue
    filterInformationMap.foldLeft(df) {
      (df: DataFrame, filterInfo: (String, String)) => df.filter(df.col(filterInfo._1) === filterInfo._2)}
  }

  /**
   * The function deletes partition in principal path with corrupted data
   *
   * @param datioSparkSession            Initialized DatioSparkSession
   * @param principalPath    principal path taken from globalParameter
   * @param columnsName      partitioning fields
   * @param columnsValue     partitioning fields' values
   * @return
   */
  def deleteBadPrincData(datioSparkSession: DatioSparkSession, principalPath: String, columnsName: Seq[String],
                              columnsValue: Seq[String]): Unit = {
    logger.info(s"CDDRestore: Init Method deleteBadPrincData")
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, principalPath)) {
      val partition: String = concatPath(principalPath, columnsName, columnsValue)
      FileSystemUtils.delete(dfs, partition)
      logger.info(s"CDDRestore: Method deleteBadPrincData: deleted data from partition $partition")
    } else {
      logger.warn(s"CDDRestore: Method deleteBadPrincData: principal path $principalPath does not exist")
      CDDExecutionStats
        .addWarnMessage("Input entities warn",
          "RestorerManager",
          "deleteBadPrincData",
          s"CDDRestore: Method deleteBadPrincData: principal path $principalPath does not exist")
    }
    logger.info(s"CDDRestore: Finished Method deleteBadPrincData")
  }

  /**
   * The function builds the partition of principal path for given partition values
   *
   * @param principalPath    principal path taken from globalParameter
   * @param columnsName      partitioning fields
   * @param columnsValue     partitioning fields' values
   * @return path with partitions concatenated
   */
  def concatPath(principalPath: String, columnsName: Seq[String], columnsValue: Seq[String]): String = {
    val filterInformationMap: Seq[(String, String)] = columnsName zip columnsValue
    filterInformationMap.foldLeft(principalPath) {
      (path: String, filter: (String, String)) =>
        filter match {
          case ("", "") => path
          case _ => path + VAL_SLASH + filter._1 + PARTITION_SPLIT_CHAR + filter._2
        }
    }
  }

}
