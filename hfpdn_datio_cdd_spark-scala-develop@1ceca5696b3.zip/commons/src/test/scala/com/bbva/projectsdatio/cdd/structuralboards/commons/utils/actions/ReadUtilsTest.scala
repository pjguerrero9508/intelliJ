package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{TestCommons, TestUtils}
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.types._
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ReadUtilsTest extends TestCommons {
  val inputPath_cutoffAndEntific: String = "src/test/resources/data/utils/actions/read/parquetFile_cutoffAndEntific"
  val inputPath_cutoff: String = "src/test/resources/data/utils/actions/read/parquetFile_cutoff"
  test("ReadUtils - simpleReadParquet") {
    val expected = spark.read.format("csv").option("header", "true")
      .load("src/test/resources/data/utils/actions/simpleReadParquet_output.csv")
    val result = ReadUtils.
      simpleReadParquet(datioSparkSession, "src/test/resources/data/utils/actions/parquetFile")
    TestUtils.assertDataFrameEquals(result, expected, false) shouldBe true
  }

  test("ReadUtils - readSchemaOfJson") {
    val expectSchema: StructType = StructType(
      Seq(
        StructField("date", DateType, nullable = false),
        StructField("string", StringType, nullable = false),
        StructField("decimal", DecimalType(12,9), nullable = false),
        StructField("integer", IntegerType, nullable = false),
        StructField("timestamp", TimestampType, nullable = false)
      ))
    val schemaPath: String = "src/test/resources/data/utils/actions/readSchemaOfJson.json"
    TestUtils.compareStructType(SchemaReaderBoards.readSchema(schemaPath).getStructType,expectSchema) shouldBe true
  }

  test("ReadUtils_prev_readParquetCutoffDateEntific") {
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, inputPath_cutoffAndEntific)) FileSystemUtils.delete(dfs, inputPath_cutoffAndEntific)
    val dateColumnName: String = "Date"
    val entificColumnName: String = "String"
    TestUtils
      .simpleWriteToParquetWithSchema(datioSparkSession,
        testResources.testingDataFrame_WriteParquetFiles.drop(dateColumnName).drop(entificColumnName),
        inputPath_cutoffAndEntific, testResources.testingDataDatioSchema_withOutDateNorString)
  }
  test("ReadUtils_prev_ReadUtils_readParquetCutoffDate") {
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, inputPath_cutoff)) FileSystemUtils.delete(dfs, inputPath_cutoff)
    val dateColumnName: String = "Date"
    TestUtils
      .simpleWriteToParquetWithSchema(datioSparkSession,
        testResources.testingDataFrame.drop(dateColumnName),inputPath_cutoff, testResources.testingDataDatioSchema_withOutDate)
  }

}
