package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import java.text.ParseException

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{DateFormatException, UnionDuplicates, ValueParameterException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.FALSE_VALUE
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class GenericUtilsTest extends TestCommons {
  test("GenericUtils_setActualAuditDate") {
    val input: DataFrame = datioSparkSession.getSparkSession.read.format("csv").option("header", "true")
      .load("src/test/resources/data/utils/setActualAuditDate_input.csv")
    val df = GenericUtils.setActualAuditDate(input, "gf_audit_date")
    val newColumnType = df.select("gf_audit_date").schema.toString()
    val expected = "StructType(StructField(gf_audit_date,TimestampType,false))"
    newColumnType == expected shouldBe true
  }

  test("GenericUtils_emptyDfValidationNoEmpty") {
    val df: DataFrame = TestUtils.loadCSV(spark, "historificador/filteredDfInformation_output.csv")
    val failIfNullDf: Int = 1
    GenericUtils.emptyDfValidation(df, failIfNullDf)
  }

  test("GenericUtils_emptyDfValidationEmptyContinue") {
    val failIfNullDf: Int = 0
    GenericUtils.emptyDfValidation(testResources.testingEmptyDataFrame, failIfNullDf)
  }

  test("GenericUtils_emptyDfValidationEmptyStop") {
    val failIfNullDf: Int = 1
    assertThrows[ValueParameterException] {
      GenericUtils.emptyDfValidation(testResources.testingEmptyDataFrame, failIfNullDf)
    }
  }

  test("GenericUtils_unionData") {
    val dfAssetsLiab: DataFrame = TestUtils.loadCSV(spark, "utils/unionAssetsLiab_input.csv")
    val dfOffBalance: DataFrame = TestUtils.loadCSV(spark, "utils/unionInternalDepo_input.csv")
    val expected: DataFrame = TestUtils.loadCSV(spark, "utils/union_output.csv")
    val groupCols: List[String] = Seq("gf_cutoff_date", "gf_local_contract_number_id").toList
    val result: DataFrame = GenericUtils.unionData(dfAssetsLiab, dfOffBalance, groupCols, testResources.testingDataDatioSchema)(FALSE_VALUE)
    val columns = result.columns.map(col)
    TestUtils.assertDataFrameEquals(result, expected.select(columns:_*), false) shouldBe true
  }

  test("GenericUtils_unionDataFail") {
    val dfAssetsLiab: DataFrame = TestUtils.loadCSV(spark, "utils/unionAssetsLiab_input.csv")
    val dfOffBalance: DataFrame = TestUtils.loadCSV(spark, "utils/unionInternalDepoDuplicates_input.csv")
    val groupCols: List[String] = Seq("gf_cutoff_date", "gf_local_contract_number_id").toList
    assertThrows[UnionDuplicates] {
      GenericUtils.unionData(dfAssetsLiab, dfOffBalance, groupCols, testResources.testingDataDatioSchema)(FALSE_VALUE)
    }
  }

  test("GenericUtils_unionDataFailWithNulls") {
    val dfAssetsLiab: DataFrame = TestUtils.loadCSV(spark, "utils/unionAssetsLiab_input.csv")
    val dfOffBalance: DataFrame = TestUtils.loadCSV(spark, "utils/unionInternalDepoDuplicatesWithNulls_input.csv")
    val groupCols: List[String] = Seq("gf_cutoff_date", "gf_local_contract_number_id").toList
    assertThrows[UnionDuplicates] {
      GenericUtils.unionData(dfAssetsLiab, dfOffBalance, groupCols, testResources.testingDataDatioSchema)(FALSE_VALUE)
    }
  }

  test("GenericUtils_validateDuplicates") {
    val input: DataFrame = TestUtils.loadCSV(spark, "utils/union_output.csv")
    val groupCols: List[String] = Seq("gf_cutoff_date", "gf_local_contract_number_id").toList
    val expected: DataFrame = TestUtils.loadCSV(spark, "utils/union_output.csv")
    val result: DataFrame = GenericUtils.validateDuplicatesByPK(input: DataFrame, groupCols: List[String])(FALSE_VALUE)
    TestUtils.assertDataFrameEquals(result, expected, false) shouldBe true
  }

  test("GenericUtils_validateDuplicatesFail") {
    val input: DataFrame = TestUtils.loadCSV(spark, "utils/unionDuplicates_output.csv")
    val groupCols: List[String] = Seq("gf_cutoff_date", "gf_local_contract_number_id").toList
    assertThrows[UnionDuplicates] {
      GenericUtils.validateDuplicatesByPK(input: DataFrame, groupCols: List[String])(FALSE_VALUE)
    }
  }

  test("GenericUtils_validateDuplicatesFailWithNulls") {
    val input: DataFrame = TestUtils.loadCSV(spark, "utils/unionDuplicatesWithNulls_output.csv")
    val groupCols: List[String] = Seq("gf_cutoff_date", "gf_local_contract_number_id").toList
    assertThrows[UnionDuplicates] {
      GenericUtils.validateDuplicatesByPK(input: DataFrame, groupCols: List[String])(FALSE_VALUE)
    }
  }

  test("cleanerManager_changeDateFormat") {
    val dateValue: String = "2020-04-12"
    val result: String = GenericUtils.changeDateFormat(testResources.dateFormat_yyyy_MM_dd, dateValue)
    val expected: String = "2020-04-12"
    result == expected shouldBe true
  }

  test("cleanerManager_changeDateFormat1") {
    val dateValue: String = "20200412"
    val result: String = GenericUtils.changeDateFormat(testResources.dateFormat_yyyyMMdd, dateValue)
    val expected: String = "2020-04-12"
    result == expected shouldBe true
  }

  test("cleanerManager_changeDateFormat2") {
    val dateValue: String = "12042020"
    val result: String = GenericUtils.changeDateFormat(testResources.dateFormat_ddMMyyyy, dateValue)
    val expected: String = "2020-04-12"
    result == expected shouldBe true
  }

  test("cleanerManager_changeDateFormat3") {
    val dateValue1: String = "2020-01"
    val dateValue2: String = "2020-03"
    val result1: String = GenericUtils.changeDateFormat(testResources.dateFormat_yyyy_MM, dateValue1)
    val result2: String = GenericUtils.changeDateFormat(testResources.dateFormat_yyyy_MM, dateValue2)
    val expected1: String = "2020-01-01"
    val expected2: String = "2020-03-01"
    (result1 == expected1 && result2 == expected2) shouldBe true
  }

  test("cleanerManager_changeDateFormatUnparseable") {
    val dateValue1: String = "2020_01_01"
    assertThrows[ParseException] {
      GenericUtils.changeDateFormat(testResources.dateFormat_yyyy_MM_dd, dateValue1)
    }
  }

  test("cleanerManager_changeDateFormatBadFormat") {
    val dateValue1: String = "20200101"
    assertThrows[DateFormatException] {
      GenericUtils.changeDateFormat(testResources.dateFormat_yyyy_MM_dd, dateValue1)
    }
  }
}
