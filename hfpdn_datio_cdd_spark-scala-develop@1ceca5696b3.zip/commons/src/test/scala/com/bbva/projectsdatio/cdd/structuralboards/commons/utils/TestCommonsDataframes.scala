package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import java.sql.Timestamp

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.NULL_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.ReadUtils
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.catalyst.util.DateTimeUtils
import org.apache.spark.sql.{DataFrame, Row}

class TestCommonsDataframes(datioSparkSession: DatioSparkSession) extends TestCommonsSchemas {
  val example_date : String = "2021-04-12"
  val example_timestamp : String = "2021-04-12 00:00:00"

  //CDD DATASETS
  val testingDataRow_1 = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRow_2 = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRow_3 = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRow_4 = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRows: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext.parallelize(Seq(testingDataRow_1,testingDataRow_2,testingDataRow_3,testingDataRow_4),1)
  val testingDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingDataRows, testingDataSchema)


  val testingDataRow_1WithoutTimestamp = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1, java.sql.Date.valueOf(example_date)),testingDataSchema)
  val testingDataRow_2WithoutTimestamp = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2, java.sql.Date.valueOf(example_date)),testingDataSchema)
  val testingDataRow_3WithoutTimestamp = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3, java.sql.Date.valueOf(example_date)),testingDataSchema)
  val testingDataRow_4WithoutTimestamp = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4, java.sql.Date.valueOf(example_date)),testingDataSchema)
  val testingDataRowsWithoutTimestamp: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1WithoutTimestamp,testingDataRow_2WithoutTimestamp,testingDataRow_3WithoutTimestamp,testingDataRow_4WithoutTimestamp),
    1)
  val testingDataFrameWithoutTimestamp: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingDataRowsWithoutTimestamp, testingDataSchema)

  val testingDataRowNullInt_1 = new GenericRowWithSchema(
    Array("Prueba string 1", NULL_VALUE, 4.1, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRowNullInt_2 = new GenericRowWithSchema(
    Array("Prueba string 2", NULL_VALUE, 4.2, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRowNullInt_3 = new GenericRowWithSchema(
    Array("Prueba string 3", NULL_VALUE, 4.3, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRowNullInt_4 = new GenericRowWithSchema(
    Array("Prueba string 4", NULL_VALUE, 4.4, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRowsNullInt: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(
    Seq(testingDataRowNullInt_1,
      testingDataRowNullInt_2,
      testingDataRowNullInt_3,
      testingDataRowNullInt_4),1)
  val testingDataFrameNullInt: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingDataRowsNullInt, testingDataSchema)

  val testingDataRowNullComplete_1 = new GenericRowWithSchema(
    Array(NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE),testingDataSchema)
  val testingDataRowNullComplete_2 = new GenericRowWithSchema(
    Array(NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE),testingDataSchema)
  val testingDataRowNullComplete_3 = new GenericRowWithSchema(
    Array(NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE),testingDataSchema)
  val testingDataRowNullComplete_4 = new GenericRowWithSchema(
    Array(NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE),testingDataSchema)
  val testingDataRowsNullComplete: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(
    Seq(testingDataRowNullComplete_1,
      testingDataRowNullComplete_2,
      testingDataRowNullComplete_3,
      testingDataRowNullComplete_4),1)
  val testingDataFrameNullComplete: DataFrame = datioSparkSession.getSparkSession
    .createDataFrame(testingDataRowsNullComplete, testingDataSchema)

  val testingEmptyDataRows: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
  val testingEmptyDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, testingDataSchema)


  val testingJsonSchemaDataRow_1 = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(example_date), "GL"),testingJsonSchemaDataSchema)
  val testingJsonSchemaDataRow_2 = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(example_date), "GL"),testingJsonSchemaDataSchema)
  val testingJsonSchemaDataRow_3 = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(example_date), "GL"),testingJsonSchemaDataSchema)
  val testingJsonSchemaDataRow_4 = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(example_date), "GL"),testingJsonSchemaDataSchema)
  val testingJsonSchemaDataRows: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(Seq(testingJsonSchemaDataRow_1,
    testingJsonSchemaDataRow_2,
    testingJsonSchemaDataRow_3,
    testingJsonSchemaDataRow_4),1)
  val testingJsonSchemaDataFrame: DataFrame = datioSparkSession.getSparkSession
    .createDataFrame(testingJsonSchemaDataRows, testingJsonSchemaDataSchema)

  lazy val testReadDataSet : DataFrame = ReadUtils
    .simpleReadParquet(datioSparkSession, "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30")

  lazy val testReadDataSetWithPartitions : DataFrame = ReadUtils
    .simpleReadParquet(datioSparkSession, "src/test/resources/data/cddBoards/principal_old/")


  lazy val boardLikeData_testing_rows = Seq(
    //                              gf_cutoff_date, g_guarantee_id      ,  g_guarantee_type, gf_guarantee_amount    , g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0001", "a1"             , "111111111111111111.01", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0002", "a2"             , "111111111111111111.02", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0003", "a3"             , "111111111111111111.03", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0004", "b1"             , "111111111111111111.04", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0005", "b2"             , "111111111111111111.05", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0006", "b3"             , "111111111111111111.06", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0007", NULL_VALUE       , "111111111111111111.07", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0008", "a4"             , "111111111111111111.08", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0009", "a5"             , "111111111111111111.09", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0010", "a6"             , "111111111111111111.10", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0011", "b4"             , "111111111111111111.11", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0012", "b5"             , "111111111111111111.12", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0013", "b6"             , "111111111111111111.13", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0014", NULL_VALUE       , "111111111111111111.14", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0015", "a7"             , "111111111111111111.15", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0016", "a8"             , "111111111111111111.16", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0017", "a9"             , "111111111111111111.17", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0018", "b7"             , "111111111111111111.18", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0019", "b8"             , "111111111111111111.19", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema),
    new GenericRowWithSchema(Array("2020-07-31"   ,"guaranteeIdCode0020", "b9"             , "111111111111111111.20", "GL"        , "2020-01-01 04:32:32.11"), testingBoardLikeDataSchema)
  )
  lazy val boardLikeData_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(boardLikeData_testing_rows, 1)
  lazy val boardLikeData_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(boardLikeData_testing_rows_rdd, testingBoardLikeDataSchema)


  val partition_date : String = "2016-01-31"
  val testingDataRow_1_with_partitions = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_2_with_partitions = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_3_with_partitions = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions,testingDataRow_2_with_partitions,
      testingDataRow_3_with_partitions,testingDataRow_4_with_partitions),1)
  val testingDataFrame_with_partitions: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions, testingDataSchema_added_partitions)

  val partition_date_28 : String = "2016-01-28"
  val testingDataRow_1_with_partitions_28 = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRow_2_with_partitions_28 = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRow_3_with_partitions_28 = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_28 = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_28: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_28,testingDataRow_2_with_partitions_28,
      testingDataRow_3_with_partitions_28,testingDataRow_4_with_partitions_28),1)
  val testingDataFrame_with_partitions_28: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_28, testingDataSchema_added_partitions)

  val example_next_timestamp : String = "2021-04-12 01:00:00"
  val testingDataRow_1_with_partitions_next = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_2_with_partitions_next = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_3_with_partitions_next = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_next = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_next: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_next,testingDataRow_2_with_partitions_next,
      testingDataRow_3_with_partitions_next,testingDataRow_4_with_partitions_next),1)
  val testingDataFrame_with_partitions_next: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_next, testingDataSchema_added_partitions)


  val testingDataRow_1_with_partitions_numString = new GenericRowWithSchema(
    Array("0001", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_2_with_partitions_numString = new GenericRowWithSchema(
    Array("0001", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_3_with_partitions_numString = new GenericRowWithSchema(
    Array("0002", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_numString = new GenericRowWithSchema(
    Array("0002", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_numString: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_numString,testingDataRow_2_with_partitions_numString,
      testingDataRow_3_with_partitions_numString,testingDataRow_4_with_partitions_numString),1)
  val testingDataFrame_with_partitions_numString: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_numString, testingDataSchema_added_partitions)

  val testingDataRow_1_with_partitions_28_numString = new GenericRowWithSchema(
    Array("0001", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRow_2_with_partitions_28_numString = new GenericRowWithSchema(
    Array("0001", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRow_3_with_partitions_28_numString = new GenericRowWithSchema(
    Array("0002", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_28_numString = new GenericRowWithSchema(
    Array("0002", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_28_numString: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_28_numString,testingDataRow_2_with_partitions_28_numString,
      testingDataRow_3_with_partitions_28_numString,testingDataRow_4_with_partitions_28_numString),1)
  val testingDataFrame_with_partitions_28_numString: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_28_numString, testingDataSchema_added_partitions)

  val testingDataRow_1_with_partitions_next_numString = new GenericRowWithSchema(
    Array("0001", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_2_with_partitions_next_numString = new GenericRowWithSchema(
    Array("0001", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_3_with_partitions_next_numString = new GenericRowWithSchema(
    Array("0002", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_next_numString = new GenericRowWithSchema(
    Array("0002", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_next_numString: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_next_numString,testingDataRow_2_with_partitions_next_numString,
      testingDataRow_3_with_partitions_next_numString,testingDataRow_4_with_partitions_next_numString),1)
  val testingDataFrame_with_partitions_next_numString: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_next_numString, testingDataSchema_added_partitions)

  val testingDataRow_3_with_partitions_next_numString_exp = new GenericRowWithSchema(
    Array("0002", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_next_numString_exp = new GenericRowWithSchema(
    Array("0002", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_next_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_next_numString_exp: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_3_with_partitions_next_numString_exp,testingDataRow_4_with_partitions_next_numString_exp),1)
  val testingDataFrame_with_partitions_next_numString_exp: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_next_numString_exp, testingDataSchema_added_partitions)


  val testingDataRow_3_with_partitions_numString_exp = new GenericRowWithSchema(
    Array("0002", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRow_4_with_partitions_numString_exp = new GenericRowWithSchema(
    Array("0002", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partitions)
  val testingDataRows_with_partitions_numString_exp: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_3_with_partitions_numString_exp,testingDataRow_4_with_partitions_numString_exp),1)
  val testingDataFrame_with_partitions_numString_exp: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_numString_exp, testingDataSchema_added_partitions)

  val testingEmptyDataRows_with_partitions_numString: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
  val testingEmptyDataFrame_with_partitions_numString: DataFrame = datioSparkSession
    .getSparkSession.createDataFrame(testingEmptyDataRows_with_partitions_numString, testingDataSchema_added_partitions)

  val testingDataRow_1_with_partition = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partition)
  val testingDataRow_2_with_partition = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partition)
  val testingDataRow_3_with_partition = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partition)
  val testingDataRow_4_with_partition = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      java.sql.Date.valueOf(partition_date)),testingDataSchema_added_partition)
  val testingDataRows_with_partition: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partition,testingDataRow_2_with_partition,
      testingDataRow_3_with_partition,testingDataRow_4_with_partition),1)
  val testingDataFrame_with_partition: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partition, testingDataSchema_added_partition)

  val testingDataRow_1_with_partitions_test = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRow_2_with_partitions_test = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRow_3_with_partitions_test = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRow_4_with_partitions_test = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRows_with_partitions_test: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_test,testingDataRow_2_with_partitions_test,
      testingDataRow_3_with_partitions_test,testingDataRow_4_with_partitions_test),1)
  val testingDataFrame_with_partitions_test: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_test, testingDataSchema_added_partitions_test)

  val testingDataRow_1_with_partitions_test_28 = new GenericRowWithSchema(
    Array("Prueba string 1", 1, 4.1,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRow_2_with_partitions_test_28 = new GenericRowWithSchema(
    Array("Prueba string 2", 2, 4.2,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRow_3_with_partitions_test_28 = new GenericRowWithSchema(
    Array("Prueba string 3", 3, 4.3,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRow_4_with_partitions_test_28 = new GenericRowWithSchema(
    Array("Prueba string 4", 4, 4.4,
      java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp),
      "ES", java.sql.Date.valueOf(partition_date_28), "OK"),testingDataSchema_added_partitions_test)
  val testingDataRows_with_partitions_test_28: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext
    .parallelize(Seq(testingDataRow_1_with_partitions_test_28,testingDataRow_2_with_partitions_test_28,
      testingDataRow_3_with_partitions_test_28,testingDataRow_4_with_partitions_test_28),1)
  val testingDataFrame_with_partitions_test_28: DataFrame =
    datioSparkSession.getSparkSession.createDataFrame(testingDataRows_with_partitions_test_28, testingDataSchema_added_partitions_test)

  val testingDataRow_WriteParquetFiles_1 = new GenericRowWithSchema(
    Array("0001", 1, 4.1, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRow_WriteParquetFiles_2 = new GenericRowWithSchema(
    Array("0001", 2, 4.2, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRow_WriteParquetFiles_3 = new GenericRowWithSchema(
    Array("0002", 3, 4.3, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRow_WriteParquetFiles_4 = new GenericRowWithSchema(
    Array("0002", 4, 4.4, java.sql.Date.valueOf(example_date), Timestamp.valueOf(example_timestamp)),testingDataSchema)
  val testingDataRows_WriteParquetFiles: RDD[Row] = datioSparkSession.getSparkSession
    .sparkContext.parallelize(
      Seq(testingDataRow_WriteParquetFiles_1,testingDataRow_WriteParquetFiles_2,testingDataRow_WriteParquetFiles_3,testingDataRow_WriteParquetFiles_4),1)
  val testingDataFrame_WriteParquetFiles: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingDataRows_WriteParquetFiles, testingDataSchema)

}
