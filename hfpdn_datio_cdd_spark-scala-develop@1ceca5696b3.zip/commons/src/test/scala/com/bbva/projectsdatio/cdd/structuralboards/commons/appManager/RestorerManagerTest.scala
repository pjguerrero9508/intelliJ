package com.bbva.projectsdatio.cdd.structuralboards.commons.appManager

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.BadColumnsNameException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{TestCommons, TestUtils}
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class RestorerManagerTest extends TestCommons {

  test("restorerManager_concatPathSinglePartition") {
    val path: String = "data/master/ktae/data/t_ktae_contract_struc_board"
    val columnsName: Seq[String] = Seq("part1")
    val columnsValue: Seq[String] = Seq("value1")
    val result: String = RestorerManager.concatPath(path, columnsName, columnsValue)
    val expected: String = "data/master/ktae/data/t_ktae_contract_struc_board/part1=value1"
    result == expected shouldBe true
  }

  test("restorerManager_concatPathTwoPartition") {
    val path: String = "data/master/ktae/data/t_ktae_contract_struc_board"
    val columnsName: Seq[String] = Seq("part1", "part2")
    val columnsValue: Seq[String] = Seq("value1", "value2")
    val result: String = RestorerManager.concatPath(path, columnsName, columnsValue)
    val expected: String = "data/master/ktae/data/t_ktae_contract_struc_board/part1=value1/part2=value2"
    result == expected shouldBe true
  }

  test("restorerManager_concatPathThreePartition") {
    val path: String = "data/master/ktae/data/t_ktae_contract_struc_board"
    val columnsName: Seq[String] = Seq("part1","part2","part3")
    val columnsValue: Seq[String] = Seq("value1","value2","value3")
    val result: String = RestorerManager.concatPath(path, columnsName, columnsValue)
    val expected: String = "data/master/ktae/data/t_ktae_contract_struc_board/part1=value1/part2=value2/part3=value3"
    result == expected shouldBe true
  }

  test("historificadorManager_filterDfInformation prev test") {
    val principalPath: String = "src/test/resources/data/restorer/first/inputRestorerParquet"
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, principalPath)
    val columnsName: Seq[String] = Seq("String","gf_cutoff_date","Timestamp")
    val inputDataFrame = testResources.testingDataFrame_with_partitions_numString
      .union(testResources.testingDataFrame_with_partitions_28_numString)
      .union(testResources.testingDataFrame_with_partitions_next_numString)
    TestUtils.simpleWriteToParquetWithSchemaAndPartitions(datioSparkSession, inputDataFrame, principalPath,
      testResources.testingDataSchema_added_partitionsDatioSchema, columnsName)
  }


  test("restorerManager_filterDfInformation test") {
    val historicalPath: String = "src/test/resources/data/restorer/first/inputRestorerParquet"
    val columnsName: Seq[String] = Seq("String","gf_cutoff_date","Timestamp")
    val columnsValue: Seq[String] = Seq("0002",testResources.partition_date,testResources.example_next_timestamp)
    val result: DataFrame = RestorerManager.readSelectedPartition(datioSparkSession, historicalPath, columnsName, columnsValue,
      testResources.testingDataSchema_added_partitionsDatioSchema)
    val columns = result.columns.map(col)
    val expected: DataFrame = testResources.testingDataFrame_with_partitions_next_numString_exp.select(columns:_*)
    TestUtils.assertDataFrameEquals(result, expected, FALSE_VALUE) shouldBe true
    TestUtils.compareStructTypeWithOutNullableOrFormat(result.schema, expected.schema)
  }

  test("restorerManager_filterDfInformation empty filter result test") {
    val historicalPath: String = "src/test/resources/data/restorer/first/inputRestorerParquet"
    val columnsName: Seq[String] = Seq("String","gf_cutoff_date","Timestamp")
    val columnsValue: Seq[String] = Seq("0004",testResources.partition_date,testResources.example_next_timestamp)
    val result: DataFrame = RestorerManager.readSelectedPartition(datioSparkSession, historicalPath, columnsName, columnsValue,
      testResources.testingDataSchema_added_partitionsDatioSchema)
    val columns = result.columns.map(col)
    val expected: DataFrame = testResources.testingEmptyDataFrame_with_partitions_numString.select(columns:_*)
    TestUtils.assertDataFrameEquals(result, expected, FALSE_VALUE) shouldBe true
    TestUtils.compareStructTypeWithOutNullableOrFormat(result.schema, expected.schema)
  }

  test("historificadorManager_filterDfInformation no String prev test") {
    val principalPath: String = "src/test/resources/data/restorer/noString/inputRestorerParquet"
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, principalPath)) {
      FileSystemUtils.delete(dfs, principalPath)
    }
    val columnsName: Seq[String] = Seq("gf_cutoff_date","Timestamp")
    val inputDataFrame = testResources.testingDataFrame_with_partitions_numString
      .union(testResources.testingDataFrame_with_partitions_28_numString)
      .union(testResources.testingDataFrame_with_partitions_next_numString)
    TestUtils.simpleWriteToParquetWithSchemaAndPartitions(datioSparkSession, inputDataFrame, principalPath,
      testResources.testingDataSchema_added_partitionsDatioSchema, columnsName)
  }

  test("restorerManager_filterDfInformation no String test") {
    val historicalPath: String = "src/test/resources/data/restorer/noString/inputRestorerParquet"
    val columnsName: Seq[String] = Seq("gf_cutoff_date","Timestamp")
    val columnsValue: Seq[String] = Seq(testResources.partition_date,testResources.example_next_timestamp)
    val result: DataFrame = RestorerManager.readSelectedPartition(datioSparkSession, historicalPath, columnsName, columnsValue,
      testResources.testingDataSchema_added_partitionsDatioSchema)
    val columns = result.columns.map(col)
    val expected: DataFrame = testResources.testingDataFrame_with_partitions_next_numString.select(columns:_*)
    TestUtils.assertDataFrameEquals(result, expected, FALSE_VALUE) shouldBe true
    TestUtils.compareStructTypeWithOutNullableOrFormat(result.schema, expected.schema)
  }

  test("restorerManager_filterDfInformationBadFieldsName") {
    val historicalPath: String = "src/test/resources/data/restorer/inputRestorerParquet"
    val columnsName: Seq[String] = Seq("g_entific_id","gf_cutoff_date","gf_audit_dateee")
    val columnsValue: Seq[String] = Seq("GL","2020-02-29","22020-06-08 15:50:58.06")
    assertThrows[BadColumnsNameException] {
      RestorerManager.readSelectedPartition(datioSparkSession, historicalPath, columnsName, columnsValue,
        testResources.testingDataDatioSchema)
    }
  }

  test("restorerManager_deleteBadPrincData") {
    val pathDeleteGL: String = "src/test/resources/data/restorer/principal/g_entific_id=GL/gf_cutoff_date=2020-02-29"
    val pathNoDeleteGL: String = "src/test/resources/data/restorer/principal/g_entific_id=GL/gf_cutoff_date=2020-03-31"
    val pathNoDeleteES1: String = "src/test/resources/data/restorer/principal/g_entific_id=ES/gf_cutoff_date=2020-02-29"
    val pathNoDeleteES2: String = "src/test/resources/data/restorer/principal/g_entific_id=ES/gf_cutoff_date=2020-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathDeleteGL).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path3: Path = dfs.qualify(pathNoDeleteES1).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(pathNoDeleteES2).fileSystem()
    val path4: Path = dfs.qualify(pathNoDeleteES2).path()
    fs4.mkdirs(path4)

    val principalPath: String = "src/test/resources/data/restorer/principal"
    val columnsName: Seq[String] = Seq("g_entific_id","gf_cutoff_date")
    val columnsValue: Seq[String] = Seq("GL","2020-02-29")
    RestorerManager.deleteBadPrincData(datioSparkSession, principalPath, columnsName, columnsValue)

    var result = VAL_FALSE
    if (!FileSystemUtils.pathExists(dfs, pathDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteGL) &&
    FileSystemUtils.pathExists(dfs, pathNoDeleteES1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES2)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("restorerManager_deleteBadPrincDataNoEntific") {
    val pathDelete: String = "src/test/resources/data/restorer/principal/gf_cutoff_date=2020-02-29"
    val pathNoDelete1: String = "src/test/resources/data/restorer/principal/gf_cutoff_date=2020-03-31"
    val pathNoDelete2: String = "src/test/resources/data/restorer/principal/gf_cutoff_date=2020-04-30"
    val pathNoDelete3: String = "src/test/resources/data/restorer/principal/gf_cutoff_date=2020-05-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathDelete).fileSystem()
    val path1: Path = dfs.qualify(pathDelete).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(pathNoDelete1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDelete1).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(pathNoDelete2).fileSystem()
    val path3: Path = dfs.qualify(pathNoDelete2).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(pathNoDelete3).fileSystem()
    val path4: Path = dfs.qualify(pathNoDelete3).path()
    fs4.mkdirs(path4)

    val principalPath: String = "src/test/resources/data/restorer/principal"
    val columnsName: Seq[String] = Seq("gf_cutoff_date")
    val columnsValue: Seq[String] = Seq("2020-02-29")
    RestorerManager.deleteBadPrincData(datioSparkSession, principalPath, columnsName, columnsValue)

    var result = VAL_FALSE
    if (!FileSystemUtils.pathExists(dfs, pathDelete) && FileSystemUtils.pathExists(dfs, pathNoDelete1) &&
      FileSystemUtils.pathExists(dfs, pathNoDelete2) && FileSystemUtils.pathExists(dfs, pathNoDelete3)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("restorerManager_deleteBadPrincDataNoExistPath") {
    val path: String = "src/test/resources/data/restorer/principal/gf_cutoff_date=2020-02-29"
    val principalPath: String = "src/test/resources/data/restorer/principal"
    val columnsName: Seq[String] = Seq("gf_cutoff_date")
    val columnsValue: Seq[String] = Seq("2020-02-29")
    val dfs = DatioFileSystem.get()

    RestorerManager.deleteBadPrincData(datioSparkSession, principalPath, columnsName, columnsValue)

    var result = VAL_FALSE
    if (!FileSystemUtils.pathExists(dfs, path)) {
      result = VAL_TRUE
    }
    result == VAL_TRUE shouldBe true
  }

}