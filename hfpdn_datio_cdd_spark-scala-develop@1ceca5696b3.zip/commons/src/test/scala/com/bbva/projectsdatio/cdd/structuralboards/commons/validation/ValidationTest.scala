package com.bbva.projectsdatio.cdd.structuralboards.commons.validation

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{TestCommons, TestUtils}
import com.typesafe.config.{Config, ConfigException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ValidationTest extends TestCommons {

  lazy val config: Config = TestUtils.getConfigTest("data/validation/validationTest.conf", "CDDValidation")

  test("TechnicalValidation_dateValidator") {
    TechnicalValidation.dateValidator("2020-02-29", "gf_cutoff_date")
  }

  test("TechnicalValidation_dateValidatorMalformed") {
    assertThrows[ParamMalformedException] {
      TechnicalValidation.dateValidator("2020-02-30", "gf_cutoff_date")
    }
  }

  test("TechnicalValidation_dateValidatorBadType") {
    assertThrows[ParamMalformedException] {
      TechnicalValidation.dateValidator("aaaaaaaaaa", "gf_cutoff_date")
    }
  }

  test("TechnicalValidation_configStringParamValidator") {
    TechnicalValidation.configStringParamValidator("param1", config)
  }

  test("TechnicalValidation_configStringParamValidatorFromInt") {
    TechnicalValidation.configStringParamValidator("param2", config)
  }

  test("TechnicalValidation_configStringParamValidatorMiss") {
    assertThrows[ParamNotInformedException] {
      TechnicalValidation.configStringParamValidator("param0", config)
    }
  }

  test("TechnicalValidation_configStringParamValidatorWrongType") {
    assertThrows[ParamMalformedException] {
      TechnicalValidation.configStringParamValidator("param3", config)
    }
  }

  test("TechnicalValidation_configIntParamValidator") {
    TechnicalValidation.configIntParamValidator("param2", config)
  }

  test("TechnicalValidation_configIntParamValidatorMiss") {
    assertThrows[ParamNotInformedException] {
      TechnicalValidation.configIntParamValidator("param0", config)
    }
  }

  test("TechnicalValidation_configIntParamValidatorWrongType") {
    assertThrows[ParamMalformedException] {
      TechnicalValidation.configIntParamValidator("param1", config)
    }
  }

  test("TechnicalValidation_configStringListParamValidator") {
    TechnicalValidation.configStringListParamValidator("param3", config)
  }

  test("TechnicalValidation_configStringListParamValidatorMiss") {
    assertThrows[ConfigException.Missing] {
      TechnicalValidation.configStringListParamValidator("param0", config)
    }
  }

  test("TechnicalValidation_configStringListParamValidatorWrongType") {
    assertThrows[ConfigException.WrongType] {
      TechnicalValidation.configStringListParamValidator("param1", config)
    }
  }

  test("TechnicalValidation_listSameLengthValidator") {
    TechnicalValidation.listSameLengthValidator(CONF_HISTORIFICADOR_COLUMNS_VALUE,
      List("col1", "col2"), List("col3", "col4"), List("col5", "col6"))
  }

  test("TechnicalValidation_listSameLengthValidatorFail") {
    assertThrows[ListSameLengthException] {
      TechnicalValidation.listSameLengthValidator(CONF_HISTORIFICADOR_COLUMNS_VALUE,
        List("col1", "col2"), List("col3", "col4"), List("col5"))
    }
  }

  test("TechnicalValidation_listElemValidator") {
      TechnicalValidation.listElemValidator(Seq("col1", "col2"), Seq("col1", "col2", "col3"), "param")
  }

  test("TechnicalValidation_listElemValidatorFail") {
    assertThrows[BadColumnsNameException] {
      TechnicalValidation.listElemValidator(Seq("col4", "col2"), Seq("col1", "col2", "col3"), "param")
    }
  }


  test("TechnicalValidation_stringNotInListKo") {
    val stringToCheck: String = "prueba"
    val validStringValues: Seq[String] = Seq("segunda_prueba_OK", "prueba", "prueba ", " prueba")
    assertThrows[StringInListException] {
      TechnicalValidation.stringNotInList(stringToCheck, validStringValues)
    }
  }

  test("TechnicalValidation_stringNotInListOk") {
    val stringToCheck: String = "prueba_OK"
    val validStringValues: Seq[String] = Seq("segunda_prueba_OK", "prueba", "prueba ", " prueba")
    TechnicalValidation.stringNotInList(stringToCheck, validStringValues)
  }

  test("TechnicalValidation_stringNotInListEmpty") {
    val stringToCheck: String = ""
    val validStringValues: Seq[String] = Seq("segunda_prueba_OK", "prueba", "prueba ", " prueba")
    TechnicalValidation.stringNotInList(stringToCheck, validStringValues)
  }

  test("TechnicalValidation_listStringValidatorKo") {
    assertThrows[BadStringNameException] {
      TechnicalValidation.listStringValidator(Seq("t_entity_1","", "t_entity_2"), Seq("t_entity_1", "t_entity_2", " "), "param")
    }
  }

  test("TechnicalValidation_listStringValidatorOk") {
    TechnicalValidation.listStringValidator(Seq("t_entity_1", "t_entity_2"), Seq("t_entity_1", "t_entity_2", "t_entity_3"), "param")
  }

}
