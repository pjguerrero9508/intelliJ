package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset, CDDStructuralMainBoardDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.StructuralBoardsExceptions
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

class TestCommonResources(datioSparkSession: DatioSparkSession) extends TestCommonsDataframes(datioSparkSession: DatioSparkSession) with TestCommonsConfigs {

    //1. CONSTANTS
    val dataCleanerResourcesPath: String = "src/test/resources/data/cleaner/"
    val dataCleanerEntity: String = "t_ktae_contract_struc_board/"

    val dataRestorerPrincipal: String = "src/test/resources/data/restorer/principal"

    val datasetResourcesPath: String = "src/test/resources/data/cddDatasets/"

    val boardResourcesPath: String = "src/test/resources/data/cddBoards/"
    val emptyDataSetPrefix: String = "EmptyDataSet_"
    val notEmptyDataSetPrefix: String = "NotEmptyDataSet_"

    val dateFormat_yyyy_MM_dd: String = "yyyy-MM-dd"
    val dateFormat_yyyyMMdd: String = "yyyyMMdd"
    val dateFormat_ddMMyyyy: String = "ddMMyyyy"
    val dateFormat_yyyy_MM: String = "yyyy-MM"

    val gf_cutoff_date: String = "gf_cutoff_date"

    val gf_cutoff_date_31012016 : String = "gf_cutoff_date=31012016"
    val gf_cutoff_date_bad_2016_01_31 : String = "gf_cutoff_date_bad=2016-01-31"

    val gf_cutoff_date_2016_01_31 : String = "gf_cutoff_date=2016-01-31"
    val gf_cutoff_date_2015_06_30 : String = "gf_cutoff_date=2015-06-30"
    val gf_cutoff_date_2015_03_31 : String = "gf_cutoff_date=2015-03-31"
    val gf_cutoff_date_2015_02_28 : String = "gf_cutoff_date=2015-02-28"
    val gf_cutoff_date_2015_01_31 : String = "gf_cutoff_date=2015-01-31"
    val gf_cutoff_date_2014_05_31 : String = "gf_cutoff_date=2014-05-31"
    val gf_cutoff_date_2014_03_31 : String = "gf_cutoff_date=2014-03-31"
    val gf_cutoff_date_2016_01_28 : String = "gf_cutoff_date=2016-01-28"
    val gf_cutoff_date_2015_06_28 : String = "gf_cutoff_date=2015-06-28"
    val gf_cutoff_date_2015_03_28 : String = "gf_cutoff_date=2015-03-28"
    val gf_cutoff_date_2015_01_28 : String = "gf_cutoff_date=2015-01-28"
    val gf_cutoff_date_2014_03_28 : String = "gf_cutoff_date=2014-03-28"
    val g_entific_id_ES : String = "g_entific_id=ES"
    val g_entific_id_GL : String = "g_entific_id=GL"
    val gf_test_OK : String = "gf_test=OK"
    val gf_test_KO : String = "gf_test=KO"
    //2. RESOURCES
    //PATHS
    //ONLY ONE PARTITION FIELD
    lazy val cleaner_path_FirstPartLevel_2016_01_31: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2016_01_31
    lazy val cleaner_path_FirstPartLevel_2015_06_30: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_06_30
    lazy val cleaner_path_FirstPartLevel_2015_03_31: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_03_31
    lazy val cleaner_path_FirstPartLevel_2015_01_31: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_01_31
    lazy val cleaner_path_FirstPartLevel_2014_03_31: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2014_03_31
    lazy val cleaner_path_FirstPartLevel_2016_01_28: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2016_01_28
    lazy val cleaner_path_FirstPartLevel_2015_06_28: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_06_28
    lazy val cleaner_path_FirstPartLevel_2015_03_28: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_03_28
    lazy val cleaner_path_FirstPartLevel_2015_01_28: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_01_28
    lazy val cleaner_path_FirstPartLevel_2014_03_28: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2014_03_28

    lazy val cleaner_path_FirstPartLevel_ES: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES

    //TWO PARTITION FIELDS
    lazy val cleaner_path_SecPartLevel_ES_2016_01_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2016_01_31
    lazy val cleaner_path_SecPartLevel_ES_2016_01_28: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2016_01_28
    lazy val cleaner_path_SecPartLevel_ES_2015_06_30: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_06_30
    lazy val cleaner_path_SecPartLevel_ES_2015_03_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_03_31
    lazy val cleaner_path_SecPartLevel_ES_2015_02_28: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_02_28
    lazy val cleaner_path_SecPartLevel_ES_2015_01_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_01_31
    lazy val cleaner_path_SecPartLevel_ES_2014_05_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2014_05_31
    lazy val cleaner_path_SecPartLevel_ES_2014_03_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2014_03_31
    lazy val cleaner_path_SecPartLevel_GL_2016_01_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2016_01_31
    lazy val cleaner_path_SecPartLevel_GL_2016_01_28: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2016_01_28
    lazy val cleaner_path_SecPartLevel_GL_2015_06_30: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2015_06_30
    lazy val cleaner_path_SecPartLevel_GL_2015_03_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2015_03_31
    lazy val cleaner_path_SecPartLevel_GL_2015_02_28: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2015_02_28
    lazy val cleaner_path_SecPartLevel_GL_2015_01_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2015_01_31
    lazy val cleaner_path_SecPartLevel_GL_2014_05_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2014_05_31
    lazy val cleaner_path_SecPartLevel_GL_2014_03_31: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2014_03_31

    lazy val cleaner_path_SecPartLevel_2016_01_31_ES: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2016_01_31+ "/" + g_entific_id_ES
    lazy val cleaner_path_SecPartLevel_2016_01_31_GL: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2016_01_31+ "/" + g_entific_id_GL
    lazy val cleaner_path_SecPartLevel_2015_06_30_GL: String = dataCleanerResourcesPath + dataCleanerEntity + gf_cutoff_date_2015_06_30+ "/" + g_entific_id_GL

    lazy val cleaner_path_SecPartLevel_ES_31012016: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_31012016

    lazy val cleaner_path_SecPartLevel_ES_OK: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_test_OK
    lazy val cleaner_path_SecPartLevel_ES_KO: String = dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_test_KO

    lazy val cleaner_path_SecPartLevel_ES_Bad_2016_01_31: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_bad_2016_01_31
    lazy val cleaner_path_SecPartLevel_GL_Bad_2016_01_31: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_bad_2016_01_31

    //THREE PARTITION FIELDS
    lazy val cleaner_path_SecPartLevel_ES_2016_01_31_test_OK: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2016_01_31 + "/" + gf_test_OK
    lazy val cleaner_path_SecPartLevel_ES_2016_01_28_test_OK: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2016_01_28 + "/" + gf_test_OK
    lazy val cleaner_path_SecPartLevel_ES_2015_06_30_test_OK: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_06_30 + "/" + gf_test_OK
    lazy val cleaner_path_SecPartLevel_ES_2015_03_31_test_OK: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_03_31 + "/" + gf_test_OK
    lazy val cleaner_path_SecPartLevel_ES_2016_01_31_test_KO: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2016_01_31 + "/" + gf_test_KO
    lazy val cleaner_path_SecPartLevel_ES_2015_06_30_test_KO: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_06_30 + "/" + gf_test_KO
    lazy val cleaner_path_SecPartLevel_ES_2015_03_31_test_KO: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_ES + "/" + gf_cutoff_date_2015_03_31 + "/" + gf_test_KO
    lazy val cleaner_path_SecPartLevel_GL_2016_01_31_test_OK: String =
        dataCleanerResourcesPath + dataCleanerEntity + g_entific_id_GL + "/" + gf_cutoff_date_2016_01_31 + "/" + gf_test_OK

    lazy val dataset_checkpoint_path: String =
        datasetResourcesPath + "checkpointTest"

    lazy val boards_principalPath: String = "src/test/resources/data/cddBoards/principal/" + "g_entific_id=ES/" + "gf_cutoff_date=2021-04-30/"
    lazy val boards_principal_gl_path: String = "src/test/resources/data/cddBoards/principal/" + "g_entific_id=GL/" + "gf_cutoff_date=2021-04-12/"
    lazy val boards_principalOldPath: String = "src/test/resources/data/cddBoards/principal_old/" + "g_entific_id=ES/" + "gf_cutoff_date=2021-04-30/"
    lazy val boards_principalOldParentPath: String = "src/test/resources/data/cddBoards/principal_read_test/"
    lazy val boards_path_no_partition: String = boards_principalOldParentPath
    lazy val boards_path_FirstPartLevel_2021_04_30: String = boards_path_no_partition + "Date=2021-04-30/"
    lazy val boards_path_FirstPartLevel_2021_04_29: String = boards_path_no_partition + "Date=2021-04-29/"
    lazy val boards_path_FirstPartLevel_2021_03_29: String = boards_path_no_partition + "Date=2021-03-29/"
    lazy val boards_path_FirstPartLevel_2020_03_29: String = boards_path_no_partition + "Date=2020-03-29/"
    lazy val boards_path_SecPartLevel_ES_2021_04_30: String = boards_path_no_partition + "String=ES/" + "Date=2021-04-30/"
    lazy val boards_path_SecPartLevel_ES_2021_04_29: String = boards_path_no_partition + "String=ES/" + "Date=2021-04-29/"
    lazy val boards_path_SecPartLevel_ES_2021_03_29: String = boards_path_no_partition + "String=ES/" + "Date=2021-03-29/"
    lazy val boards_path_SecPartLevel_ES_2020_03_29: String = boards_path_no_partition + "String=ES/" + "Date=2020-03-29/"


    //3. DATASETS
    lazy val cleaner_file_ParquetToCopy: String = dataCleanerResourcesPath.concat("dataFile.parquet")

    //GLOBAL CONFIGURATION
    lazy val schemaPath: String = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
    lazy val badSchemaPath: String = "src/test/resources/data/cddBoards/schemas/t_cdd_board_bad_path.json"
    lazy val temporalPath: String = "src/test/resources/data/cddBoards/temporal"
    lazy val schemaBoard: String = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
    lazy val schemaWithCutoffEntificPath: String = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_cutoff_entific_audit.json"

    lazy val notInformedAllButRoot: Seq[String] = Seq("First", "Second")
    lazy val notInformedOne: Seq[String] = Seq("First")

    lazy val execution_date: String = "2021-04-01"
    lazy val cutoff_date: String = "2021-04-30"
    lazy val cutoff_field: String = "gf_cutoff_date"
    lazy val entific_field: String = "g_entific_id"
    lazy val entific_content: String = "ES"
    lazy val audit_field: String = "gf_audit_date"

    lazy val expected: GlobalConfigurationReaded = GlobalConfigurationReaded(execution_date, "Date",
        cutoff_date, "String", entific_content, audit_field, 1,
        "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json",
        "src/test/resources/data/cddBoards/temporal", "src/test/resources/data/cddBoards/principal", 1, Array(""))
    lazy val expectedDefault: GlobalConfigurationReaded = GlobalConfigurationReaded(execution_date, cutoff_field,
        cutoff_date, entific_field, entific_content, audit_field, 2,
        schemaBoard, boards_principalPath, boards_principalOldPath, 2, Array(""))
    lazy val expectedNotInformedAllButRoot: GlobalConfigurationReaded = GlobalConfigurationReaded(execution_date, cutoff_field,
        cutoff_date, entific_field, entific_content, audit_field, 1,
        schemaBoard, boards_principalPath, boards_principalOldPath, 1, notInformedAllButRoot)
    lazy val expectedNotInformedOne: GlobalConfigurationReaded = GlobalConfigurationReaded(execution_date, cutoff_field,
        cutoff_date, entific_field, entific_content, audit_field, 1,
        schemaBoard, boards_principalPath, boards_principalOldPath, 1, notInformedOne)

    val testingGlobalConfigurationReaded : GlobalConfigurationReaded =
        GlobalConfigurationReaded(dateIngestion = "2021-04-01",
            dateColumnName = "gf_cutoff_date",
            dateColumnValue = "2021-04-30",
            entificColumnName = "g_entific_id",
            entificColumnValue = "ES",
            auditColumnName = "gf_audit_date",
            averageKBPerRecord = 1,
            fullNameSchemaBoard = schemaBoard,
            pathTemporal = temporalPath,
            pathOutputBoard = "src/test/resources/data/cddBoards/principal",
            repartitionBase = 1,
            notInformedDatasets = Seq.empty[String])
    val globalTranslated : GlobalConfigurationTranslated =
        GlobalConfigurationTranslated(datioOutputSchema = testingDataDatioSchema_withAudit,
            checkpointTempPath = temporalPath,
            backupTempPath = "src/test/resources/data/cddBoards/backup",
            actualPrincipalPath = "src/test/resources/data/cddBoards/principal",
            actualPrincipalPathWithPartitions = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30")
    lazy val testingGlobalConfigurationReadedBadPath: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(fullNameSchemaBoard = badSchemaPath)
    lazy val testingGlobalConfigurationReadedWithNoAudit: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(fullNameSchemaBoard = schemaPath)
    lazy val testingGlobalConfigurationReadedWithCutoffEntific: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(fullNameSchemaBoard = schemaWithCutoffEntificPath)
    lazy val testingGlobalConfigurationReadedBadAudit: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(auditColumnName = "bad_audit_date")
    lazy val testingGlobalConfigurationReadedAllInformed: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(notInformedDatasets = Nil)
    lazy val testingGlobalConfigurationReadedNotInformed_1: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(notInformedDatasets = Seq("First"))
    lazy val testingGlobalConfigurationReadedNotInformed_2: GlobalConfigurationReaded = testingGlobalConfigurationReaded
      .copy(notInformedDatasets = Seq("First", "Second"))
}

case class CddStructuralBoardsDatasetTestClass (original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[CddStructuralBoardsDatasetTestClass] {
    val TEST_DATASET_DESC: String = "Unit Testing Dataset"
    val CONF_TEST_DATASET_PATH: String = "testingDataset.dataPath"
    val CONF_TEST_DATASET_SCHEMA: String = "testingDataset.schemaPath"
    val CONF_TEST_DATASET_RELEVANT_FIELDS: String = "testingDataset.relevantFields"
    val CONF_TEST_DATASET_OLD_FIELDS: String = "testingDataset.previousRename.oldFieldNames"
    val CONF_TEST_DATASET_NEW_FIELDS: String = "testingDataset.previousRename.newFieldNames"
    val CONF_TEST_DATASET_PREVIOUS_FILTER_FIELDS: String = "testingDataset.previousFilterAppliedFields"
    val CONF_TEST_DATASET_JOIN_FIELDS: String = "testingDataset.joinFields"
    val TEST_DATASET_CONSTANTS : DatasetParams = DatasetParams(TEST_DATASET_DESC,
        CONF_TEST_DATASET_PATH,
        CONF_TEST_DATASET_SCHEMA,
        CONF_TEST_DATASET_RELEVANT_FIELDS,
        CONF_TEST_DATASET_OLD_FIELDS,
        CONF_TEST_DATASET_NEW_FIELDS,
        CONF_TEST_DATASET_JOIN_FIELDS,
        CONF_TEST_DATASET_PREVIOUS_FILTER_FIELDS
    )

    val datasetParams : DatasetParams = TEST_DATASET_CONSTANTS
    globalParameterSetter()
    def wrap(transformed: DataFrame): CddStructuralBoardsDatasetTestClass = {
        copy(original = transformed)
    }
}

case class CddStructuralMainBoardDatasetTestClass (original: DataFrame, config: Config)
  extends CDDStructuralMainBoardDataset[CddStructuralBoardsDatasetTestClass] {
    lazy val testResources = new TestCommonResources(DatioSparkSession.getOrCreate())
    val TEST_DATASET_DESC: String = "Unit Testing Main Board Dataset"
    val CONF_TEST_DATASET_PATH: String = "testingDataset.dataPath"
    val CONF_TEST_DATASET_SCHEMA: String = "testingDataset.schemaPath"
    val CONF_TEST_DATASET_RELEVANT_FIELDS: String = "testingDataset.relevantFields"
    val CONF_TEST_DATASET_OLD_FIELDS: String = "testingDataset.previousRename.oldFieldNames"
    val CONF_TEST_DATASET_NEW_FIELDS: String = "testingDataset.previousRename.newFieldNames"
    val CONF_TEST_DATASET_PREVIOUS_FILTER_FIELDS: String = "testingDataset.previousFilterAppliedFields"
    val CONF_TEST_DATASET_JOIN_FIELDS: String = "testingDataset.joinFields"
    val TEST_DATASET_CONSTANTS : DatasetParams = DatasetParams(TEST_DATASET_DESC,
        CONF_TEST_DATASET_PATH,
        CONF_TEST_DATASET_SCHEMA,
        CONF_TEST_DATASET_RELEVANT_FIELDS,
        CONF_TEST_DATASET_OLD_FIELDS,
        CONF_TEST_DATASET_NEW_FIELDS,
        CONF_TEST_DATASET_PREVIOUS_FILTER_FIELDS,
        CONF_TEST_DATASET_JOIN_FIELDS
    )
    val datasetParams : DatasetParams = TEST_DATASET_CONSTANTS

    override def selectTablonColumns(): CDDStructuralBoardsDataset[CddStructuralBoardsDatasetTestClass] = this
    override def join(right: CDDStructuralBoardsDataset[_]): CDDStructuralMainBoardDataset[CddStructuralBoardsDatasetTestClass] = this
    override def wrap(transformed: DataFrame): CddStructuralBoardsDatasetTestClass =
        CddStructuralBoardsDatasetTestClass(testResources.testingEmptyDataFrame, config)
}

case class CddStructuralMainBoardDatasetTestNotInOutputClass (original: DataFrame, config: Config)
  extends CDDStructuralMainBoardDataset[CddStructuralBoardsDatasetTestClass] {
    lazy val testResources = new TestCommonResources(DatioSparkSession.getOrCreate())
    val TEST_DATASET_DESC: String = "Unit Testing Main Board Dataset"
    val CONF_TEST_DATASET_PATH: String = "testingDataset.dataPath"
    val CONF_TEST_DATASET_SCHEMA: String = "testingDataset.schemaPath"
    val CONF_TEST_DATASET_RELEVANT_FIELDS: String = "testingDataset.relevantFields"
    val CONF_TEST_DATASET_OLD_FIELDS: String = "testingDataset.previousRename.oldFieldNames"
    val CONF_TEST_DATASET_NEW_FIELDS: String = "testingDataset.previousRename.newFieldNames"
    val CONF_TEST_DATASET_PREVIOUS_FILTER_FIELDS: String = "testingDataset.previousFilterAppliedFields"
    val CONF_TEST_DATASET_JOIN_FIELDS: String = "testingDataset.joinFields"
    val TEST_DATASET_CONSTANTS : DatasetParams = DatasetParams(TEST_DATASET_DESC,
        CONF_TEST_DATASET_PATH,
        CONF_TEST_DATASET_SCHEMA,
        CONF_TEST_DATASET_RELEVANT_FIELDS,
        CONF_TEST_DATASET_OLD_FIELDS,
        CONF_TEST_DATASET_NEW_FIELDS,
        CONF_TEST_DATASET_PREVIOUS_FILTER_FIELDS,
        CONF_TEST_DATASET_JOIN_FIELDS
    )
    val datasetParams : DatasetParams = TEST_DATASET_CONSTANTS
    override val fieldsNotInOutput: Seq[String] = Seq("Timestamp")

    override def selectTablonColumns(): CDDStructuralBoardsDataset[CddStructuralBoardsDatasetTestClass] = this
    override def join(right: CDDStructuralBoardsDataset[_]): CDDStructuralMainBoardDataset[CddStructuralBoardsDatasetTestClass] = this
    override def wrap(transformed: DataFrame): CddStructuralBoardsDatasetTestClass =
        CddStructuralBoardsDatasetTestClass(testResources.testingEmptyDataFrame, config)
}

case class CDDStructuralBoardsAppTestClass() extends CDDStructuralBoardsApp{
    val mainEntity: String = "Root"
    val configId: String = "CDDBoard"
    val structuralBoard: String = "Test Structural Board"
    val boardTables: Seq[String] = Seq("First", "Second")
    val defaultAverageKBPerRecord : Int = 2
    val defaultRepartitionBase : Int = 2
    lazy val testResources = new TestCommonResources(DatioSparkSession.getOrCreate())

    def dataSetCollectionMapper (entityName: String,
                                 globalConfigurationReaded: GlobalConfigurationReaded,
                                 globalConfigurationTranslated: GlobalConfigurationTranslated,
                                 config: Config,
                                 datioSparkSession: DatioSparkSession,
                                 emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])] = {
        if (emptyInitializeMode){
            Option((testResources.emptyDataSetPrefix.concat(entityName),
              CddStructuralBoardsDatasetTestClass(testResources.testingEmptyDataFrame, config).globalParameterSetter()))
        } else {
            Option((testResources.notEmptyDataSetPrefix.concat(entityName),
              CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, config).globalParameterSetter()))
        }
    }

    override def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                            globalConfigurationReaded: GlobalConfigurationReaded,
                            globalConfigurationTranslated: GlobalConfigurationTranslated,
                            datioSparkSession: DatioSparkSession): CDDStructuralMainBoardDataset[_] = {
        CddStructuralMainBoardDatasetTestClass(testResources.testingJsonSchemaDataFrame, testResources.board_config_basic)
    }
}

case class CDDStructuralBoardsAppExceptionTestClass() extends CDDStructuralBoardsApp(){
    val mainEntity: String = "Root"
    val configId: String = "CDDBoard"
    val structuralBoard: String = "Test Structural Board"
    val boardTables: Seq[String] = Seq("First", "Second")
    val defaultAverageKBPerRecord : Int = 1
    val defaultRepartitionBase : Int = 1
    lazy val testResources = new TestCommonResources(DatioSparkSession.getOrCreate())

    override def dataSetCollectionMapper(entityName: String,
                                         globalConfigurationReaded: GlobalConfigurationReaded,
                                         globalConfigurationTranslated: GlobalConfigurationTranslated,
                                         config: Config,
                                         datioSparkSession: DatioSparkSession,
                                         emptyInitializeMode: Boolean):
        Option[(String, CDDStructuralBoardsDataset[_])] = throw new StructuralBoardsExceptions

    override def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                            globalConfigurationReaded: GlobalConfigurationReaded,
                            globalConfigurationTranslated: GlobalConfigurationTranslated,
                            datioSparkSession: DatioSparkSession):
        CDDStructuralMainBoardDataset[_] = CddStructuralMainBoardDatasetTestClass(testResources.testingJsonSchemaDataFrame, testResources.board_config_basic)
}

class TestingRuntimeContext extends RuntimeContext {
    var config : Config =_
    override def getProcessId: String = "TestingRuntimeContext"
    override def getConfig: Config = this.config
    def setConfig(config:Config): RuntimeContext = {
        this.config = config
        this
    }
    override def getProperty(s: String): AnyRef = Unit
    override def setUserCode(s: String): Unit = Unit
    override def setMessage(s: String): Unit = Unit
    override def setAdditionalInfo(s: String): Unit = Unit
}
