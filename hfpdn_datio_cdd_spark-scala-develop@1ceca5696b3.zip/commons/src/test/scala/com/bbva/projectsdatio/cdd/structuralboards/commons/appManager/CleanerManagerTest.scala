package com.bbva.projectsdatio.cdd.structuralboards.commons.appManager

import java.text.ParseException
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{BadStringNameException, ValueParameterException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{TestCommons, TestUtils}
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.hadoop.fs.{FileSystem, Path}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class CleanerManagerTest extends TestCommons {

  test("cleanerManager_cleanMainPathSinglePartition") {
    val pathNoDeleteGL: String = testResources.cleaner_path_FirstPartLevel_2016_01_31
    val pathNoDeleteES: String = testResources.cleaner_path_FirstPartLevel_2016_01_31
    val pathNoDeleteGL1: String = testResources.cleaner_path_FirstPartLevel_2015_06_30
    val pathNoDeleteES1: String = testResources.cleaner_path_FirstPartLevel_2015_06_30
    val pathActualGL: String = testResources.cleaner_path_FirstPartLevel_2015_03_31
    val pathActualES: String = testResources.cleaner_path_FirstPartLevel_2015_03_31
    val pathPrevGL: String = testResources.cleaner_path_FirstPartLevel_2015_01_31
    val pathPrevES: String = testResources.cleaner_path_FirstPartLevel_2015_01_31
    val pathOtherYearGL: String = testResources.cleaner_path_FirstPartLevel_2014_03_31
    val pathOtherYearES: String = testResources.cleaner_path_FirstPartLevel_2014_03_31
    val principalPath: String = testResources.cleaner_config_SinglePartition.getString(CONF_CLEAN_BOARDS_PATH)
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val today: String = testResources.cleaner_config_SinglePartition.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_SinglePartition.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_SinglePartition.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_SinglePartition.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && !FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathFirstDay") {
    val pathNoDeleteGL: String = testResources.cleaner_path_SecPartLevel_GL_2016_01_31
    val pathNoDeleteGL1: String = testResources.cleaner_path_SecPartLevel_GL_2015_06_30
    val pathActualGL: String = testResources.cleaner_path_SecPartLevel_GL_2015_03_31
    val pathPrevGL: String = testResources.cleaner_path_SecPartLevel_GL_2015_01_31
    val pathOtherYearGL: String = testResources.cleaner_path_SecPartLevel_GL_2014_03_31
    val pathNoDeleteES: String = testResources.cleaner_path_SecPartLevel_ES_2016_01_31
    val pathNoDeleteES1: String = testResources.cleaner_path_SecPartLevel_ES_2015_06_30
    val pathActualES: String = testResources.cleaner_path_SecPartLevel_ES_2015_03_31
    val pathPrevES: String = testResources.cleaner_path_SecPartLevel_ES_2015_01_31
    val pathOtherYearES: String = testResources.cleaner_path_SecPartLevel_ES_2014_03_31
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_FirstDay.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && !FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathFifthDay") {
    val pathNoDeleteGL: String = testResources.cleaner_path_SecPartLevel_GL_2016_01_31
    val pathNoDeleteGL1: String = testResources.cleaner_path_SecPartLevel_GL_2015_06_30
    val pathActualGL: String = testResources.cleaner_path_SecPartLevel_GL_2015_02_28
    val pathPrevGL: String = testResources.cleaner_path_SecPartLevel_GL_2015_01_31
    val pathOtherYearGL: String = testResources.cleaner_path_SecPartLevel_GL_2014_05_31
    val pathNoDeleteES: String = testResources.cleaner_path_SecPartLevel_ES_2016_01_31
    val pathNoDeleteES1: String = testResources.cleaner_path_SecPartLevel_ES_2015_06_30
    val pathActualES: String = testResources.cleaner_path_SecPartLevel_ES_2015_02_28
    val pathPrevES: String = testResources.cleaner_path_SecPartLevel_ES_2015_01_31
    val pathOtherYearES: String = testResources.cleaner_path_SecPartLevel_ES_2014_05_31
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = testResources.cleaner_config_FifthDay.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_FifthDay.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_FifthDay.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_FifthDay.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_FifthDay.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && !FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathSameYear") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-07-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-04-30"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-03-31"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-02-28"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-07-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-04-30"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-03-31"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-01-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-02-28"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = testResources.cleaner_config_HistSameYear.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_HistSameYear.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_HistSameYear.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_HistSameYear.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_HistSameYear.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, historicalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && !FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, historicalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathChangeYear") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-07-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-01-31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-11-30"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-12-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-07-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-01-31"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-11-30"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-12-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = testResources.cleaner_config_HistChangeYear.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_HistChangeYear.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_HistChangeYear.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_HistChangeYear.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_HistChangeYear.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, historicalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && !FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, historicalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathBadPath") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-07-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-01-31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-11-30"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-12-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-07-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-01-31"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-11-30"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-12-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = testResources.cleaner_config_BadPath.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_BadPath.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_BadPath.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_BadPath.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_BadPath.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    assertThrows[ValueParameterException] {
      CleanerManager.cleanMainPath(datioSparkSession, historicalPath, today, persistenceLimit, datePartitionName, dateFormat)
    }

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      FileSystemUtils.pathExists(dfs, pathPrevGL) && FileSystemUtils.pathExists(dfs, pathPrevES) &&
      FileSystemUtils.pathExists(dfs, pathPrevGL1) && FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      FileSystemUtils.pathExists(dfs, pathOtherYearGL) && FileSystemUtils.pathExists(dfs, pathOtherYearES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup")
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathOtherFormat1") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20160131"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20150630"
    val pathActualGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20150228"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20150131"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20140331"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20160131"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20150630"
    val pathActualES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20150228"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20150131"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20140331"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = testResources.cleaner_config_OtherFormat1.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_OtherFormat1.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_OtherFormat1.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_OtherFormat1.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_OtherFormat1.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && !FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathOtherFormat2") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=31012016"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=30062015"
    val pathActualGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=28022015"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=31012015"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=31032014"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31012016"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=30062015"
    val pathActualES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31032015"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31012015"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31032014"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = testResources.cleaner_config_OtherFormat2.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_OtherFormat2.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_OtherFormat2.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_OtherFormat2.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_OtherFormat2.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathUnparseable") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2016_01_31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015_06_30"
    val pathActualGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015_03_31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015_01_31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2014_03_31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2016_01_31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015_06_30"
    val pathActualES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015_03_31"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015_01_31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2014_03_31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_FirstDay.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    assertThrows[ParseException] {
      CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)
    }

    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      FileSystemUtils.pathExists(dfs, pathActualGL) && FileSystemUtils.pathExists(dfs, pathActualES) &&
      FileSystemUtils.pathExists(dfs, pathOtherYearGL) && FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      FileSystemUtils.pathExists(dfs, pathPrevGL) && FileSystemUtils.pathExists(dfs, pathPrevES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

  test("cleanerManager_cleanMainPathNoSubdir") {
    val pathnoSubdirGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL"
    val pathnoSubdirES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathnoSubdirGL).fileSystem()
    val path1: Path = dfs.qualify(pathnoSubdirGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathnoSubdirES).fileSystem()
    val path2: Path = dfs.qualify(pathnoSubdirES).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirES,
      testResources.testingDataDatioSchema)

    val principalPath: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_PATH)
    val today: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_INGESTION)
    val persistenceLimit: Int = testResources.cleaner_config_FirstDay.getInt(CONF_CLEAN_BOARDS_PERSISTENCE_LIMIT)
    val datePartitionName: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_NAME)
    val dateFormat: String = testResources.cleaner_config_FirstDay.getString(CONF_CLEAN_BOARDS_DATE_FORMAT)
    assertThrows[BadStringNameException] {
      CleanerManager.cleanMainPath(datioSparkSession, principalPath, today, persistenceLimit, datePartitionName, dateFormat)
    }
    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathnoSubdirGL) && FileSystemUtils.pathExists(dfs, pathnoSubdirES)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, principalPath)
    result == VAL_TRUE shouldBe true
  }

}