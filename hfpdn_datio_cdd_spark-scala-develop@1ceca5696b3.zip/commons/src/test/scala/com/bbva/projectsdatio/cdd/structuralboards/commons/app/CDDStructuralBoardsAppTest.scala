package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{BadStringNameException, ParamMalformedException, ParamNotInformedException, StringInListException, StructuralBoardsExceptions}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.TestCommons
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{CDDStructuralBoardsAppExceptionTestClass, CDDStructuralBoardsAppTestClass, TestingRuntimeContext}
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.schema.exception.DataprocSchemaException
import org.apache.spark.sql.AnalysisException
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class CDDStructuralBoardsAppTest extends TestCommons {

  test("CDDStructuralBoardsApp_writerCDDBoard") {
    CDDStructuralBoardsAppTestClass().writerCDDBoard(datioSparkSession,
      testResources.testingJsonSchemaDataFrame,
      testResources.testingGlobalConfigurationReadedWithCutoffEntific,
      testResources.globalTranslated)
    val dfs = DatioFileSystem.get()
    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, testResources.boards_principal_gl_path)) {
      result = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, testResources.boards_principal_gl_path)
    (result == VAL_TRUE) shouldBe TRUE_VALUE
  }


  test("CDDStructuralBoardsApp_writerCDDBoardBadSchemaPath") {
    assertThrows[StructuralBoardsExceptions] {
      CDDStructuralBoardsAppTestClass().writerCDDBoard(datioSparkSession,
        testResources.testingJsonSchemaDataFrame,
        testResources.testingGlobalConfigurationReadedBadPath,
        testResources.globalTranslated)
    }
    val dfs = DatioFileSystem.get()
    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, testResources.boards_principalOldPath)) {
      result = VAL_TRUE
    }
    (result == VAL_TRUE) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_writerCDDBoardSchemaWithOutAuditPath") {
    assertThrows[DataprocSchemaException.InvalidDatasetException] {
      CDDStructuralBoardsAppTestClass().writerCDDBoard(datioSparkSession,
        testResources.testingJsonSchemaDataFrame,
        testResources.testingGlobalConfigurationReadedWithNoAudit,
        testResources.globalTranslated)
    }
    val dfs = DatioFileSystem.get()
    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, testResources.boards_principalOldPath)) {
      result = VAL_TRUE
    }
    (result == VAL_TRUE) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_writerCDDBoardSchemaBadAuditName") {
    assertThrows[AnalysisException] {
      CDDStructuralBoardsAppTestClass().writerCDDBoard(datioSparkSession,
        testResources.testingJsonSchemaDataFrame,
        testResources.testingGlobalConfigurationReadedBadAudit,
        testResources.globalTranslated)
    }
    val dfs = DatioFileSystem.get()
    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, testResources.boards_principalOldPath)) {
      result = VAL_TRUE
    }
    (result == VAL_TRUE) shouldBe TRUE_VALUE
  }


  test("CDDStructuralBoardsApp_writerCDDBoardRestoreBackUp") {
    assertThrows[AnalysisException] {
      CDDStructuralBoardsAppTestClass().writerCDDBoard(datioSparkSession,
        testResources.testingJsonSchemaDataFrame,
        testResources.testingGlobalConfigurationReadedBadAudit,
        testResources.globalTranslated)
    }
    val dfs = DatioFileSystem.get()
    var result = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, testResources.boards_principalOldPath)) {
      result = VAL_TRUE
    }
    (result == VAL_TRUE) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_checkNotInformedDataSets") {
    CDDStructuralBoardsAppTestClass().checkNotInformedDataSets(Seq("First"))
  }

  test("CDDStructuralBoardsApp_checkNotInformedDataSetsRoot") {
    assertThrows[StringInListException] {
      CDDStructuralBoardsAppTestClass().checkNotInformedDataSets(Seq("Root"))
    }
  }
  test("CDDStructuralBoardsApp_checkNotInformedDataSetsAll") {
    assertThrows[StringInListException] {
      CDDStructuralBoardsAppTestClass().checkNotInformedDataSets(Seq("Root", "First", "Second"))
    }
  }
  test("CDDStructuralBoardsApp_checkNotInformedDataSetsWrong") {
    assertThrows[BadStringNameException] {
      CDDStructuralBoardsAppTestClass().checkNotInformedDataSets(Seq("Frist"))
    }
  }
  test("contractsIngestion_doBusinessLogicNotInformedWrongMix") {
    assertThrows[BadStringNameException] {
      CDDStructuralBoardsAppTestClass().checkNotInformedDataSets(Seq("First", "Sercond"))
    }
  }

  test("CDDStructuralBoardsApp_dataSetsMapperEveryDataSetInformed") {
    val datasetMap: Map[String, CDDStructuralBoardsDataset[_]] = CDDStructuralBoardsAppTestClass()
      .dataSetsMapper(testResources.testingGlobalConfigurationReadedAllInformed, testResources.globalTranslated, testResources.board_complete_config_basic, datioSparkSession)
    assert(!datasetMap(testResources.notEmptyDataSetPrefix.concat("First")).original.count().equals(0.toLong))
    assert(!datasetMap(testResources.notEmptyDataSetPrefix.concat("Second")).original.count().equals(0.toLong))
  }

  test("CDDStructuralBoardsApp_dataSetsMapperMixDataSetInformed") {
    val datasetMap: Map[String, CDDStructuralBoardsDataset[_]] = CDDStructuralBoardsAppTestClass()
      .dataSetsMapper(testResources.testingGlobalConfigurationReadedNotInformed_1, testResources.globalTranslated, testResources.board_complete_config_basic, datioSparkSession)
    assert(datasetMap(testResources.emptyDataSetPrefix.concat("First")).original.count().equals(0.toLong))
    assert(!datasetMap(testResources.notEmptyDataSetPrefix.concat("Second")).original.count().equals(0.toLong))
  }

  test("CDDStructuralBoardsApp_dataSetsMapperNoDataSetInformed") {
    val datasetMap: Map[String, CDDStructuralBoardsDataset[_]] = CDDStructuralBoardsAppTestClass()
      .dataSetsMapper(testResources.testingGlobalConfigurationReadedNotInformed_2, testResources.globalTranslated, testResources.board_complete_config_basic, datioSparkSession)
    assert(datasetMap(testResources.emptyDataSetPrefix.concat("First")).original.count().equals(0.toLong))
    assert(datasetMap(testResources.emptyDataSetPrefix.concat("Second")).original.count().equals(0.toLong))
  }

  test("CDDStructuralBoardsApp_setterConfigurations") {
    val result = CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_basic)
    (result == testResources.expected) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_setterConfigurationsDefault") {
    val result = CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_default)
    (result == testResources.expectedDefault) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_setterConfigurationsNotInformedAllButRootTest") {
    val result = CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_notInformedAllButRoot)
    (result == testResources.expectedNotInformedAllButRoot) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_setterConfigurationsNotInformedOne") {
    val result = CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_notInformedOne)
    (result == testResources.expectedNotInformedOne) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsApp_setterConfigurationsMissParam") {
    assertThrows[ParamNotInformedException] {
      CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_missParam)
    }
  }

  test("contractsIngestion_setterConfigurationsBadCutoffDate") {
    assertThrows[ParamMalformedException] {
      CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_badCutoffDate)
    }
  }

  test("contractsIngestion_setterConfigurationsBadCutoffDateType") {
    assertThrows[ParamMalformedException] {
      CDDStructuralBoardsAppTestClass().setterGlobalConfigurationReadedParamsReader(testResources.board_config_badCutoffDateType)
    }
  }

  test("CDDStructuralBoardsApp_runProcess_OK") {
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.board_complete_with_cutoff_entific_config_basic_base)
    val result: Int = CDDStructuralBoardsAppTestClass().runProcess(testingRuntimeContext)
    val expected: Int = 0
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.board_config_basic.getString(CONF_PATH_OUTPUT_PRINCIPAL))
    result == expected shouldBe true
  }

  test("CDDStructuralBoardsApp_runProcess_KO") {
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.board_root_config_basic)
    val result: Int = CDDStructuralBoardsAppExceptionTestClass().runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }
}
