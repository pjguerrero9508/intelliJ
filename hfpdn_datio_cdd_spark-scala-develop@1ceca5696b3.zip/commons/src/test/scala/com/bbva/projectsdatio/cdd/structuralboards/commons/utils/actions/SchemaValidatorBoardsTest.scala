package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.TestCommons
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.types.{StructField, _}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class SchemaValidatorBoardsTest extends TestCommons {

  lazy val outputSchema: DatioSchema = SchemaReaderBoards.readSchema("src/test/resources/data/utils/actions/readSchemaOfJson.json")
  lazy val outputSchemaNotMandatory: DatioSchema = SchemaReaderBoards.readSchema("src/test/resources/data/utils/actions/schemaNotMandatory.json")
  //1. El DataFrame tiene todas las columnas
  //2. Al dataframe tiene todas las columnas menos una
  //3. Al dataframe tiene todas las columnas menos varias
  //4. Al dataframe no tiene ninguna de las columnas
  //5. Al dataframe no tiene una de las columnas y no está en el esquema de salida - Inactivo
  test("SchemaValidatorBoards - initializeNotInformedColumnsHasEveryColumn") {
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, outputSchemaNotMandatory.getStructType)
    val columnNames: Seq[String] = Seq("date",
      "string",
      "decimal",
      "integer",
      "timestamp")
    val outputDf: DataFrame = SchemaValidatorBoards.initializeNotInformedColumns(df, outputSchemaNotMandatory.getStructType, columnNames)
    assert(outputSchemaNotMandatory.getStructType.equals(outputDf.schema))
  }
  test("SchemaValidatorBoards - initializeNotInformedColumnsHasNotOneColumn") {
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val schemaTest : StructType = StructType(outputSchemaNotMandatory.getStructType.filterNot(_.name.equals("timestamp")))
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaTest)
    val columnNames: Seq[String] = Seq("date",
      "string",
      "decimal",
      "integer",
      "timestamp")
    val outputDf: DataFrame = SchemaValidatorBoards.initializeNotInformedColumns(df, outputSchemaNotMandatory.getStructType, columnNames)
    val mappedResultSchema = outputDf.schema.fields.map(field => (field.name,field.dataType))
    val mappedoutputSchemaNotMandatory = outputSchemaNotMandatory.getStructType.fields.map(field => (field.name,field.dataType))
    assert(mappedResultSchema.sameElements(mappedoutputSchemaNotMandatory))
  }
  test("SchemaValidatorBoards - initializeNotInformedColumnsHasNotSeveralColumns") {
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val schemaTest : StructType = StructType(outputSchemaNotMandatory.getStructType.filterNot(field => field.name.equals("integer") || field.name.equals("timestamp")))
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaTest)
    val columnNames: Seq[String] = Seq("date",
      "string",
      "decimal",
      "integer",
      "timestamp")
    val outputDf: DataFrame = SchemaValidatorBoards.initializeNotInformedColumns(df, outputSchemaNotMandatory.getStructType, columnNames)
    val mappedResultSchema = outputDf.schema.fields.map(field => (field.name,field.dataType))
    val mappedoutputSchemaNotMandatory = outputSchemaNotMandatory.getStructType.fields.map(field => (field.name,field.dataType))
    assert(mappedResultSchema.sameElements(mappedoutputSchemaNotMandatory))
  }
  test("SchemaValidatorBoards - initializeNotInformedColumnsHasNoneColumns") {
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val schemaTest : StructType = StructType.apply(Seq(StructField("test",StringType,true)))
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaTest).drop("test")
    val columnNames: Seq[String] = Seq("date",
      "string",
      "decimal",
      "integer",
      "timestamp")
    val outputDf: DataFrame = SchemaValidatorBoards.initializeNotInformedColumns(df, outputSchemaNotMandatory.getStructType, columnNames)
    val mappedResultSchema = outputDf.schema.fields.map(field => (field.name,field.dataType))
    val mappedoutputSchemaNotMandatory = outputSchemaNotMandatory.getStructType.fields.map(field => (field.name,field.dataType))
    assert(mappedResultSchema.sameElements(mappedoutputSchemaNotMandatory))
  }

  test("SchemaValidatorBoards - initializeNotInformedColumns") {
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val schemaTest : StructType = StructType.apply(
      Seq(
        StructField("test_keep",StringType,true, new MetadataBuilder()
          .putString("default", "Test")
          .build()
        )
      )
    )
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaTest)
    val columnNames: Seq[String] = Seq("test_nullable",
      "test_string",
      "test_int",
      "test_double",
      "test_date",
      "test_timestamp")
    val outputDf: DataFrame = SchemaValidatorBoards
      .initializeNotInformedColumns(df, testResources.testingDataSchema_output_autoinit.getStructType, columnNames)
    val mappedResultSchema = outputDf.schema.fields.map(field => (field.name, field.dataType))
    val mappedExpectedSchema = testResources.testingDataSchema_output_autoinit
      .getStructType.fields.map(field => (field.name, field.dataType))
    assert(mappedResultSchema.map(field => mappedExpectedSchema.contains(field)).reduce(_&&_))
    assert(mappedExpectedSchema.map(field => mappedResultSchema.contains(field)).reduce(_&&_))
  }
}
