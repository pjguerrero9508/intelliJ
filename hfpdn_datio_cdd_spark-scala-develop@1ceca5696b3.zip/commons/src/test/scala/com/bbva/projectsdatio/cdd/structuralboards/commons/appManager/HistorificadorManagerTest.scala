package com.bbva.projectsdatio.cdd.structuralboards.commons.appManager

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.BadColumnsNameException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, ReadUtils, SchemaReaderBoards, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{TestCommons, TestUtils}
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.schema.DatioSchema
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.sql.functions.col
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class HistorificadorManagerTest extends TestCommons {

  val outputSchema: DatioSchema = SchemaReaderBoards
    .readSchema("src/test/resources/data/historificador/schemas/t_ktae_contract_struc_board.json")

  test("historificadorManager_filterDfInformation prev test") {
    val principalPath: String = "src/test/resources/data/historificador/firstTest/inputParquet"
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, principalPath)
    val columnsName: Seq[String] = Seq("g_entific_id","gf_cutoff_date")
    val inputDataFrame = testResources.testingDataFrame_with_partitions
      .union(testResources.testingDataFrame_with_partitions_28)
    TestUtils.simpleWriteToParquetWithSchemaAndPartitions(datioSparkSession, inputDataFrame, principalPath,
      testResources.testingDataSchema_added_partitionsDatioSchema, columnsName)
  }

  test("historificadorManager_filterDfInformation test") {
    val principalPath: String = "src/test/resources/data/historificador/firstTest/inputParquet"
    val columnsName: Seq[String] = Seq("g_entific_id","gf_cutoff_date")
    val columnsValue: Seq[String] = Seq("ES",testResources.partition_date)
    val applyFilter: Seq[String] = Seq("Y","Y")
    val columnAudit: String = "Timestamp"
    val result: DataFrame = HistorificadorManager
      .filterDfInformation(datioSparkSession, principalPath, columnsName, columnsValue,
        applyFilter, columnAudit)(testResources.testingDataSchema_added_partitionsDatioSchema)
    val columns = result.columns.map(col)
    TestUtils.assertDataFrameEquals(result,
      testResources.testingDataFrame_with_partitions.select(columns:_*), FALSE_VALUE, FALSE_VALUE) shouldBe TRUE_VALUE
  }
  test("historificadorManager_filterDfInformation prev test withStringInts") {
    val principalPath: String = "src/test/resources/data/historificador/secondTest/inputParquet"
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, principalPath)
    val columnsName: Seq[String] = Seq("String","gf_cutoff_date")
    val inputDataFrame = testResources.testingDataFrame_with_partitions_numString
      .union(testResources.testingDataFrame_with_partitions_28_numString)
    TestUtils.simpleWriteToParquetWithSchemaAndPartitions(datioSparkSession, inputDataFrame, principalPath,
      testResources.testingDataSchema_added_partitionsDatioSchema, columnsName)
  }

  test("historificadorManager_filterDfInformation test withStringInts") {
    val principalPath: String = "src/test/resources/data/historificador/secondTest/inputParquet"
    val columnsName: Seq[String] = Seq("String","gf_cutoff_date")
    val columnsValue: Seq[String] = Seq("0002",testResources.partition_date)
    val applyFilter: Seq[String] = Seq("Y","Y")
    val columnAudit: String = "Timestamp"
    val result: DataFrame = HistorificadorManager
      .filterDfInformation(datioSparkSession, principalPath, columnsName, columnsValue,
        applyFilter, columnAudit)(testResources.testingDataSchema_added_partitionsDatioSchema)
    val columns = result.columns.map(col)
    TestUtils.assertDataFrameEquals(result,
      testResources.testingDataFrame_with_partitions_numString_exp.select(columns:_*), FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("historificadorManager_filterDfInformationBadFieldsName") {
    val principalPath: String = "src/test/resources/data/historificador/inputParquet"
    val columnsName: Seq[String] = Seq("g_entific_iddd", "gf_cutoff_dateee")
    val columnsValue: Seq[String] = Seq("GL", "2020-03-31")
    val applyFilter: Seq[String] = Seq("Y", "Y")
    val columnAudit: String = "gf_audit_date"
    assertThrows[BadColumnsNameException] {
      HistorificadorManager
        .filterDfInformation(datioSparkSession, principalPath, columnsName, columnsValue, applyFilter, columnAudit)(outputSchema)
    }
  }

  test("historificadorManager_filterDfInformationBadAuditFieldName") {
    val principalPath: String = "src/test/resources/data/historificador/inputParquet"
    val columnsName: Seq[String] = Seq("g_entific_id", "gf_cutoff_date")
    val columnsValue: Seq[String] = Seq("GL", "2020-03-31")
    val applyFilter: Seq[String] = Seq("Y", "Y")
    val columnAudit: String = "gf_audit_dateee"
    assertThrows[BadColumnsNameException] {
      HistorificadorManager
        .filterDfInformation(datioSparkSession, principalPath, columnsName, columnsValue, applyFilter, columnAudit)(outputSchema)
    }
  }
}
