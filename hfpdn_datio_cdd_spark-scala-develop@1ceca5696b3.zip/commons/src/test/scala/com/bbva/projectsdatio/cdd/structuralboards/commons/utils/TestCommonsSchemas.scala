package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import org.apache.spark.sql.types.{DataTypes, MetadataBuilder, StructField, StructType}
import com.datio.dataproc.sdk.schema.{DatioSchema, DatioSchemaForTesting}
import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.col
import org.mockito.Mockito.spy

trait TestCommonsSchemas {
  lazy val testingDataSchema: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))
  lazy val testingDataSchemaColumnNames: List[Column] = testingDataSchema.fields.map(field => col(field.name)).toList
  lazy val testingDataSchema_withOutDate: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))
  lazy val testingDataSchema_withOutDateNorString: StructType = StructType(List(
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))

  lazy val schemaToInitializeTest : StructType = StructType.apply(
    Seq(
      StructField("test_keep",DataTypes.StringType,true, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      ),
      StructField("test_nullable",DataTypes.StringType,true, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      ),
      StructField("test_string",DataTypes.StringType,false, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      ),
      StructField("test_int",DataTypes.IntegerType,false, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      ),
      StructField("test_double",DataTypes.DoubleType,false, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      ),
      StructField("test_date",DataTypes.DateType,false, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      ),
      StructField("test_timestamp",DataTypes.TimestampType,false, new MetadataBuilder()
        .putString("default", "Test")
        .build()
      )
    )
  )

  lazy val testingDataInitStringSchema: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE),
    StructField("String ", DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val testingDataStringSchema: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val testingJsonSchemaDataSchema: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Decimal", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE),
    StructField("gf_cutoff_date", DataTypes.DateType, TRUE_VALUE),
    StructField("g_entific_id", DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val testingJsonSchemaWithAuditDataSchema: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Decimal", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE),
    StructField("gf_audit_date", DataTypes.TimestampType, TRUE_VALUE)
  ))

  lazy val testingBoardLikeDataSchema: StructType = StructType(List(
    StructField("gf_cutoff_date",      DataTypes.StringType, FALSE_VALUE),
    StructField("g_guarantee_id",      DataTypes.StringType, FALSE_VALUE),
    StructField("g_guarantee_type",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_guarantee_amount", DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",       DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val testingDataSchema_added_partition: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE),
    StructField("gf_cutoff_date", DataTypes.DateType, TRUE_VALUE)
  ))
  lazy val testingDataSchema_added_partitions: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE),
    StructField("g_entific_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date", DataTypes.DateType, TRUE_VALUE)
  ))
  lazy val testingDataSchema_added_partitions_test: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE),
    StructField("g_entific_id", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date", DataTypes.DateType, TRUE_VALUE),
    StructField("gf_test", DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val testingDataDatioSchema: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema))
  lazy val testingDataDatioSchema_withOutDate: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema_withOutDate))
  lazy val testingDataInitStringDatioSchema: DatioSchema = spy(new DatioSchemaForTesting(testingDataInitStringSchema))
  lazy val testingDataDatioSchema_withOutDateNorString: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema_withOutDateNorString))
  lazy val testingDataSchema_added_partitionDatioSchema: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema_added_partition))
  lazy val testingDataSchema_added_partitionsDatioSchema: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema_added_partitions))
  lazy val testingDataSchema_added_partitionsTestDatioSchema: DatioSchema = spy(new DatioSchemaForTesting(testingDataSchema_added_partitions_test))
  lazy val testingDataSchema_output_autoinit: DatioSchema = spy(new DatioSchemaForTesting(schemaToInitializeTest))
  lazy val testingDataDatioSchema_withAudit: DatioSchema = spy(new DatioSchemaForTesting(testingJsonSchemaWithAuditDataSchema))
}
