package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{ParamMalformedException, ParamNotInformedException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{CleanConfiguration, TestCommons, TestUtils, TestingRuntimeContext}
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.hadoop.fs.{FileSystem, Path}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class CleanBoardsTest extends TestCommons {


  test("cleanBoard_setterConfiguration") {
    val result = (new CleanBoards).setterGlobalConfigurationReadedParamsReader(testResources.cleaner_config_FifthDay)
    val expected = CleanConfiguration("2020-02-05", "src/test/resources/data/cleaner/t_ktae_contract_struc_board", 60,
      "gf_cutoff_date", "yyyy-MM-dd",1)
    (result == expected) shouldBe true
  }

  test("cleanBoard_setterConfigurationSinglePartition") {
    val result = (new CleanBoards).setterGlobalConfigurationReadedParamsReader(testResources.cleaner_config_SinglePartition)
    val expected = CleanConfiguration("2020-03-01", "src/test/resources/data/cleaner/t_ktae_contract_struc_board", 60,
      "gf_cutoff_date", "yyyy-MM-dd",1)
    (result == expected) shouldBe true
  }

  test("cleanBoard_setterConfigurationsMissParam") {
    assertThrows[ParamNotInformedException] {
      (new CleanBoards).setterGlobalConfigurationReadedParamsReader(testResources.cleaner_config_MissParam)
    }
  }

  test("cleanBoard_setterConfigurationsBadDate") {
    assertThrows[ParamMalformedException] {
      (new CleanBoards).setterGlobalConfigurationReadedParamsReader(testResources.cleaner_config_BadDate)
    }
  }

  test("cleanBoard_setterConfigurationsBadDateType") {
    assertThrows[ParamMalformedException] {
      (new CleanBoards).setterGlobalConfigurationReadedParamsReader(testResources.cleaner_config_BadDateType)
    }
  }

  test("cleanBoard_setterConfigurationsBadPersistenceLimitType") {
    assertThrows[ParamMalformedException] {
      (new CleanBoards).setterGlobalConfigurationReadedParamsReader(testResources.cleaner_config_BadPersistenceLimitType)
    }
  }

  test("cleanBoard_runProcessFirstDay") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2016-01-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-06-30"
    val pathActualGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-03-31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-01-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2014-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2016-01-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015-06-30"
    val pathActualES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015-03-31"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015-01-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2014-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_FirstDay)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs,pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && !FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,principalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessFifthDay") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2016-01-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-06-30"
    val pathActualGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-02-28"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-01-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2014-05-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2016-01-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2015-06-30"
    val pathActualES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015-02-28"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2015-01-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=2014-05-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathActualGL).fileSystem()
    val path3: Path = dfs.qualify(pathActualGL).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualGL,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathActualES).fileSystem()
    val path8: Path = dfs.qualify(pathActualES).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathActualES,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val principalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_FifthDay)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathActualGL) && !FileSystemUtils.pathExists(dfs, pathActualES) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,principalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessPathSameYear") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-07-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-04-30"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-03-31"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-02-28"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-07-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-04-30"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-03-31"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-01-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-02-28"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)


    val historicalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_HistSameYear)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && !FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,historicalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessPathChangeYear") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-07-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-01-31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-11-30"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-12-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-07-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-01-31"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-11-30"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-12-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_HistChangeYear)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && !FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,historicalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessSinglePartition") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2016-01-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2015-06-30"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2015-03-31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2015-01-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2014-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2016-01-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2015-06-30"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2015-03-31"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2015-01-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2014-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_SinglePartition)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && !FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,historicalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessOtherFormat1") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20160131"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20150630"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20150228"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20150131"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=20140331"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20160131"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20150630"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20150228"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20150131"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=20140331"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_OtherFormat1)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && !FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,historicalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessOtherFormat2") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=31012016"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=30062015"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=28022015"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=31012015"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=31032014"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31012016"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=30062015"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31032015"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31012015"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES/gf_cutoff_date=31032014"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val historicalPath: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_OtherFormat2)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 0

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL1) && FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      !FileSystemUtils.pathExists(dfs, pathOtherYearGL) && !FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      !FileSystemUtils.pathExists(dfs, pathPrevGL) && !FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,historicalPath)
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessBadPath") {
    val pathNoDeleteGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-07-31"
    val pathNoDeleteGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2020-01-31"
    val pathPrevGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-11-30"
    val pathPrevGL1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-12-31"
    val pathOtherYearGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=GL/gf_cutoff_date=2019-03-31"
    val pathNoDeleteES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-07-31"
    val pathNoDeleteES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2020-01-31"
    val pathPrevES1: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-11-30"
    val pathPrevES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-12-31"
    val pathOtherYearES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup/g_entific_id=ES/gf_cutoff_date=2019-03-31"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathNoDeleteGL).fileSystem()
    val path1: Path = dfs.qualify(pathNoDeleteGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathNoDeleteGL1).fileSystem()
    val path2: Path = dfs.qualify(pathNoDeleteGL1).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteGL1,
      testResources.testingDataDatioSchema)
    val fs3: FileSystem = dfs.qualify(pathPrevGL1).fileSystem()
    val path3: Path = dfs.qualify(pathPrevGL1).path()
    fs3.mkdirs(path3)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL1,
      testResources.testingDataDatioSchema)
    val fs4: FileSystem = dfs.qualify(pathPrevGL).fileSystem()
    val path4: Path = dfs.qualify(pathPrevGL).path()
    fs4.mkdirs(path4)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevGL,
      testResources.testingDataDatioSchema)
    val fs5: FileSystem = dfs.qualify(pathOtherYearGL).fileSystem()
    val path5: Path = dfs.qualify(pathOtherYearGL).path()
    fs5.mkdirs(path5)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearGL,
      testResources.testingDataDatioSchema)
    val fs6: FileSystem = dfs.qualify(pathNoDeleteES).fileSystem()
    val path6: Path = dfs.qualify(pathNoDeleteES).path()
    fs6.mkdirs(path6)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES,
      testResources.testingDataDatioSchema)
    val fs7: FileSystem = dfs.qualify(pathNoDeleteES1).fileSystem()
    val path7: Path = dfs.qualify(pathNoDeleteES1).path()
    fs7.mkdirs(path7)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathNoDeleteES1,
      testResources.testingDataDatioSchema)
    val fs8: FileSystem = dfs.qualify(pathPrevES1).fileSystem()
    val path8: Path = dfs.qualify(pathPrevES1).path()
    fs8.mkdirs(path8)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES1,
      testResources.testingDataDatioSchema)
    val fs9: FileSystem = dfs.qualify(pathPrevES).fileSystem()
    val path9: Path = dfs.qualify(pathPrevES).path()
    fs9.mkdirs(path9)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathPrevES,
      testResources.testingDataDatioSchema)
    val fs10: FileSystem = dfs.qualify(pathOtherYearES).fileSystem()
    val path10: Path = dfs.qualify(pathOtherYearES).path()
    fs10.mkdirs(path10)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathOtherYearES,
      testResources.testingDataDatioSchema)

    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_BadPath)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 1

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathNoDeleteGL) && FileSystemUtils.pathExists(dfs, pathNoDeleteES) &&
      FileSystemUtils.pathExists(dfs, pathNoDeleteGL1) && FileSystemUtils.pathExists(dfs, pathNoDeleteES1) &&
      FileSystemUtils.pathExists(dfs, pathPrevGL1) && FileSystemUtils.pathExists(dfs, pathPrevES1) &&
      FileSystemUtils.pathExists(dfs, pathOtherYearGL) && FileSystemUtils.pathExists(dfs, pathOtherYearES) &&
      FileSystemUtils.pathExists(dfs, pathPrevGL) && FileSystemUtils.pathExists(dfs, pathPrevES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,"src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup")
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessPathNoSubdir") {
    val pathnoSubdirGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=GL"
    val pathnoSubdirES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/g_entific_id=ES"
    val dfs = DatioFileSystem.get()

    val fs1: FileSystem = dfs.qualify(pathnoSubdirGL).fileSystem()
    val path1: Path = dfs.qualify(pathnoSubdirGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathnoSubdirES).fileSystem()
    val path2: Path = dfs.qualify(pathnoSubdirES).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirES,
      testResources.testingDataDatioSchema)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_FirstDay)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 1

    var clean = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathnoSubdirGL) && FileSystemUtils.pathExists(dfs, pathnoSubdirES)) {
      clean = VAL_TRUE
    }
    FileSystemUtils.delete(dfs,"src/test/resources/data/cleaner/t_ktae_contract_struc_board")
    (clean == VAL_TRUE && result == expected) shouldBe true
  }

  test("cleanBoard_runProcessUnparseable") {
    val pathnoSubdirGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2020_03_31"
    val pathnoSubdirES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2020_05_31"
    val dfs = DatioFileSystem.get()

    val parquetToCopy: String = "src/test/resources/data/cleaner/dataFile.parquet"
    val fs1: FileSystem = dfs.qualify(pathnoSubdirGL).fileSystem()
    val path1: Path = dfs.qualify(pathnoSubdirGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathnoSubdirES).fileSystem()
    val path2: Path = dfs.qualify(pathnoSubdirES).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirES,
      testResources.testingDataDatioSchema)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_SinglePartition)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 1
    FileSystemUtils.delete(dfs,"src/test/resources/data/cleaner/t_ktae_contract_struc_board")
    (result == expected) shouldBe true
  }

  test("cleanBoard_runProcessBadPersistenceLimitType") {
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_BadPersistenceLimitType)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 1
    (result == expected) shouldBe true
  }

  test("cleanBoard_runProcessBadDateType") {
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_BadDateType)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 1
    (result == expected) shouldBe true
  }

  test("cleanBoard_runProcessBadColumnNameSingle") {
    val pathnoSubdirGL: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2020_03_31"
    val pathnoSubdirES: String = "src/test/resources/data/cleaner/t_ktae_contract_struc_board/gf_cutoff_date=2020_05_31"
    val dfs = DatioFileSystem.get()

    val parquetToCopy: String = "src/test/resources/data/cleaner/dataFile.parquet"
    val fs1: FileSystem = dfs.qualify(pathnoSubdirGL).fileSystem()
    val path1: Path = dfs.qualify(pathnoSubdirGL).path()
    fs1.mkdirs(path1)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirGL,
      testResources.testingDataDatioSchema)
    val fs2: FileSystem = dfs.qualify(pathnoSubdirES).fileSystem()
    val path2: Path = dfs.qualify(pathnoSubdirES).path()
    fs2.mkdirs(path2)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame, pathnoSubdirES,
      testResources.testingDataDatioSchema)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.cleaner_root_config_BadColumnNameSingle)
    val result: Int = (new CleanBoards).runProcess(testingRuntimeContext)
    val expected = 1
    FileSystemUtils.delete(dfs,"src/test/resources/data/cleaner/t_ktae_contract_struc_board")
    (result == expected) shouldBe true
  }

}
