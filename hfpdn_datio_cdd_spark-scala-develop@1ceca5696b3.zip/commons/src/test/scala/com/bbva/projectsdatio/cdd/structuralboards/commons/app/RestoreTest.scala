package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{ListSameLengthException, ParamMalformedException, ParamNotInformedException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.TestingRuntimeContext
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{RestoreConfiguration, TestCommons}
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.hadoop.fs.{FileSystem, Path}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class RestoreTest extends TestCommons {

  test("restore_setterConfiguration") {
    val result = (new Restore).setterGlobalConfigurationReadedParamsReader(testResources.restore_Test_config)
    val expected = RestoreConfiguration(testResources.dataRestorerPrincipal,
      "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json",
      "src/test/resources/data/restorer/inputRestorerParquet", Seq("g_entific_id","gf_cutoff_date","gf_audit_date"),
      Seq("GL","2020-02-29","2020-06-08 15:50:58.067"), Seq("g_entific_id","gf_cutoff_date"),
      Seq("GL","2020-02-29"), 1, 8, 1)
    result == expected shouldBe true
  }

  test("restore_setterConfigurationNoEntific") {
    val result = (new Restore).setterGlobalConfigurationReadedParamsReader(testResources.restore_NoEntificTest_config)
    val expected = RestoreConfiguration(testResources.dataRestorerPrincipal,
      "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json",
      "src/test/resources/data/restorer/inputRestorerParquet", Seq("gf_cutoff_date","gf_audit_date"),
      Seq("2020-03-31","2020-06-08 15:50:58.067"), Seq("gf_cutoff_date"),
      Seq("2020-03-31"), 1, 8, 1)
    result == expected shouldBe true
  }

  test("restore_setterConfigurationMissParam") {
    assertThrows[ParamNotInformedException] {
      (new Restore).setterGlobalConfigurationReadedParamsReader(testResources.restore_MissParamsTest_config)
    }
  }

  test("restore_setterConfigurationMalformed") {
    assertThrows[ParamMalformedException] {
      (new Restore).setterGlobalConfigurationReadedParamsReader(testResources.restore_MalformedTest_config)
    }
  }

  test("restore_setterConfigurationDifferentListLength") {
    assertThrows[ListSameLengthException] {
      (new Restore).setterGlobalConfigurationReadedParamsReader(testResources.restore_DiffListLengthTest_config)
    }
  }

  test("restore_runProcess") {
    val dfs = DatioFileSystem.get()
    val pathPrincipalFull = "src/test/resources/data/restorer/principal/g_entific_id=GL/gf_cutoff_date=2020-02-29"
    val fs1: FileSystem = dfs.qualify(testResources.dataRestorerPrincipal).fileSystem()
    val path1: Path = dfs.qualify(testResources.dataRestorerPrincipal).path()
    fs1.mkdirs(path1)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 0
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathPrincipalFull)) written = VAL_TRUE
    FileSystemUtils.delete(dfs, testResources.dataRestorerPrincipal)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("restore_runProcessNoEntific") {
    val dfs = DatioFileSystem.get()
    val pathPrincipalFull = "src/test/resources/data/restorer/principal/gf_cutoff_date=2020-03-31"
    val fs1: FileSystem = dfs.qualify(testResources.dataRestorerPrincipal).fileSystem()
    val path1: Path = dfs.qualify(testResources.dataRestorerPrincipal).path()
    fs1.mkdirs(path1)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreNoEntificTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 0
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, pathPrincipalFull)) written = VAL_TRUE
    FileSystemUtils.delete(dfs, testResources.dataRestorerPrincipal)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("restore_runProcessEmptyDFContinue") {
    val dfs = DatioFileSystem.get()
    val pathPrincipalFull = "src/test/resources/data/restorer/principal/g_entific_id=AA"
    val fs1: FileSystem = dfs.qualify(testResources.dataRestorerPrincipal).fileSystem()
    val path1: Path = dfs.qualify(testResources.dataRestorerPrincipal).path()
    fs1.mkdirs(path1)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreEmptyDfContinueTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 0
    var written = VAL_FALSE
    if (!FileSystemUtils.pathExists(dfs, pathPrincipalFull)) written = VAL_TRUE
    FileSystemUtils.delete(dfs, testResources.dataRestorerPrincipal)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("restore_runProcessEmptyDFStop") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.dataRestorerPrincipal).fileSystem()
    val path1: Path = dfs.qualify(testResources.dataRestorerPrincipal).path()
    fs1.mkdirs(path1)
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreEmptyStopTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 1
    FileSystemUtils.delete(dfs, testResources.dataRestorerPrincipal)
    result == expected shouldBe true
  }

  test("restore_runProcessBadPathPrinc") {
    val pathPrincipal = "src/test/resources/data/restorer/princ"
    val pathPrincipalFull = "src/test/resources/data/restorer/princ/g_entific_id=GL/gf_cutoff_date=2020-02-29"
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreBadPathPrincTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 0
    var written = VAL_FALSE
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, pathPrincipalFull)) written = VAL_TRUE
    FileSystemUtils.delete(dfs, pathPrincipal)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("restore_runProcessBadPathHist") {
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreBadPathHistTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }

  test("restore_runProcessMalformed") {
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(testResources.restore_restoreMalformedTest_config)
    val result: Int = (new Restore).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }

}
