package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import java.io.FileNotFoundException
import java.time.format.DateTimeParseException
import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{DateFormatException, NotExistMonthPartitionInParameterPath}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.TestCommons
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.hadoop.fs.{FileSystem, Path}

import scala.collection.mutable.ArrayBuffer
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class FileSystemUtilsTest extends TestCommons {


  test("FileSystemUtils - returnPathsSubLevelFunc: Only one child path") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path2: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils.returnPathsSubLevelFunc(fs2, path2)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.head)(result.head.getName)
  }

  test("FileSystemUtils - returnPathsSubLevelFunc: Several child paths") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).fileSystem()
    val path3: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).fileSystem()
    val path4: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path()
    fs4.mkdirs(path4)
    val fs5: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2014_03_31).fileSystem()
    val path5: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2014_03_31).path()
    fs5.mkdirs(path5)
    val fs6: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path6: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()

    val result = FileSystemUtils.returnPathsSubLevelFunc(fs6, path6)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31,
      testResources.gf_cutoff_date_2015_06_30,
      testResources.gf_cutoff_date_2015_03_31,
      testResources.gf_cutoff_date_2015_01_31,
      testResources.gf_cutoff_date_2014_03_31
    )
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - returnPathsSubLevelFunc: Has not any child path") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path1: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    fs1.mkdirs(path1)
    val result = FileSystemUtils.returnPathsSubLevelFunc(fs1, path1)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(ArrayBuffer.empty[Path])(result)
  }

  test("FileSystemUtils - returnPathsSubLevelFunc: Not valid path in parentPath param") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.gf_cutoff_date_2016_01_31).fileSystem()
    val path2: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.gf_cutoff_date_2016_01_31).path()
    assertThrows[FileNotFoundException](FileSystemUtils
      .returnPathsSubLevelFunc(fs2, path2))
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: today > partition") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(4)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2016-05-31"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: today < partition") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(-3)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2015-10-31"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: today = partition") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(0)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2016-01-31"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: complete months difference") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(0)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2016-01-31"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: not leap-year 29-feb") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertThrows[DateTimeParseException](FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2015-02-29"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: leap-year 29-feb") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(1)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2016-02-29"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: not complete months positive") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(4)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2016-05-15"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: not complete months negative") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertResult(-3)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_yyyy_MM_dd)("2015-10-15"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: Date not in last path position") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).path()
    assertThrows[DateFormatException](FileSystemUtils.calculatePartitionMonthDifference(path,  testResources.dateFormat_yyyy_MM_dd)("2016-05-31"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: Different today date format") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    assertThrows[DateFormatException](FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_ddMMyyyy)( "31052016"))
  }

  test("FileSystemUtils - calculatePartitionMonthDifference: Different Partition Date formats") {
    val dfs = DatioFileSystem.get()
    val path: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_31012016).path()
    assertResult(4)(FileSystemUtils.calculatePartitionMonthDifference(path, testResources.dateFormat_ddMMyyyy)( "2016-05-31"))
  }

  test("FileSystemUtils - selectOlderPartitions: Every path in partitionsDateLevel should be returned") {
    val dfs = DatioFileSystem.get()
    val arrayPaths : Array[Path] = Array(dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path())
    assertResult(arrayPaths)(FileSystemUtils.selectOlderPartitions(arrayPaths, testResources.dateFormat_yyyy_MM_dd)("2018-05-31", 5))
  }

  test("FileSystemUtils - selectOlderPartitions: At least one path in partitionsDateLevel should be returned") {
    val dfs = DatioFileSystem.get()
    val arrayPaths: Array[Path] = Array(dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path())
    val expectedArrayPaths : Array[Path] = Array(dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path())
    assertResult(expectedArrayPaths)(FileSystemUtils.selectOlderPartitions(arrayPaths, testResources.dateFormat_yyyy_MM_dd)("2016-03-31", 3))
  }

  test("FileSystemUtils - selectOlderPartitions: No path in partitionsDateLevel should be returned") {
    val dfs = DatioFileSystem.get()
    val arrayPaths: Array[Path] = Array(dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).path(),
      dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path())
    assertResult(Array.empty[Path])(FileSystemUtils.selectOlderPartitions(arrayPaths, testResources.dateFormat_yyyy_MM_dd)("2016-03-31", 15))
  }

  test("FileSystemUtils - selectOlderPartitions: Empty Array[Path] as input parameter") {
    assertResult(Array.empty[Path])(FileSystemUtils.selectOlderPartitions(Array.empty[Path], testResources.dateFormat_yyyy_MM_dd)("2016-03-31", 13))
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has only one immediate child path") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path2: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs2, path2, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has only one not immediate child path (last partition)") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path2: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs2, path2, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has only one not immediate child path (not last partition)") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path2: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs2, path2, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has several immediate child paths") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).fileSystem()
    val path3: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_03_31).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).fileSystem()
    val path4: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path()
    fs4.mkdirs(path4)
    val fs5: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2014_03_31).fileSystem()
    val path5: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2014_03_31).path()
    fs5.mkdirs(path5)
    val fs6: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path6: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs6, path6, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31,
      testResources.gf_cutoff_date_2015_06_30,
      testResources.gf_cutoff_date_2015_03_31,
      testResources.gf_cutoff_date_2015_01_31,
      testResources.gf_cutoff_date_2014_03_31
    )
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has several not immediate child paths (last partition)") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_06_30).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_06_30).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_03_31).fileSystem()
    val path3: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_03_31).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_01_31).fileSystem()
    val path4: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_01_31).path()
    fs4.mkdirs(path4)
    val fs5: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2014_03_31).fileSystem()
    val path5: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2014_03_31).path()
    fs5.mkdirs(path5)
    val fs6: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path6: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()

    val result = FileSystemUtils
      .recursivePathFinder(fs6, path6, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31,
      testResources.gf_cutoff_date_2015_06_30,
      testResources.gf_cutoff_date_2015_03_31,
      testResources.gf_cutoff_date_2015_01_31,
      testResources.gf_cutoff_date_2014_03_31
    )
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has several not immediate child paths (not last partition)") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_KO).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_KO).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_06_30_test_OK).fileSystem()
    val path3: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_06_30_test_OK).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_06_30_test_KO).fileSystem()
    val path4: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_06_30_test_KO).path()
    fs4.mkdirs(path4)

    val fs5: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path5: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs5, path5, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31,
      testResources.gf_cutoff_date_2015_06_30
    )
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.sorted)(result.map(_.getName).sorted)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has not child paths but it has as partition name partitionDateFieldName") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val result = FileSystemUtils
      .recursivePathFinder(fs1, path1, testResources.gf_cutoff_date)
    val expected = ArrayBuffer(testResources.gf_cutoff_date_2016_01_31)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(expected.head)(result.head.getName)
  }

  test("FileSystemUtils - recursivePathFinder: Parent Path has not child paths and has not as partition name partitionDateFieldName") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path1: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    fs1.mkdirs(path1)
    val result = FileSystemUtils
      .recursivePathFinder(fs1, path1, testResources.gf_cutoff_date)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(ArrayBuffer.empty[Path])(result)
  }

  test("FileSystemUtils - recursivePathFinder: None of the child paths has as partition name partitionDateFieldName") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_OK).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_OK).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_KO).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_KO).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path3: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs3, path3, testResources.gf_cutoff_date)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(ArrayBuffer.empty[Path])(result)
  }

  test("FileSystemUtils - recursivePathFinder: partitionDateFieldName is just a substring of real partition name") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_Bad_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_Bad_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_Bad_2016_01_31).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_Bad_2016_01_31).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).fileSystem()
    val path3: Path = dfs.qualify(testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity).path()
    val result = FileSystemUtils
      .recursivePathFinder(fs3, path3, testResources.gf_cutoff_date)
    FileSystemUtils.delete(dfs, testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity)
    assertResult(ArrayBuffer.empty[Path])(result)
  }

  test("FileSystemUtils - returnNewerPartitionDateInMonth: gets newer in selected month") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_28).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_28).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result = FileSystemUtils
      .returnNewerPartitionDateInMonth(parentPath, datioSparkSession, testResources.gf_cutoff_date, "01", "2016", "-")
    FileSystemUtils.delete(dfs, parentPath)
    assertResult("2016-01-31")(result)
  }

  test("FileSystemUtils - returnNewerPartitionDateInMonth: same month different year") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_28).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_28).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result = FileSystemUtils
      .returnNewerPartitionDateInMonth (parentPath, datioSparkSession, testResources.gf_cutoff_date, "01", "2016","-")
    FileSystemUtils.delete(dfs, parentPath)
    assertResult("2016-01-28")(result)
  }

  test("FileSystemUtils - returnNewerPartitionDateInMonth: gets newer in selected month not last partition level") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_28_test_OK).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_28_test_OK).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity + testResources.g_entific_id_ES
    val result = FileSystemUtils
      .returnNewerPartitionDateInMonth (parentPath, datioSparkSession, testResources.gf_cutoff_date, "01", "2016","-")
    FileSystemUtils.delete(dfs, parentPath)
    assertResult("2016-01-31")(result)
  }

  test("FileSystemUtils - returnNewerPartitionDateInMonth: there is no partition in selected month") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_28).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_28).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    assertThrows[NotExistMonthPartitionInParameterPath](FileSystemUtils
      .returnNewerPartitionDateInMonth (parentPath, datioSparkSession, testResources.gf_cutoff_date, "06", "2016","-")
    )
    FileSystemUtils.delete(dfs, parentPath)
  }

  test("FileSystemUtils - returnFullPartitionPathListFromValues: Ok execution with just one partition level") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_FirstPartLevel_2015_06_30).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result: Array[String] = FileSystemUtils.returnFullPartitionPathListFromValues(parentPath, Map(("gf_cutoff_date", "2016-01-31")))(datioSparkSession)
    FileSystemUtils.delete(dfs, parentPath)
    assert(result.count(_.contains(testResources.cleaner_path_FirstPartLevel_2016_01_31)) === 1)
    assert(result.length === 1)
  }
  test("FileSystemUtils - returnFullPartitionPathListFromValues: Ok execution with two partition level") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_28).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_28).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result: Array[String] = FileSystemUtils.returnFullPartitionPathListFromValues(parentPath, Map(("gf_cutoff_date", "2016-01-31")))(datioSparkSession)
    FileSystemUtils.delete(dfs, parentPath)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_ES_2016_01_31)) === 1)
    assert(result.length === 1)
  }
  test("FileSystemUtils - returnFullPartitionPathListFromValues: Ok execution with no partition represented") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_28).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_28).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result: Array[String] = FileSystemUtils.returnFullPartitionPathListFromValues(parentPath, Map(("gf_cutoff_date", "2016-01-30")))(datioSparkSession)
    FileSystemUtils.delete(dfs, parentPath)
    assertResult(Array.empty[String])(result)
  }
  test("FileSystemUtils - returnFullPartitionPathListFromValues: Ok execution with more than one partition after filtering") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_2016_01_31).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_2016_01_31).path()
    fs2.mkdirs(path2)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result: Array[String] = FileSystemUtils.returnFullPartitionPathListFromValues(parentPath, Map(("gf_cutoff_date", "2016-01-31")))(datioSparkSession)
    FileSystemUtils.delete(dfs, parentPath)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_ES_2016_01_31)) === 1)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_GL_2016_01_31)) === 1)
    assert(result.length === 2)
  }
  test("FileSystemUtils - returnFullPartitionPathListFromValues: Ok execution when filtering not first nor last partition") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_KO).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_KO).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_2016_01_31_test_OK).fileSystem()
    val path3: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_2016_01_31_test_OK).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_03_31_test_OK).fileSystem()
    val path4: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_03_31_test_OK).path()
    fs4.mkdirs(path4)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result: Array[String] = FileSystemUtils.returnFullPartitionPathListFromValues(parentPath, Map(("gf_cutoff_date", "2016-01-31")))(datioSparkSession)
    FileSystemUtils.delete(dfs, parentPath)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_ES_2016_01_31)) === 2)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_GL_2016_01_31)) === 1)
    assert(result.length === 3)
  }
  test("FileSystemUtils - returnFullPartitionPathListFromValues: Ok execution when filtering several partitions") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).fileSystem()
    val path1: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_KO).fileSystem()
    val path2: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_KO).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_2016_01_31_test_OK).fileSystem()
    val path3: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_GL_2016_01_31_test_OK).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_03_31_test_OK).fileSystem()
    val path4: Path = dfs.qualify(testResources.cleaner_path_SecPartLevel_ES_2015_03_31_test_OK).path()
    fs4.mkdirs(path4)
    val parentPath = testResources.dataCleanerResourcesPath + testResources.dataCleanerEntity
    val result: Array[String] = FileSystemUtils.returnFullPartitionPathListFromValues(parentPath,
      Map(("gf_cutoff_date", "2016-01-31"),("gf_test","OK")))(datioSparkSession)
    FileSystemUtils.delete(dfs, parentPath)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_ES_2016_01_31_test_OK)) === 1)
    assert(result.count(_.contains(testResources.cleaner_path_SecPartLevel_GL_2016_01_31_test_OK)) === 1)
    assert(result.length === 2)
  }

}
