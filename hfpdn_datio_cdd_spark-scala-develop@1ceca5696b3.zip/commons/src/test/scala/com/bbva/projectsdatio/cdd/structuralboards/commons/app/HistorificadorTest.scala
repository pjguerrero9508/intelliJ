package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{ListSameLengthException, ParamMalformedException, ParamNotInformedException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.TestingRuntimeContext
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{HistorificadorConfiguration, TestCommons, TestUtils}
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.typesafe.config.Config
import org.apache.hadoop.fs.{FileSystem, Path}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class HistorificadorTest extends TestCommons {

  test("historificador_setterConfiguration") {
    val configSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorTest.conf", "CDDHistorificador")
    val result = (new Historificador).setterGlobalConfigurationReadedParamsReader(configSetter)
    val expected = HistorificadorConfiguration("src/test/resources/data/historificador/inputParquet",
      "src/test/resources/data/historificador/outputParquet", Seq("g_entific_id", "gf_cutoff_date"),
      Seq("GL", "2020-02-29"), Seq("Y", "Y"), "gf_audit_date",
      "src/test/resources/data/historificador/schemas/t_ktae_contract_struc_board.json", 1, 8, 1)
    result == expected shouldBe true
  }

  test("historificador_setterConfigurationDefault") {
    val configDefaultSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorDefaultTest.conf", "CDDHistorificador")
    val result = (new Historificador).setterGlobalConfigurationReadedParamsReader(configDefaultSetter)
    val expected = HistorificadorConfiguration("src/test/resources/data/historificador/inputParquet",
      "src/test/resources/data/historificador/outputParquet", Seq("g_entific_id", "gf_cutoff_date"),
      Seq("", "2020-03-31"), Seq("N", "Y"), "gf_audit_date",
      "src/test/resources/data/historificador/schemas/t_ktae_contract_struc_board.json", 1, 8, 1)
    result == expected shouldBe true
  }

  test("historificador_setterConfigurationSinglePartition") {
    val configDefaultSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorSinglePartitionTest.conf", "CDDHistorificador")
    val result = (new Historificador).setterGlobalConfigurationReadedParamsReader(configDefaultSetter)
    val expected = HistorificadorConfiguration("src/test/resources/data/historificador/inputParquet",
      "src/test/resources/data/historificador/outputParquet", Seq("gf_cutoff_date"),
      Seq("2020-02-29"), Seq("Y"), "gf_audit_date",
      "src/test/resources/data/historificador/schemas/t_ktae_contract_struc_board.json", 1, 8, 1)
    result == expected shouldBe true
  }

  test("historificador_setterConfigurationMissParam") {
    val configMissParamSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorMissParamTest.conf", "CDDHistorificador")
    assertThrows[ParamNotInformedException] {
      (new Historificador).setterGlobalConfigurationReadedParamsReader(configMissParamSetter)
    }
  }

  test("historificador_setterConfigurationMalformed") {
    val configMalformedSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorMalformedTest.conf", "CDDHistorificador")
    assertThrows[ParamMalformedException] {
      (new Historificador).setterGlobalConfigurationReadedParamsReader(configMalformedSetter)
    }
  }

  test("historificador_setterConfigurationDifferentListLength") {
    val configDifferentListLengthSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorDifferentListLengthTest.conf", "CDDHistorificador")
    assertThrows[ListSameLengthException] {
      (new Historificador).setterGlobalConfigurationReadedParamsReader(configDifferentListLengthSetter)
    }
  }

  test("historificador_setterConfigurationBadListLength") {
    val configBadListLengthSetter: Config = TestUtils.getConfigTest("data/historificador/historificadorBadListLengthTest.conf", "CDDHistorificador")
    assertThrows[ListSameLengthException] {
      (new Historificador).setterGlobalConfigurationReadedParamsReader(configBadListLengthSetter)
    }
  }

  /*
  test("historificador_runProcess") {
    val config: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(config)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 0

    val pathBackupFull = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20%2009%3A53%3A34.434"
    val pathBackupFullhdfs = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20 09%3A53%3A34.434"
    /*val pathBackupFull = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20"
    val pathBackupFullhdfs = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20"*/
    val pathBackup = "src/test/resources/data/historificador/outputParquet"

    var written = VAL_FALSE
    val hdfs: FileSystem = DatioFileSystem.get().qualify(pathBackup).fileSystem()
    val pathBckFull: Path = DatioFileSystem.get().qualify(pathBackupFull).path()
    val pathBckFullHdfs: Path = DatioFileSystem.get().qualify(pathBackupFull).path()
    //if (FileSystemUtils.pathExist(datioSparkSession, pathBackupFull) || FileSystemUtils.pathExist(datioSparkSession, pathBackupFullhdfs)) {
    if (hdfs.exists(new Path(pathBackupFull)) || hdfs.exists(new Path(pathBackupFullhdfs))) {
      written = VAL_TRUE
    }
    val pathBck: Path = DatioFileSystem.get().qualify(pathBackup).path()
    hdfs.delete(pathBck, true)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("historificador_runProcessSinglePartition") {
    val config: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorSinglePartitionTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(config)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 0

    /*val pathBackupFull = "src/test/resources/data/historificador/outputParquet/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20%2009%3A53%3A34.434"
    val pathBackupFullhdfs = "src/test/resources/data/historificador/outputParquet/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20 09%3A53%3A34.434"*/
    val pathBackupFull = "src/test/resources/data/historificador/outputParquet/gf_cutoff_date=2020-02-29"
    val pathBackupFullhdfs = "src/test/resources/data/historificador/outputParquet/gf_cutoff_date=2020-02-29/gf_audit_date=2020-07-20"
    val pathBackup = "src/test/resources/data/historificador/outputParquet"

    var written = VAL_FALSE
    if (FileSystemUtils.pathExist(datioSparkSession, pathBackupFull) || FileSystemUtils.pathExist(datioSparkSession, pathBackupFullhdfs)) {
      written = VAL_TRUE
    }
    val pathBck: Path = DatioFileSystem.get().qualify(pathBackup).path()
    val hdfs: FileSystem = DatioFileSystem.get().qualify(pathBackup).fileSystem()
    hdfs.delete(pathBck, true)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("historificador_runProcessDefault") {
    val configDefault: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorDefaultTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configDefault)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 0

    val pathBackupFull1 = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20%2009%3A53%3A34.434"
    val pathBackupFull2 = "src/test/resources/data/historificador/outputParquet/g_entific_id=AR/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20%2009%3A53%3A34.434"
    val pathBackupFull3 = "src/test/resources/data/historificador/outputParquet/g_entific_id=ES/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20%2009%3A53%3A34.434"
    val pathBackupFullhdfs1 = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20 09%3A53%3A34.434"
    val pathBackupFullhdfs2 = "src/test/resources/data/historificador/outputParquet/g_entific_id=AR/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20 09%3A53%3A34.434"
    val pathBackupFullhdfs3 = "src/test/resources/data/historificador/outputParquet/g_entific_id=ES/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20 09%3A53%3A34.434"

    /*val pathBackupFull1 = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20"
    val pathBackupFull2 = "src/test/resources/data/historificador/outputParquet/g_entific_id=AR/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20"
    val pathBackupFull3 = "src/test/resources/data/historificador/outputParquet/g_entific_id=ES/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20"
    val pathBackupFullhdfs1 = "src/test/resources/data/historificador/outputParquet/g_entific_id=GL/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20"
    val pathBackupFullhdfs2 = "src/test/resources/data/historificador/outputParquet/g_entific_id=AR/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20"
    val pathBackupFullhdfs3 = "src/test/resources/data/historificador/outputParquet/g_entific_id=ES/gf_cutoff_date=2020-03-31/gf_audit_date=2020-07-20"*/
    val pathBackup = "src/test/resources/data/historificador/outputParquet"

    var written = VAL_FALSE
    val hdfs: FileSystem = DatioFileSystem.get().qualify(pathBackup).fileSystem()
    /*if ((FileSystemUtils.pathExist(datioSparkSession, pathBackupFull1) && FileSystemUtils.pathExist(datioSparkSession, pathBackupFull2) &&
      FileSystemUtils.pathExist(datioSparkSession, pathBackupFull3)) ||
      (FileSystemUtils.pathExist(datioSparkSession, pathBackupFullhdfs1) && FileSystemUtils.pathExist(datioSparkSession, pathBackupFullhdfs2) &&
        FileSystemUtils.pathExist(datioSparkSession, pathBackupFullhdfs3))) {
      written = VAL_TRUE
    }*/
    if ((hdfs.exists(new Path(pathBackupFull1)) && hdfs.exists(new Path(pathBackupFull2)) &&
      hdfs.exists(new Path(pathBackupFull3))) ||
      (hdfs.exists(new Path(pathBackupFullhdfs1)) && hdfs.exists(new Path(pathBackupFullhdfs2)) &&
        hdfs.exists(new Path(pathBackupFullhdfs3)))) {
      written = VAL_TRUE
    }
    val pathBck: Path = DatioFileSystem.get().qualify(pathBackup).path()
    hdfs.delete(pathBck, true)
    (written == VAL_TRUE & result == expected) shouldBe true
  }*/


  test("historificador_runProcessEmptyDFContinue") {
    val configEmptyContinue: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorEmptyContinueTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configEmptyContinue)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 0
    val dfs = DatioFileSystem.get()

    val pathBackup = "src/test/resources/data/historificador/outputParquet"
    val pathBackupPartition = "src/test/resources/data/historificador/outputParquet/g_entific_id=AA"

    var written = VAL_FALSE
    if (!FileSystemUtils.pathExists(dfs, pathBackupPartition)) {
      written = VAL_TRUE
    }
    FileSystemUtils.delete(dfs, pathBackup)
    (written == VAL_TRUE & result == expected) shouldBe true
  }

  test("historificador_runProcessEmptyDF") {
    val configEmpty: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorEmptyTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configEmpty)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }

  test("historificador_runProcessBadPath") {
    val configBadPath: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorBadPathTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configBadPath)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }

  test("historificador_runProcessMissSchema") {
    val configMissSchema: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorMissSchemaTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configMissSchema)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }

  // gf_last_refinancing_date not in schema
  test("historificador_runProcessWrongSchema_miss_in_schema") {
    val configWrongSchema: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorWrongSchemaNotInSchemaTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configWrongSchema)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 0
    result == expected shouldBe true
  }
  //test_schema_field
  test("historificador_runProcessWrongSchema_miss_in_data") {
    val configWrongSchema: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorWrongSchemaNotInDataTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configWrongSchema)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }
  //gf_local_contract_number_id as date in schema
  test("historificador_runProcessWrongSchema_wrong_type_in_data") {
    val configWrongSchema: Config = TestUtils.getConfigRunProcessTest("data/historificador/historificadorWrongSchemaBadTypeInDataTest.conf")
    val testingRuntimeContext: RuntimeContext = (new TestingRuntimeContext).setConfig(configWrongSchema)
    val result: Int = (new Historificador).runProcess(testingRuntimeContext)
    val expected: Int = 1
    result == expected shouldBe true
  }

}
