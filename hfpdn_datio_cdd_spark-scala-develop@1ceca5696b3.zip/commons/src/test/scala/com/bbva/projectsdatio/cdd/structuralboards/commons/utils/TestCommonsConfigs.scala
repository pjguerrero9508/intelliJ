package com.bbva.projectsdatio.cdd.structuralboards.commons.utils

import com.typesafe.config.{Config, ConfigFactory}

trait TestCommonsConfigs {

  //CONSTANTS
  val board_confStruct: String = "CDDBoard"
  val dataset_confStruct: String = "CDDDataset"
  val cleaner_confStruct: String = "CDDCleanBoards"
  val backUp_confStruct: String = "CDDBoard"
  val restore_confStruct: String = "CDDRestore"

  lazy val cleaner_config_SinglePartition: Config = cleaner_root_config_SinglePartition.getConfig(cleaner_confStruct)
  lazy val cleaner_config_BadColumnNameSingle: Config = cleaner_root_config_BadColumnNameSingle.getConfig(cleaner_confStruct)
  lazy val cleaner_config_BadDateType: Config = cleaner_root_config_BadDateType.getConfig(cleaner_confStruct)
  lazy val cleaner_config_HistSameYear: Config = cleaner_root_config_HistSameYear.getConfig(cleaner_confStruct)
  lazy val cleaner_config_HistChangeYear: Config = cleaner_root_config_HistChangeYear.getConfig(cleaner_confStruct)
  lazy val cleaner_config_OtherFormat1: Config = cleaner_root_config_OtherFormat1.getConfig(cleaner_confStruct)
  lazy val cleaner_config_OtherFormat2: Config = cleaner_root_config_OtherFormat2.getConfig(cleaner_confStruct)
  lazy val cleaner_config_BadPath: Config = cleaner_root_config_BadPath.getConfig(cleaner_confStruct)
  lazy val cleaner_config_BadPersistenceLimitType: Config = cleaner_root_config_BadPersistenceLimitType.getConfig(cleaner_confStruct)
  lazy val cleaner_config_FirstDay: Config = cleaner_root_config_FirstDay.getConfig(cleaner_confStruct)
  lazy val cleaner_config_FifthDay: Config = cleaner_root_config_FifthDay.getConfig(cleaner_confStruct)
  lazy val cleaner_config_MissParam: Config = cleaner_root_config_MissParam.getConfig(cleaner_confStruct)
  lazy val cleaner_config_BadDate: Config = cleaner_root_config_BadDate.getConfig(cleaner_confStruct)

  lazy val backUp_config_test: Config = backUp_root_config.getConfig(backUp_confStruct)

  lazy val dataset_config_basic: Config = dataset_root_config.getConfig(dataset_confStruct)
  lazy val dataset_config_without_int: Config = dataset_withOutInt_config.getConfig(dataset_confStruct)
  lazy val dataset_config_just_int: Config = dataset_justInt_config.getConfig(dataset_confStruct)
  lazy val dataset_config_empty_relevant: Config = dataset_emptyRelevant_config.getConfig(dataset_confStruct)
  lazy val dataset_config_no_relevant: Config = dataset_noRelevant_config.getConfig(dataset_confStruct)
  lazy val dataset_config_bad_relevant_col_name: Config = dataset_badRelevantColName_config.getConfig(dataset_confStruct)
  lazy val dataset_config_WithRename: Config = dataset_withRename_config.getConfig(dataset_confStruct)
  lazy val dataset_config_BadRename: Config = dataset_badRename_config.getConfig(dataset_confStruct)

  lazy val board_root_config_basic: Config = board_root_config
  lazy val board_root_config_basic_principal_old: Config = board_root_config_principal_old
  lazy val board_config_basic: Config = board_root_config.getConfig(board_confStruct)
  lazy val board_root_config_badSchemaPath: Config = board_badSchemaPath_config
  lazy val board_complete_config_basic_base: Config = board_dataset_root_config
  lazy val board_complete_with_cutoff_entific_config_basic_base: Config = board_dataset_with_cutoff_entific_root_config
  lazy val board_complete_config_basic: Config = board_dataset_root_config.getConfig(board_confStruct)
  lazy val board_complete_cutoff_entific_config_basic: Config = board_dataset_root_cutoff_entific_config.getConfig(board_confStruct)
  lazy val board_complete_config_basic_principal_old_base: Config = board_dataset_root_principal_old_config
  lazy val board_complete_config_basic_principal_old: Config = board_dataset_root_principal_old_config.getConfig(board_confStruct)
  lazy val board_config_badSchemaPath: Config = board_badSchemaPath_config.getConfig(board_confStruct)
  lazy val board_config_withOutAudit: Config = board_withOutAudit_config.getConfig(board_confStruct)
  lazy val board_config_badDataPath: Config = board_dataset_badDataPath_config.getConfig(board_confStruct)
  lazy val board_config_missDataPath: Config = board_dataset_missDataPath_config.getConfig(board_confStruct)
  lazy val board_config_noPartitions: Config = board_dataset_noPartitions_config.getConfig(board_confStruct)
  lazy val board_config_onePartition: Config = board_dataset_onePartition_config.getConfig(board_confStruct)
  lazy val board_config_bothPartition: Config = board_dataset_bothPartition_config.getConfig(board_confStruct)
  lazy val board_config_empty: Config = ConfigFactory.empty()
  lazy val board_config_default: Config = board_root_config_default.getConfig(board_confStruct)
  lazy val board_config_notInformedAllButRoot: Config = board_root_config_notInformedAllButRoot.getConfig(board_confStruct)
  lazy val board_config_notInformedOne: Config = board_root_config_notInformedOne.getConfig(board_confStruct)
  lazy val board_config_missParam: Config = board_root_config_missParam.getConfig(board_confStruct)
  lazy val board_config_badCutoffDate: Config = board_root_config_badCutoffDate.getConfig(board_confStruct)
  lazy val board_config_badCutoffDateType: Config = board_root_config_badCutoffDateType.getConfig(board_confStruct)

  lazy val restore_Test_config: Config = restore_restoreTest_config.getConfig(restore_confStruct)
  lazy val restore_NoEntificTest_config: Config = restore_restoreNoEntificTest_config.getConfig(restore_confStruct)
  lazy val restore_MissParamsTest_config: Config = restore_restoreMissParamsTest_config.getConfig(restore_confStruct)
  lazy val restore_DiffListLengthTest_config: Config = restore_restoreDiffListLengthTest_config.getConfig(restore_confStruct)
  lazy val restore_EmptyDfContinueTest_config: Config = restore_restoreEmptyDfContinueTest_config.getConfig(restore_confStruct)
  lazy val restore_BadPathPrincTest_config: Config = restore_restoreBadPathPrincTest_config.getConfig(restore_confStruct)
  lazy val restore_BadPathHistTest_config: Config = restore_restoreBadPathHistTest_config.getConfig(restore_confStruct)
  lazy val restore_MalformedTest_config: Config = restore_restoreMalformedTest_config.getConfig(restore_confStruct)
  lazy val restore_EmptyStopTest_config: Config = restore_restoreEmptyStopTest_config.getConfig(restore_confStruct)

  lazy val cleaner_SinglePartition : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-03-01"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |  }"""

  lazy val cleaner_PrincFifthDay : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-02-05"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_HistSameYear : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-05-02"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup"
      |  persistenceLimit = 2
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_HistChangeYear : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-02-20"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board_backup"
      |  persistenceLimit = 2
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_OtherFormat1 : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-02-05"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyyMMdd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_OtherFormat2 : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-02-05"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "ddMMyyyy"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_BadPath : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-03-03"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc"
      |  persistenceLimit = 2
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_BadPersistenceLimitType : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-03-03"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc"
      |  persistenceLimit = "aaa"
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_BadDateType : String =
    """CDDCleanBoards {
      |  dateIngestion = "aaaaaaaaaa"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_BadColumnNameSingle : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-03-01"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_d"
      |  }
      |}""".stripMargin

  lazy val cleaner_FirstDay : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-03-01"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_MissParam : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-03-03"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cleaner_BadDate : String =
    """CDDCleanBoards {
      |  dateIngestion = "2020-02-40"
      |  path = "src/test/resources/data/cleaner/t_ktae_contract_struc_board"
      |  persistenceLimit = 60
      |  partitionFeature = {
      |    dateFormat = "yyyy-MM-dd"
      |    datePartitionName = "gf_cutoff_date"
      |  }
      |}""".stripMargin

  lazy val cddBoard_complete : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "Date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "String"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal"
      |  }"""
  lazy val cddBoard_with_cutoff_entific_complete : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "Date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "String"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_cutoff_entific_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal"
      |  }"""

  lazy val cddBoard_complete_principal_old : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal"
      |  }"""
  lazy val cddBoard_cutoff_entific_complete : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal"
      |  }"""

  lazy val cddBoard_badSchemaPath : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_bad_path.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal"
      |  }
      |  }"""

  lazy val cddBoard_withOutAudit : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal"
      |  }
      |  }"""

  lazy val cddBoard_usingDefaultValues : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = "X"
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |  }"""

  lazy val cddBoard_notInformedOne : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = "First"
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |  }"""

  lazy val cddBoard_notInformedAllButRoot : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = "First;Second"
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |  }"""

  // entificColumnValue
  lazy val cddBoard_missParam : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2021-04-30"
      |  entificColumnName = "g_entific_id"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |  }"""

  lazy val cddBoard_badCutoffDate : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-13-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |  }"""

  lazy val cddBoard_badCutoffDateType : String =
    """CDDBoard {
      |  dateIngestion = "2021-04-01"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "aaaaa"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "ES"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 1
      |  schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_with_audit.json"
      |  repartitionBase = 1
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/cddBoards/principal/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |    pathTablonOutputPrincipal = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30/"
      |  }"""

  lazy val backUp_config : String =
    """CDDBoard {
      |  dateIngestion = "2020-03-02"
      |  averageKBPerRecord = 8
      |  schemaPath = "src/main/resources/schemas/contracts/t_ktae_contract_struc_board.json"
      |  repartitionBase = 3
      |
      |  paths = {
      |    pathTablonOutputPrincipal = "src/test/resources/data/backup/t_ktae_contract_struc_board/g_entific_id=GL/gf_cutoff_date=2020-02-29"
      |    temporalPath = "src/test/resources/data/backup/datatmp"
      |  }
      |}"""

  lazy val cddDatasetAlone_complete : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String"]
       |    previousFilterAppliedFields = ["test"]
       |  }"""

  lazy val cddDataset_complete : String =
    """| testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String", "Date"]
       |    previousFilterAppliedFields = ["String"]
       |  }"""

  lazy val cddDataset_principal_old_complete : String =
    """| testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp",
       |      "gf_audit_date",
       |      "g_entific_id",
       |      "gf_cutoff_date"]
       |    joinFields = ["String", "Date"]
       |    previousRename = {
       |      oldFieldNames = "Double"
       |      newFieldNames = "Decimal"
       |    }
       |    previousFilterAppliedFields = ["g_entific_id", "gf_cutoff_date"]
       |  }"""
  lazy val cddDataset_complete_cutoff_entific : String =
    """| testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Decimal",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String", "Date"]
       |    previousFilterAppliedFields = ["g_entific_id", "gf_cutoff_date"]
       |  }"""
  lazy val cddDatasetAlone_withOutInt : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousFilterAppliedFields = ["String"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_justInt : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["Int"]
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_emptyRelevant : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = []
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_noRelevant : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    badRelevantFields = ["String",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_badRelevantColName : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String ",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_withRename : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousRename = {
       |      oldFieldNames = "DoubleToRename"
       |      newFieldNames = "Double"
       |    }
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_badRename : String =
    """|  CDDDataset {
       |  dateColumnName = ""
       |  dateColumnValue = ""
       |  entificColumnName = ""
       |  entificColumnValue = ""
       |  auditColumnName = ""
       |  testingDataset = {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old/g_entific_id=ES/gf_cutoff_date=2021-04-30"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousRename = {
       |      oldFieldNames = "DoubleToRename"
       |      newFieldNames = "Double;Int"
       |    }
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_badDataPath : String =
    """|  CDDDataset {
       |    dataPath = "path_de_prueba"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousFilterAppliedFields = ["test"]
       |    joinFields = ["String"]
       |  }"""

  lazy val cddDataset_badDataPath : String =
    """|  testingDataset {
       |    dataPath = "path_de_prueba"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String"]
       |    previousFilterAppliedFields = ["String"]
       |  }"""

  lazy val cddDatasetAlone_missDataPath : String =
    """|  CDDDataset {
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousFilterAppliedFields = ["test"]
       |  }"""

  lazy val cddDataset_missDataPath : String =
    """|  testingDataset {
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    previousFilterAppliedFields = ["test"]
       |  }"""

  lazy val cddDatasetNoPartitions_complete : String =
    """|  testingDataset {
       |    dataPath = "src/test/resources/data/cddBoards/principal_old"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String", "Int"]
       |    previousFilterAppliedFields = ["test"]
       |  }"""

  lazy val cddDatasetOnePartition_complete : String =
    """|  testingDataset {
       |    dataPath = "src/test/resources/data/cddBoards/principal_read_test"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String", "Int"]
       |    previousFilterAppliedFields = ["Date"]
       |  }"""

  lazy val cddDatasetBothPartition_complete : String =
    """|  testingDataset {
       |    dataPath = "src/test/resources/data/cddBoards/principal_read_test"
       |    schemaPath = "src/test/resources/data/cddBoards/schemas/t_cdd_board_basic.json"
       |    relevantFields = ["String",
       |      "Int",
       |      "Double",
       |      "Date",
       |      "Timestamp"]
       |    joinFields = ["String", "Int"]
       |    previousFilterAppliedFields = ["Date", "String"]
       |  }"""

  lazy val restore_restoreTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "g_entific_id;gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "GL;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "GL;2020-02-29"
      |  }
      | }""".stripMargin

  lazy val restore_restoreNoEntificTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "2020-03-31;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "gf_cutoff_date"
      |    columnsPrincipalValue = "2020-03-31"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  lazy val restore_emptyStopTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "g_entific_id;gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "AA;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "AA;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  lazy val restore_restoreMissParamsTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalValue = "GL;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "GL;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  lazy val restore_restoreDiffListLengthTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "g_entific_id;gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "GL;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  lazy val restore_restoreEmptyDfContinueTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "g_entific_id;gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "AA;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "AA;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 0
      |}""".stripMargin

  lazy val restore_restoreBadPathPrincTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/princ"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "g_entific_id;gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "GL;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "GL;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  lazy val restore_restoreBadPathHistTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerPar"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = "g_entific_id;gf_cutoff_date;gf_audit_date"
      |    columnsHistoricalValue = "GL;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "GL;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  lazy val restore_restoreMalformedTest : String =
    """CDDRestore {
      |  paths = {
      |    pathTablonPrincipal = "src/test/resources/data/restorer/principal"
      |    schemaTablonPrincipal = "src/test/resources/data/restorer/schemas/t_ktae_contract_struc_board.json"
      |    pathTablonHistorical = "src/test/resources/data/restorer/inputRestorerParquet"
      |  }
      |  partitionFeature = {
      |    columnsHistoricalName = ["g_entific_id","gf_cutoff_date","gf_audit_date"]
      |    columnsHistoricalValue = "GL;2020-02-29;2020-06-08 15:50:58.067"
      |    columnsPrincipalName = "g_entific_id;gf_cutoff_date"
      |    columnsPrincipalValue = "GL;2020-02-29"
      |  }
      |  repartitionBase = 1
      |  averageKBPerRecord = 8
      |  failIfNoDataToRestore = 1
      |}""".stripMargin

  //CONFIG FILES
  lazy val board_root_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
      |}
      |""".stripMargin)
  lazy val board_root_config_principal_old: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete_principal_old.stripMargin + """
                                                           |}
                                                           |""".stripMargin)
  lazy val board_badSchemaPath_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_badSchemaPath.stripMargin + """
      |}
      |""".stripMargin)
  lazy val board_withOutAudit_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_withOutAudit.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_root_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_complete.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_withOutInt_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_withOutInt.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_justInt_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_justInt.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_emptyRelevant_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_emptyRelevant.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_noRelevant_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_noRelevant.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_badRelevantColName_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_badRelevantColName.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_withRename_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_withRename.stripMargin + """
      |}
      |""".stripMargin)
  lazy val dataset_badRename_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddDatasetAlone_badRename.stripMargin + """
      |}
      |""".stripMargin)
  lazy val board_dataset_root_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
       |}
       |""".stripMargin)
  lazy val board_dataset_with_cutoff_entific_root_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_with_cutoff_entific_complete.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                             |}
                                                             |""".stripMargin)
  lazy val board_dataset_root_principal_old_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete_principal_old.stripMargin + """
       """.stripMargin + cddDataset_principal_old_complete.stripMargin + """
                                                             |}
                                                             |""".stripMargin)
  lazy val board_dataset_root_cutoff_entific_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_cutoff_entific_complete.stripMargin + """
       """.stripMargin + cddDataset_complete_cutoff_entific.stripMargin + """
                                                                            |}
                                                                            |""".stripMargin)
  lazy val board_dataset_badDataPath_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
       """.stripMargin + cddDataset_badDataPath.stripMargin + """
       |}
       |""".stripMargin)
  lazy val board_dataset_missDataPath_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
       """.stripMargin + cddDataset_missDataPath.stripMargin + """
       |}
       |""".stripMargin)
  lazy val board_dataset_noPartitions_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
       """.stripMargin + cddDatasetNoPartitions_complete.stripMargin + """
       |}
       |""".stripMargin)
  lazy val board_dataset_onePartition_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
       """.stripMargin + cddDatasetOnePartition_complete.stripMargin + """
       |}
       |""".stripMargin)
  lazy val board_dataset_bothPartition_config: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_complete.stripMargin + """
       """.stripMargin + cddDatasetBothPartition_complete.stripMargin + """
       |}
       |""".stripMargin)
  lazy val board_root_config_default: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_usingDefaultValues.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                             |}
                                                             |""".stripMargin)
  lazy val board_root_config_notInformedAllButRoot: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_notInformedAllButRoot.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                             |}
                                                             |""".stripMargin)
  lazy val board_root_config_notInformedOne: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_notInformedOne.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                                |}
                                                                |""".stripMargin)
  lazy val board_root_config_missParam: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_missParam.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)
  lazy val board_root_config_badCutoffDate: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_badCutoffDate.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                             |}
                                                             |""".stripMargin)
  lazy val board_root_config_badCutoffDateType: Config = ConfigFactory.parseString(
    """""".stripMargin + cddBoard_badCutoffDateType.stripMargin + """
       """.stripMargin + cddDataset_complete.stripMargin + """
                                                             |}
                                                             |""".stripMargin)

  lazy val cleaner_root_config_SinglePartition: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_SinglePartition.stripMargin + """
      |""".stripMargin)

  lazy val cleaner_root_config_HistSameYear: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_HistSameYear.stripMargin + """
                                                                 |""".stripMargin)

  lazy val cleaner_root_config_HistChangeYear: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_HistChangeYear.stripMargin + """
                                                              |""".stripMargin)

  lazy val cleaner_root_config_OtherFormat1: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_OtherFormat1.stripMargin + """
                                                              |""".stripMargin)

  lazy val cleaner_root_config_OtherFormat2: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_OtherFormat2.stripMargin + """
                                                              |""".stripMargin)

  lazy val cleaner_root_config_BadPath: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_BadPath.stripMargin + """
                                                              |""".stripMargin)

  lazy val cleaner_root_config_BadPersistenceLimitType: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_BadPersistenceLimitType.stripMargin + """
                                                              |""".stripMargin)

  lazy val cleaner_root_config_BadDateType: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_BadDateType.stripMargin + """
                                                              |""".stripMargin)

  lazy val cleaner_root_config_BadColumnNameSingle: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_BadColumnNameSingle.stripMargin + """
                                                             |""".stripMargin)

  lazy val cleaner_root_config_FirstDay: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_FirstDay.stripMargin + """
                                                                     |""".stripMargin)

  lazy val cleaner_root_config_FifthDay: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_PrincFifthDay.stripMargin + """
                                                          |""".stripMargin)

  lazy val cleaner_root_config_MissParam: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_MissParam.stripMargin + """
                                                               |""".stripMargin)

  lazy val cleaner_root_config_BadDate: Config = ConfigFactory.parseString(
    """""".stripMargin + cleaner_BadDate.stripMargin + """
                                                               |""".stripMargin)

  lazy val backUp_root_config: Config = ConfigFactory.parseString(
    """""".stripMargin + backUp_config.stripMargin + """
                                                         |""".stripMargin)
  lazy val restore_restoreTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreTest + """
                                                 |""".stripMargin)

  lazy val restore_restoreNoEntificTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreNoEntificTest + """
                                                          |""".stripMargin)

  lazy val restore_restoreMissParamsTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreMissParamsTest + """
                                                           |""".stripMargin)

  lazy val restore_restoreDiffListLengthTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreDiffListLengthTest + """
                                                               |""".stripMargin)

  lazy val restore_restoreEmptyDfContinueTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreEmptyDfContinueTest + """
                                                                |""".stripMargin)

  lazy val restore_restoreBadPathPrincTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreBadPathPrincTest + """
                                                             |""".stripMargin)

  lazy val restore_restoreBadPathHistTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreBadPathHistTest + """
                                                            |""".stripMargin)

  lazy val restore_restoreMalformedTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_restoreMalformedTest + """
                                                          |""".stripMargin)

  lazy val restore_restoreEmptyStopTest_config: Config = ConfigFactory.parseString(
    """""".stripMargin + restore_emptyStopTest + """
                                                          |""".stripMargin)
}
