package com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, TestCommons, TestUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class WriteUtilsTest extends TestCommons {

  val sourcePath: String = "src/test/resources/data/utils/actions/intermediate/writeParquetFile"
  val targetPath: String = "src/test/resources/data/utils/actions/salida"

  test("WriteUtils - simpleWriteToParquet") {
    WriteUtils.simpleWriteToParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles, targetPath, 1)
    val result: DataFrame = ReadUtils.simpleReadParquet(datioSparkSession, targetPath)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(result, expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - writePrincipalBoardParquet") {
    val globalParameter: GlobalConfigurationReaded = GlobalConfigurationReaded(dateIngestion = "",
      dateColumnName = "Date",
      dateColumnValue = "",
      entificColumnName = "String",
      entificColumnValue = "",
      auditColumnName = "",
      averageKBPerRecord = 1,
      fullNameSchemaBoard = "",
      pathTemporal = "",
      pathOutputBoard = "",
      repartitionBase = 1,
      notInformedDatasets = Seq.empty[String])
    TestUtils
      .writePrincipalBoardParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
        targetPath, globalParameter, testResources.testingDataDatioSchema)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    val dfs = DatioFileSystem.get()
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(result, expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - writeBackupBoardParquet partition datatype String") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.writeBackupBoardParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles, targetPath, 1,
      Seq("String"), "Timestamp", testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - writeBackupBoardParquet partition datatype Date") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.writeBackupBoardParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles, targetPath, 1,
      Seq("Date"), "Timestamp", testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }
  test("WriteUtils - writeBackupBoardParquet partition datatype Double") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.writeBackupBoardParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles, targetPath, 1,
      Seq("Double"), "Timestamp", testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }
  test("WriteUtils - writeBackupBoardParquet partition datatype Int") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.writeBackupBoardParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles, targetPath, 1,
      Seq("Int"), "Timestamp", testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - writeBackupBoardParquetTwoPartitions writeBackupBoardParquet partition datatype String and Int") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.writeBackupBoardParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles, targetPath, 1,
      Seq("String", "Int"), "Timestamp", testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - restorePrincipalParquet partition datatype String and Int") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.restorePrincipalParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      targetPath, 1, Seq("String", "Int"), testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - restorePrincipalParquet partition datatype String") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.restorePrincipalParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      targetPath, 1, Seq("String"), testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - restorePrincipalParquet partition datatype Date") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.restorePrincipalParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      targetPath, 1, Seq("Date"), testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - restorePrincipalParquet partition datatype Int") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.restorePrincipalParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      targetPath, 1, Seq("Int"), testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - restorePrincipalParquet partition datatype Double") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.restorePrincipalParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      targetPath, 1, Seq("Double"), testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - restorePrincipalParquet partition datatype Timestamp") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    WriteUtils.restorePrincipalParquet(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      targetPath, 1, Seq("Timestamp"), testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
  }

  test("WriteUtils - copyParquetInBackup") {
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, targetPath)
    TestUtils.simpleWriteToParquetWithSchema(datioSparkSession, testResources.testingDataFrame_WriteParquetFiles,
      sourcePath, testResources.testingDataDatioSchema)
    WriteUtils.copyParquetInBackup(datioSparkSession, sourcePath, targetPath, 1,
      testResources.testingDataDatioSchema, 1)
    val result: DataFrame = ReadUtils.readParquetWithSchema(datioSparkSession, targetPath, testResources.testingDataDatioSchema)
    val expected: DataFrame = testResources.testingDataFrame_WriteParquetFiles
    var written = VAL_FALSE
    if (FileSystemUtils.pathExists(dfs, targetPath)) written = VAL_TRUE
    (written == VAL_TRUE & TestUtils.assertDataFrameEquals(
      result.select(testResources.testingDataSchemaColumnNames: _*),
      expected, FALSE_VALUE)) shouldBe TRUE_VALUE
    FileSystemUtils.delete(dfs, targetPath)
    FileSystemUtils.delete(dfs, sourcePath)
  }

}
