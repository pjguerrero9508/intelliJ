package com.bbva.projectsdatio.cdd.structuralboards.commons.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.{ParamEmptyException, ParamNotInformedException}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, NULL_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{CddStructuralBoardsDatasetTestClass, CddStructuralMainBoardDatasetTestClass, CddStructuralMainBoardDatasetTestNotInOutputClass, TestCommons, TestUtils}
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.ConfigException
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.types._
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class CDDStructuralBoardsDatasetTest extends TestCommons {

  test("CDDStructuralBoardsDataset_Checkpoint_Unchanged_Dataset") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .checkpoint(datioSparkSession, testResources.dataset_checkpoint_path)
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_GetDataFrame_Unchanged_Dataset") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_SelectRelevantColumns_Unchanged_Dataset") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .selectRelevantColumns()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }
  test("CDDStructuralBoardsDataset_SelectRelevantColumns_Without_Int") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_without_int)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame.drop("Int"),
      cddStructuralBoardsDatasetTestObject
        .selectRelevantColumns()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_SelectRelevantColumns_Just_Int") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_just_int)
    val columnsToDrop = testResources.testingDataFrame.columns.filterNot(_.equals("Int"))
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame
      .drop(columnsToDrop:_*),
      cddStructuralBoardsDatasetTestObject
        .selectRelevantColumns()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_SelectRelevantColumns_No_Relevant_Param") {
    assertThrows[ConfigException.Missing] {
      val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
      = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_no_relevant)
      cddStructuralBoardsDatasetTestObject
        .selectRelevantColumns()
    }
  }

  test("CDDStructuralBoardsDataset_SelectRelevantColumns_Empty_Relevant_Param") {
    assertThrows[ParamEmptyException] {
      val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
      = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_empty_relevant)
      cddStructuralBoardsDatasetTestObject
        .selectRelevantColumns()
    }
  }

  test("CDDStructuralBoardsDataset_SelectRelevantColumns_Bad_Relevant_ColumnName_Param") {
    assertThrows[org.apache.spark.sql.AnalysisException] {
      val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
      = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_bad_relevant_col_name)
      cddStructuralBoardsDatasetTestObject
        .selectRelevantColumns()
    }
  }

  test("CDDStructuralBoardsDataset_InitializeNotInformedColumns_Int_Not_In_Original_Dataset") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame.drop("Int"), testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrameNullInt,
      cddStructuralBoardsDatasetTestObject
        .initializeNotInformedColumns(testResources.testingDataDatioSchema)
        .selectRelevantColumns()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_InitializeNotInformedColumns_No_Relevant_Param") {
    assertThrows[ConfigException.Missing]{
      val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
      = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_no_relevant)
      cddStructuralBoardsDatasetTestObject
        .initializeNotInformedColumns(testResources.testingDataDatioSchema)
    }
  }

  test("CDDStructuralBoardsDataset_InitializeNotInformedColumns_Empty_Relevant_Param") {
    assertThrows[ParamEmptyException] {
      val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
      = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_empty_relevant)
      cddStructuralBoardsDatasetTestObject
        .initializeNotInformedColumns(testResources.testingDataDatioSchema)
    }
  }

  test("CDDStructuralBoardsDataset_InitializeNotInformedColumns_Bad_Relevant_ColumnName_Param") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_bad_relevant_col_name)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame.withColumn("String ", lit(NULL_VALUE: String).cast("string")),
      cddStructuralBoardsDatasetTestObject
        .initializeNotInformedColumns(testResources.testingDataInitStringDatioSchema)
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_InitializeNotInformedColumns_Every_Column_Initialized") {
    val columnsToDrop = testResources.testingDataFrame.columns.filterNot(_.equals("Int"))
    val dataSetWithNoColumnInRelevant = testResources.testingDataFrame
      .drop(columnsToDrop:_*)
      .withColumnRenamed("Int", "IntRenamed")
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(dataSetWithNoColumnInRelevant, testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrameNullComplete,
      cddStructuralBoardsDatasetTestObject
        .initializeNotInformedColumns(testResources.testingDataDatioSchema)
        .selectRelevantColumns()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_RenameDataSetInputFields_Empty_Rename_Map") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .renameDataSetInputFields()
        .selectRelevantColumns()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_RenameDataSetInputFields_Rename_Double_Map") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame.withColumnRenamed("Double","DoubleToRename"),
      testResources.dataset_config_WithRename)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .renameDataSetInputFields()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_RenameDataSetInputFields_Rename_Bad_Map") {
    val cddStructuralBoardsDatasetTestObject : CddStructuralBoardsDatasetTestClass
    = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame.withColumnRenamed("Double","DoubleToRename"),
      testResources.dataset_config_BadRename)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .renameDataSetInputFields()
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

  test("CDDStructuralBoardsDataset_Apply_Read_Ok") {
    val result : DataFrame = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.board_complete_cutoff_entific_config_basic)
      .apply(datioSparkSession, testResources.testingDataSchema_added_partitionsDatioSchema).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.testReadDataSetWithPartitions
      .select(result.columns.map(col):_*), FALSE_VALUE, FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("CDDStructuralBoardsDataset_Apply_Bad_Data_Path") {
    assertThrows[AnalysisException] {
      CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.board_config_badDataPath)
        .apply(datioSparkSession, testResources.testingDataDatioSchema).getDataFrame()
    }
  }

  test("CDDStructuralBoardsDataset_Apply_Miss_Data_Path") {
    assertThrows[ParamNotInformedException] {
      CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.board_config_missDataPath)
        .apply(datioSparkSession, testResources.testingDataDatioSchema).getDataFrame()
    }
  }

  test("CDDStructuralBoardsDataset_ApplyEmpty") {
    val result: DataFrame = CddStructuralBoardsDatasetTestClass(testResources.testingDataFrame, testResources.board_complete_config_basic)
      .applyEmpty(datioSparkSession, testResources.testingDataDatioSchema).getDataFrame()
    val expectedSize = 0
    val resultSchema: StructType = StructType.apply(result.schema.sortBy(_.name))
    assert(TestUtils.compareStructType(testResources.testingDataDatioSchema.getStructType,resultSchema))
    assert(result.count().equals(expectedSize.toLong))
  }
  test("CDDStructuralBoardsDataset_getLastPartitionDateOfDf_One_partition") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.boards_path_FirstPartLevel_2021_04_30).fileSystem()
    val path1: Path = dfs.qualify(testResources.boards_path_FirstPartLevel_2021_04_30).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.boards_path_FirstPartLevel_2021_04_29).fileSystem()
    val path2: Path = dfs.qualify(testResources.boards_path_FirstPartLevel_2021_04_29).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.boards_path_FirstPartLevel_2021_03_29).fileSystem()
    val path3: Path = dfs.qualify(testResources.boards_path_FirstPartLevel_2021_03_29).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.boards_path_FirstPartLevel_2020_03_29).fileSystem()
    val path4: Path = dfs.qualify(testResources.boards_path_FirstPartLevel_2020_03_29).path()
    fs4.mkdirs(path4)
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrame, testResources.board_config_onePartition)
    val result: String = cddStructuralBoardsDatasetTestObject.globalParameterSetter()
      .getLastPartitionDateOfDf(datioSparkSession)
    FileSystemUtils.delete(dfs, testResources.boards_path_no_partition)
    assertResult("2021-04-30")(result)
  }

  test("CDDStructuralBoardsDataset_getLastPartitionDateOfDf_Two_partitions") {
    val dfs = DatioFileSystem.get()
    val fs1: FileSystem = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2021_04_30).fileSystem()
    val path1: Path = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2021_04_30).path()
    fs1.mkdirs(path1)
    val fs2: FileSystem = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2021_04_29).fileSystem()
    val path2: Path = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2021_04_29).path()
    fs2.mkdirs(path2)
    val fs3: FileSystem = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2021_03_29).fileSystem()
    val path3: Path = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2021_03_29).path()
    fs3.mkdirs(path3)
    val fs4: FileSystem = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2020_03_29).fileSystem()
    val path4: Path = dfs.qualify(testResources.boards_path_SecPartLevel_ES_2020_03_29).path()
    fs4.mkdirs(path4)
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrame, testResources.board_config_bothPartition)
    val result: String = cddStructuralBoardsDatasetTestObject.globalParameterSetter()
      .getLastPartitionDateOfDf(datioSparkSession)
    FileSystemUtils.delete(dfs, testResources.boards_path_no_partition)
    assertResult("2021-04-30")(result)
  }

  test("CDDStructuralBoardsDataset_schemaFromRelevantColumn") {
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    val testingSchema: DatioSchema = testResources.testingDataDatioSchema
    val selectFields: Seq[String] = Seq("Double", "Timestamp")
    val result: Array[StructField] = cddStructuralBoardsDatasetTestObject
      .schemaFromRelevantColumns(testingSchema,selectFields)
      .fields
    val expected = Array(
      StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
      StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE))
    assert(result.length.equals(selectFields.size))
    assert(result.map(field => expected.contains(field)).reduce(_&&_))
    assert(expected.map(field => result.contains(field)).reduce(_&&_))

  }
  test("CDDStructuralBoardsDataset_buildValuesPartitionParam") {
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    val emptyPartitionsNames: Seq[String]  = Seq()
    val emptyPartitionsValues: Seq[String] = Seq()
    val emptyFilterValues: Seq[String]     = Seq()
    val emptyResult: Seq[(String, String, String)] = cddStructuralBoardsDatasetTestObject
      .buildValuesPartitionParam(emptyPartitionsNames, emptyPartitionsValues, emptyFilterValues)
    val emptyExpected: Seq[(String, String, String)] = Seq()
    assert(emptyResult.equals(emptyExpected))

    val partitionsNames: Seq[String]  = Seq("first_part_name_1", "first_part_name_2", "first_part_name_3")
    val partitionsValues: Seq[String] = Seq("value", "2021-10-26", "1")
    val filterValues: Seq[String]     = Seq("Y", "N", "Y")
    val result: Seq[(String, String, String)] = cddStructuralBoardsDatasetTestObject
      .buildValuesPartitionParam(partitionsNames, partitionsValues, filterValues)
    val expected: Seq[(String, String, String)] = Seq(("Y","first_part_name_1","value"),
      ("N","first_part_name_2","2021-10-26"),
      ("Y","first_part_name_3","1"))
    assert(result.equals(expected))

    val badPartitionsNames: Seq[String]  = Seq("first_part_name_1", "first_part_name_2", "first_part_name_3")
    val badPartitionsValues: Seq[String] = Seq("value", "2021-10-26")
    val badFilterValues: Seq[String]     = Seq("Y", "N", "Y")
    val badResult: Seq[(String, String, String)] = cddStructuralBoardsDatasetTestObject
      .buildValuesPartitionParam(badPartitionsNames, badPartitionsValues, badFilterValues)
    val badExpected: Seq[(String, String, String)] = Seq(("Y","first_part_name_1","value"),
      ("N","first_part_name_2","2021-10-26"))
    assert(badResult.equals(badExpected))
  }
  test("CDDStructuralMainBoardDataset_createRelevantSchema every field is in input") {
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrame, testResources.board_complete_config_basic)
    val result = cddStructuralBoardsDatasetTestObject.globalParameterSetter().createRelevantSchema(testResources.testingDataDatioSchema)
      .filterNot(_.name.equals("gf_audit_date"))
    assert(result.equals(testResources.testingDataSchema))
  }

  test("CDDStructuralMainBoardDataset_createRelevantSchema not every relevant is in input") {
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrameWithoutTimestamp, testResources.board_complete_config_basic)
    val result = cddStructuralBoardsDatasetTestObject.globalParameterSetter().createRelevantSchema(testResources.testingDataDatioSchema)
      .filterNot(_.name.equals("gf_audit_date"))
    assert(result.equals(testResources.testingDataSchema))
  }

  test("CDDStructuralMainBoardDataset_createRelevantSchema not every relevant is in output") {
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestNotInOutputClass(testResources.testingDataFrame, testResources.board_complete_config_basic)
    val result = cddStructuralBoardsDatasetTestObject.globalParameterSetter().createRelevantSchema(testResources.testingDataDatioSchema)
      .filterNot(_.name.equals("gf_audit_date"))
    assert(result.equals(testResources.testingDataSchema))
  }

  test("CDDStructuralMainBoardDataset_getCustomizedDataSet_Not_Empty") {

  }

  test("CDDStructuralMainBoardDataset_getCustomizedDataSet_Empty") {

  }

  test("CDDStructuralMainBoardDataset_GetDataFrame_Unchanged_Dataset") {
    val cddStructuralBoardsDatasetTestObject
    = CddStructuralMainBoardDatasetTestClass(testResources.testingDataFrame, testResources.dataset_config_basic)
    TestUtils.assertDataFrameEquals(testResources.testingDataFrame,
      cddStructuralBoardsDatasetTestObject
        .getDataFrame(),
      FALSE_VALUE) shouldBe true
  }

}
