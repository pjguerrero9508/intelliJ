package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

case class KSAGEomPrtcptLclGroup(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KSAGEomPrtcptLclGroup] {

  val datasetParams: DatasetParams = KSAG_EOM_PRTCPT_LCL_GROUP_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("g_customer_main_group_ind_type", "g_spec_lc_reglty_grp_ind_type")

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_CUSTOMER_GROUP_TYPE, config)
  lazy val customerGroupType: String = config.getString(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_CUSTOMER_GROUP_TYPE)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_SPEC_LC_REGLTY, config)
  lazy val specLcReglty: String = config.getString(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_SPEC_LC_REGLTY)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_GROUP_ID, config)
  lazy val groupId: String = config.getString(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_GROUP_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_LOCAL_REGLTY_SPEC, config)
  lazy val localRegltySpec: String = config.getString(CONF_COLUMNS_KSAG_EOM_PRTCPT_LCL_GROUP_LOCAL_REGLTY_SPEC)

  override def dataSetTransformations(outputSchema: DatioSchema): KSAGEomPrtcptLclGroup = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.filterCustomerGroupType()
  }

  override def dataSetEmptyTransformations(): KSAGEomPrtcptLclGroup = {
    val renamedData = super.dataSetEmptyTransformations()
    renamedData.filterCustomerGroupTypeEmpty()
  }

  /**
   * Filter the original dataframe by the value 'Y' of column 'g_customer_main_group_ind_type',
   * set value of 'g_group_id' in the column with the same name, and drop filter column.
   * Filter again the original dataframe by the value 'Y' of column 'g_spec_lc_reglty_grp_ind_type',
   * set value of 'g_group_id' in the column 'gf_local_reglty_spec_group_id', and drop filter column.
   * Join both dataframes with the value of the distinct 'g_customer_id' from the original dataframe.
   *
   * @return Dataframe with the filters and columns desired
   */
  def filterCustomerGroupType(): KSAGEomPrtcptLclGroup = {

    val mainIndTypeGroup: DataFrame = original
      .where(original.col(customerGroupType) === FIELD_TO_FILTER_FLAG)
      .withColumnRenamed("g_customer_id", "customer_main")
      .drop(customerGroupType, specLcReglty)

    val originalDistinct = original
      .drop(customerGroupType, specLcReglty, groupId)
      .distinct()

    val joinMainIndType = originalDistinct
      .join(mainIndTypeGroup,
        originalDistinct.col("g_customer_id") === mainIndTypeGroup.col("customer_main"), "left")
      .drop("customer_main")

    val regltySpecGroup: DataFrame = original
      .where(original.col(specLcReglty) === FIELD_TO_FILTER_FLAG)
      .withColumnRenamed("g_customer_id", "customer_spec")
      .withColumnRenamed(groupId, localRegltySpec)
      .drop(customerGroupType, specLcReglty)

    val joinFinal = joinMainIndType
      .join(regltySpecGroup,
        joinMainIndType.col("g_customer_id") === regltySpecGroup.col("customer_spec"), "left")
      .drop("customer_spec")

    wrap(joinFinal)

  }

  /**
   * Filter dataframe by the value of a column and drop filter column
   *
   * @return Dataframe with the filter and columns desired
   */
  def filterCustomerGroupTypeEmpty(): KSAGEomPrtcptLclGroup = {
    val transformed: DataFrame = original
      .withColumn(localRegltySpec, col(groupId))
      .drop(customerGroupType, specLcReglty)
    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */
  def wrap(transformed: DataFrame): KSAGEomPrtcptLclGroup = {
    copy(original = transformed)
  }
}
