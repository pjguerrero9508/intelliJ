package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KSAGEomRiskSectorization(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KSAGEomRiskSectorization] {

  val datasetParams : DatasetParams = KSAG_EOM_RISK_SECTORIZATION_CONSTANTS

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KSAGEomRiskSectorization = {
    copy(original = transformed)
  }
}
