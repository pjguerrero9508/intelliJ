package com.bbva.projectsdatio.cdd.structuralboards.customers.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.bbva.projectsdatio.cdd.structuralboards.customers.datasets._
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Row}

/**
 * Main file for Customer Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsCustomers_R302_Trait extends StructuralboardsCustomers_RQ22021_Trait {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDCustomersBoard_R302"
  override val boardTables: Seq[String] = CUSTOMERS_BOARD_TABLES_302

  /**
   * This method join with all tables required for customers board
   *
   * @param dataSetMap   All case class of tables
   * @return kbtqEomCustomer with customers board
   */
  override def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                          globalConfigurationReaded: GlobalConfigurationReaded,
                          globalConfigurationTranslated: GlobalConfigurationTranslated,
                          datioSparkSession: DatioSparkSession): KBTQEomCustomer = {
    logger.info(s"CDDStructuralboards: Init method joinTablon")
    dataSetMap(mainEntity).asInstanceOf[KBTQEomCustomer].globalParameterSetter()
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_SOVEREIGN_EXT_RATING))  // Table Join 5
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_PRTCPT_LCL_GROUP))  // Table Join 14
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_LOCAL_GROUP))       // Table Join 15
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_CORP_EXT_RATING))       // Table Join 4
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_ECON_INFORMATION))  // Table Join 1
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_CUSTOMER_ENGAGEMENT))   // Table Join 8
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_SEGMENTATION))      // Table Join 10
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_INAPPRT_CUST_SITUTN))   // Table Join 2
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_SECTORIZATION))     // Table Join 11
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_CUST_RATING_ATRB))      // Table Join 3
  }
}

class StructuralboardsCustomers_R302 extends StructuralboardsCustomers_R302_Trait
