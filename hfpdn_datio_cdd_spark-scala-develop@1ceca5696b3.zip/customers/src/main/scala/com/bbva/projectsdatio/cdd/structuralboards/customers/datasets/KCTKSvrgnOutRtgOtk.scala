package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.sql.functions.{col, last, when}

import scala.collection.JavaConverters._

case class KCTKSvrgnOutRtgOtk(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KCTKSvrgnOutRtgOtk] {

  val datasetParams : DatasetParams = KCTK_SVRGN_OUT_RTG_OTK_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("g_record_rating_type", "gf_rating_generation_date", "g_country_id")
  override val fieldsNotInInput: Seq[String] = Seq("g_residence_country_id")

  override def dataSetTransformations(outputSchema: DatioSchema): KCTKSvrgnOutRtgOtk = {
    val superDataSet: KCTKSvrgnOutRtgOtk = super.dataSetTransformations(outputSchema)
    val ratingTypeColumnName: String = config.getString(CONF_KCTK_SVRGN_OUT_RTG_OTK_RATING_TYPE_FIELD_NAME)
    val ratingTypeAllowedValue: String = config.getString(CONF_KCTK_SVRGN_OUT_RTG_OTK_RATING_TYPE_ALLOWED_VALUE)
    val generationDateFieldName: String = config.getString(CONF_KCTK_SVRGN_OUT_RTG_OTK_GENERATION_DATE_FIELD_NAME)
    val joinKeys: Seq[Column] = config.getStringList(datasetParams.dataSetJoinFields).asScala.map(col)
    val cutoffByMonth = Window.partitionBy(joinKeys:_*)
      .orderBy(col(generationDateFieldName))
      .rowsBetween(Window.currentRow, Window.unboundedFollowing)
    val isLastRecordColumnName = "last_date_flag"
    val previouslyTreatedDF: DataFrame = superDataSet
      .getDataFrame()
      .filter(col(ratingTypeColumnName) === ratingTypeAllowedValue)
      .withColumn(isLastRecordColumnName, when(
        last(col(generationDateFieldName)).over(cutoffByMonth) === col(generationDateFieldName), 1)
        .otherwise(0))
      .filter(col(isLastRecordColumnName) === 1)
      .drop(isLastRecordColumnName)
    wrap(previouslyTreatedDF)
  }
  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KCTKSvrgnOutRtgOtk = {
    copy(original = transformed)
  }
}
