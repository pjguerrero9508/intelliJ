package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KSAGEomLocalGroup(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KSAGEomLocalGroup] {

  override val fieldsNotInOutput: Seq[String] = Seq("gf_personal_type", "gf_personal_id")
  override val fieldsNotInInput: Seq[String] = Seq("gf_group_official_doc_type", "gf_group_official_doc_id")

  val datasetParams : DatasetParams = KSAG_EOM_LOCAL_GROUP_CONSTANTS

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KSAGEomLocalGroup = {
    copy(original = transformed)
  }
}
