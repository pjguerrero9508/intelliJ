package com.bbva.projectsdatio.cdd.structuralboards.customers.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.CDDStructuralBoardsApp

/**
 * Main file for Customer Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsCustomers_RQ22021_Trait extends StructuralboardsCustomers_RQ42021_Trait {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDCustomersBoard_RQ22021"

}

class StructuralboardsCustomers_RQ22021 extends StructuralboardsCustomers_RQ22021_Trait
