package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, CDDStructuralMainBoardDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.functions.{col, typedLit}
import org.apache.spark.sql.{Column, DataFrame}

import scala.collection.JavaConverters._
import scala.collection.mutable

case class KBTQEomCustomer(original: DataFrame, config: Config)
  extends CDDStructuralMainBoardDataset[KBTQEomCustomer] {

  val datasetParams: DatasetParams = KBTQ_EOM_CUSTOMER_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("gf_address_y_coord_number", "gf_address_x_coord_number")
  override val fieldsNotInInput: Seq[String] = Seq("gf_latitude_number", "gf_longitude_number")

  TechnicalValidation.configStringListParamValidator(datasetParams.dataSetSelectOutputFields.get, config)
  val selectTablonFields: mutable.Seq[Column] = config.getStringList(datasetParams.dataSetSelectOutputFields.get).asScala.map(col)

  override def dataSetTransformations(outputSchema: DatioSchema): KBTQEomCustomer = {
    val castedData = super.dataSetTransformations(outputSchema)
    castedData.castCoordinates()
  }

  override def dataSetEmptyTransformations(): KBTQEomCustomer = {
    val castedDataEmpty = super.dataSetEmptyTransformations()
    castedDataEmpty.castCoordinates()
  }

  def castCoordinates(): KBTQEomCustomer = {
    val dfCasted: DataFrame = original
      .withColumn("gf_latitude_number", col("gf_latitude_number").cast("decimal(15,7)"))
      .withColumn("gf_longitude_number", col("gf_longitude_number").cast("decimal(15,7)"))
    wrap(dfCasted)
  }

  /**
   * left join between two tables with the given columns for the join
   *
   * @param right dataframe, enriches the information in the Customers table
   * @return Dataframe with the interest columns' selection
   */
  def join(right: CDDStructuralBoardsDataset[_]): KBTQEomCustomer = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    dataSetsColumnsChecker(right, joinColumns)
    val transformed: DataFrame = original.join(right.getDataFrame(), joinColumns, "left")
    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */
  def wrap(transformed: DataFrame): KBTQEomCustomer = {
    copy(original = transformed)
  }

  /**
   * selection of columns for customer structural board
   *
   * @return Dataframe with the interest customer board columns' selection
   */
  def selectTablonColumns(): KBTQEomCustomer = {
    val tablon: DataFrame = original.select(selectTablonFields: _*)
    this.wrap(tablon)
  }

  override def globalParameterSetter(): KBTQEomCustomer = {
    this.globalParameter = setterDatasetConfiguration(config)
    this
  }
}
