package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KCTKSovereignExtRating(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KCTKSovereignExtRating] {

  val datasetParams : DatasetParams = KCTK_SOVEREIGN_EXT_RATING_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("g_country_id")
  override val fieldsNotInInput: Seq[String] = Seq("g_residence_country_id")

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KCTKSovereignExtRating = {
    copy(original = transformed)
  }
}
