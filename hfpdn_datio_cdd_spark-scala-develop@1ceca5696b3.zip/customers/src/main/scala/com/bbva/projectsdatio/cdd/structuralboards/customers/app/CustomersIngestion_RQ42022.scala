package com.bbva.projectsdatio.cdd.structuralboards.customers.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.customers.datasets._
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Row}

/**
 * Main file for Customer Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsCustomers_RQ42022_Trait extends CDDStructuralBoardsApp {
  this: CDDStructuralBoardsApp =>

  val mainEntity: String = CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER
  val configId : String = "CDDCustomersBoard_RQ42022"
  val structuralBoard : String = "Customers"
  val boardTables: Seq[String] = CUSTOMERS_BOARD_TABLES_RQ42022
  val defaultAverageKBPerRecord : Int = DEFAULT_AVERAGE_KB_PER_RECORD_BOARDS_CUSTOMERS
  val defaultRepartitionBase : Int = DEFAULT_REPARTITION_BASE_BOARDS_CUSTOMERS

  /**
   * This method generates, for the dataset informed in entityName param, a Tuple with its name in the first value
   * and the dataset that will be used in the board calculation in the second value. If emptyInitializeMode is set as "true",
   * the dataset that will be returned will have all it's values set to null. If any of the needed column is not informed
   * in input dataset, it will be initialized with null value as long as output schema contains that column.
   *
   * @param entityName: String
   * @param globalConfigurationReaded: GlobalConfigurationReaded
   * @param globalConfigurationTranslated: GlobalConfigurationTranslated
   * @param config: Config
   * @param emptyInitializeMode: Boolean
   * @return
   */
  def dataSetCollectionMapper(entityName: String,
                              globalConfigurationReaded: GlobalConfigurationReaded,
                              globalConfigurationTranslated: GlobalConfigurationTranslated,
                              config: Config,
                              datioSparkSession: DatioSparkSession,
                              emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])] = {
    logger.info(s"CDDStructuralboards: Read output schema")
    val emptyDataframe : DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row],
        globalConfigurationTranslated.datioOutputSchema.getStructType)
    logger.info(s"CDDStructuralboards: entityName $entityName")
    entityName match {
      case CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER,
          KBTQEomCustomer(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_ECON_INFORMATION =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_ECON_INFORMATION,
          KBTQEomEconInformation(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_INAPPRT_CUST_SITUTN =>
        Some(CUSTOMERS_BOARD_TABLE_INAPPRT_CUST_SITUTN,
          KDEOInapprtCustSitutn(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_CUST_RATING_ATRB =>
        Some(CUSTOMERS_BOARD_TABLE_CUST_RATING_ATRB,
          KCTKCustRatingAtrb(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_CORP_EXT_RATING =>
        Some(CUSTOMERS_BOARD_TABLE_CORP_EXT_RATING,
          KCTKCorpExtRating(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_CUSTOMER_ENGAGEMENT =>
        Some(CUSTOMERS_BOARD_TABLE_CUSTOMER_ENGAGEMENT,
          KCEGCustomerEngagement(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_SEGMENTATION =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_SEGMENTATION,
          KSAGEomSegmentation(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_SECTORIZATION =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_SECTORIZATION,
          KSAGEomSectorization(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_PRTCPT_LCL_GROUP =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_PRTCPT_LCL_GROUP,
          KSAGEomPrtcptLclGroup(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_LOCAL_GROUP =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_LOCAL_GROUP,
          KSAGEomLocalGroup(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_SOVEREIGN_EXT_RATING =>
        Some(CUSTOMERS_BOARD_TABLE_SOVEREIGN_EXT_RATING,
          KCTKSovereignExtRating(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_PARTICIPATED_COMPANY =>
        Some(CUSTOMERS_BOARD_TABLE_PARTICIPATED_COMPANY,
          NA8ZParticipatedCompany(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_SVRGN_OUT_RTG_OTK =>
        Some(CUSTOMERS_BOARD_TABLE_SVRGN_OUT_RTG_OTK,
          KCTKSvrgnOutRtgOtk(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_RISK_SECTORIZATION =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_RISK_SECTORIZATION,
          KSAGEomRiskSectorization(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_INCOME_SOURCE =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_INCOME_SOURCE,
          KBTQEomIncomeSource(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER_INDICATOR =>
        Some(CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER_INDICATOR,
          KBTQEomCustomerIndicator(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case _ => None
    }
  }

  /**
   * This method join with all tables required for customers board
   *
   * @param dataSetMap   All case class of tables
   * @return kbtqEomCustomer with customers board
   */
  def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                 globalConfigurationReaded: GlobalConfigurationReaded,
                 globalConfigurationTranslated: GlobalConfigurationTranslated,
                 datioSparkSession: DatioSparkSession): KBTQEomCustomer = {
    logger.info(s"CDDStructuralboards: Init method joinTablon")
    dataSetMap(mainEntity).asInstanceOf[KBTQEomCustomer].globalParameterSetter()
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_SOVEREIGN_EXT_RATING))  // Table Join 5
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_SVRGN_OUT_RTG_OTK))     // Table Join 6
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_INCOME_SOURCE))     // Table Join 12
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_PRTCPT_LCL_GROUP))  // Table Join 12
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER_INDICATOR))// Table Join 13
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_RISK_SECTORIZATION))// Table Join 14
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_LOCAL_GROUP))       // Table Join 13
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_CORP_EXT_RATING))       // Table Join 4
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_ECON_INFORMATION))  // Table Join 1
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_CUSTOMER_ENGAGEMENT))   // Table Join 8
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_SEGMENTATION))      // Table Join 10
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_INAPPRT_CUST_SITUTN))   // Table Join 2
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_EOM_SECTORIZATION))     // Table Join 11
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_CUST_RATING_ATRB))      // Table Join 3
      .join(dataSetMap(CUSTOMERS_BOARD_TABLE_PARTICIPATED_COMPANY))  // Table Join 9
  }
}

class StructuralboardsCustomers_RQ42022 extends StructuralboardsCustomers_RQ42022_Trait
