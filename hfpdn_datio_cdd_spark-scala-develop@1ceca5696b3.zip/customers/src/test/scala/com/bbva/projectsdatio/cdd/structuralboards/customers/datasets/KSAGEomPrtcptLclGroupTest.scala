package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import com.bbva.projectsdatio.cdd.structuralboards.customers.utils.TestUtils
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSAGEomPrtcptLclGroupTest extends TestCustomers {

  test("ksagEomPrtcptLclGroup_wrap") {
    val instancia: KSAGEomPrtcptLclGroup = KSAGEomPrtcptLclGroup(testResources.ksagEomPrtcptLclGroup_complete_input_testing, testResources.config)
    val result: KSAGEomPrtcptLclGroup = instancia.wrap(testResources.ksagEomPrtcptLclGroup_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("ksagEomPrtcptLclGroup_filterCustomerGroupType") {
    val result: DataFrame = KSAGEomPrtcptLclGroup(testResources.ksagEomPrtcptLclGroup_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ksagEomPrtcptLclGroup_customized_testing, false) shouldBe TRUE_VALUE
  }

  test("ksagEomPrtcptLclGroup_filterCustomerGroupTypeBadFields") {
    assertThrows[AnalysisException] {
      KSAGEomPrtcptLclGroup(testResources.ksagEomPrtcptLclGroup_complete_input_testing, testResources.configBadFields).filterCustomerGroupType().getDataFrame()
    }
  }

  test("ksagEomPrtcptLclGroup_filterCustomerGroupTypeMissFields") {
    assertThrows[ParamNotInformedException] {
      KSAGEomPrtcptLclGroup(testResources.ksagEomPrtcptLclGroup_complete_input_testing, testResources.configMissFields).filterCustomerGroupType().getDataFrame()
    }
  }
}
