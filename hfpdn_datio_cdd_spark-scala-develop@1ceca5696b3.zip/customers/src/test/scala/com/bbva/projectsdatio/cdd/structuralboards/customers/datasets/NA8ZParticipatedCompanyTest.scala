package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class NA8ZParticipatedCompanyTest extends TestCustomers {
  test("na8zParticipatedCompany_wrap") {
    val instancia: NA8ZParticipatedCompany = NA8ZParticipatedCompany(testResources.na8zParticipatedCompany_complete_input_testing, testResources.config)
    val result: NA8ZParticipatedCompany = instancia.wrap(testResources.na8zParticipatedCompany_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
