package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{CONF_KCTK_SOVEREIGN_EXT_RATING_RELEVANT_FIELDS, FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{StringType, StructType}

import scala.collection.JavaConverters.asScalaBufferConverter
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KCTKSovereignExtRatingTest extends TestCustomers {

  test("kctkSovereignExtRating_wrap") {
    val instancia: KCTKSovereignExtRating = KCTKSovereignExtRating(testResources.kctkSovereignExtRating_complete_input_testing, testResources.config)
    val result: KCTKSovereignExtRating = instancia.wrap(testResources.kctkSovereignExtRating_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kctkSovereignExtRating_generateEmptyDataSet") {
    val result: DataFrame = KCTKSovereignExtRating(testResources.testingEmptyDataFrame, testResources.config)
      .globalParameterSetter().applyEmpty(datioSparkSession, testResources.ktae_customers_after_join_testing_datio_schema).getDataFrame()
    val expectedSize = 0
    val relevantColumns = testResources.config.getStringList(CONF_KCTK_SOVEREIGN_EXT_RATING_RELEVANT_FIELDS).asScala.toList

    var expectedSchema: StructType = new StructType()
    expectedSchema = expectedSchema.add("g_residence_country_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_kctk_sovereign_ext_rating_relevant", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_kctk_sovereign_ext_rating_relevant_initialized", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_kctk_sovereign_ext_rating_relevant_renamed", StringType, TRUE_VALUE)

    StructType.apply(testResources.outputSchema.filter(a => relevantColumns.contains(a.name)).sortBy(_.name))
    val resultSchema : StructType = StructType.apply(result.schema.sortBy(_.name))
    assert(expectedSchema.simpleString.equals(resultSchema.simpleString))
    assert(result.count().equals(expectedSize.toLong))
  }
}
