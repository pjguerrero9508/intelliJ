package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import com.bbva.projectsdatio.cdd.structuralboards.customers.utils.TestUtils
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KCTKSvrgnOutRtgOtkTest extends TestCustomers {
  test("kctkSvrgnOutRtgOtk_wrap") {
    val instancia: KCTKSvrgnOutRtgOtk = KCTKSvrgnOutRtgOtk(testResources.kctkSvrgnOutRtgOtk_complete_input_testing, testResources.config)
    val result: KCTKSvrgnOutRtgOtk = instancia.wrap(testResources.kctkSvrgnOutRtgOtk_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kctkSvrgnOutRtgOtk_filterCustomerGroupType") {
    val result: DataFrame = KCTKSvrgnOutRtgOtk(testResources.kctkSvrgnOutRtgOtk_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.kctkSvrgnOutRtgOtk_customized_testing, false) shouldBe TRUE_VALUE
  }
}
