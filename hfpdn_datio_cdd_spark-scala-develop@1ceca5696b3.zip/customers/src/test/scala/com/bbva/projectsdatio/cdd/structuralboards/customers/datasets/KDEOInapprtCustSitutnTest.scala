package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KDEOInapprtCustSitutnTest extends TestCustomers {
  test("kdeoInapprtCustSitutn_wrap") {
    val instancia: KDEOInapprtCustSitutn = KDEOInapprtCustSitutn(testResources.kdeoInapprtCustSitutn_complete_input_testing, testResources.config)
    val result: KDEOInapprtCustSitutn = instancia.wrap(testResources.kdeoInapprtCustSitutn_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
