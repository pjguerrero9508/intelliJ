package com.bbva.projectsdatio.cdd.structuralboards.customers.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.NULL_VALUE
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.{DataFrame, Row}

class TestCustomersDataframes(datioSparkSession: DatioSparkSession) extends TestCustomersSchemas {

  //CDD DATASETS
  val testingEmptyDataRows: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
  val testingEmptyDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, testingDataSchema)
  val testingEmptyCDDCustomersDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, outputSchema)

  lazy val kbtqEomCustomer_complete_input_testing_rows = Seq(
    //                             g_customer_id   ,  g_bbva_owned_security_co_id, g_residence_country_id,  g_t_kbtq_eom_customer_relevant , g_t_kbtq_eom_customer_not_relevant  , g_t_kbtq_eom_customer_relevant_to_rename  , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "owned_security01"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_not_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "owned_security01"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_not_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "owned_security02"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_not_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "owned_security03"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_not_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "owned_security04"          , "MX"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_not_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema)
  )
  lazy val kbtqEomCustomer_customized_testing_rows = Seq(
    //                             g_customer_id   ,  g_bbva_owned_security_co_id, g_residence_country_id,  g_t_kbtq_eom_customer_relevant , g_t_kbtq_eom_customer_relevant_renamed    , g_t_kbtq_eom_customer_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "owned_security01"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                              , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "owned_security01"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                              , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "owned_security02"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                              , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "owned_security03"          , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                              , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "owned_security04"          , "MX"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                              , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomer_complete_input_testing_schema)
  )
  lazy val kbtqEomCustomer_complete_input_testing_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomCustomer_complete_input_testing_rows, 1)
  lazy val kbtqEomCustomer_customized_testing_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomCustomer_customized_testing_rows, 1)
  lazy val kbtqEomCustomer_complete_input: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomCustomer_complete_input_testing_rdd, kbtqEomCustomer_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kbtqEomCustomer_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomCustomer_customized_testing_rdd, kbtqEomCustomer_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kbtqEomEconInformation_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_kbtq_eom_econ_information_relevant ,  g_t_kbtq_eom_econ_information_not_relevant ,  g_t_kbtq_eom_econ_information_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_not_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_not_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_not_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_not_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_not_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_complete_input_testing_schema)
  )
  lazy val kbtqEomEconInformation_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_kbtq_eom_econ_information_relevant ,  g_t_kbtq_eom_econ_information_relevant_renamed    , g_t_kbtq_eom_econ_information_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomEconInformation_customized_testing_schema)
  )
  lazy val kbtqEomEconInformation_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomEconInformation_complete_input_testing_rows, 1)
  lazy val kbtqEomEconInformation_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomEconInformation_customized_testing_rows, 1)
  lazy val kbtqEomEconInformation_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomEconInformation_complete_input_testing_rows_rdd, kbtqEomEconInformation_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kbtqEomEconInformation_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomEconInformation_customized_testing_rows_rdd, kbtqEomEconInformation_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kcegCustomerEngagement_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_kceg_customer_engagement_relevant ,  g_t_kceg_customer_engagement_not_relevant ,  g_t_kceg_customer_engagement_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_not_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_not_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_not_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_not_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_not_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_complete_input_testing_schema)
  )
  lazy val kcegCustomerEngagement_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_kceg_customer_engagement_relevant ,  g_t_kceg_customer_engagement_relevant_renamed    , g_t_kceg_customer_engagement_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kcegCustomerEngagement_customized_testing_schema)
  )
  lazy val kcegCustomerEngagement_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kcegCustomerEngagement_complete_input_testing_rows, 1)
  lazy val kcegCustomerEngagement_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kcegCustomerEngagement_customized_testing_rows, 1)
  lazy val kcegCustomerEngagement_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kcegCustomerEngagement_complete_input_testing_rows_rdd, kcegCustomerEngagement_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kcegCustomerEngagement_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kcegCustomerEngagement_customized_testing_rows_rdd, kcegCustomerEngagement_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkCorpExtRating_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_kctk_corp_ext_rating_relevant ,  g_t_kctk_corp_ext_rating_not_relevant ,  g_t_kctk_corp_ext_rating_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_not_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_not_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_not_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_not_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_not_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_complete_input_testing_schema)
  )
  lazy val kctkCorpExtRating_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_kctk_corp_ext_rating_relevant ,  g_t_kctk_corp_ext_rating_relevant_renamed    , g_t_kctk_corp_ext_rating_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCorpExtRating_customized_testing_schema)
  )
  lazy val kctkCorpExtRating_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCorpExtRating_complete_input_testing_rows, 1)
  lazy val kctkCorpExtRating_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCorpExtRating_customized_testing_rows, 1)
  lazy val kctkCorpExtRating_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCorpExtRating_complete_input_testing_rows_rdd, kctkCorpExtRating_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkCorpExtRating_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCorpExtRating_customized_testing_rows_rdd, kctkCorpExtRating_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkCustRatingAtrb_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_kctk_cust_rating_atrb_relevant ,  g_t_kctk_cust_rating_atrb_not_relevant ,  g_t_kctk_cust_rating_atrb_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_not_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_not_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_not_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_not_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_not_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_complete_input_testing_schema)
  )
  lazy val kctkCustRatingAtrb_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_kctk_cust_rating_atrb_relevant ,  g_t_kctk_cust_rating_atrb_relevant_renamed    , g_t_kctk_cust_rating_atrb_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustRatingAtrb_customized_testing_schema)
  )
  lazy val kctkCustRatingAtrb_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCustRatingAtrb_complete_input_testing_rows, 1)
  lazy val kctkCustRatingAtrb_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCustRatingAtrb_customized_testing_rows, 1)
  lazy val kctkCustRatingAtrb_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCustRatingAtrb_complete_input_testing_rows_rdd, kctkCustRatingAtrb_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkCustRatingAtrb_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCustRatingAtrb_customized_testing_rows_rdd, kctkCustRatingAtrb_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkCustSplProjectRels_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_kctk_cust_spl_project_rels_relevant ,  g_t_kctk_cust_spl_project_rels_not_relevant ,  g_t_kctk_cust_spl_project_rels_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_not_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_not_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_not_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_not_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_not_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_complete_input_testing_schema)
  )
  lazy val kctkCustSplProjectRels_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_kctk_cust_spl_project_rels_relevant ,  g_t_kctk_cust_spl_project_rels_relevant_renamed    , g_t_kctk_cust_spl_project_rels_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCustSplProjectRels_customized_testing_schema)
  )
  lazy val kctkCustSplProjectRels_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCustSplProjectRels_complete_input_testing_rows, 1)
  lazy val kctkCustSplProjectRels_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCustSplProjectRels_customized_testing_rows, 1)
  lazy val kctkCustSplProjectRels_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCustSplProjectRels_complete_input_testing_rows_rdd, kctkCustSplProjectRels_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkCustSplProjectRels_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCustSplProjectRels_customized_testing_rows_rdd, kctkCustSplProjectRels_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkSovereignExtRating_complete_input_testing_rows = Seq(
    //                             g_country_id,  g_t_kctk_sovereign_ext_rating_relevant ,  g_t_kctk_sovereign_ext_rating_not_relevant ,  g_t_kctk_sovereign_ext_rating_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("ES"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_not_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("MX"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_not_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("PE"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_not_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("CO"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_not_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_complete_input_testing_schema),
    new GenericRowWithSchema(Array("AR"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_not_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_complete_input_testing_schema)
  )
  lazy val kctkSovereignExtRating_customized_testing_rows = Seq(
    //                             g_country_id, g_t_kctk_sovereign_ext_rating_relevant ,  g_t_kctk_sovereign_ext_rating_relevant_renamed    , g_t_kctk_sovereign_ext_rating_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("ES"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("MX"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("PE"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("CO"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_customized_testing_schema),
    new GenericRowWithSchema(Array("AR"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSovereignExtRating_customized_testing_schema)
  )
  lazy val kctkSovereignExtRating_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkSovereignExtRating_complete_input_testing_rows, 1)
  lazy val kctkSovereignExtRating_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkSovereignExtRating_customized_testing_rows, 1)
  lazy val kctkSovereignExtRating_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkSovereignExtRating_complete_input_testing_rows_rdd, kctkSovereignExtRating_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkSovereignExtRating_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkSovereignExtRating_customized_testing_rows_rdd, kctkSovereignExtRating_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kdeoInapprtCustSitutn_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_kdeo_inapprt_cust_situtn_relevant ,  g_t_kdeo_inapprt_cust_situtn_not_relevant ,  g_t_kdeo_inapprt_cust_situtn_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_not_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_not_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_not_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_not_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_not_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_complete_input_testing_schema)
  )
  lazy val kdeoInapprtCustSitutn_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_kdeo_inapprt_cust_situtn_relevant ,  g_t_kdeo_inapprt_cust_situtn_relevant_renamed    , g_t_kdeo_inapprt_cust_situtn_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtCustSitutn_customized_testing_schema)
  )
  lazy val kdeoInapprtCustSitutn_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoInapprtCustSitutn_complete_input_testing_rows, 1)
  lazy val kdeoInapprtCustSitutn_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoInapprtCustSitutn_customized_testing_rows, 1)
  lazy val kdeoInapprtCustSitutn_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoInapprtCustSitutn_complete_input_testing_rows_rdd, kdeoInapprtCustSitutn_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kdeoInapprtCustSitutn_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoInapprtCustSitutn_customized_testing_rows_rdd, kdeoInapprtCustSitutn_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksagEomLocalGroup_complete_input_testing_rows = Seq(
    //                             g_group_id,  g_t_ksag_eom_local_group_relevant ,  g_t_ksag_eom_local_group_not_relevant ,  g_t_ksag_eom_local_group_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("GR0001"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_not_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("GR0002"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_not_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("GR0003"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_not_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("GR0004"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_not_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("GR0005"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_not_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_complete_input_testing_schema)
  )
  lazy val ksagEomLocalGroup_customized_testing_rows = Seq(
    //                             g_group_id,  g_t_ksag_eom_local_group_relevant ,  g_t_ksag_eom_local_group_relevant_renamed    , g_t_ksag_eom_local_group_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("GR0001"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("GR0002"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("GR0003"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("GR0004"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("GR0005"  , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomLocalGroup_customized_testing_schema)
  )
  lazy val ksagEomLocalGroup_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomLocalGroup_complete_input_testing_rows, 1)
  lazy val ksagEomLocalGroup_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomLocalGroup_customized_testing_rows, 1)
  lazy val ksagEomLocalGroup_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomLocalGroup_complete_input_testing_rows_rdd, ksagEomLocalGroup_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksagEomLocalGroup_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomLocalGroup_customized_testing_rows_rdd, ksagEomLocalGroup_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksagEomPrtcptLclGroup_complete_input_testing_rows = Seq(
    //                             g_customer_id   , g_group_id, g_customer_main_group_ind_type, g_spec_lc_reglty_grp_ind_type ,  g_t_ksag_eom_prtcpt_lcl_group_relevant ,  g_t_ksag_eom_prtcpt_lcl_group_not_relevant ,  g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "GR0001"  , "Y"                           , "Y"                           , "g_t_ksag_eom_prtcpt_lcl_group_relevant", "g_t_ksag_eom_prtcpt_lcl_group_not_relevant", "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "GR0002"  , "Y"                           , "Y"                           , "g_t_ksag_eom_prtcpt_lcl_group_relevant", "g_t_ksag_eom_prtcpt_lcl_group_not_relevant", "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "GR0003"  , "Y"                           , "Y"                           , "g_t_ksag_eom_prtcpt_lcl_group_relevant", "g_t_ksag_eom_prtcpt_lcl_group_not_relevant", "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "GR0004"  , "Y"                           , "Y"                           , "g_t_ksag_eom_prtcpt_lcl_group_relevant", "g_t_ksag_eom_prtcpt_lcl_group_not_relevant", "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "GR0005"  , "Y"                           , "Y"                           , "g_t_ksag_eom_prtcpt_lcl_group_relevant", "g_t_ksag_eom_prtcpt_lcl_group_not_relevant", "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_complete_input_testing_schema),
  )
  lazy val ksagEomPrtcptLclGroup_customized_testing_rows = Seq(
    //                             g_customer_id   , g_group_id, gf_local_reglty_spec_group_id, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "GR0001"  , "GR0001"                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "GR0002"  , "GR0002"                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "GR0003"  , "GR0003"                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "GR0004"  , "GR0004"                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "GR0005"  , "GR0005"                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomPrtcptLclGroup_customized_testing_schema)
  )
  lazy val ksagEomPrtcptLclGroup_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomPrtcptLclGroup_complete_input_testing_rows, 1)
  lazy val ksagEomPrtcptLclGroup_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomPrtcptLclGroup_customized_testing_rows, 1)
  lazy val ksagEomPrtcptLclGroup_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomPrtcptLclGroup_complete_input_testing_rows_rdd, ksagEomPrtcptLclGroup_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksagEomPrtcptLclGroup_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomPrtcptLclGroup_customized_testing_rows_rdd, ksagEomPrtcptLclGroup_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksagEomSectorization_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_ksag_eom_sectorization_relevant ,  g_t_ksag_eom_sectorization_not_relevant ,  g_t_ksag_eom_sectorization_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_not_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_not_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_not_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_not_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_not_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_complete_input_testing_schema)
  )
  lazy val ksagEomSectorization_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_ksag_eom_sectorization_relevant ,  g_t_ksag_eom_sectorization_relevant_renamed    , g_t_ksag_eom_sectorization_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSectorization_customized_testing_schema)
  )
  lazy val ksagEomSectorization_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomSectorization_complete_input_testing_rows, 1)
  lazy val ksagEomSectorization_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomSectorization_customized_testing_rows, 1)
  lazy val ksagEomSectorization_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomSectorization_complete_input_testing_rows_rdd, ksagEomSectorization_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksagEomSectorization_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomSectorization_customized_testing_rows_rdd, ksagEomSectorization_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ksagEomSegmentation_complete_input_testing_rows = Seq(
    //                             g_customer_id,  g_t_ksag_eom_segmentation_relevant ,  g_t_ksag_eom_segmentation_not_relevant ,  g_t_ksag_eom_segmentation_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_not_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_not_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_not_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_not_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_not_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_complete_input_testing_schema)
  )
  lazy val ksagEomSegmentation_customized_testing_rows = Seq(
    //                             g_customer_id,  g_t_ksag_eom_segmentation_relevant ,  g_t_ksag_eom_segmentation_relevant_renamed    , g_t_ksag_eom_segmentation_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005"     , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), ksagEomSegmentation_customized_testing_schema)
  )
  lazy val ksagEomSegmentation_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomSegmentation_complete_input_testing_rows, 1)
  lazy val ksagEomSegmentation_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ksagEomSegmentation_customized_testing_rows, 1)
  lazy val ksagEomSegmentation_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomSegmentation_complete_input_testing_rows_rdd, ksagEomSegmentation_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val ksagEomSegmentation_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ksagEomSegmentation_customized_testing_rows_rdd, ksagEomSegmentation_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  
  lazy val na8zParticipatedCompany_complete_input_testing_rows = Seq(
    //                             g_bbva_owned_security_co_id,  g_t_na8z_participated_company_relevant ,  g_t_na8z_participated_company_not_relevant ,  g_t_na8z_participated_company_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("owned_security01"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_not_relevant", "g_t_na8z_participated_company_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_complete_input_testing_schema),
    new GenericRowWithSchema(Array("owned_security02"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_not_relevant", "g_t_na8z_participated_company_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_complete_input_testing_schema),
    new GenericRowWithSchema(Array("owned_security03"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_not_relevant", "g_t_na8z_participated_company_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_complete_input_testing_schema),
    new GenericRowWithSchema(Array("owned_security04"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_not_relevant", "g_t_na8z_participated_company_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_complete_input_testing_schema),
    new GenericRowWithSchema(Array("owned_security05"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_not_relevant", "g_t_na8z_participated_company_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_complete_input_testing_schema)
  )
  lazy val na8zParticipatedCompany_customized_testing_rows = Seq(
    //                             g_bbva_owned_security_co_id,  g_t_na8z_participated_company_relevant ,  g_t_na8z_participated_company_relevant_renamed    , g_t_na8z_participated_company_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("owned_security01"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_customized_testing_schema),
    new GenericRowWithSchema(Array("owned_security02"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_customized_testing_schema),
    new GenericRowWithSchema(Array("owned_security03"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_customized_testing_schema),
    new GenericRowWithSchema(Array("owned_security04"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_customized_testing_schema),
    new GenericRowWithSchema(Array("owned_security05"         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), na8zParticipatedCompany_customized_testing_schema)
  )
  lazy val na8zParticipatedCompany_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(na8zParticipatedCompany_complete_input_testing_rows, 1)
  lazy val na8zParticipatedCompany_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(na8zParticipatedCompany_customized_testing_rows, 1)
  lazy val na8zParticipatedCompany_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(na8zParticipatedCompany_complete_input_testing_rows_rdd, na8zParticipatedCompany_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val na8zParticipatedCompany_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(na8zParticipatedCompany_customized_testing_rows_rdd, na8zParticipatedCompany_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkSvrgnOutRtgOtk_complete_input_testing_rows = Seq(
    //                             g_country_id, g_record_rating_type , "gf_rating_generation_date" ,  g_t_kctk_svrgn_out_rtg_otk_relevant ,  g_t_kctk_svrgn_out_rtg_otk_not_relevant ,  g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("ES"        , "3"                  , "2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("ES"        , "4"                  , "2020-07-28"                , "g_t_kctk_svrgn_out_rtg_otk_relevant_bad", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("ES"        , "4"                  , "2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("MX"        , "4"                  , "2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("PE"        , "4"                  , "2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("CO"        , "4"                  , "2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema),
    new GenericRowWithSchema(Array("AR"        , "4"                  , "2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_not_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_complete_input_testing_schema)
  )
  lazy val kctkSvrgnOutRtgOtk_customized_testing_rows = Seq(
    //                             g_country_id, g_record_rating_type ,"gf_rating_generation_date" ,  g_t_kctk_svrgn_out_rtg_otk_relevant ,  g_t_kctk_svrgn_out_rtg_otk_relevant_renamed    , g_t_kctk_sovereign_ext_rating_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("ES"        , "4"                  ,"2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_customized_testing_schema),
    new GenericRowWithSchema(Array("MX"        , "4"                  ,"2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_customized_testing_schema),
    new GenericRowWithSchema(Array("PE"        , "4"                  ,"2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_customized_testing_schema),
    new GenericRowWithSchema(Array("CO"        , "4"                  ,"2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_customized_testing_schema),
    new GenericRowWithSchema(Array("AR"        , "4"                  ,"2020-07-31"                , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkSvrgnOutRtgOtk_customized_testing_schema)
  )
  lazy val kctkSvrgnOutRtgOtk_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkSvrgnOutRtgOtk_complete_input_testing_rows, 1)
  lazy val kctkSvrgnOutRtgOtk_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkSvrgnOutRtgOtk_customized_testing_rows, 1)
  lazy val kctkSvrgnOutRtgOtk_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkSvrgnOutRtgOtk_complete_input_testing_rows_rdd, kctkSvrgnOutRtgOtk_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkSvrgnOutRtgOtk_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkSvrgnOutRtgOtk_customized_testing_rows_rdd, kctkSvrgnOutRtgOtk_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kbtqEomIncomeSource_complete_input_testing_rows = Seq(
    //                             g_customer_id,     g_t_kbtq_eom_income_source_relevant ,  g_t_kbtq_eom_income_source_not_relevant ,  g_t_kbtq_eom_income_source_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_not_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_not_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_not_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_not_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_not_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_complete_input_testing_schema)
  )
  lazy val kbtqEomIncomeSource_customized_testing_rows = Seq(
    //                             g_customer_id,     g_t_kbtq_eom_income_source_relevant ,  g_t_kbtq_eom_income_source_relevant_renamed   , g_t_kbtq_eom_income_source_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomIncomeSource_customized_testing_schema)
  )
  lazy val kbtqEomIncomeSource_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomIncomeSource_complete_input_testing_rows, 1)
  lazy val kbtqEomIncomeSource_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomIncomeSource_customized_testing_rows, 1)
  lazy val kbtqEomIncomeSource_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomIncomeSource_complete_input_testing_rows_rdd, kbtqEomIncomeSource_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kbtqEomIncomeSource_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomIncomeSource_customized_testing_rows_rdd, kbtqEomIncomeSource_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kbtqEomCustomerIndicator_complete_input_testing_rows = Seq(
    //                             g_customer_id,     g_t_kbtq_eom_customer_indicator_relevant ,  g_t_kbtq_eom_customer_indicator_not_relevant ,  g_t_kbtq_eom_customer_indicator_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_not_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_not_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_not_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_not_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_complete_input_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_not_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_complete_input_testing_schema)
  )
  lazy val kbtqEomCustomerIndicator_customized_testing_rows = Seq(
    //                             g_customer_id,     g_t_kbtq_eom_customer_indicator_relevant ,  g_t_kbtq_eom_customer_indicator_relevant_renamed   , g_t_kbtq_eom_customer_indicator_relevant_initialized , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("customerId0001", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0002", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0003", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0004", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_customized_testing_schema),
    new GenericRowWithSchema(Array("customerId0005", "g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kbtqEomCustomerIndicator_customized_testing_schema)
  )
  lazy val kbtqEomCustomerIndicator_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomCustomerIndicator_complete_input_testing_rows, 1)
  lazy val kbtqEomCustomerIndicator_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kbtqEomCustomerIndicator_customized_testing_rows, 1)
  lazy val kbtqEomCustomerIndicator_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomCustomerIndicator_complete_input_testing_rows_rdd, kbtqEomCustomerIndicator_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kbtqEomCustomerIndicator_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kbtqEomCustomerIndicator_customized_testing_rows_rdd, kbtqEomCustomerIndicator_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ktae_customers_after_join_rows = Seq(
    //                             g_bbva_owned_security_co_id, g_customer_id   , g_group_id  , g_residence_country_id,  g_t_kbtq_eom_customer_relevant ,  g_t_kbtq_eom_customer_relevant_renamed   , g_t_kbtq_eom_customer_relevant_initialized, gf_cutoff_date,g_entific_id,  g_t_kctk_sovereign_ext_rating_relevant ,  g_t_kctk_sovereign_ext_rating_relevant_renamed   , g_t_kctk_sovereign_ext_rating_relevant_initialized ,g_record_rating_type ,"gf_rating_generation_date",  g_t_kctk_svrgn_out_rtg_otk_relevant ,  g_t_kctk_svrgn_out_rtg_otk_relevant_renamed   , g_t_kctk_svrgn_out_rtg_otk_relevant_initialized , g_t_kbtq_eom_income_source_relevant ,  g_t_kbtq_eom_income_source_relevant_renamed   , g_t_kbtq_eom_income_source_relevant_initialized, gf_local_reglty_spec_group_id, g_t_kbtq_eom_customer_indicator_relevant ,  g_t_kbtq_eom_customer_indicator_relevant_renamed   , g_t_kbtq_eom_customer_indicator_relevant_initialized ,  g_t_ksag_eom_local_group_relevant ,  g_t_ksag_eom_local_group_relevant_renamed   , g_t_ksag_eom_local_group_relevant_initialized,  g_t_kctk_corp_ext_rating_relevant,   g_t_kctk_corp_ext_rating_relevant_renamed   , g_t_kctk_corp_ext_rating_relevant_initialized ,  g_t_kbtq_eom_econ_information_relevant,   g_t_kbtq_eom_econ_information_relevant_renamed   , g_t_kbtq_eom_econ_information_relevant_initialized,  g_t_kceg_customer_engagement_relevant ,  g_t_kceg_customer_engagement_relevant_renamed, g_t_kceg_customer_engagement_relevant_initialized,  g_t_ksag_eom_segmentation_relevant,   g_t_ksag_eom_segmentation_relevant_renamed   , g_t_ksag_eom_segmentation_relevant_initialized,  g_t_kdeo_inapprt_cust_situtn_relevant ,  g_t_kdeo_inapprt_cust_situtn_relevant_renamed   , g_t_kdeo_inapprt_cust_situtn_relevant_initialized,  g_t_ksag_eom_sectorization_relevant ,  g_t_ksag_eom_sectorization_relevant_renamed   , g_t_ksag_eom_sectorization_relevant_initialized,  g_t_kctk_cust_rating_atrb_relevant ,  g_t_kctk_cust_rating_atrb_relevant_renamed   , g_t_kctk_cust_rating_atrb_relevant_initialized,  g_t_kctk_cust_spl_project_rels_relevant ,  g_t_kctk_cust_spl_project_rels_relevant_renamed   , g_t_kctk_cust_spl_project_rels_relevant_initialized,  g_t_na8z_participated_company_relevant ,  g_t_na8z_participated_company_relevant_renamed   , g_t_na8z_participated_company_relevant_initialized, gf_audit_date
    new GenericRowWithSchema(Array("owned_security01"         , "customerId0001", "GR0001"    , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                                , "2020-07-31"  ,"GL"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                                         ,"4"                  ,"2020-07-31"               , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                                      ,"g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "GR0001"                     ,"g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                                   , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                                    , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                                        , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                                    , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                                    , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                                       , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                                     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                                    , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                                         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                                        , "2020-01-01 04:32:32.111111"), ktae_customers_after_join_testing_schema),
    new GenericRowWithSchema(Array("owned_security01"         , "customerId0002", "GR0002"    , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                                , "2020-07-31"  ,"GL"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                                         ,"4"                  ,"2020-07-31"               , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                                      ,"g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "GR0002"                     ,"g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                                   , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                                    , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                                        , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                                    , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                                    , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                                       , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                                     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                                    , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                                         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                                        , "2020-01-01 04:32:32.111111"), ktae_customers_after_join_testing_schema),
    new GenericRowWithSchema(Array("owned_security02"         , "customerId0003", "GR0003"    , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                                , "2020-07-31"  ,"GL"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                                         ,"4"                  ,"2020-07-31"               , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                                      ,"g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "GR0003"                     ,"g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                                   , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                                    , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                                        , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                                    , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                                    , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                                       , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                                     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                                    , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                                         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                                        , "2020-01-01 04:32:32.111111"), ktae_customers_after_join_testing_schema),
    new GenericRowWithSchema(Array("owned_security03"         , "customerId0004", "GR0004"    , "ES"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                                , "2020-07-31"  ,"GL"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                                         ,"4"                  ,"2020-07-31"               , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                                      ,"g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "GR0004"                     ,"g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                                   , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                                    , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                                        , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                                    , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                                    , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                                       , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                                     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                                    , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                                         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                                        , "2020-01-01 04:32:32.111111"), ktae_customers_after_join_testing_schema),
    new GenericRowWithSchema(Array("owned_security04"         , "customerId0005", "GR0005"    , "MX"                  , "g_t_kbtq_eom_customer_relevant", "g_t_kbtq_eom_customer_relevant_to_rename", NULL_VALUE                                , "2020-07-31"  ,"GL"        , "g_t_kctk_sovereign_ext_rating_relevant", "g_t_kctk_sovereign_ext_rating_relevant_to_rename", NULL_VALUE                                         ,"4"                  ,"2020-07-31"               , "g_t_kctk_svrgn_out_rtg_otk_relevant", "g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename", NULL_VALUE                                      ,"g_t_kbtq_eom_income_source_relevant", "g_t_kbtq_eom_income_source_relevant_to_rename", NULL_VALUE                                     , "GR0005"                     ,"g_t_kbtq_eom_customer_indicator_relevant", "g_t_kbtq_eom_customer_indicator_relevant_to_rename", NULL_VALUE                                           , "g_t_ksag_eom_local_group_relevant", "g_t_ksag_eom_local_group_relevant_to_rename", NULL_VALUE                                   , "g_t_kctk_corp_ext_rating_relevant", "g_t_kctk_corp_ext_rating_relevant_to_rename", NULL_VALUE                                    , "g_t_kbtq_eom_econ_information_relevant", "g_t_kbtq_eom_econ_information_relevant_to_rename", NULL_VALUE                                        , "g_t_kceg_customer_engagement_relevant", "g_t_kceg_customer_engagement_relevant_to_rename", NULL_VALUE                                    , "g_t_ksag_eom_segmentation_relevant", "g_t_ksag_eom_segmentation_relevant_to_rename", NULL_VALUE                                    , "g_t_kdeo_inapprt_cust_situtn_relevant", "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename", NULL_VALUE                                       , "g_t_ksag_eom_sectorization_relevant", "g_t_ksag_eom_sectorization_relevant_to_rename", NULL_VALUE                                     , "g_t_kctk_cust_rating_atrb_relevant", "g_t_kctk_cust_rating_atrb_relevant_to_rename", NULL_VALUE                                    , "g_t_kctk_cust_spl_project_rels_relevant", "g_t_kctk_cust_spl_project_rels_relevant_to_rename", NULL_VALUE                                         , "g_t_na8z_participated_company_relevant", "g_t_na8z_participated_company_relevant_to_rename", NULL_VALUE                                        , "2020-01-01 04:32:32.111111"), ktae_customers_after_join_testing_schema)
  )
  lazy val ktae_customers_after_join_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ktae_customers_after_join_rows, 1)
  lazy val ktae_customers_after_join_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ktae_customers_after_join_testing_rows_rdd, ktae_customers_after_join_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
}
