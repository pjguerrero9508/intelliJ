package com.bbva.projectsdatio.cdd.structuralboards.customers.utils

import java.net.URI

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.SchemaReadingException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.datio.dataproc.sdk.schema.{DatioSchema, DatioSchemaForTesting}
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import org.mockito.Mockito.spy

trait TestCustomersSchemas {

  //PATHS
  lazy val schemaPath: String = "src/test/resources/schemas/customers/t_ktae_customer_struc_board.json"

  //SCHEMAS
  lazy val outputSchema: StructType = DatioSchema.getBuilder.fromURI(URI.create(schemaPath)).build().getStructType
  lazy val testingDataSchema: StructType = StructType(List(
    StructField("String", DataTypes.StringType, TRUE_VALUE),
    StructField("Int", DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double", DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date", DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))

  lazy val kbtqEomCustomer_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_bbva_owned_security_co_id",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_residence_country_id",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kbtqEomCustomer_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_customer_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kbtqEomEconInformation_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_econ_information_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kbtqEomEconInformation_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_econ_information_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kcegCustomerEngagement_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kceg_customer_engagement_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kcegCustomerEngagement_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kceg_customer_engagement_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkCorpExtRating_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_corp_ext_rating_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkCorpExtRating_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_corp_ext_rating_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkCustRatingAtrb_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_cust_rating_atrb_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkCustRatingAtrb_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_cust_rating_atrb_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkCustSplProjectRels_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_cust_spl_project_rels_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkCustSplProjectRels_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_cust_spl_project_rels_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkSovereignExtRating_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_country_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_sovereign_ext_rating_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_sovereign_ext_rating_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_sovereign_ext_rating_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkSovereignExtRating_customized_testing_schema: StructType = StructType(List(
    StructField("g_country_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_sovereign_ext_rating_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_sovereign_ext_rating_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_sovereign_ext_rating_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kdeoInapprtCustSitutn_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoInapprtCustSitutn_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ksagEomLocalGroup_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_group_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksag_eom_local_group_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksagEomLocalGroup_customized_testing_schema: StructType = StructType(List(
    StructField("g_group_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksag_eom_local_group_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ksagEomPrtcptLclGroup_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_group_id",                                           DataTypes.StringType, TRUE_VALUE), //Para poder cruzar con ksagEomLocalGroup
    StructField("g_customer_main_group_ind_type",                       DataTypes.StringType, TRUE_VALUE), //Filtrado == Y
    StructField("g_spec_lc_reglty_grp_ind_type",                        DataTypes.StringType, TRUE_VALUE), //Filtrado == Y
    StructField("g_t_ksag_eom_prtcpt_lcl_group_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_prtcpt_lcl_group_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksagEomPrtcptLclGroup_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_group_id",                                           DataTypes.StringType, TRUE_VALUE), //Para poder cruzar con ksagEomLocalGroup
    StructField("gf_local_reglty_spec_group_id",                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ksagEomSectorization_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksag_eom_sectorization_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksagEomSectorization_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksag_eom_sectorization_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ksagEomSegmentation_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksag_eom_segmentation_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val ksagEomSegmentation_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_ksag_eom_segmentation_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val na8zParticipatedCompany_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_bbva_owned_security_co_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_na8z_participated_company_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val na8zParticipatedCompany_customized_testing_schema: StructType = StructType(List(
    StructField("g_bbva_owned_security_co_id",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_na8z_participated_company_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkSvrgnOutRtgOtk_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_country_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_record_rating_type",                           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_rating_generation_date",                      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_not_relevant",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                  DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkSvrgnOutRtgOtk_customized_testing_schema: StructType = StructType(List(
    StructField("g_residence_country_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_record_rating_type",                             DataTypes.StringType, TRUE_VALUE),
    StructField("gf_rating_generation_date",                        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kbtqEomCustomerIndicator_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_customer_indicator_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_not_relevant",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_relevant_to_rename",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kbtqEomCustomerIndicator_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_customer_indicator_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                          DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kbtqEomIncomeSource_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_income_source_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_not_relevant",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_relevant_to_rename",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                  DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kbtqEomIncomeSource_customized_testing_schema: StructType = StructType(List(
    StructField("g_customer_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kbtq_eom_income_source_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_customers_after_join_testing_schema: StructType = StructType(List(
    StructField("g_bbva_owned_security_co_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_customer_id",                                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_group_id",                                            DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_residence_country_id",                                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant",                        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant_renamed",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_relevant_initialized",            DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_sovereign_ext_rating_relevant",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_sovereign_ext_rating_relevant_renamed",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_sovereign_ext_rating_relevant_initialized",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_record_rating_type",                                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_rating_generation_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_income_source_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_local_reglty_spec_group_id",                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_customer_indicator_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_relevant",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_relevant_renamed",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_local_group_relevant_initialized",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_relevant",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_relevant_renamed",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_corp_ext_rating_relevant_initialized",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_relevant",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_relevant_renamed",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kbtq_eom_econ_information_relevant_initialized",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_relevant",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_relevant_renamed",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kceg_customer_engagement_relevant_initialized",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_relevant",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_relevant_renamed",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_segmentation_relevant_initialized",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant_renamed",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_cust_situtn_relevant_initialized",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_ksag_eom_sectorization_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_relevant",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_relevant_renamed",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_rating_atrb_relevant_initialized",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_cust_spl_project_rels_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_relevant",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_relevant_renamed",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_na8z_participated_company_relevant_initialized",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kbtqEomCustomer_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomCustomer_complete_input_testing_schema))
  lazy val kbtqEomCustomer_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomCustomer_customized_testing_schema))
  lazy val kbtqEomEconInformation_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomEconInformation_complete_input_testing_schema))
  lazy val kbtqEomEconInformation_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomEconInformation_customized_testing_schema))
  lazy val kcegCustomerEngagement_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kcegCustomerEngagement_complete_input_testing_schema))
  lazy val kcegCustomerEngagement_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kcegCustomerEngagement_customized_testing_schema))
  lazy val kctkCorpExtRating_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCorpExtRating_complete_input_testing_schema))
  lazy val kctkCorpExtRating_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCorpExtRating_customized_testing_schema))
  lazy val kctkCustRatingAtrb_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCustRatingAtrb_complete_input_testing_schema))
  lazy val kctkCustRatingAtrb_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCustRatingAtrb_customized_testing_schema))
  lazy val kctkCustSplProjectRels_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCustSplProjectRels_complete_input_testing_schema))
  lazy val kctkCustSplProjectRels_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCustSplProjectRels_customized_testing_schema))
  lazy val kctkSovereignExtRating_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkSovereignExtRating_complete_input_testing_schema))
  lazy val kctkSovereignExtRating_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkSovereignExtRating_customized_testing_schema))
  lazy val kdeoInapprtCustSitutn_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoInapprtCustSitutn_complete_input_testing_schema))
  lazy val kdeoInapprtCustSitutn_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoInapprtCustSitutn_customized_testing_schema))
  lazy val ksagEomLocalGroup_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomLocalGroup_complete_input_testing_schema))
  lazy val ksagEomLocalGroup_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomLocalGroup_customized_testing_schema))
  lazy val ksagEomPrtcptLclGroup_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomPrtcptLclGroup_complete_input_testing_schema))
  lazy val ksagEomPrtcptLclGroup_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomPrtcptLclGroup_customized_testing_schema))
  lazy val ksagEomSectorization_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomSectorization_complete_input_testing_schema))
  lazy val ksagEomSectorization_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomSectorization_customized_testing_schema))
  lazy val ksagEomSegmentation_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomSegmentation_complete_input_testing_schema))
  lazy val ksagEomSegmentation_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ksagEomSegmentation_customized_testing_schema))
  lazy val ktae_customers_after_join_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_customers_after_join_testing_schema))
  lazy val kbtqEomIncomeSource_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomIncomeSource_complete_input_testing_schema))
  lazy val kbtqEomIncomeSource_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomIncomeSource_customized_testing_schema))
  lazy val kbtqEomCustomerIndicator_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomCustomerIndicator_complete_input_testing_schema))
  lazy val kbtqEomCustomerIndicator_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kbtqEomCustomerIndicator_customized_testing_schema))
}
