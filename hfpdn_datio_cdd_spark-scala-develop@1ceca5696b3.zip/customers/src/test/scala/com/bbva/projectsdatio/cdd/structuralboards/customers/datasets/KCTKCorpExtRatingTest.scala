package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KCTKCorpExtRatingTest extends TestCustomers {
  test("kctkCorpExtRating_wrap") {
    val instancia: KCTKCorpExtRating = KCTKCorpExtRating(testResources.kctkCorpExtRating_complete_input_testing, testResources.config)
    val result: KCTKCorpExtRating = instancia.wrap(testResources.kctkCorpExtRating_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
