package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KCEGCustomerEngagementTest extends TestCustomers {
  test("kcegCustomerEngagement_wrap") {
    val instancia: KCEGCustomerEngagement = KCEGCustomerEngagement(testResources.kcegCustomerEngagement_complete_input_testing, testResources.config)
    val result: KCEGCustomerEngagement = instancia.wrap(testResources.kcegCustomerEngagement_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
