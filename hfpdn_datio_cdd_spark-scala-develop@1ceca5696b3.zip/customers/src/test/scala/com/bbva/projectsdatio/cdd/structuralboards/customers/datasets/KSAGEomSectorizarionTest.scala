package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSAGEomSectorizarionTest extends TestCustomers {
  test("ksagEomSectorization_wrap") {
    val instancia: KSAGEomSectorization = KSAGEomSectorization(testResources.ksagEomSectorization_complete_input_testing, testResources.config)
    val result: KSAGEomSectorization = instancia.wrap(testResources.ksagEomSectorization_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
