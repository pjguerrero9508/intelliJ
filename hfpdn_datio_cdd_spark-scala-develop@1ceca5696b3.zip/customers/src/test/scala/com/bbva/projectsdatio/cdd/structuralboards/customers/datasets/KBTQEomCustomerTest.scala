package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import com.bbva.projectsdatio.cdd.structuralboards.customers.utils.TestUtils
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import com.typesafe.config.ConfigException

@RunWith(classOf[JUnitRunner])
class KBTQEomCustomerTest extends TestCustomers {

  test("kbtqEomCustomer_wrap") {
    val instancia: KBTQEomCustomer = KBTQEomCustomer(testResources.kbtqEomEconInformation_complete_input_testing, testResources.config)
    val result: KBTQEomCustomer = instancia.wrap(testResources.kbtqEomEconInformation_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kbtqEomCustomer_selectTablonColumns") {
    val result: DataFrame = KBTQEomCustomer(testResources.ktae_customers_after_join_testing, testResources.config).selectTablonColumns().getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ktae_customers_after_join_testing, false) shouldBe TRUE_VALUE
  }

  test("kbtqEomCustomer_selectTablonColumnsBadSelect") {
    assertThrows[AnalysisException] {
      KBTQEomCustomer(testResources.ktae_customers_after_join_testing, testResources.configBadSelect).selectTablonColumns().getDataFrame()
    }
  }

  test("kbtqEomCustomer_selectTablonColumnsMissSelect") {
    assertThrows[ConfigException.Missing] {
      KBTQEomCustomer(testResources.ktae_customers_after_join_testing, testResources.configMissSelect).selectTablonColumns().getDataFrame()
    }
  }
}
