package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.CDDStructuralBoardsDataset
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils
import com.bbva.projectsdatio.cdd.structuralboards.customers.app.StructuralboardsCustomers_RQ42021
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import com.bbva.projectsdatio.cdd.structuralboards.customers.utils.TestUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class CustomersIngestionTest extends TestCustomers {

  /* test("customersIngestion_joinTablon") {
    val kbtqEomCustomer = KBTQEomCustomer(testResources.kbtqEomCustomer_complete_input, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kbtqEomEconInformation = KBTQEomEconInformation(testResources.kbtqEomEconInformation_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kcegCustomerEngagement = KCEGCustomerEngagement(testResources.kcegCustomerEngagement_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kctkCorpExtRating = KCTKCorpExtRating(testResources.kctkCorpExtRating_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kctkCustRatingAtrb = KCTKCustRatingAtrb(testResources.kctkCustRatingAtrb_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoInapprtCustSitutn = KDEOInapprtCustSitutn(testResources.kdeoInapprtCustSitutn_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val ksagEomLocalGroup = KSAGEomLocalGroup(testResources.ksagEomLocalGroup_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val ksagEomPrtcptLclGroup = KSAGEomPrtcptLclGroup(testResources.ksagEomPrtcptLclGroup_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val ksagEomSectorization = KSAGEomSectorization(testResources.ksagEomSectorization_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val ksagEomSegmentation = KSAGEomSegmentation(testResources.ksagEomSegmentation_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kctkSovereignExtRating = KCTKSovereignExtRating(testResources.kctkSovereignExtRating_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val na8zParticipatedCompany = NA8ZParticipatedCompany(testResources.na8zParticipatedCompany_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kctkCustSplProjectRels = KCTKCustSplProjectRels(testResources.kctkCustSplProjectRels_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kctkSvrgnOutRtgOtk = KCTKSvrgnOutRtgOtk(testResources.kctkSvrgnOutRtgOtk_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kbtqEomIncomeSource = KBTQEomIncomeSource(testResources.kbtqEomIncomeSource_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val kbtqEomCustomerIndicator = KBTQEomCustomerIndicator(testResources.kbtqEomCustomerIndicator_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_customers_after_join_testing_datio_schema).globalParameterSetter()
    val expected = testResources.ktae_customers_after_join_testing

    val datasetMap: Map[String,CDDStructuralBoardsDataset[_]] = Map(
      CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER -> kbtqEomCustomer,
      CUSTOMERS_BOARD_TABLE_EOM_ECON_INFORMATION -> kbtqEomEconInformation,
      CUSTOMERS_BOARD_TABLE_INAPPRT_CUST_SITUTN -> kdeoInapprtCustSitutn,
      CUSTOMERS_BOARD_TABLE_CUST_RATING_ATRB -> kctkCustRatingAtrb,
      CUSTOMERS_BOARD_TABLE_CORP_EXT_RATING -> kctkCorpExtRating,
      CUSTOMERS_BOARD_TABLE_CUSTOMER_ENGAGEMENT -> kcegCustomerEngagement,
      CUSTOMERS_BOARD_TABLE_EOM_SEGMENTATION -> ksagEomSegmentation,
      CUSTOMERS_BOARD_TABLE_EOM_SECTORIZATION -> ksagEomSectorization,
      CUSTOMERS_BOARD_TABLE_EOM_PRTCPT_LCL_GROUP -> ksagEomPrtcptLclGroup,
      CUSTOMERS_BOARD_TABLE_EOM_LOCAL_GROUP -> ksagEomLocalGroup,
      CUSTOMERS_BOARD_TABLE_SOVEREIGN_EXT_RATING -> kctkSovereignExtRating,
      CUSTOMERS_BOARD_TABLE_PARTICIPATED_COMPANY -> na8zParticipatedCompany,
      CUSTOMERS_BOARD_TABLE_CUST_SPL_PROJECT_RELS -> kctkCustSplProjectRels,
      CUSTOMERS_BOARD_TABLE_SVRGN_OUT_RTG_OTK -> kctkSvrgnOutRtgOtk,
      CUSTOMERS_BOARD_TABLE_EOM_INCOME_SOURCE -> kbtqEomIncomeSource,
      CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER_INDICATOR -> kbtqEomCustomerIndicator
    )
    val result: DataFrame = (new StructuralboardsCustomers_RQ42021).joinTablon(datasetMap,
      testResources.globalReaded, testResources.globalTranslated, datioSparkSession).getDataFrame()
    TestUtils.assertDataFrameEquals(result, expected, false) shouldBe true
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("customersIngestion_dataSetCollectorMapper_KBTQEomEconInformation") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_EOM_ECON_INFORMATION
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KBTQEomEconInformation])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  } */

  test("customersIngestion_dataSetCollectorMapper_KCEGCustomerEngagement") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_CUSTOMER_ENGAGEMENT
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCEGCustomerEngagement])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KCTKCorpExtRating") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_CORP_EXT_RATING
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKCorpExtRating])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KCTKCustRatingAtrb") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_CUST_RATING_ATRB
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKCustRatingAtrb])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KCTKCustSplProjectRels") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_CUST_SPL_PROJECT_RELS
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKCustSplProjectRels])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KCTKSovereignExtRating") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_SOVEREIGN_EXT_RATING
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKSovereignExtRating])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KDEOInapprtCustSitutn") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_INAPPRT_CUST_SITUTN
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KDEOInapprtCustSitutn])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KSAGEomLocalGroup") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_EOM_LOCAL_GROUP
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSAGEomLocalGroup])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KSAGEomSectorization") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_EOM_SECTORIZATION
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSAGEomSectorization])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KSAGEomSegmentation") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_EOM_SEGMENTATION
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSAGEomSegmentation])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_NA8ZParticipatedCompany") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_PARTICIPATED_COMPANY
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[NA8ZParticipatedCompany])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KCTKSvrgnOutRtgOtk") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_SVRGN_OUT_RTG_OTK
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKSvrgnOutRtgOtk])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KBTQEomIncomeSource") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_EOM_INCOME_SOURCE
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KBTQEomIncomeSource])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("customersIngestion_dataSetCollectorMapper_KBTQEomCustomerIndicator") {
    val testInputEntityName : String = CUSTOMERS_BOARD_TABLE_EOM_CUSTOMER_INDICATOR
    val result = (new StructuralboardsCustomers_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KBTQEomCustomerIndicator])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }
}
