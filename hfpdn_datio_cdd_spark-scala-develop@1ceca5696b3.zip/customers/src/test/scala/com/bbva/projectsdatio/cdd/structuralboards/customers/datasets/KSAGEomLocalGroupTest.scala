package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSAGEomLocalGroupTest extends TestCustomers {
  test("ksagEomLocalGroup_wrap") {
    val instancia: KSAGEomLocalGroup = KSAGEomLocalGroup(testResources.ksagEomLocalGroup_complete_input_testing, testResources.config)
    val result: KSAGEomLocalGroup = instancia.wrap(testResources.ksagEomLocalGroup_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
