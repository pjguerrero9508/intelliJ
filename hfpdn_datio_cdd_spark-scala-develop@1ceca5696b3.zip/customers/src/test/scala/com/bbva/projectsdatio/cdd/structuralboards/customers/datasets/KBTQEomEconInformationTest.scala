package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KBTQEomEconInformationTest extends TestCustomers {
  test("kbtqEomEconInformation_wrap") {
    val instancia: KBTQEomEconInformation = KBTQEomEconInformation(testResources.kbtqEomEconInformation_complete_input_testing, testResources.config)
    val result: KBTQEomEconInformation = instancia.wrap(testResources.kbtqEomEconInformation_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
