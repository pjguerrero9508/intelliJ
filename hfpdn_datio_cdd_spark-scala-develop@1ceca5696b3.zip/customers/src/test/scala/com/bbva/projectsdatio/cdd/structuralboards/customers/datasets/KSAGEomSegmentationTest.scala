package com.bbva.projectsdatio.cdd.structuralboards.customers.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.customers.TestCustomers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSAGEomSegmentationTest extends TestCustomers {
  test("ksagEomSegmentation_wrap") {
    val instancia: KSAGEomSegmentation = KSAGEomSegmentation(testResources.ksagEomSegmentation_complete_input_testing, testResources.config)
    val result: KSAGEomSegmentation = instancia.wrap(testResources.ksagEomSegmentation_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
