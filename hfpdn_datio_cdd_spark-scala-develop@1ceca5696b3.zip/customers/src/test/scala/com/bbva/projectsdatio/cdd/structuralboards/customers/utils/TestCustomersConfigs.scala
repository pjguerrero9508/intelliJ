package com.bbva.projectsdatio.cdd.structuralboards.customers.utils

import com.typesafe.config.{Config, ConfigFactory}

trait TestCustomersConfigs {

  //CONSTANTS
  val confStruct: String = "CDDCustomersBoard"

  //CONFIG FILES
  lazy val config: Config = rootConfig.getConfig(confStruct)
  lazy val configBadSelect: Config = rootConfigBadSelect.getConfig(confStruct)
  lazy val configMissSelect: Config = rootConfigMissSelect.getConfig(confStruct)
  lazy val configBadJoinFields: Config = rootConfigBadJoinFields.getConfig(confStruct)
  lazy val configBadFields: Config =  rootConfigBadFields.getConfig(confStruct)
  lazy val configMissFields: Config = rootConfigMissFields.getConfig(confStruct)

  lazy val ktaeCustomersBoardRoot_complete : String =
    """CDDCustomersBoard {
      |  dateIngestion = "2020-08-08"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 6
      |  schemaPath = "src/test/resources/schemas/customers/t_ktae_customer_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/customersIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/customersIngestion/principal"
      |  }"""

  lazy val kbtqEomCustomer_correct : String =
    """|  kbtqEomCustomer = {
      |    dataPath = "src/test/resources/data/kbtqEomCustomer/parquet/"
      |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer.json"
      |    relevantFields = ["g_customer_id",
      |      "g_bbva_owned_security_co_id",
      |      "g_residence_country_id",
      |      "g_t_kbtq_eom_customer_relevant",
      |      "g_t_kbtq_eom_customer_relevant_renamed",
      |      "g_t_kbtq_eom_customer_relevant_initialized"]
      |    previousRename = {
      |      oldFieldNames = "g_t_kbtq_eom_customer_relevant_to_rename"
      |      newFieldNames = "g_t_kbtq_eom_customer_relevant_renamed"
      |    }
      |    selectTablonFields = ["g_bbva_owned_security_co_id",
      |      "g_customer_id",
      |      "g_group_id",
      |      "g_residence_country_id",
      |      "g_t_kbtq_eom_customer_relevant",
      |      "g_t_kbtq_eom_customer_relevant_renamed",
      |      "g_t_kbtq_eom_customer_relevant_initialized",
      |      "g_t_kctk_sovereign_ext_rating_relevant",
      |      "g_t_kctk_sovereign_ext_rating_relevant_renamed",
      |      "g_t_kctk_sovereign_ext_rating_relevant_initialized",
      |      "g_record_rating_type",
      |      "gf_rating_generation_date",
      |      "g_t_kctk_svrgn_out_rtg_otk_relevant",
      |      "g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",
      |      "g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",
      |      "g_t_kbtq_eom_income_source_relevant",
      |      "g_t_kbtq_eom_income_source_relevant_renamed",
      |      "g_t_kbtq_eom_income_source_relevant_initialized",
      |      "gf_local_reglty_spec_group_id",
      |      "g_t_kbtq_eom_customer_indicator_relevant",
      |      "g_t_kbtq_eom_customer_indicator_relevant_renamed",
      |      "g_t_kbtq_eom_customer_indicator_relevant_initialized",
      |      "g_t_ksag_eom_local_group_relevant",
      |      "g_t_ksag_eom_local_group_relevant_renamed",
      |      "g_t_ksag_eom_local_group_relevant_initialized",
      |      "g_t_kctk_corp_ext_rating_relevant",
      |      "g_t_kctk_corp_ext_rating_relevant_renamed",
      |      "g_t_kctk_corp_ext_rating_relevant_initialized",
      |      "g_t_kbtq_eom_econ_information_relevant",
      |      "g_t_kbtq_eom_econ_information_relevant_renamed",
      |      "g_t_kbtq_eom_econ_information_relevant_initialized",
      |      "g_t_kceg_customer_engagement_relevant",
      |      "g_t_kceg_customer_engagement_relevant_renamed",
      |      "g_t_kceg_customer_engagement_relevant_initialized",
      |      "g_t_ksag_eom_segmentation_relevant",
      |      "g_t_ksag_eom_segmentation_relevant_renamed",
      |      "g_t_ksag_eom_segmentation_relevant_initialized",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant_renamed",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant_initialized",
      |      "g_t_ksag_eom_sectorization_relevant",
      |      "g_t_ksag_eom_sectorization_relevant_renamed",
      |      "g_t_ksag_eom_sectorization_relevant_initialized",
      |      "g_t_kctk_cust_rating_atrb_relevant",
      |      "g_t_kctk_cust_rating_atrb_relevant_renamed",
      |      "g_t_kctk_cust_rating_atrb_relevant_initialized",
      |      "g_t_kctk_cust_spl_project_rels_relevant",
      |      "g_t_kctk_cust_spl_project_rels_relevant_renamed",
      |      "g_t_kctk_cust_spl_project_rels_relevant_initialized",
      |      "g_t_na8z_participated_company_relevant",
      |      "g_t_na8z_participated_company_relevant_renamed",
      |      "g_t_na8z_participated_company_relevant_initialized"]
      |    previousFilterAppliedFields = ["gf_cutoff_date",
      |      "g_entific_id"]
      |  }"""

  lazy val kbtqEomCustomer_badJoinFields : String =
    """|  kbtqEomCustomer = {
      |    dataPath = "src/test/resources/data/kbtqEomCustomer/parquet/"
      |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer.json"
      |    relevantFields = ["g_customer_id",
      |      "g_bbva_owned_security_co_id",
      |      "g_residence_country_id",
      |      "g_t_kbtq_eom_customer_relevant",
      |      "g_t_kbtq_eom_customer_relevant_renamed",
      |      "g_t_kbtq_eom_customer_relevant_initialized"]
      |    previousRename = {
      |      oldFieldNames = "g_t_kbtq_eom_customer_relevant_to_rename"
      |      newFieldNames = "g_t_kbtq_eom_customer_relevant_renamed"
      |    }
      |    selectTablonFields = ["g_bbva_owned_security_co_id",
      |      "g_customer_id",
      |      "g_group_id",
      |      "g_residence_country_id",
      |      "g_t_kbtq_eom_customer_relevant",
      |      "g_t_kbtq_eom_customer_relevant_renamed",
      |      "g_t_kbtq_eom_customer_relevant_initialized",
      |      "g_t_kctk_sovereign_ext_rating_relevant",
      |      "g_t_kctk_sovereign_ext_rating_relevant_renamed",
      |      "g_t_kctk_sovereign_ext_rating_relevant_initialized",
      |      "g_t_kctk_svrgn_out_rtg_otk_relevant",
      |      "g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",
      |      "g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",
      |      "g_t_kbtq_eom_income_source_relevant",
      |      "g_t_kbtq_eom_income_source_relevant_renamed",
      |      "g_t_kbtq_eom_income_source_relevant_initialized",
      |      "g_t_ksag_eom_prtcpt_lcl_group_relevant",
      |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed",
      |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_initialized",
      |      "g_t_kbtq_eom_customer_indicator_relevant",
      |      "g_t_kbtq_eom_customer_indicator_relevant_renamed",
      |      "g_t_kbtq_eom_customer_indicator_relevant_initialized",
      |      "g_t_ksag_eom_local_group_relevant",
      |      "g_t_ksag_eom_local_group_relevant_renamed",
      |      "g_t_ksag_eom_local_group_relevant_initialized",
      |      "g_t_kctk_corp_ext_rating_relevant",
      |      "g_t_kctk_corp_ext_rating_relevant_renamed",
      |      "g_t_kctk_corp_ext_rating_relevant_initialized",
      |      "g_t_kbtq_eom_econ_information_relevant",
      |      "g_t_kbtq_eom_econ_information_relevant_renamed",
      |      "g_t_kbtq_eom_econ_information_relevant_initialized",
      |      "g_t_kceg_customer_engagement_relevant",
      |      "g_t_kceg_customer_engagement_relevant_renamed",
      |      "g_t_kceg_customer_engagement_relevant_initialized",
      |      "g_t_ksag_eom_segmentation_relevant",
      |      "g_t_ksag_eom_segmentation_relevant_renamed",
      |      "g_t_ksag_eom_segmentation_relevant_initialized",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant_renamed",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant_initialized",
      |      "g_t_ksag_eom_sectorization_relevant",
      |      "g_t_ksag_eom_sectorization_relevant_renamed",
      |      "g_t_ksag_eom_sectorization_relevant_initialized",
      |      "g_t_kctk_cust_rating_atrb_relevant",
      |      "g_t_kctk_cust_rating_atrb_relevant_renamed",
      |      "g_t_kctk_cust_rating_atrb_relevant_initialized",
      |      "g_t_kctk_cust_spl_project_rels_relevant",
      |      "g_t_kctk_cust_spl_project_rels_relevant_renamed",
      |      "g_t_kctk_cust_spl_project_rels_relevant_initialized",
      |      "g_t_na8z_participated_company_relevant",
      |      "g_t_na8z_participated_company_relevant_renamed",
      |      "g_t_na8z_participated_company_relevant_initialized"]
      |    previousFilterAppliedFields = ["gf_cutoff_date",
      |      "g_entific_id"]
      |  }"""

  lazy val kbtqEomCustomer_missSelect : String =
    """|  kbtqEomCustomer = {
      |    dataPath = "src/test/resources/data/kbtqEomCustomer/parquet/"
      |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer.json"
      |    relevantFields =  ["g_customer_id",
      |      "g_bbva_owned_security_co_id",
      |      "g_residence_country_id",
      |      "g_t_kbtq_eom_customer_relevant",
      |      "g_t_kbtq_eom_customer_relevant_renamed",
      |      "g_t_kbtq_eom_customer_relevant_initialized"]
      |    previousRename = {
      |      oldFieldNames = "g_t_kbtq_eom_customer_relevant_to_rename"
      |      newFieldNames = "g_t_kbtq_eom_customer_relevant_renamed"
      |    }
      |    previousFilterAppliedFields = ["gf_cutoff_date",
      |      "g_entific_id"]
      |  }"""

  lazy val kbtqEomCustomer_badSelect : String =
    """|  kbtqEomCustomer = {
       |    dataPath = "src/test/resources/data/kbtqEomCustomer/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer.json"
       |    relevantFields = ["g_customer_id",
       |      "g_bbva_owned_security_co_id",
       |      "g_residence_country_id",
       |      "g_t_kbtq_eom_customer_relevant",
       |      "g_t_kbtq_eom_customer_relevant_renamed",
       |      "g_t_kbtq_eom_customer_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kbtq_eom_customer_relevant_to_rename"
       |      newFieldNames = "g_t_kbtq_eom_customer_relevant_renamed"
       |    }
       |    selectTablonFields = ["g_bbva_owned_security_co_id",
       |      "g_customer_id",
       |      "g_group_id",
       |      "g_residence_country_id",
       |      "g_t_kbtq_eom_customer_relevant",
       |      "g_t_kbtq_eom_customer_relevant_renamed",
       |      "g_t_kbtq_eom_customer_relevant_initialized",
       |      "g_t_kctk_sovereign_ext_rating_relevant",
       |      "g_t_kctk_sovereign_ext_rating_relevant_renamed",
       |      "g_t_kctk_sovereign_ext_rating_relevant_initialized",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",
       |      "g_t_kbtq_eom_income_source_relevant",
       |      "g_t_kbtq_eom_income_source_relevant_renamed",
       |      "g_t_kbtq_eom_income_source_relevant_initialized",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_initialized",
       |      "g_t_kbtq_eom_customer_indicator_relevant",
       |      "g_t_kbtq_eom_customer_indicator_relevant_renamed",
       |      "g_t_kbtq_eom_customer_indicator_relevant_initialized",
       |      "g_t_ksag_eom_local_group_relevant",
       |      "g_t_ksag_eom_local_group_relevant_renamed",
       |      "g_t_ksag_eom_local_group_relevant_initialized",
       |      "g_t_kctk_corp_ext_rating_relevant",
       |      "g_t_kctk_corp_ext_rating_relevant_renamed",
       |      "g_t_kctk_corp_ext_rating_relevant_initialized",
       |      "g_t_kbtq_eom_econ_information_relevant",
       |      "g_t_kbtq_eom_econ_information_relevant_renamed",
       |      "g_t_kbtq_eom_econ_information_relevant_initialized",
       |      "g_t_kceg_customer_engagement_relevant",
       |      "g_t_kceg_customer_engagement_relevant_renamed",
       |      "g_t_kceg_customer_engagement_relevant_initialized",
       |      "g_t_ksag_eom_segmentation_relevant",
       |      "g_t_ksag_eom_segmentation_relevant_renamed",
       |      "g_t_ksag_eom_segmentation_relevant_initialized",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant_initialized",
       |      "g_t_ksag_eom_sectorization_relevant",
       |      "g_t_ksag_eom_sectorization_relevant_renamed",
       |      "g_t_ksag_eom_sectorization_relevant_initialized",
       |      "g_t_kctk_cust_rating_atrb_relevant",
       |      "g_t_kctk_cust_rating_atrb_relevant_renamed",
       |      "g_t_kctk_cust_rating_atrb_relevant_initialized",
       |      "g_t_kctk_cust_spl_project_rels_relevant",
       |      "g_t_kctk_cust_spl_project_rels_relevant_renamed",
       |      "g_t_kctk_cust_spl_project_rels_relevant_initialized",
       |      "g_t_na8z_participated_company_relevant",
       |      "g_t_na8z_participated_company_relevant_renamed",
       |      "g_t_na8z_participated_company_relevant_initialized",
       |      "aaaaaaaaaaa"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kbtqEomCustomer_badFields : String =
    """|  kbtqEomCustomer = {
       |    dataPath = "src/test/resources/data/kbtqEomCustomer/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer.json"
       |    relevantFields = ["g_customer_id",
       |      "g_bbva_owned_security_co_id",
       |      "g_residence_country_id",
       |      "g_t_kbtq_eom_customer_relevant",
       |      "g_t_kbtq_eom_customer_relevant_renamed",
       |      "g_t_kbtq_eom_customer_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kbtq_eom_customer_relevant_to_rename"
       |      newFieldNames = "g_t_kbtq_eom_customer_relevant_renamed"
       |    }
       |    selectTablonFields = ["g_bbva_owned_security_co_id",
       |      "g_customer_id",
       |      "g_group_id",
       |      "g_residence_country_id",
       |      "g_t_kbtq_eom_customer_relevant",
       |      "g_t_kbtq_eom_customer_relevant_renamed",
       |      "g_t_kbtq_eom_customer_relevant_initialized",
       |      "g_t_kctk_sovereign_ext_rating_relevant",
       |      "g_t_kctk_sovereign_ext_rating_relevant_renamed",
       |      "g_t_kctk_sovereign_ext_rating_relevant_initialized",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",
       |      "g_t_kbtq_eom_income_source_relevant",
       |      "g_t_kbtq_eom_income_source_relevant_renamed",
       |      "g_t_kbtq_eom_income_source_relevant_initialized",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_initialized",
       |      "g_t_kbtq_eom_customer_indicator_relevant",
       |      "g_t_kbtq_eom_customer_indicator_relevant_renamed",
       |      "g_t_kbtq_eom_customer_indicator_relevant_initialized",
       |      "g_t_ksag_eom_local_group_relevant",
       |      "g_t_ksag_eom_local_group_relevant_renamed",
       |      "g_t_ksag_eom_local_group_relevant_initialized",
       |      "g_t_kctk_corp_ext_rating_relevant",
       |      "g_t_kctk_corp_ext_rating_relevant_renamed",
       |      "g_t_kctk_corp_ext_rating_relevant_initialized",
       |      "g_t_kbtq_eom_econ_information_relevant",
       |      "g_t_kbtq_eom_econ_information_relevant_renamed",
       |      "g_t_kbtq_eom_econ_information_relevant_initialized",
       |      "g_t_kceg_customer_engagement_relevant",
       |      "g_t_kceg_customer_engagement_relevant_renamed",
       |      "g_t_kceg_customer_engagement_relevant_initialized",
       |      "g_t_ksag_eom_segmentation_relevant",
       |      "g_t_ksag_eom_segmentation_relevant_renamed",
       |      "g_t_ksag_eom_segmentation_relevant_initialized",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant_initialized",
       |      "g_t_ksag_eom_sectorization_relevant",
       |      "g_t_ksag_eom_sectorization_relevant_renamed",
       |      "g_t_ksag_eom_sectorization_relevant_initialized",
       |      "g_t_kctk_cust_rating_atrb_relevant",
       |      "g_t_kctk_cust_rating_atrb_relevant_renamed",
       |      "g_t_kctk_cust_rating_atrb_relevant_initialized",
       |      "g_t_kctk_cust_spl_project_rels_relevant",
       |      "g_t_kctk_cust_spl_project_rels_relevant_renamed",
       |      "g_t_kctk_cust_spl_project_rels_relevant_initialized",
       |      "g_t_na8z_participated_company_relevant",
       |      "g_t_na8z_participated_company_relevant_renamed",
       |      "g_t_na8z_participated_company_relevant_initialized"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kbtqEomCustomer_missFields : String =
    """|  kbtqEomCustomer = {
       |    dataPath = "src/test/resources/data/kbtqEomCustomer/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer.json"
       |    relevantFields = ["g_customer_id",
       |      "g_bbva_owned_security_co_id",
       |      "g_residence_country_id",
       |      "g_t_kbtq_eom_customer_relevant",
       |      "g_t_kbtq_eom_customer_relevant_renamed"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kbtq_eom_customer_relevant_to_rename"
       |      newFieldNames = "g_t_kbtq_eom_customer_relevant_renamed"
       |    }
       |    selectTablonFields = ["g_bbva_owned_security_co_id",
       |      "g_customer_id",
       |      "g_group_id",
       |      "g_residence_country_id",
       |      "g_t_kbtq_eom_customer_relevant",
       |      "g_t_kbtq_eom_customer_relevant_renamed",
       |      "g_t_kbtq_eom_customer_relevant_initialized",
       |      "g_t_kctk_sovereign_ext_rating_relevant",
       |      "g_t_kctk_sovereign_ext_rating_relevant_renamed",
       |      "g_t_kctk_sovereign_ext_rating_relevant_initialized",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_initialized",
       |      "g_t_kbtq_eom_income_source_relevant",
       |      "g_t_kbtq_eom_income_source_relevant_renamed",
       |      "g_t_kbtq_eom_income_source_relevant_initialized",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_initialized",
       |      "g_t_kbtq_eom_customer_indicator_relevant",
       |      "g_t_kbtq_eom_customer_indicator_relevant_renamed",
       |      "g_t_kbtq_eom_customer_indicator_relevant_initialized",
       |      "g_t_ksag_eom_local_group_relevant",
       |      "g_t_ksag_eom_local_group_relevant_renamed",
       |      "g_t_ksag_eom_local_group_relevant_initialized",
       |      "g_t_kctk_corp_ext_rating_relevant",
       |      "g_t_kctk_corp_ext_rating_relevant_renamed",
       |      "g_t_kctk_corp_ext_rating_relevant_initialized",
       |      "g_t_kbtq_eom_econ_information_relevant",
       |      "g_t_kbtq_eom_econ_information_relevant_renamed",
       |      "g_t_kbtq_eom_econ_information_relevant_initialized",
       |      "g_t_kceg_customer_engagement_relevant",
       |      "g_t_kceg_customer_engagement_relevant_renamed",
       |      "g_t_kceg_customer_engagement_relevant_initialized",
       |      "g_t_ksag_eom_segmentation_relevant",
       |      "g_t_ksag_eom_segmentation_relevant_renamed",
       |      "g_t_ksag_eom_segmentation_relevant_initialized",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_cust_situtn_relevant_initialized",
       |      "g_t_ksag_eom_sectorization_relevant",
       |      "g_t_ksag_eom_sectorization_relevant_renamed",
       |      "g_t_ksag_eom_sectorization_relevant_initialized",
       |      "g_t_kctk_cust_rating_atrb_relevant",
       |      "g_t_kctk_cust_rating_atrb_relevant_renamed",
       |      "g_t_kctk_cust_rating_atrb_relevant_initialized",
       |      "g_t_kctk_cust_spl_project_rels_relevant",
       |      "g_t_kctk_cust_spl_project_rels_relevant_renamed",
       |      "g_t_kctk_cust_spl_project_rels_relevant_initialized",
       |      "g_t_na8z_participated_company_relevant",
       |      "g_t_na8z_participated_company_relevant_renamed",
       |      "g_t_na8z_participated_company_relevant_initialized"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kbtqEomEconInformation_correct : String =
    """|  kbtqEomEconInformation = {
      |    dataPath = "src/test/resources/data/kbtqEomEconInformation/parquet/"
      |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_econ_information.json"
      |    relevantFields = ["g_customer_id",
      |      "g_t_kbtq_eom_econ_information_relevant",
      |      "g_t_kbtq_eom_econ_information_relevant_renamed",
      |      "g_t_kbtq_eom_econ_information_relevant_initialized"]
      |    previousRename = {
      |      oldFieldNames = "g_t_kbtq_eom_econ_information_relevant_to_rename"
      |      newFieldNames = "g_t_kbtq_eom_econ_information_relevant_renamed"
      |    }
      |    joinFields = ["g_customer_id"]
      |    previousFilterAppliedFields = ["gf_cutoff_date",
      |      "g_entific_id"]
      |  }"""

  lazy val kdeoInapprtCustSitutn_correct : String =
    """|  kdeoInapprtCustSitutn = {
      |    dataPath = "src/test/resources/data/kdeoInapprtCustSitutn/parquet/"
      |    schemaPath = "src/test/resources/schemas/RQ42021/t_kdeo_inapprt_cust_situtn.json"
      |    relevantFields = ["g_customer_id",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant_renamed",
      |      "g_t_kdeo_inapprt_cust_situtn_relevant_initialized"]
      |    previousRename = {
      |      oldFieldNames = "g_t_kdeo_inapprt_cust_situtn_relevant_to_rename"
      |      newFieldNames = "g_t_kdeo_inapprt_cust_situtn_relevant_renamed"
      |    }
      |    joinFields = ["g_customer_id"]
      |    previousFilterAppliedFields = ["gf_cutoff_date",
      |      "g_entific_id"]
      |  }"""

  lazy val kctkCustRatingAtrb_correct : String =
    """| kctkCustRatingAtrb = {
       |    dataPath = "src/test/resources/data/kctkCustRatingAtrb/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kctk_cust_rating_atrb.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_kctk_cust_rating_atrb_relevant",
       |      "g_t_kctk_cust_rating_atrb_relevant_renamed",
       |      "g_t_kctk_cust_rating_atrb_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_cust_rating_atrb_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_cust_rating_atrb_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkCorpExtRating_correct : String =
    """|   kctkCorpExtRating = {
       |    dataPath = "src/test/resources/data/kctkCorpExtRating/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kctk_corp_ext_rating.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_kctk_corp_ext_rating_relevant",
       |      "g_t_kctk_corp_ext_rating_relevant_renamed",
       |      "g_t_kctk_corp_ext_rating_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_corp_ext_rating_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_corp_ext_rating_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kcegCustomerEngagement_correct : String =
    """| kcegCustomerEngagement = {
       |    dataPath = "src/test/resources/data/kcegCustomerEngagement/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kceg_customer_engagement.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_kceg_customer_engagement_relevant",
       |      "g_t_kceg_customer_engagement_relevant_renamed",
       |      "g_t_kceg_customer_engagement_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kceg_customer_engagement_relevant_to_rename"
       |      newFieldNames = "g_t_kceg_customer_engagement_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksagEomSegmentation_correct : String =
    """| ksagEomSegmentation = {
       |    dataPath = "src/test/resources/data/ksagEomSegmentation/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_ksag_eom_segmentation.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_ksag_eom_segmentation_relevant",
       |      "g_t_ksag_eom_segmentation_relevant_renamed",
       |      "g_t_ksag_eom_segmentation_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksag_eom_segmentation_relevant_to_rename"
       |      newFieldNames = "g_t_ksag_eom_segmentation_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksagEomSectorization_correct : String =
    """ksagEomSectorization = {
      |    dataPath = "src/test/resources/data/ksagEomSectorization/parquet/"
      |    schemaPath = "src/test/resources/schemas/RQ42021/t_ksag_eom_sectorization.json"
      |    relevantFields = ["g_customer_id",
      |      "g_t_ksag_eom_sectorization_relevant",
      |      "g_t_ksag_eom_sectorization_relevant_renamed",
      |      "g_t_ksag_eom_sectorization_relevant_initialized"]
      |    previousRename = {
      |      oldFieldNames = "g_t_ksag_eom_sectorization_relevant_to_rename"
      |      newFieldNames = "g_t_ksag_eom_sectorization_relevant_renamed"
      |    }
      |    joinFields = ["g_customer_id"]
      |    previousFilterAppliedFields = ["gf_cutoff_date",
      |      "g_entific_id"]
      |  }"""

  lazy val ksagEomPrtcptLclGroup_correct : String =
    """|  ksagEomPrtcptLclGroup = {
       |    dataPath = "src/test/resources/data/ksagEomPrtcptLclGroup/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_ksag_eom_prtcpt_lcl_group.json"
       |    relevantFields = ["g_customer_id",
       |      "g_group_id",
       |      "g_customer_main_group_ind_type",
       |      "g_spec_lc_reglty_grp_ind_type"]
       |    fields = {
       |      customerGroupType = "g_customer_main_group_ind_type"
       |      specLcReglty = "g_spec_lc_reglty_grp_ind_type"
       |      groupId = "g_group_id"
       |      localRegltySpec = "gf_local_reglty_spec_group_id"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksagEomPrtcptLclGroup_missFields : String =
    """|  ksagEomPrtcptLclGroup = {
       |    dataPath = "src/test/resources/data/ksagEomPrtcptLclGroup/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_ksag_eom_prtcpt_lcl_group.json"
       |    relevantFields = ["g_customer_id",
       |      "g_group_id",
       |      "g_customer_main_group_ind_type",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename"
       |      newFieldNames = "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksagEomPrtcptLclGroup_badFields : String =
    """|  ksagEomPrtcptLclGroup = {
       |    dataPath = "src/test/resources/data/ksagEomPrtcptLclGroup/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_ksag_eom_prtcpt_lcl_group.json"
       |    relevantFields = ["g_customer_id",
       |      "g_group_id",
       |      "g_customer_main_group_ind_type",
       |      "g_spec_lc_reglty_grp_ind_type_g",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed",
       |      "g_t_ksag_eom_prtcpt_lcl_group_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksag_eom_prtcpt_lcl_group_relevant_to_rename"
       |      newFieldNames = "g_t_ksag_eom_prtcpt_lcl_group_relevant_renamed"
       |    }
       |    fields = {
       |      customerGroupType = "g_customer_main_group_ind_type"
       |      specLcReglty = "g_spec_lc_reglty_grp_ind_type_g"
       |      groupId = "g_group_id"
       |      localRegltySpec = "gf_local_reglty_spec_group_id"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val ksagEomLocalGroup_correct : String =
    """| ksagEomLocalGroup = {
       |    dataPath = "src/test/resources/data/ksagEomLocalGroup/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_ksag_eom_local_group.json"
       |    relevantFields = ["g_group_id",
       |      "g_t_ksag_eom_local_group_relevant",
       |      "g_t_ksag_eom_local_group_relevant_renamed",
       |      "g_t_ksag_eom_local_group_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_ksag_eom_local_group_relevant_to_rename"
       |      newFieldNames = "g_t_ksag_eom_local_group_relevant_renamed"
       |    }
       |    joinFields = ["g_group_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkSovereignExtRating_correct : String =
    """| kctkSovereignExtRating = {
       |    dataPath = "src/test/resources/data/kctkSovereignExtRating/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kctk_sovereign_ext_rating.json"
       |    relevantFields = ["g_residence_country_id",
       |      "g_t_kctk_sovereign_ext_rating_relevant",
       |      "g_t_kctk_sovereign_ext_rating_relevant_renamed",
       |      "g_t_kctk_sovereign_ext_rating_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_country_id;g_t_kctk_sovereign_ext_rating_relevant_to_rename"
       |      newFieldNames = "g_residence_country_id;g_t_kctk_sovereign_ext_rating_relevant_renamed"
       |    }
       |    joinFields = ["g_residence_country_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val na8zParticipatedCompany_correct : String =
    """| na8zParticipatedCompany = {
       |    dataPath = "src/test/resources/data/na8zParticipatedCompany/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_na8z_participated_company.json"
       |    relevantFields = ["g_bbva_owned_security_co_id",
       |      "g_t_na8z_participated_company_relevant",
       |      "g_t_na8z_participated_company_relevant_renamed",
       |      "g_t_na8z_participated_company_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_na8z_participated_company_relevant_to_rename"
       |      newFieldNames = "g_t_na8z_participated_company_relevant_renamed"
       |    }
       |    joinFields = ["g_bbva_owned_security_co_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkCustSplProjectRels_correct : String =
    """| kctkCustSplProjectRels = {
       |    dataPath = "src/test/resources/data/kctkCustSplProjectRels/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kctk_cust_spl_project_rels.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_kctk_cust_spl_project_rels_relevant",
       |      "g_t_kctk_cust_spl_project_rels_relevant_renamed",
       |      "g_t_kctk_cust_spl_project_rels_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_cust_spl_project_rels_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_cust_spl_project_rels_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkSvrgnOutRtgOtk_correct : String =
    """| kctkSvrgnOutRtgOtk = {
       |    dataPath = "src/test/resources/data/kctkSvrgnOutRtgOtk/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kctk_svrgn_out_rtg_otk.json"
       |    relevantFields = ["g_residence_country_id",
       |      "g_record_rating_type",
       |      "gf_rating_generation_date",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_renamed",
       |      "g_t_kctk_svrgn_out_rtg_otk_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_country_id;g_t_kctk_svrgn_out_rtg_otk_relevant_to_rename"
       |      newFieldNames = "g_residence_country_id;g_t_kctk_svrgn_out_rtg_otk_relevant_renamed"
       |    }
       |    fields = {
       |      ratingTypeFieldName = "g_record_rating_type"
       |      ratingTypeAllowedValue = "4"
       |      generationDateFieldName = "gf_rating_generation_date"
       |    }
       |    joinFields = ["g_residence_country_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kbtqEomCustomerIndicator_correct : String =
    """| kbtqEomCustomerIndicator = {
       |    dataPath = "src/test/resources/data/kbtqEomCustomerIndicator/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_customer_indicator.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_kbtq_eom_customer_indicator_relevant",
       |      "g_t_kbtq_eom_customer_indicator_relevant_renamed",
       |      "g_t_kbtq_eom_customer_indicator_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kbtq_eom_customer_indicator_relevant_to_rename"
       |      newFieldNames = "g_t_kbtq_eom_customer_indicator_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kbtqEomIncomeSource_correct : String =
    """| kbtqEomIncomeSource = {
       |    dataPath = "src/test/resources/data/kbtqEomIncomeSource/parquet/"
       |    schemaPath = "src/test/resources/schemas/RQ42021/t_kbtq_eom_income_source.json"
       |    relevantFields = ["g_customer_id",
       |      "g_t_kbtq_eom_income_source_relevant",
       |      "g_t_kbtq_eom_income_source_relevant_renamed",
       |      "g_t_kbtq_eom_income_source_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kbtq_eom_income_source_relevant_to_rename"
       |      newFieldNames = "g_t_kbtq_eom_income_source_relevant_renamed"
       |    }
       |    joinFields = ["g_customer_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val rootConfig: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeCustomersBoardRoot_complete.stripMargin + """
      """.stripMargin + kbtqEomCustomer_correct.stripMargin + """
      """.stripMargin + kbtqEomEconInformation_correct.stripMargin + """
      """.stripMargin + kdeoInapprtCustSitutn_correct.stripMargin + """
      """.stripMargin + kctkCustRatingAtrb_correct.stripMargin + """
      """.stripMargin + kctkCorpExtRating_correct.stripMargin + """
      """.stripMargin + kcegCustomerEngagement_correct.stripMargin + """
      """.stripMargin + ksagEomSegmentation_correct.stripMargin + """
      """.stripMargin + ksagEomSectorization_correct.stripMargin +  """
      """.stripMargin + ksagEomPrtcptLclGroup_correct.stripMargin + """
      """.stripMargin + ksagEomLocalGroup_correct.stripMargin + """
      """.stripMargin + kctkSovereignExtRating_correct.stripMargin + """
      """.stripMargin + na8zParticipatedCompany_correct.stripMargin + """
      """.stripMargin + kctkCustSplProjectRels_correct.stripMargin + """
      """.stripMargin + kctkSvrgnOutRtgOtk_correct.stripMargin + """
      """.stripMargin + kbtqEomCustomerIndicator_correct.stripMargin + """
      """.stripMargin + kbtqEomIncomeSource_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeCustomersBoardRoot_complete.stripMargin + """
      """.stripMargin + kbtqEomCustomer_badSelect.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigMissSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeCustomersBoardRoot_complete.stripMargin + """
      """.stripMargin + kbtqEomCustomer_missSelect.stripMargin + """
      """.stripMargin + kbtqEomEconInformation_correct.stripMargin + """
      """.stripMargin + kdeoInapprtCustSitutn_correct.stripMargin + """
      """.stripMargin + kctkCustRatingAtrb_correct.stripMargin + """
      """.stripMargin + kctkCorpExtRating_correct.stripMargin + """
      """.stripMargin + kcegCustomerEngagement_correct.stripMargin + """
      """.stripMargin + ksagEomSegmentation_correct.stripMargin + """
      """.stripMargin + ksagEomSectorization_correct.stripMargin +  """
      """.stripMargin + ksagEomPrtcptLclGroup_correct.stripMargin + """
      """.stripMargin + ksagEomLocalGroup_correct.stripMargin + """
      """.stripMargin + kctkSovereignExtRating_correct.stripMargin + """
      """.stripMargin + na8zParticipatedCompany_correct.stripMargin + """
      """.stripMargin + kctkCustSplProjectRels_correct.stripMargin + """
      """.stripMargin + kctkSvrgnOutRtgOtk_correct.stripMargin + """
      """.stripMargin + kbtqEomCustomerIndicator_correct.stripMargin + """
      """.stripMargin + kbtqEomIncomeSource_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadJoinFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeCustomersBoardRoot_complete.stripMargin  + """
      """.stripMargin + kbtqEomCustomer_badJoinFields.stripMargin + """
      """.stripMargin + kbtqEomEconInformation_correct.stripMargin + """
      """.stripMargin + kdeoInapprtCustSitutn_correct.stripMargin + """
      """.stripMargin + kctkCustRatingAtrb_correct.stripMargin + """
      """.stripMargin + kctkCorpExtRating_correct.stripMargin + """
      """.stripMargin + kcegCustomerEngagement_correct.stripMargin + """
      """.stripMargin + ksagEomSegmentation_correct.stripMargin + """
      """.stripMargin + ksagEomSectorization_correct.stripMargin +  """
      """.stripMargin + ksagEomPrtcptLclGroup_correct.stripMargin + """
      """.stripMargin + ksagEomLocalGroup_correct.stripMargin + """
      """.stripMargin + kctkSovereignExtRating_correct.stripMargin + """
      """.stripMargin + na8zParticipatedCompany_correct.stripMargin + """
      """.stripMargin + kctkCustSplProjectRels_correct.stripMargin + """
      """.stripMargin + kctkSvrgnOutRtgOtk_correct.stripMargin + """
      """.stripMargin + kbtqEomCustomerIndicator_correct.stripMargin + """
      """.stripMargin + kbtqEomIncomeSource_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeCustomersBoardRoot_complete.stripMargin  + """
      """.stripMargin + kbtqEomCustomer_badFields.stripMargin + """
      """.stripMargin + kbtqEomEconInformation_correct.stripMargin + """
      """.stripMargin + kdeoInapprtCustSitutn_correct.stripMargin + """
      """.stripMargin + kctkCustRatingAtrb_correct.stripMargin + """
      """.stripMargin + kctkCorpExtRating_correct.stripMargin + """
      """.stripMargin + kcegCustomerEngagement_correct.stripMargin + """
      """.stripMargin + ksagEomSegmentation_correct.stripMargin + """
      """.stripMargin + ksagEomSectorization_correct.stripMargin +  """
      """.stripMargin + ksagEomPrtcptLclGroup_badFields.stripMargin + """
      """.stripMargin + ksagEomLocalGroup_correct.stripMargin + """
      """.stripMargin + kctkSovereignExtRating_correct.stripMargin + """
      """.stripMargin + na8zParticipatedCompany_correct.stripMargin + """
      """.stripMargin + kctkCustSplProjectRels_correct.stripMargin + """
      """.stripMargin + kctkSvrgnOutRtgOtk_correct.stripMargin + """
      """.stripMargin + kbtqEomCustomerIndicator_correct.stripMargin + """
      """.stripMargin + kbtqEomIncomeSource_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigMissFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeCustomersBoardRoot_complete.stripMargin  + """
      """.stripMargin + kbtqEomCustomer_missFields.stripMargin + """
      """.stripMargin + kbtqEomEconInformation_correct.stripMargin + """
      """.stripMargin + kdeoInapprtCustSitutn_correct.stripMargin + """
      """.stripMargin + kctkCustRatingAtrb_correct.stripMargin + """
      """.stripMargin + kctkCorpExtRating_correct.stripMargin + """
      """.stripMargin + kcegCustomerEngagement_correct.stripMargin + """
      """.stripMargin + ksagEomSegmentation_correct.stripMargin + """
      """.stripMargin + ksagEomSectorization_correct.stripMargin +  """
      """.stripMargin + ksagEomPrtcptLclGroup_missFields.stripMargin + """
      """.stripMargin + ksagEomLocalGroup_correct.stripMargin + """
      """.stripMargin + kctkSovereignExtRating_correct.stripMargin + """
      """.stripMargin + na8zParticipatedCompany_correct.stripMargin + """
      """.stripMargin + kctkCustSplProjectRels_correct.stripMargin + """
      """.stripMargin + kctkSvrgnOutRtgOtk_correct.stripMargin + """
      """.stripMargin + kbtqEomCustomerIndicator_correct.stripMargin + """
      """.stripMargin + kbtqEomIncomeSource_correct.stripMargin + """
      |}
      |""".stripMargin)
}
