package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KDEOInapprtOpeSitutnTest extends TestOperations {
  test("kdeoInapprtOpeSitutn_wrap") {
    val instancia: KDEOInapprtOpeSitutn = KDEOInapprtOpeSitutn(testResources.kdeoInapprtOpeSitutn_customized_testing, testResources.config)
    val result: KDEOInapprtOpeSitutn = instancia.wrap(testResources.kdeoInapprtOpeSitutn_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
