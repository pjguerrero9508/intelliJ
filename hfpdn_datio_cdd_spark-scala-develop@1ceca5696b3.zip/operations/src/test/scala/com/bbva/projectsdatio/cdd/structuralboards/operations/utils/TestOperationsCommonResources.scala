package com.bbva.projectsdatio.cdd.structuralboards.operations.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession

class TestOperationsCommonResources(datioSparkSession: DatioSparkSession) extends TestOperationsDataframes(datioSparkSession) with TestOperationsConfigs {

    //CONSTANTS
    val emptyString: String = ""

    //PATHS
    lazy val checkpointPath: String = "src/test/resources/data/operationsIngestion/temporal/checkpoint"

    //CONFIGURATIONS EXPECTED
    val globalReaded : GlobalConfigurationReaded =
        GlobalConfigurationReaded(dateIngestion = "2021-04-01",
            dateColumnName = "gf_cutoff_date",
            dateColumnValue = "2021-04-12",
            entificColumnName = "g_entific_id",
            entificColumnValue = "ES",
            auditColumnName = "gf_audit_date",
            averageKBPerRecord = 1,
            fullNameSchemaBoard = "src/test/resources/schemas/operations/full_operation_schema.json",
            pathTemporal = "",
            pathOutputBoard = "",
            repartitionBase = 1,
            notInformedDatasets = Seq.empty[String])
    val globalTranslated : GlobalConfigurationTranslated =
        GlobalConfigurationTranslated(datioOutputSchema = ktae_operations_after_join_testing_datio_schema,
            checkpointTempPath = checkpointPath,
            backupTempPath = "",
            actualPrincipalPath = "",
            actualPrincipalPathWithPartitions = "")
}
