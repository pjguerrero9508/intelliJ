package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KREIRegltyInfoOlHoldTest extends TestOperations {
  test("kreiRegltyInfoOlHold_wrap") {
    val instancia: KREIRegltyInfoOlHold = KREIRegltyInfoOlHold(testResources.kreiRegltyInfoOlHold_customized_testing, testResources.config)
    val result: KREIRegltyInfoOlHold = instancia.wrap(testResources.kreiRegltyInfoOlHold_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
