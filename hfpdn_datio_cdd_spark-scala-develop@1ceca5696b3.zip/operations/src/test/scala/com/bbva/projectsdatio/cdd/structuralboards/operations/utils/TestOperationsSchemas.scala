package com.bbva.projectsdatio.cdd.structuralboards.operations.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.datio.dataproc.sdk.schema.{DatioSchema, DatioSchemaForTesting}
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import java.net.URI

import org.mockito.Mockito.spy

trait TestOperationsSchemas {

  //PATHS
  lazy val schemaPath: String = "src/test/resources/schemas/operations/t_ktae_operation_struc_board.json"

  //SCHEMAS
  lazy val outputSchema: StructType = DatioSchema.getBuilder.fromURI(URI.create(schemaPath)).build().getStructType
  lazy val testingDataSchema: StructType = StructType(List(
    StructField("String"   , DataTypes.StringType, TRUE_VALUE),
    StructField("Int"      , DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double"   , DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date"     , DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))

  lazy val kaocEomOperation_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_operation_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_operation_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_operation_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaocEomOperation_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_operation_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_operation_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kaocEomAssetsLiabOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaocEomAssetsLiabOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kaocEomDomIntervenersOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_customer_id",                                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_main_holder_customer_type",                           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaocEomDomIntervenersOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_cont_main_holder_cust_id",                            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkCreditRiskOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_credit_risk_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                 DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkCreditRiskOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_credit_risk_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                 DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kctkCreditRiskOlHold_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                              DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_credit_risk_ol_hold_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_hold_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_hold_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                      DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kctkCreditRiskOlHold_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                              DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kctk_credit_risk_ol_hold_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_hold_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                      DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kdeoInapprtOpeSitutn_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_ope_situtn_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kdeoInapprtOpeSitutn_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kreiRegltyInfoOlHold_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                              DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_krei_reglty_info_ol_hold_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_reglty_info_ol_hold_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_reglty_info_ol_hold_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                      DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kreiRegltyInfoOlHold_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                              DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_krei_reglty_info_ol_hold_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_reglty_info_ol_hold_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                      DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kreiRegulatoryInfoOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_krei_regulatory_info_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_regulatory_info_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_regulatory_info_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kreiRegulatoryInfoOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_krei_regulatory_info_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_regulatory_info_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                     DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kslbFinancialAtrbOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                            DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kslb_financial_atrb_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kslb_financial_atrb_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kslb_financial_atrb_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kslbFinancialAtrbOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                            DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kslb_financial_atrb_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kslb_financial_atrb_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                     DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                    DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kstmAssetsLiabOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_assets_liab_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmAssetsLiabOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_assets_liab_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaocEomOutOfBalItemOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaocEomOutOfBalItemOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmSOffBalanceItemsOl_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_off_balance_items_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_not_relevant",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_to_rename",    DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstmSOffBalanceItemsOl_customized_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                  DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                    DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                   DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaoc_operations_union_schema: StructType = StructType(List(
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_renamed",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",  DataTypes.StringType, TRUE_VALUE),
    StructField("g_operation_number_id",                                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_initialized",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                        DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                                          DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                                         DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kstm_operations_union_schema: StructType = StructType(List(
    StructField("g_t_kstm_s_assets_liab_ol_relevant",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_operation_number_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_renamed",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant_renamed",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant_initialized",      DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                                         DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                                        DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_operations_after_join_testing_schema: StructType = StructType(List(
    StructField("g_operation_number_id",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kaoc_eom_operation_relevant",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_operation_relevant_renamed",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_operation_relevant_initialized",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_relevant",                    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_relevant_renamed",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_relevant_initialized",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_regulatory_info_ol_relevant",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_regulatory_info_ol_relevant_renamed",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_regulatory_info_ol_relevant_initialized",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant",                DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant_renamed",        DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kdeo_inapprt_ope_situtn_relevant_initialized",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_reglty_info_ol_hold_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_reglty_info_ol_hold_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_krei_reglty_info_ol_hold_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_cont_main_holder_cust_id",                          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant",            DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",    DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_hold_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_hold_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kctk_credit_risk_ol_hold_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kslb_financial_atrb_ol_relevant",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kslb_financial_atrb_ol_relevant_renamed",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kslb_financial_atrb_ol_relevant_initialized",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_renamed",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_assets_liab_ol_relevant_initialized",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kaoc_eom_out_of_bal_item_ol_relevant",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant",                       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_renamed",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant_renamed",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_assets_liab_ol_relevant_initialized",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kstm_s_off_balance_items_ol_relevant_initialized",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                                      DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                        DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                       DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kaocEomOperation_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomOperation_complete_input_testing_schema))
  lazy val kaocEomOperation_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomOperation_customized_testing_schema))
  lazy val kaocEomAssetsLiabOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomAssetsLiabOl_complete_input_testing_schema))
  lazy val kaocEomAssetsLiabOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomAssetsLiabOl_customized_testing_schema))
  lazy val kaocEomDomIntervenersOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomDomIntervenersOl_complete_input_testing_schema))
  lazy val kaocEomDomIntervenersOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomDomIntervenersOl_customized_testing_schema))
  lazy val kctkCreditRiskOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCreditRiskOl_complete_input_testing_schema))
  lazy val kctkCreditRiskOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCreditRiskOl_customized_testing_schema))
  lazy val kctkCreditRiskOlHold_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCreditRiskOlHold_complete_input_testing_schema))
  lazy val kctkCreditRiskOlHold_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kctkCreditRiskOlHold_customized_testing_schema))
  lazy val kdeoInapprtOpeSitutn_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoInapprtOpeSitutn_complete_input_testing_schema))
  lazy val kdeoInapprtOpeSitutn_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kdeoInapprtOpeSitutn_customized_testing_schema))
  lazy val kreiRegltyInfoOlHold_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kreiRegltyInfoOlHold_complete_input_testing_schema))
  lazy val kreiRegltyInfoOlHold_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kreiRegltyInfoOlHold_customized_testing_schema))
  lazy val kreiRegulatoryInfoOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kreiRegulatoryInfoOl_complete_input_testing_schema))
  lazy val kreiRegulatoryInfoOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kreiRegulatoryInfoOl_customized_testing_schema))
  lazy val kslbFinancialAtrbOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kslbFinancialAtrbOl_complete_input_testing_schema))
  lazy val kslbFinancialAtrbOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kslbFinancialAtrbOl_customized_testing_schema))
  lazy val kstmAssetsLiabOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmAssetsLiabOl_complete_input_testing_schema))
  lazy val kstmAssetsLiabOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmAssetsLiabOl_customized_testing_schema))
  lazy val kaocEomOutOfBalItemOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomOutOfBalItemOl_complete_input_testing_schema))
  lazy val kaocEomOutOfBalItemOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaocEomOutOfBalItemOl_customized_testing_schema))
  lazy val kstmSOffBalanceItemsOl_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmSOffBalanceItemsOl_complete_input_testing_schema))
  lazy val kstmSOffBalanceItemsOl_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstmSOffBalanceItemsOl_customized_testing_schema))
  lazy val kaoc_operations_union_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kaoc_operations_union_schema))
  lazy val kstm_operations_union_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kstm_operations_union_schema))
  lazy val ktae_operations_after_join_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_operations_after_join_testing_schema))
}
