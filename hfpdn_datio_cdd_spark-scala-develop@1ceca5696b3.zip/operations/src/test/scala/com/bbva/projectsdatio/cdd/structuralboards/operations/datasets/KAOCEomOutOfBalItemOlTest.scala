package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KAOCEomOutOfBalItemOlTest extends TestOperations {
  test("kaocEomOutOfBalItemOl_wrap") {
    val instancia: KAOCEomOutOfBalItemOl = KAOCEomOutOfBalItemOl(testResources.kaocEomOutOfBalItemOl_complete_input_testing, testResources.config)
    val result: KAOCEomOutOfBalItemOl = instancia.wrap(testResources.kaocEomOutOfBalItemOl_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
