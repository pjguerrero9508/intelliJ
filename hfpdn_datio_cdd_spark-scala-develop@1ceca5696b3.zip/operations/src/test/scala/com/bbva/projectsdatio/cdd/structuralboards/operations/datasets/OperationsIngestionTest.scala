package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.CDDStructuralBoardsDataset
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.{FileSystemUtils, WriteUtils}
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.bbva.projectsdatio.cdd.structuralboards.operations.app.StructuralboardsOperations_RQ42021
import com.bbva.projectsdatio.cdd.structuralboards.operations.{TestOperations, datasets}
import com.bbva.projectsdatio.cdd.structuralboards.operations.utils.TestUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class OperationsIngestionTest extends TestOperations {

  test("operationsIngestion_joinTablon") {
    val kaocEomOperation = KAOCEomOperation(testResources.kaocEomOperation_complete_input, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kaocEomAssetsLiabOl = KAOCEomAssetsLiabOl(testResources.kaocEomAssetsLiabOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kstmAssetsLiabOl = KSTMAssetsLiabOl(testResources.kstmAssetsLiabOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kdeoInapprtOpeSitutn = KDEOInapprtOpeSitutn(testResources.kdeoInapprtOpeSitutn_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kreiRegulatoryInfoOl = KREIRegulatoryInfoOl(testResources.kreiRegulatoryInfoOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kctkCreditRiskOl = KCTKCreditRiskOl(testResources.kctkCreditRiskOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kreiRegltyInfoOlHold = KREIRegltyInfoOlHold(testResources.kreiRegltyInfoOlHold_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kaocEomDomIntervenersOl = KAOCEomDomIntervenersOl(testResources.kaocEomDomIntervenersOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kslbFinancialAtrbOl = KSLBFinancialAtrbOl(testResources.kslbFinancialAtrbOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kctkCreditRiskOlHold = KCTKCreditRiskOlHold(testResources.kctkCreditRiskOlHold_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kaocEomOutOfBalItemOl = KAOCEomOutOfBalItemOl(testResources.kaocEomOutOfBalItemOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kstmSOffBalanceItemsOl = KSTMSOffBalanceItemsOl(testResources.kstmSOffBalanceItemsOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()

    val datasetMap: Map[String,CDDStructuralBoardsDataset[_]] = Map(
      OPERATIONS_BOARD_TABLE_EOM_OPERATION -> kaocEomOperation,
      OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL -> kaocEomAssetsLiabOl,
      OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL -> kstmAssetsLiabOl,
      OPERATIONS_BOARD_TABLE_INAPPRT_OPE_SITUTN -> kdeoInapprtOpeSitutn,
      OPERATIONS_BOARD_TABLE_REGULATORY_INFO_OL -> kreiRegulatoryInfoOl,
      OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL -> kctkCreditRiskOl,
      OPERATIONS_BOARD_TABLE_REGLTY_INFO_OL_HOLD -> kreiRegltyInfoOlHold,
      OPERATIONS_BOARD_TABLE_EOM_DOM_INTERVENERS_OL -> kaocEomDomIntervenersOl,
      OPERATIONS_BOARD_TABLE_FINANCIAL_ATRB_OL -> kslbFinancialAtrbOl,
      OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL_HOLD -> kctkCreditRiskOlHold,
      OPERATIONS_BOARD_TABLE_EOM_OUT_OF_BAL_ITEM_OL -> kaocEomOutOfBalItemOl,
      OPERATIONS_BOARD_TABLE_S_OFF_BALANCE_ITEMS_OL -> kstmSOffBalanceItemsOl
    )
    val unionDataset = (new StructuralboardsOperations_RQ42021).operationsUnion(datasetMap, testResources.config, testResources.globalReaded)
    val datasetMapComplete: Map[String, CDDStructuralBoardsDataset[_]] = datasetMap
      . +(OPERATIONS_BOARD_UNION_KAOC -> unionDataset._1)
      . +(OPERATIONS_BOARD_UNION_KSTM -> unionDataset._2)
    val result: DataFrame = (new StructuralboardsOperations_RQ42021).joinTablon(datasetMapComplete,
      testResources.globalReaded, testResources.globalTranslated, datioSparkSession).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ktae_operations_after_join_testing, FALSE_VALUE) shouldBe true
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("operationsIngestion_dataSetCollectorMapper_KAOCEomAssetsLiabOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KAOCEomAssetsLiabOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }


  test("operationsIngestion_dataSetCollectorMapper_KAOCEomDomIntervenersOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_EOM_DOM_INTERVENERS_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KAOCEomDomIntervenersOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }


  test("operationsIngestion_dataSetCollectorMapper_KCTKCreditRiskOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKCreditRiskOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KCTKCreditRiskOlHold") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL_HOLD
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KCTKCreditRiskOlHold])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KDEOInapprtOpeSitutn") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_INAPPRT_OPE_SITUTN
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KDEOInapprtOpeSitutn])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KREIRegltyInfoOlHold") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_REGLTY_INFO_OL_HOLD
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KREIRegltyInfoOlHold])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KREIRegulatoryInfoOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_REGULATORY_INFO_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KREIRegulatoryInfoOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KSLBFinancialAtrbOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_FINANCIAL_ATRB_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSLBFinancialAtrbOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KSTMAssetsLiabOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSTMAssetsLiabOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KAOCEomOutOfBalItemOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_EOM_OUT_OF_BAL_ITEM_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KAOCEomOutOfBalItemOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_dataSetCollectorMapper_KSTMSOffBalanceItemsOl") {
    val testInputEntityName : String = OPERATIONS_BOARD_TABLE_S_OFF_BALANCE_ITEMS_OL
    val result = (new StructuralboardsOperations_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KSTMSOffBalanceItemsOl])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("operationsIngestion_unionOperations") {
    val kaocEomAssetsLiabOl = KAOCEomAssetsLiabOl(testResources.kaocEomAssetsLiabOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kaocEomOutOfBalItemOl = KAOCEomOutOfBalItemOl(testResources.kaocEomOutOfBalItemOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kstmSAssetsLiabOl = KSTMAssetsLiabOl(testResources.kstmAssetsLiabOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()
    val kstmSOffBalanceItemsOl = KSTMSOffBalanceItemsOl(testResources.kstmSOffBalanceItemsOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).globalParameterSetter()

    val dataSetMap: Map[String, CDDStructuralBoardsDataset[_]] = Map(
      OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL -> kaocEomAssetsLiabOl,
      OPERATIONS_BOARD_TABLE_EOM_OUT_OF_BAL_ITEM_OL -> kaocEomOutOfBalItemOl,
      OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL -> kstmSAssetsLiabOl,
      OPERATIONS_BOARD_TABLE_S_OFF_BALANCE_ITEMS_OL -> kstmSOffBalanceItemsOl
    )
    val result = (new StructuralboardsOperations_RQ42021).operationsUnion(dataSetMap, testResources.config, testResources.globalReaded)
    TestUtils.assertDataFrameEquals(result._1.getDataFrame(), testResources.kaoc_operations_union, FALSE_VALUE) shouldBe TRUE_VALUE
    TestUtils.assertDataFrameEquals(result._2.getDataFrame(), testResources.kstm_operations_union, FALSE_VALUE) shouldBe TRUE_VALUE
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }
}
