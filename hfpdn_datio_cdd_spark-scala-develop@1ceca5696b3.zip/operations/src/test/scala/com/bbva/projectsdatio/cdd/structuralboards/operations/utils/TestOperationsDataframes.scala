package com.bbva.projectsdatio.cdd.structuralboards.operations.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.NULL_VALUE
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.{DataFrame, Row}

class TestOperationsDataframes(datioSparkSession: DatioSparkSession) extends TestOperationsSchemas {

  //CDD DATASETS
  val testingEmptyDataRows: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
  val testingEmptyDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, testingDataSchema)
  val testingEmptyCDDOperationsDataFrame: DataFrame = datioSparkSession.getSparkSession.createDataFrame(testingEmptyDataRows, outputSchema)

  lazy val kaocEomOperation_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_operation_relevant ,  g_t_kaoc_eom_operation_not_relevant ,  g_t_kaoc_eom_operation_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_not_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_not_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_not_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_not_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_not_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_complete_input_testing_schema)
  )
  lazy val kaocEomOperation_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_operation_relevant , g_t_kaoc_eom_operation_relevant_renamed    , g_t_kaoc_eom_operation_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOperation_customized_testing_schema)
  )
  lazy val kaocEomOperation_complete_input_testing_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomOperation_complete_input_testing_rows, 1)
  lazy val kaocEomOperation_customized_testing_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomOperation_customized_testing_rows, 1)
  lazy val kaocEomOperation_complete_input: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomOperation_complete_input_testing_rdd, kaocEomOperation_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kaocEomOperation_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomOperation_customized_testing_rdd, kaocEomOperation_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kaocEomAssetsLiabOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_assets_liab_ol_relevant ,  g_t_kaoc_eom_assets_liab_ol_not_relevant ,  g_t_kaoc_eom_assets_liab_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kaoc_eom_assets_liab_ol_relevant", "g_t_kaoc_eom_assets_liab_ol_not_relevant", "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomAssetsLiabOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kaoc_eom_assets_liab_ol_relevant", "g_t_kaoc_eom_assets_liab_ol_not_relevant", "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomAssetsLiabOl_complete_input_testing_schema)
  )
  lazy val kaocEomAssetsLiabOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_assets_liab_ol_relevant ,  g_t_kaoc_eom_assets_liab_ol_relevant_renamed    , g_t_kaoc_eom_assets_liab_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kaoc_eom_assets_liab_ol_relevant", "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomAssetsLiabOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kaoc_eom_assets_liab_ol_relevant", "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomAssetsLiabOl_customized_testing_schema)
  )
  lazy val kaocEomAssetsLiabOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomAssetsLiabOl_complete_input_testing_rows, 1)
  lazy val kaocEomAssetsLiabOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomAssetsLiabOl_customized_testing_rows, 1)
  lazy val kaocEomAssetsLiabOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomAssetsLiabOl_complete_input_testing_rows_rdd, kaocEomAssetsLiabOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kaocEomAssetsLiabOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomAssetsLiabOl_customized_testing_rows_rdd, kaocEomAssetsLiabOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kaocEomDomIntervenersOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id ,  g_customer_id, g_main_holder_customer_type,  g_t_kaoc_eom_dom_interveners_ol_relevant ,  g_t_kaoc_eom_dom_interveners_ol_not_relevant ,  g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "customerId01", "Y"                        , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_not_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "customerId02", "Y"                        , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_not_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "customerId03", "Y"                        , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_not_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "customerId04", "Y"                        , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_not_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "customerId05", "Y"                        , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_not_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0006"     , "customerId06", "N"                        , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_not_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_complete_input_testing_schema)
  )
  lazy val kaocEomDomIntervenersOl_customized_testing_rows = Seq(
    //                             g_operation_number_id , g_cont_main_holder_cust_id,  g_t_kaoc_eom_dom_interveners_ol_relevant ,  g_t_kaoc_eom_dom_interveners_ol_relevant_renamed    , g_t_kaoc_eom_dom_interveners_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "customerId01"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "customerId02"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "customerId03"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "customerId04"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "customerId05"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomDomIntervenersOl_customized_testing_schema)
  )
  lazy val kaocEomDomIntervenersOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomDomIntervenersOl_complete_input_testing_rows, 1)
  lazy val kaocEomDomIntervenersOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomDomIntervenersOl_customized_testing_rows, 1)
  lazy val kaocEomDomIntervenersOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomDomIntervenersOl_complete_input_testing_rows_rdd, kaocEomDomIntervenersOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kaocEomDomIntervenersOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomDomIntervenersOl_customized_testing_rows_rdd, kaocEomDomIntervenersOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kctkCreditRiskOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kctk_credit_risk_ol_relevant ,  g_t_kctk_credit_risk_ol_not_relevant ,  g_t_kctk_credit_risk_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_not_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_not_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_not_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_not_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_not_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_complete_input_testing_schema)
  )
  lazy val kctkCreditRiskOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kctk_credit_risk_ol_relevant ,  g_t_kctk_credit_risk_ol_relevant_renamed    , g_t_kctk_credit_risk_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOl_customized_testing_schema)
  )
  lazy val kctkCreditRiskOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCreditRiskOl_complete_input_testing_rows, 1)
  lazy val kctkCreditRiskOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCreditRiskOl_customized_testing_rows, 1)
  lazy val kctkCreditRiskOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCreditRiskOl_complete_input_testing_rows_rdd, kctkCreditRiskOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkCreditRiskOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCreditRiskOl_customized_testing_rows_rdd, kctkCreditRiskOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")



  lazy val kctkCreditRiskOlHold_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kctk_credit_risk_ol_hold_relevant ,  g_t_kctk_credit_risk_ol_hold_not_relevant ,  g_t_kctk_credit_risk_ol_hold_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_not_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_not_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_not_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_not_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_not_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_complete_input_testing_schema)
  )
  lazy val kctkCreditRiskOlHold_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kctk_credit_risk_ol_hold_relevant ,  g_t_kctk_credit_risk_ol_hold_relevant_renamed    , g_t_kctk_credit_risk_ol_hold_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kctkCreditRiskOlHold_customized_testing_schema)
  )
  lazy val kctkCreditRiskOlHold_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCreditRiskOlHold_complete_input_testing_rows, 1)
  lazy val kctkCreditRiskOlHold_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kctkCreditRiskOlHold_customized_testing_rows, 1)
  lazy val kctkCreditRiskOlHold_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCreditRiskOlHold_complete_input_testing_rows_rdd, kctkCreditRiskOlHold_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kctkCreditRiskOlHold_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kctkCreditRiskOlHold_customized_testing_rows_rdd, kctkCreditRiskOlHold_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")



  lazy val kdeoInapprtOpeSitutn_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kdeo_inapprt_ope_situtn_relevant ,  g_t_kdeo_inapprt_ope_situtn_not_relevant ,  g_t_kdeo_inapprt_ope_situtn_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_not_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_not_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_not_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_not_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_not_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_complete_input_testing_schema)
  )
  lazy val kdeoInapprtOpeSitutn_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kdeo_inapprt_ope_situtn_relevant ,  g_t_kdeo_inapprt_ope_situtn_relevant_renamed    , g_t_kdeo_inapprt_ope_situtn_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kdeoInapprtOpeSitutn_customized_testing_schema)
  )
  lazy val kdeoInapprtOpeSitutn_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoInapprtOpeSitutn_complete_input_testing_rows, 1)
  lazy val kdeoInapprtOpeSitutn_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kdeoInapprtOpeSitutn_customized_testing_rows, 1)
  lazy val kdeoInapprtOpeSitutn_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoInapprtOpeSitutn_complete_input_testing_rows_rdd, kdeoInapprtOpeSitutn_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kdeoInapprtOpeSitutn_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kdeoInapprtOpeSitutn_customized_testing_rows_rdd, kdeoInapprtOpeSitutn_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")



  lazy val kreiRegltyInfoOlHold_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_krei_reglty_info_ol_hold_relevant ,  g_t_krei_reglty_info_ol_hold_not_relevant ,  g_t_krei_reglty_info_ol_hold_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_not_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_not_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_not_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_not_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_not_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_complete_input_testing_schema)
  )
  lazy val kreiRegltyInfoOlHold_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_krei_reglty_info_ol_hold_relevant ,  g_t_krei_reglty_info_ol_hold_relevant_renamed    , g_t_krei_reglty_info_ol_hold_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegltyInfoOlHold_customized_testing_schema)
  )
  lazy val kreiRegltyInfoOlHold_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kreiRegltyInfoOlHold_complete_input_testing_rows, 1)
  lazy val kreiRegltyInfoOlHold_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kreiRegltyInfoOlHold_customized_testing_rows, 1)
  lazy val kreiRegltyInfoOlHold_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kreiRegltyInfoOlHold_complete_input_testing_rows_rdd, kreiRegltyInfoOlHold_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kreiRegltyInfoOlHold_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kreiRegltyInfoOlHold_customized_testing_rows_rdd, kreiRegltyInfoOlHold_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")



  lazy val kreiRegulatoryInfoOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_krei_regulatory_info_ol_relevant ,  g_t_krei_regulatory_info_ol_not_relevant ,  g_t_krei_regulatory_info_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_not_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_not_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_not_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_not_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_not_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_complete_input_testing_schema)
  )
  lazy val kreiRegulatoryInfoOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_krei_regulatory_info_ol_relevant ,  g_t_krei_regulatory_info_ol_relevant_renamed    , g_t_krei_regulatory_info_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kreiRegulatoryInfoOl_customized_testing_schema)
  )
  lazy val kreiRegulatoryInfoOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kreiRegulatoryInfoOl_complete_input_testing_rows, 1)
  lazy val kreiRegulatoryInfoOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kreiRegulatoryInfoOl_customized_testing_rows, 1)
  lazy val kreiRegulatoryInfoOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kreiRegulatoryInfoOl_complete_input_testing_rows_rdd, kreiRegulatoryInfoOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kreiRegulatoryInfoOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kreiRegulatoryInfoOl_customized_testing_rows_rdd, kreiRegulatoryInfoOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")



  lazy val kslbFinancialAtrbOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kslb_financial_atrb_ol_relevant ,  g_t_kslb_financial_atrb_ol_not_relevant ,  g_t_kslb_financial_atrb_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_not_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_not_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_not_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_not_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_not_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_complete_input_testing_schema)
  )
  lazy val kslbFinancialAtrbOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kslb_financial_atrb_ol_relevant ,  g_t_kslb_financial_atrb_ol_relevant_renamed    , g_t_kslb_financial_atrb_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"     , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kslbFinancialAtrbOl_customized_testing_schema)
  )
  lazy val kslbFinancialAtrbOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kslbFinancialAtrbOl_complete_input_testing_rows, 1)
  lazy val kslbFinancialAtrbOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kslbFinancialAtrbOl_customized_testing_rows, 1)
  lazy val kslbFinancialAtrbOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kslbFinancialAtrbOl_complete_input_testing_rows_rdd, kslbFinancialAtrbOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kslbFinancialAtrbOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kslbFinancialAtrbOl_customized_testing_rows_rdd, kslbFinancialAtrbOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")



  lazy val kstmAssetsLiabOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kstm_s_assets_liab_ol_relevant ,  g_t_kstm_s_assets_liab_ol_not_relevant ,  g_t_kstm_s_assets_liab_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kstm_s_assets_liab_ol_relevant", "g_t_kstm_s_assets_liab_ol_not_relevant", "g_t_kstm_s_assets_liab_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kstm_s_assets_liab_ol_relevant", "g_t_kstm_s_assets_liab_ol_not_relevant", "g_t_kstm_s_assets_liab_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabOl_complete_input_testing_schema)
  )
  lazy val kstmAssetsLiabOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kstm_s_assets_liab_ol_relevant ,  g_t_kstm_s_assets_liab_ol_relevant_renamed    , g_t_kstm_s_assets_liab_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"     , "g_t_kstm_s_assets_liab_ol_relevant", "g_t_kstm_s_assets_liab_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"     , "g_t_kstm_s_assets_liab_ol_relevant", "g_t_kstm_s_assets_liab_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmAssetsLiabOl_customized_testing_schema)
  )
  lazy val kstmAssetsLiabOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmAssetsLiabOl_complete_input_testing_rows, 1)
  lazy val kstmAssetsLiabOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmAssetsLiabOl_customized_testing_rows, 1)
  lazy val kstmAssetsLiabOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmAssetsLiabOl_complete_input_testing_rows_rdd, kstmAssetsLiabOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kstmAssetsLiabOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmAssetsLiabOl_customized_testing_rows_rdd, kstmAssetsLiabOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kaocEomOutOfBalItemOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_out_of_bal_item_ol_relevant ,  g_t_kaoc_eom_out_of_bal_item_ol_not_relevant ,  g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kaoc_eom_out_of_bal_item_ol_relevant", "g_t_kaoc_eom_out_of_bal_item_ol_not_relevant", "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOutOfBalItemOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kaoc_eom_out_of_bal_item_ol_relevant", "g_t_kaoc_eom_out_of_bal_item_ol_not_relevant", "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOutOfBalItemOl_complete_input_testing_schema)
  )
  lazy val kaocEomOutOfBalItemOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_out_of_bal_item_ol_relevant ,  g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed    , g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kaoc_eom_out_of_bal_item_ol_relevant", "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOutOfBalItemOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kaoc_eom_out_of_bal_item_ol_relevant", "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kaocEomOutOfBalItemOl_customized_testing_schema)
  )
  lazy val kaocEomOutOfBalItemOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomOutOfBalItemOl_complete_input_testing_rows, 1)
  lazy val kaocEomOutOfBalItemOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaocEomOutOfBalItemOl_customized_testing_rows, 1)
  lazy val kaocEomOutOfBalItemOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomOutOfBalItemOl_complete_input_testing_rows_rdd, kaocEomOutOfBalItemOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kaocEomOutOfBalItemOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaocEomOutOfBalItemOl_customized_testing_rows_rdd, kaocEomOutOfBalItemOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kstmSOffBalanceItemsOl_complete_input_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kstm_s_off_balance_items_ol_relevant ,  g_t_kstm_s_off_balance_items_ol_not_relevant ,  g_t_kstm_s_off_balance_items_ol_relevant_to_rename , gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kstm_s_off_balance_items_ol_relevant", "g_t_kstm_s_off_balance_items_ol_not_relevant", "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmSOffBalanceItemsOl_complete_input_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kstm_s_off_balance_items_ol_relevant", "g_t_kstm_s_off_balance_items_ol_not_relevant", "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmSOffBalanceItemsOl_complete_input_testing_schema)
  )
  lazy val kstmSOffBalanceItemsOl_customized_testing_rows = Seq(
    //                             g_operation_number_id,  g_t_kstm_s_off_balance_items_ol_relevant ,  g_t_kstm_s_off_balance_items_ol_relevant_renamed    , g_t_kstm_s_off_balance_items_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0003"     , "g_t_kstm_s_off_balance_items_ol_relevant", "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmSOffBalanceItemsOl_customized_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"     , "g_t_kstm_s_off_balance_items_ol_relevant", "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", NULL_VALUE                           , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111"), kstmSOffBalanceItemsOl_customized_testing_schema)
  )
  lazy val kstmSOffBalanceItemsOl_complete_input_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmSOffBalanceItemsOl_complete_input_testing_rows, 1)
  lazy val kstmSOffBalanceItemsOl_customized_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstmSOffBalanceItemsOl_customized_testing_rows, 1)
  lazy val kstmSOffBalanceItemsOl_complete_input_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmSOffBalanceItemsOl_complete_input_testing_rows_rdd, kstmSOffBalanceItemsOl_complete_input_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
  lazy val kstmSOffBalanceItemsOl_customized_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstmSOffBalanceItemsOl_customized_testing_rows_rdd, kstmSOffBalanceItemsOl_customized_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val kaoc_operations_union_rows = Seq(
    //                              g_t_kaoc_eom_assets_liab_ol_relevant",  g_t_kaoc_eom_assets_liab_ol_relevant_renamed   , g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized, g_operation_number_id, g_t_kaoc_eom_assets_liab_ol_relevant_initialized,  g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed   ,  g_t_kaoc_eom_out_of_bal_item_ol_relevant
    new GenericRowWithSchema(Array("g_t_kaoc_eom_assets_liab_ol_relevant"  ,  "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename" , NULL_VALUE                                          , "operationId0001"    , NULL_VALUE                                        , NULL_VALUE                                          ,  NULL_VALUE                                    , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kaoc_operations_union_schema),
    new GenericRowWithSchema(Array("g_t_kaoc_eom_assets_liab_ol_relevant"  ,  "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename" , NULL_VALUE                                          , "operationId0002"    , NULL_VALUE                                        , NULL_VALUE                                          ,  NULL_VALUE                                    , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kaoc_operations_union_schema),
    new GenericRowWithSchema(Array(NULL_VALUE                              ,  NULL_VALUE                                      , NULL_VALUE                                          , "operationId0003"    , NULL_VALUE                                        ,"g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename" , "g_t_kaoc_eom_out_of_bal_item_ol_relevant"     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kaoc_operations_union_schema),
    new GenericRowWithSchema(Array(NULL_VALUE                              ,  NULL_VALUE                                      , NULL_VALUE                                          , "operationId0004"    , NULL_VALUE                                        ,"g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename" , "g_t_kaoc_eom_out_of_bal_item_ol_relevant"     , "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kaoc_operations_union_schema)
  )
  lazy val kaoc_operations_union_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kaoc_operations_union_rows, 1)
  lazy val kaoc_operations_union: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kaoc_operations_union_rows_rdd, kaoc_operations_union_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")


  lazy val kstm_operations_union_rows = Seq(
    //                              g_t_kstm_s_assets_liab_ol_relevant, g_operation_number_id, g_t_kstm_s_off_balance_items_ol_relevant_renamed,   g_t_kstm_s_off_balance_items_ol_relevant,    g_t_kstm_s_assets_liab_ol_relevant_renamed,      g_t_kstm_s_assets_liab_ol_relevant_initialized, g_t_kstm_s_off_balance_items_ol_relevant_initialized ,  g_t_kstm_s_off_balance_items_ol_relevant_initialized , ,
    new GenericRowWithSchema(Array("g_t_kstm_s_assets_liab_ol_relevant", "operationId0001"   , NULL_VALUE                                          ,NULL_VALUE                                  , "g_t_kstm_s_assets_liab_ol_relevant_to_rename" ,NULL_VALUE                                   , NULL_VALUE  ,  "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_operations_union_schema),
    new GenericRowWithSchema(Array("g_t_kstm_s_assets_liab_ol_relevant", "operationId0002"   , NULL_VALUE                                          ,NULL_VALUE                                  , "g_t_kstm_s_assets_liab_ol_relevant_to_rename" ,NULL_VALUE                                   , NULL_VALUE  ,  "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_operations_union_schema),
    new GenericRowWithSchema(Array(NULL_VALUE                          , "operationId0003"   , "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", "g_t_kstm_s_off_balance_items_ol_relevant" ,NULL_VALUE                                      ,NULL_VALUE                                   , NULL_VALUE  ,  "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_operations_union_schema),
    new GenericRowWithSchema(Array(NULL_VALUE                          , "operationId0004"   , "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", "g_t_kstm_s_off_balance_items_ol_relevant" ,NULL_VALUE                                      ,NULL_VALUE                                   , NULL_VALUE  ,  "2020-07-31"  , "GL"        , "2020-01-01 04:32:32.111111" ), kstm_operations_union_schema)
  )
  lazy val kstm_operations_union_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(kstm_operations_union_rows, 1)
  lazy val kstm_operations_union: DataFrame = datioSparkSession.getSparkSession.createDataFrame(kstm_operations_union_rows_rdd, kstm_operations_union_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")

  lazy val ktae_operations_after_join_rows = Seq(
    //                             g_operation_number_id,  g_t_kaoc_eom_operation_relevant ,  g_t_kaoc_eom_operation_relevant_renamed   , g_t_kaoc_eom_operation_relevant_initialized,  g_t_kctk_credit_risk_ol_relevant ,  g_t_kctk_credit_risk_ol_relevant_renamed   , g_t_kctk_credit_risk_ol_relevant_initialized,  g_t_krei_regulatory_info_ol_relevant ,  g_t_krei_regulatory_info_ol_relevant_renamed   , g_t_krei_regulatory_info_ol_relevant_initialized,  g_t_kdeo_inapprt_ope_situtn_relevant ,  g_t_kdeo_inapprt_ope_situtn_relevant_renamed   , g_t_kdeo_inapprt_ope_situtn_relevant_initialized,  g_t_krei_reglty_info_ol_hold_relevant ,  g_t_krei_reglty_info_ol_hold_relevant_renamed   , g_t_krei_reglty_info_ol_hold_relevant_initialized, g_cont_main_holder_cust_id,  g_t_kaoc_eom_dom_interveners_ol_relevant ,  g_t_kaoc_eom_dom_interveners_ol_relevant_renamed   , g_t_kaoc_eom_dom_interveners_ol_relevant_initialized,  g_t_kctk_credit_risk_ol_hold_relevant ,  g_t_kctk_credit_risk_ol_hold_relevant_renamed   , g_t_kctk_credit_risk_ol_hold_relevant_initialized,  g_t_kslb_financial_atrb_ol_relevant ,  g_t_kslb_financial_atrb_ol_relevant_renamed   , g_t_kslb_financial_atrb_ol_relevant_initialized,  g_t_kaoc_eom_assets_liab_ol_relevant ,  g_t_kaoc_eom_assets_liab_ol_relevant_renamed    g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized, g_t_kaoc_eom_assets_liab_ol_relevant_initialized, g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename    , g_t_kaoc_eom_out_of_bal_item_ol_relevant  ,  g_t_kstm_s_assets_liab_ol_relevant ,  g_t_kstm_s_off_balance_items_ol_relevant_renamed   , g_t_kstm_s_off_balance_items_ol_relevant      ,g_t_kstm_s_assets_liab_ol_relevant_renamed     , g_t_kstm_s_assets_liab_ol_relevant_initialized, g_t_kstm_s_off_balance_items_ol_relevant_initialized, gf_cutoff_date, g_entific_id, gf_audit_date
    new GenericRowWithSchema(Array("operationId0001"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                                  , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                                      , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                                      , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                                       , "customerId01"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                                          , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                                       , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                                     , "g_t_kaoc_eom_assets_liab_ol_relevant", "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename", NULL_VALUE                                         , NULL_VALUE                                      , NULL_VALUE                                          , NULL_VALUE                                , "g_t_kstm_s_assets_liab_ol_relevant", NULL_VALUE                                          , NULL_VALUE                                    , "g_t_kstm_s_assets_liab_ol_relevant_to_rename", NULL_VALUE                                    , NULL_VALUE                                          , "2020-07-31",   "GL"        , "2020-01-01 04:32:32.111111"), ktae_operations_after_join_testing_schema),
    new GenericRowWithSchema(Array("operationId0002"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                                  , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                                      , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                                      , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                                       , "customerId02"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                                          , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                                       , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                                     , "g_t_kaoc_eom_assets_liab_ol_relevant", "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename", NULL_VALUE                                         , NULL_VALUE                                      , NULL_VALUE                                          , NULL_VALUE                                , "g_t_kstm_s_assets_liab_ol_relevant", NULL_VALUE                                          , NULL_VALUE                                    , "g_t_kstm_s_assets_liab_ol_relevant_to_rename", NULL_VALUE                                    , NULL_VALUE                                          , "2020-07-31",   "GL"        , "2020-01-01 04:32:32.111111"), ktae_operations_after_join_testing_schema),
    new GenericRowWithSchema(Array("operationId0003"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                                  , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                                      , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                                      , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                                       , "customerId03"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                                          , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                                       , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                                     , NULL_VALUE                            , NULL_VALUE                                      , NULL_VALUE                                         , NULL_VALUE                                      , "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename", "g_t_kaoc_eom_out_of_bal_item_ol_relevant", NULL_VALUE                          , "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", "g_t_kstm_s_off_balance_items_ol_relevant"    , NULL_VALUE                                    , NULL_VALUE                                    , NULL_VALUE                                          , "2020-07-31",   "GL"        , "2020-01-01 04:32:32.111111"), ktae_operations_after_join_testing_schema),
    new GenericRowWithSchema(Array("operationId0004"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                                  , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                                      , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                                      , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                                       , "customerId04"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                                          , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                                       , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                                     , NULL_VALUE                            , NULL_VALUE                                      , NULL_VALUE                                         , NULL_VALUE                                      , "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename", "g_t_kaoc_eom_out_of_bal_item_ol_relevant", NULL_VALUE                          , "g_t_kstm_s_off_balance_items_ol_relevant_to_rename", "g_t_kstm_s_off_balance_items_ol_relevant"    , NULL_VALUE                                    , NULL_VALUE                                    , NULL_VALUE                                          , "2020-07-31",   "GL"        , "2020-01-01 04:32:32.111111"), ktae_operations_after_join_testing_schema),
    new GenericRowWithSchema(Array("operationId0005"    , "g_t_kaoc_eom_operation_relevant", "g_t_kaoc_eom_operation_relevant_to_rename", NULL_VALUE                                 , "g_t_kctk_credit_risk_ol_relevant", "g_t_kctk_credit_risk_ol_relevant_to_rename", NULL_VALUE                                  , "g_t_krei_regulatory_info_ol_relevant", "g_t_krei_regulatory_info_ol_relevant_to_rename", NULL_VALUE                                      , "g_t_kdeo_inapprt_ope_situtn_relevant", "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename", NULL_VALUE                                      , "g_t_krei_reglty_info_ol_hold_relevant", "g_t_krei_reglty_info_ol_hold_relevant_to_rename", NULL_VALUE                                       , "customerId05"            , "g_t_kaoc_eom_dom_interveners_ol_relevant", "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename", NULL_VALUE                                          , "g_t_kctk_credit_risk_ol_hold_relevant", "g_t_kctk_credit_risk_ol_hold_relevant_to_rename", NULL_VALUE                                       , "g_t_kslb_financial_atrb_ol_relevant", "g_t_kslb_financial_atrb_ol_relevant_to_rename", NULL_VALUE                                     , NULL_VALUE                            , NULL_VALUE                                      , NULL_VALUE                                         , NULL_VALUE                                      , NULL_VALUE                                          , NULL_VALUE                                , NULL_VALUE                          , NULL_VALUE                                          , NULL_VALUE                                    , NULL_VALUE                                    , NULL_VALUE                                    , NULL_VALUE                                          , "2020-07-31",   "GL"        , "2020-01-01 04:32:32.111111"), ktae_operations_after_join_testing_schema)
  )
  lazy val ktae_operations_after_join_testing_rows_rdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.parallelize(ktae_operations_after_join_rows, 1)
  lazy val ktae_operations_after_join_testing: DataFrame = datioSparkSession.getSparkSession.createDataFrame(ktae_operations_after_join_testing_rows_rdd, ktae_operations_after_join_testing_schema)
    .drop("gf_cutoff_date")
    .drop("g_entific_id")
    .drop("gf_audit_date")
}
