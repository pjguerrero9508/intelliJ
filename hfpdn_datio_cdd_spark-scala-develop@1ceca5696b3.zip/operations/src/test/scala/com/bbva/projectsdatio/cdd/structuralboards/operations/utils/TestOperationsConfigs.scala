package com.bbva.projectsdatio.cdd.structuralboards.operations.utils

import com.typesafe.config.{Config, ConfigFactory}

trait TestOperationsConfigs {

  //CONSTANTS
  val confStruct: String = "CDDOperationsBoard"

  //CONFIG FILES
  lazy val config: Config = rootConfig.getConfig(confStruct)
  lazy val configBadSelect: Config = rootConfigBadSelect.getConfig(confStruct)
  lazy val configMissSelect: Config = rootConfigMissSelect.getConfig(confStruct)
  lazy val configBadFields: Config = rootConfigBadFields.getConfig(confStruct)
  lazy val configMissFields: Config = rootConfigMissFields.getConfig(confStruct)
  lazy val configBadJoinFields: Config = rootConfigBadJoinFields.getConfig(confStruct)

  lazy val ktaeOperationsBoardRoot_complete : String =
    """CDDOperationsBoard {
      |  dateIngestion = "2020-08-08"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 4
      |  schemaPath = "src/test/resources/schemas/operations/t_ktae_operation_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/operationsIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/operationsIngestion/principal"
      |  }"""

  lazy val kaocEomOperation_correct : String =
    """|  kaocEomOperation = {
       |    dataPath = "src/test/resources/data/kaocEomOperation/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_operation.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_operation_relevant_to_rename"
       |      newFieldNames = "g_t_kaoc_eom_operation_relevant_renamed"
       |    }
       |    selectTablonFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_relevant",
       |      "g_t_kctk_credit_risk_ol_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_relevant_initialized",
       |      "g_t_krei_regulatory_info_ol_relevant",
       |      "g_t_krei_regulatory_info_ol_relevant_renamed",
       |      "g_t_krei_regulatory_info_ol_relevant_initialized",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_initialized",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_renamed",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_initialized",
       |      "g_t_kstm_s_assets_liab_ol_relevant",
       |      "g_t_kstm_s_assets_liab_ol_relevant_renamed",
       |      "g_t_kstm_s_assets_liab_ol_relevant_initialized",
       |      "g_t_krei_reglty_info_ol_hold_relevant",
       |      "g_t_krei_reglty_info_ol_hold_relevant_renamed",
       |      "g_t_krei_reglty_info_ol_hold_relevant_initialized",
       |      "g_cont_main_holder_cust_id",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_hold_relevant",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_initialized",
       |      "g_t_kslb_financial_atrb_ol_relevant",
       |      "g_t_kslb_financial_atrb_ol_relevant_renamed",
       |      "g_t_kslb_financial_atrb_ol_relevant_initialized",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_ol_relevant",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_initialized"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomOperation_badJoinFields : String =
    """|  kaocEomOperation = {
       |    dataPath = "src/test/resources/data/kaocEomOperation/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_operation.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_operation_relevant_to_rename"
       |      newFieldNames = "g_t_kaoc_eom_operation_relevant_renamed"
       |    }
       |    selectTablonFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_relevant",
       |      "g_t_kctk_credit_risk_ol_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_relevant_initialized",
       |      "g_t_krei_regulatory_info_ol_relevant",
       |      "g_t_krei_regulatory_info_ol_relevant_renamed",
       |      "g_t_krei_regulatory_info_ol_relevant_initialized",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_initialized",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_renamed",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_initialized",
       |      "g_t_kstm_s_assets_liab_ol_relevant",
       |      "g_t_kstm_s_assets_liab_ol_relevant_renamed",
       |      "g_t_kstm_s_assets_liab_ol_relevant_initialized",
       |      "g_t_krei_reglty_info_ol_hold_relevant",
       |      "g_t_krei_reglty_info_ol_hold_relevant_renamed",
       |      "g_t_krei_reglty_info_ol_hold_relevant_initialized",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_hold_relevant",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_initialized",
       |      "g_t_kslb_financial_atrb_ol_relevant",
       |      "g_t_kslb_financial_atrb_ol_relevant_renamed",
       |      "g_t_kslb_financial_atrb_ol_relevant_initialized",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_ol_relevant",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_initialized"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomOperation_missSelect : String =
    """|  kaocEomOperation = {
       |    dataPath = "src/test/resources/data/kaocEomOperation/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_operation.json"
       |    relevantFields =  ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_operation_relevant_to_rename"
       |      newFieldNames = "g_t_kaoc_eom_operation_relevant_renamed"
       |    }
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomOperation_badSelect : String =
    """|  kaocEomOperation = {
       |    dataPath = "src/test/resources/data/kaocEomOperation/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_operation.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_operation_relevant_to_rename"
       |      newFieldNames = "g_t_kaoc_eom_operation_relevant_renamed"
       |    }
       |    selectTablonFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_renamed",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_initialized",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_relevant",
       |      "g_t_kctk_credit_risk_ol_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_hold_relevant",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_initialized",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_initialized",
       |      "g_t_krei_reglty_info_ol_hold_relevant",
       |      "g_t_krei_reglty_info_ol_hold_relevant_renamed",
       |      "g_t_krei_reglty_info_ol_hold_relevant_initialized",
       |      "g_t_krei_regulatory_info_ol_relevant",
       |      "g_t_krei_regulatory_info_ol_relevant_renamed",
       |      "g_t_krei_regulatory_info_ol_relevant_initialized",
       |      "g_t_kslb_financial_atrb_ol_relevant",
       |      "g_t_kslb_financial_atrb_ol_relevant_renamed",
       |      "g_t_kslb_financial_atrb_ol_relevant_initialized",
       |      "g_t_kstm_s_assets_liab_ol_relevant",
       |      "g_t_kstm_s_assets_liab_ol_relevant_renamed",
       |      "g_t_kstm_s_assets_liab_ol_relevant_initialized",
       |      "aaaaaaaaaaaaaa"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomOperation_badFields : String =
    """|  kaocEomOperation = {
       |    dataPath = "src/test/resources/data/kaocEomOperation/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_operation.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized"]
       |
       |    selectTablonFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_relevant",
       |      "g_t_kctk_credit_risk_ol_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_relevant_initialized",
       |      "g_t_krei_regulatory_info_ol_relevant",
       |      "g_t_krei_regulatory_info_ol_relevant_renamed",
       |      "g_t_krei_regulatory_info_ol_relevant_initialized",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_initialized",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_renamed",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_initialized",
       |      "g_t_kstm_s_assets_liab_ol_relevant",
       |      "g_t_kstm_s_assets_liab_ol_relevant_renamed",
       |      "g_t_kstm_s_assets_liab_ol_relevant_initialized",
       |      "g_t_krei_reglty_info_ol_hold_relevant",
       |      "g_t_krei_reglty_info_ol_hold_relevant_renamed",
       |      "g_t_krei_reglty_info_ol_hold_relevant_initialized",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_hold_relevant",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_initialized",
       |      "g_t_kslb_financial_atrb_ol_relevant",
       |      "g_t_kslb_financial_atrb_ol_relevant_renamed",
       |      "g_t_kslb_financial_atrb_ol_relevant_initialized",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_ol_relevant",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_initialized"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomOperation_missFields : String =
    """|  kaocEomOperation = {
       |    dataPath = "src/test/resources/data/kaocEomOperation/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_operation.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized"]
       |
       |    selectTablonFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_operation_relevant",
       |      "g_t_kaoc_eom_operation_relevant_renamed",
       |      "g_t_kaoc_eom_operation_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_relevant",
       |      "g_t_kctk_credit_risk_ol_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_relevant_initialized",
       |      "g_t_krei_regulatory_info_ol_relevant",
       |      "g_t_krei_regulatory_info_ol_relevant_renamed",
       |      "g_t_krei_regulatory_info_ol_relevant_initialized",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_initialized",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_renamed",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_initialized",
       |      "g_t_kstm_s_assets_liab_ol_relevant",
       |      "g_t_kstm_s_assets_liab_ol_relevant_renamed",
       |      "g_t_kstm_s_assets_liab_ol_relevant_initialized",
       |      "g_t_krei_reglty_info_ol_hold_relevant",
       |      "g_t_krei_reglty_info_ol_hold_relevant_renamed",
       |      "g_t_krei_reglty_info_ol_hold_relevant_initialized",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized",
       |      "g_t_kctk_credit_risk_ol_hold_relevant",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_initialized",
       |      "g_t_kslb_financial_atrb_ol_relevant",
       |      "g_t_kslb_financial_atrb_ol_relevant_renamed",
       |      "g_t_kslb_financial_atrb_ol_relevant_initialized",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized",
       |      "g_t_kstm_s_off_balance_items_ol_relevant",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_initialized"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomAssetsLiabOl_correct : String =
    """|  kaocEomAssetsLiabOl = {
       |    dataPath = "src/test/resources/data/kaocEomAssetsLiabOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_assets_liab_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_renamed",
       |      "g_t_kaoc_eom_assets_liab_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_assets_liab_ol_relevant_to_rename"
       |      newFieldNames = "g_t_kaoc_eom_assets_liab_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomDomIntervenersOl_correct : String =
    """|  kaocEomDomIntervenersOl = {
       |    dataPath = "src/test/resources/data/kaocEomDomIntervenersOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_dom_interveners_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_cont_main_holder_cust_id",
       |      "g_main_holder_customer_type",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename;g_customer_id"
       |      newFieldNames = "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed;g_cont_main_holder_cust_id"
       |    }
       |    fields = {
       |      holderCustomerType = "g_main_holder_customer_type"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomDomIntervenersOl_badFields : String =
    """|  kaocEomDomIntervenersOl = {
       |    dataPath = "src/test/resources/data/kaocEomDomIntervenersOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_dom_interveners_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_main_holder_customer_type",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename;g_customer_id"
       |      newFieldNames = "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed;g_cont_main_holder_cust_id"
       |    }
       |    fields = {
       |      localContractId = "g_operation_number_id"
       |      customerId = "g_customer_id"
       |      holderCustomerType = "bad_g_main_holder_customer_type"
       |      customerIdNew = "g_cont_main_holder_cust_id"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomDomIntervenersOl_missFields : String =
    """|  kaocEomDomIntervenersOl = {
       |    dataPath = "src/test/resources/data/kaocEomDomIntervenersOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_dom_interveners_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_main_holder_customer_type",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed",
       |      "g_t_kaoc_eom_dom_interveners_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_dom_interveners_ol_relevant_to_rename;g_customer_id"
       |      newFieldNames = "g_t_kaoc_eom_dom_interveners_ol_relevant_renamed;g_cont_main_holder_cust_id"
       |    }
       |    fields = {
       |      localContractId = "g_operation_number_id"
       |      customerIdNew = "g_cont_main_holder_cust_id"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkCreditRiskOl_correct : String =
    """|  kctkCreditRiskOl = {
       |    dataPath = "src/test/resources/data/kctkCreditRiskOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kctk_credit_risk_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kctk_credit_risk_ol_relevant",
       |      "g_t_kctk_credit_risk_ol_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_credit_risk_ol_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_credit_risk_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kctkCreditRiskOlHold_correct : String =
    """|  kctkCreditRiskOlHold = {
       |    dataPath = "src/test/resources/data/kctkCreditRiskOlHold/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kctk_credit_risk_ol_hold.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kctk_credit_risk_ol_hold_relevant",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_renamed",
       |      "g_t_kctk_credit_risk_ol_hold_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kctk_credit_risk_ol_hold_relevant_to_rename"
       |      newFieldNames = "g_t_kctk_credit_risk_ol_hold_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kdeoInapprtOpeSitutn_correct : String =
    """|  kdeoInapprtOpeSitutn = {
       |    dataPath = "src/test/resources/data/kdeoInapprtOpeSitutn/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kdeo_inapprt_ope_situtn.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_renamed",
       |      "g_t_kdeo_inapprt_ope_situtn_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kdeo_inapprt_ope_situtn_relevant_to_rename"
       |      newFieldNames = "g_t_kdeo_inapprt_ope_situtn_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kreiRegltyInfoOlHold_correct : String =
    """|  kreiRegltyInfoOlHold = {
       |    dataPath = "src/test/resources/data/kreiRegltyInfoOlHold/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_krei_reglty_info_ol_hold.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_krei_reglty_info_ol_hold_relevant",
       |      "g_t_krei_reglty_info_ol_hold_relevant_renamed",
       |      "g_t_krei_reglty_info_ol_hold_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_krei_reglty_info_ol_hold_relevant_to_rename"
       |      newFieldNames = "g_t_krei_reglty_info_ol_hold_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kreiRegulatoryInfoOl_correct : String =
    """|  kreiRegulatoryInfoOl = {
       |    dataPath = "src/test/resources/data/kreiRegulatoryInfoOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_krei_regulatory_info_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_krei_regulatory_info_ol_relevant",
       |      "g_t_krei_regulatory_info_ol_relevant_renamed",
       |      "g_t_krei_regulatory_info_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_krei_regulatory_info_ol_relevant_to_rename"
       |      newFieldNames = "g_t_krei_regulatory_info_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kslbFinancialAtrbOl_correct : String =
    """|  kslbFinancialAtrbOl = {
       |    dataPath = "src/test/resources/data/kslbFinancialAtrbOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kslb_financial_atrb_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kslb_financial_atrb_ol_relevant",
       |      "g_t_kslb_financial_atrb_ol_relevant_renamed",
       |      "g_t_kslb_financial_atrb_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kslb_financial_atrb_ol_relevant_to_rename"
       |      newFieldNames = "g_t_kslb_financial_atrb_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kstmAssetsLiabOl_correct : String =
    """|  kstmAssetsLiabOl = {
       |    dataPath = "src/test/resources/data/kstmAssetsLiabOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kstm_s_assets_liab_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kstm_s_assets_liab_ol_relevant",
       |      "g_t_kstm_s_assets_liab_ol_relevant_renamed",
       |      "g_t_kstm_s_assets_liab_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kstm_s_assets_liab_ol_relevant_to_rename"
       |      newFieldNames = "g_t_kstm_s_assets_liab_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kaocEomOutOfBalItemOl_correct : String =
    """|  kaocEomOutOfBalItemOl = {
       |    dataPath = "src/test/resources/data/kaocEomOutOfBalItemOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kaoc_eom_out_of_bal_item_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed",
       |      "g_t_kaoc_eom_out_of_bal_item_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kaoc_eom_out_of_bal_item_ol_relevant_to_rename"
       |      newFieldNames = "g_t_kaoc_eom_out_of_bal_item_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kstmSOffBalanceItemsOl_correct : String =
    """|  kstmSOffBalanceItemsOl = {
       |    dataPath = "src/test/resources/data/kstmSOffBalanceItemsOl/parquet/"
       |    schemaPath = "src/test/resources/schemas/operations/RQ42021/t_kstm_s_off_balance_items_ol.json"
       |    relevantFields = ["g_operation_number_id",
       |      "g_t_kstm_s_off_balance_items_ol_relevant",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_renamed",
       |      "g_t_kstm_s_off_balance_items_ol_relevant_initialized"]
       |    previousRename = {
       |      oldFieldNames = "g_t_kstm_s_off_balance_items_ol_relevant_to_rename"
       |      newFieldNames = "g_t_kstm_s_off_balance_items_ol_relevant_renamed"
       |    }
       |    joinFields = ["g_operation_number_id"]
       |
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""


  lazy val rootConfig: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeOperationsBoardRoot_complete.stripMargin + """
      """.stripMargin + kaocEomOperation_correct.stripMargin + """
      """.stripMargin + kaocEomAssetsLiabOl_correct.stripMargin + """
      """.stripMargin + kaocEomDomIntervenersOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOlHold_correct.stripMargin + """
      """.stripMargin + kdeoInapprtOpeSitutn_correct.stripMargin + """
      """.stripMargin + kreiRegltyInfoOlHold_correct.stripMargin + """
      """.stripMargin + kreiRegulatoryInfoOl_correct.stripMargin +  """
      """.stripMargin + kslbFinancialAtrbOl_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabOl_correct.stripMargin + """
      """.stripMargin + kaocEomOutOfBalItemOl_correct.stripMargin + """
      """.stripMargin + kstmSOffBalanceItemsOl_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigBadSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeOperationsBoardRoot_complete.stripMargin + """
      """.stripMargin + kaocEomOperation_badSelect.stripMargin + """
                                                                   |}
                                                                   |""".stripMargin)

  lazy val rootConfigMissSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeOperationsBoardRoot_complete.stripMargin + """
      """.stripMargin + kaocEomOperation_missSelect.stripMargin + """
      """.stripMargin + kaocEomAssetsLiabOl_correct.stripMargin + """
      """.stripMargin + kaocEomDomIntervenersOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOlHold_correct.stripMargin + """
      """.stripMargin + kdeoInapprtOpeSitutn_correct.stripMargin + """
      """.stripMargin + kreiRegltyInfoOlHold_correct.stripMargin + """
      """.stripMargin + kreiRegulatoryInfoOl_correct.stripMargin +  """
      """.stripMargin + kslbFinancialAtrbOl_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabOl_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigBadJoinFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeOperationsBoardRoot_complete.stripMargin  + """
      """.stripMargin + kaocEomOperation_badJoinFields.stripMargin + """
      """.stripMargin + kaocEomAssetsLiabOl_correct.stripMargin + """
      """.stripMargin + kaocEomDomIntervenersOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOlHold_correct.stripMargin + """
      """.stripMargin + kdeoInapprtOpeSitutn_correct.stripMargin + """
      """.stripMargin + kreiRegltyInfoOlHold_correct.stripMargin + """
      """.stripMargin + kreiRegulatoryInfoOl_correct.stripMargin +  """
      """.stripMargin + kslbFinancialAtrbOl_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabOl_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigBadFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeOperationsBoardRoot_complete.stripMargin  + """
      """.stripMargin + kaocEomOperation_badFields.stripMargin + """
      """.stripMargin + kaocEomAssetsLiabOl_correct.stripMargin + """
      """.stripMargin + kaocEomDomIntervenersOl_badFields.stripMargin + """
      """.stripMargin + kctkCreditRiskOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOlHold_correct.stripMargin + """
      """.stripMargin + kdeoInapprtOpeSitutn_correct.stripMargin + """
      """.stripMargin + kreiRegltyInfoOlHold_correct.stripMargin + """
      """.stripMargin + kreiRegulatoryInfoOl_correct.stripMargin +  """
      """.stripMargin + kslbFinancialAtrbOl_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabOl_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)

  lazy val rootConfigMissFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeOperationsBoardRoot_complete.stripMargin  + """
      """.stripMargin + kaocEomOperation_missFields.stripMargin + """
      """.stripMargin + kaocEomAssetsLiabOl_correct.stripMargin + """
      """.stripMargin + kaocEomDomIntervenersOl_missFields.stripMargin + """
      """.stripMargin + kctkCreditRiskOl_correct.stripMargin + """
      """.stripMargin + kctkCreditRiskOlHold_correct.stripMargin + """
      """.stripMargin + kdeoInapprtOpeSitutn_correct.stripMargin + """
      """.stripMargin + kreiRegltyInfoOlHold_correct.stripMargin + """
      """.stripMargin + kreiRegulatoryInfoOl_correct.stripMargin +  """
      """.stripMargin + kslbFinancialAtrbOl_correct.stripMargin + """
      """.stripMargin + kstmAssetsLiabOl_correct.stripMargin + """
                                                                 |}
                                                                 |""".stripMargin)
}
