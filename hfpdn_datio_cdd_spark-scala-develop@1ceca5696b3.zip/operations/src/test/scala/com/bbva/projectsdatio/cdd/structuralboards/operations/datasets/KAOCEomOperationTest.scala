package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import com.bbva.projectsdatio.cdd.structuralboards.operations.utils.TestUtils
import com.typesafe.config.ConfigException
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KAOCEomOperationTest extends TestOperations {
  test("kaocEomOperation_wrap") {
    val instancia: KAOCEomOperation = KAOCEomOperation(testResources.kaocEomOperation_customized_testing, testResources.config)
    val result: KAOCEomOperation = instancia.wrap(testResources.kaocEomOperation_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kaocEomOperation_selectTablonColumns") {
    val result: DataFrame = KAOCEomOperation(testResources.ktae_operations_after_join_testing, testResources.config).selectTablonColumns().getDataFrame()
    val columns = result.columns.map(col)
    TestUtils.assertDataFrameEquals(result, testResources.ktae_operations_after_join_testing.select(columns:_*), FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("kaocEomOperation_selectTablonColumnsBadSelect") {
    assertThrows[AnalysisException] {
      KAOCEomOperation(testResources.ktae_operations_after_join_testing, testResources.configBadSelect).selectTablonColumns().getDataFrame()
    }
  }

  test("kaocEomOperation_selectTablonColumnsMissSelect") {
    assertThrows[ConfigException.Missing] {
      KAOCEomOperation(testResources.ktae_operations_after_join_testing, testResources.configMissSelect).selectTablonColumns().getDataFrame()
    }
  }
}
