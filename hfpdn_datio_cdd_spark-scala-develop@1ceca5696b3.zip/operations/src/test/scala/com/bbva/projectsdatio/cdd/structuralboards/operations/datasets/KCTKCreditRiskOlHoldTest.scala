package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KCTKCreditRiskOlHoldTest extends TestOperations {
  test("kctkCreditRiskOlHold_wrap") {
    val instancia: KCTKCreditRiskOlHold = KCTKCreditRiskOlHold(testResources.kctkCreditRiskOlHold_customized_testing, testResources.config)
    val result: KCTKCreditRiskOlHold = instancia.wrap(testResources.kctkCreditRiskOlHold_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
