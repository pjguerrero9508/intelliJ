package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSTMSOffBalanceItemsOlTest extends TestOperations {
  test("kstmSOffBalanceItemsOl_wrap") {
    val instancia: KSTMSOffBalanceItemsOl = KSTMSOffBalanceItemsOl(testResources.kstmSOffBalanceItemsOl_complete_input_testing, testResources.config)
    val result: KSTMSOffBalanceItemsOl = instancia.wrap(testResources.kstmSOffBalanceItemsOl_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
