package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{CONF_KAOC_EOM_DOM_INTERVENERS_OL_RELEVANT_FIELDS, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import com.bbva.projectsdatio.cdd.structuralboards.operations.utils.TestUtils
import org.apache.spark.sql.types.{StringType, StructType}
import org.apache.spark.sql.{AnalysisException, DataFrame}
import scala.collection.JavaConverters.asScalaBufferConverter
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KAOCEomDomIntervenersOlTest extends TestOperations {
  test("kaocEomDomIntervenersOl_wrap") {
    val instancia: KAOCEomDomIntervenersOl = KAOCEomDomIntervenersOl(testResources.kaocEomDomIntervenersOl_customized_testing, testResources.config)
    val result: KAOCEomDomIntervenersOl = instancia.wrap(testResources.kaocEomDomIntervenersOl_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kaocEomDomIntervenersOl_filterCustomerGroupType") {
    val result: DataFrame = KAOCEomDomIntervenersOl(testResources.kaocEomDomIntervenersOl_complete_input_testing, testResources.config)
      .globalParameterSetter().dataSetTransformations(testResources.ktae_operations_after_join_testing_datio_schema).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.kaocEomDomIntervenersOl_customized_testing, false) shouldBe TRUE_VALUE
  }

  test("kaocEomDomIntervenersOl_filterCustomerGroupTypeBadFields") {
    assertThrows[AnalysisException] {
      KAOCEomDomIntervenersOl(testResources.kaocEomDomIntervenersOl_complete_input_testing, testResources.configBadFields).filterMainCustomerType().getDataFrame()
    }
  }

  test("kaocEomDomIntervenersOl_filterCustomerGroupTypeMissFields") {
    assertThrows[ParamNotInformedException] {
      KAOCEomDomIntervenersOl(testResources.kaocEomDomIntervenersOl_complete_input_testing, testResources.configMissFields).filterMainCustomerType().getDataFrame()
    }
  }

  test("kaocEomDomIntervenersOl_generateEmptyDataSet") {
    val result: DataFrame = KAOCEomDomIntervenersOl(testResources.testingEmptyDataFrame, testResources.config)
      .globalParameterSetter().applyEmpty(datioSparkSession, testResources.ktae_operations_after_join_testing_datio_schema).getDataFrame()
    val expectedSize = 0
    val relevantColumns = testResources.config.getStringList(CONF_KAOC_EOM_DOM_INTERVENERS_OL_RELEVANT_FIELDS).asScala.toList
    var expectedSchema: StructType = new StructType()
    expectedSchema = expectedSchema.add("g_cont_main_holder_cust_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_operation_number_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_kaoc_eom_dom_interveners_ol_relevant", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_kaoc_eom_dom_interveners_ol_relevant_initialized", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_t_kaoc_eom_dom_interveners_ol_relevant_renamed", StringType, TRUE_VALUE)

    StructType.apply(testResources.outputSchema.filter(a => relevantColumns.contains(a.name)).sortBy(_.name))
    val resultSchema : StructType = StructType.apply(result.schema.sortBy(_.name))
    assert(expectedSchema.simpleString.equals(resultSchema.simpleString))
    assert(result.count().equals(expectedSize.toLong))
  }
}
