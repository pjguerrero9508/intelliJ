package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KSTMAssetsLiabOlTest extends TestOperations {
  test("kstmAssetsLiabOl_wrap") {
    val instancia: KSTMAssetsLiabOl = KSTMAssetsLiabOl(testResources.kstmAssetsLiabOl_customized_testing, testResources.config)
    val result: KSTMAssetsLiabOl = instancia.wrap(testResources.kstmAssetsLiabOl_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
