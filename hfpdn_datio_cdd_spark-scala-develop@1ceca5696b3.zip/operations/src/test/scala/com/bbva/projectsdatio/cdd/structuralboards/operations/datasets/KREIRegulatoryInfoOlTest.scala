package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.operations.TestOperations
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KREIRegulatoryInfoOlTest extends TestOperations {
  test("kreiRegulatoryInfoOl_wrap") {
    val instancia: KREIRegulatoryInfoOl = KREIRegulatoryInfoOl(testResources.kreiRegulatoryInfoOl_customized_testing, testResources.config)
    val result: KREIRegulatoryInfoOl = instancia.wrap(testResources.kreiRegulatoryInfoOl_customized_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
