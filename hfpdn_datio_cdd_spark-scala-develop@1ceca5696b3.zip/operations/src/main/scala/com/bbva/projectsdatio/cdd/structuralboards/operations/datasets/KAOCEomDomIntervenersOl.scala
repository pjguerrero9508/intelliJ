package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KAOCEomDomIntervenersOl(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KAOCEomDomIntervenersOl] {

  val datasetParams : DatasetParams = KAOC_EOM_DOM_INTERVENERS_OL_CONSTANTS

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KAOC_EOM_DOM_INTERVENERS_OL_HOLDER_CUSTOMER_TYPE, config)
  lazy val holderCustomerType: String = config.getString(CONF_COLUMNS_KAOC_EOM_DOM_INTERVENERS_OL_HOLDER_CUSTOMER_TYPE)

  override val fieldsNotInOutput: Seq[String] = Seq(holderCustomerType, "g_customer_id")
  override val fieldsNotInInput: Seq[String] = Seq("g_cont_main_holder_cust_id")

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KAOCEomDomIntervenersOl = {
    copy(original = transformed)
  }

  /**
   * Select interest column, filter result and change column name
   *
   * @return Dataframe with the filter and columns desired
   */

  def filterMainCustomerType(): KAOCEomDomIntervenersOl = {
    val transformed: DataFrame = original
      .where(original.col(holderCustomerType) === FIELD_TO_FILTER_FLAG)
      .drop(holderCustomerType)
    wrap(transformed)
  }

  override def dataSetTransformations(outputSchema: DatioSchema): KAOCEomDomIntervenersOl = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.filterMainCustomerType()
  }
}
