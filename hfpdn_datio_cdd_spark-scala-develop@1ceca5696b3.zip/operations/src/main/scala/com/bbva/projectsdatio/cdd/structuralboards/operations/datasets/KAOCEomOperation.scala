package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, CDDStructuralMainBoardDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.typesafe.config.Config
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{Column, DataFrame}

import scala.collection.JavaConverters._
import scala.collection.mutable

case class KAOCEomOperation(original: DataFrame, config: Config)
  extends CDDStructuralMainBoardDataset[KAOCEomOperation] {

  val datasetParams: DatasetParams = KAOC_EOM_OPERATION_CONSTANTS

  TechnicalValidation.configStringListParamValidator(datasetParams.dataSetSelectOutputFields.get, config)
  val selectTablonFields: mutable.Seq[Column] = config.getStringList(datasetParams.dataSetSelectOutputFields.get).asScala.map(col)

  /**
   * left join between two tables with the given columns for the join
   *
   * @param right dataframe, enriches the information in the Operations table
   * @return Dataframe with the interest columns' selection
   */

  def join(right: CDDStructuralBoardsDataset[_]): KAOCEomOperation = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    if (joinColumns.head.contains("=")) joinDifferentKeys(right) else classicJoin(right)
  }

  def classicJoin(right: CDDStructuralBoardsDataset[_]): KAOCEomOperation = {
    val joinColumns = right.globalParameterSetter().getJoinFields.toList
    dataSetsColumnsChecker(right, joinColumns)
    val transformed: DataFrame = original.join(right.getDataFrame(), joinColumns, "left")
    wrap(transformed)
  }

  def joinDifferentKeys(right: CDDStructuralBoardsDataset[_]): KAOCEomOperation = {
    val joinColumns: List[(String, String)] = right.globalParameterSetter().getJoinFields
      .toList.map(fields => (fields.split("=").head, fields.split("=").last))
    TechnicalValidation.listStringValidator(joinColumns.map(_._1), getDataFrame().columns.toSeq,
      s"MainBoard Dataset - has not join columns: ${joinColumns.map(_._1).mkString(", ")}")
    TechnicalValidation.listStringValidator(joinColumns.map(_._2), right.getDataFrame().columns.toSeq,
      s"Right Dataset - has not join columns: ${joinColumns.map(_._2).mkString(", ")}")
    val transformed: DataFrame = original.join(right.getDataFrame(),
      original.col(joinColumns.map(_._1).head).equalTo(right.getDataFrame().col(joinColumns.map(_._2).head)), "left")
    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KAOCEomOperation = {
    copy(original = transformed)
  }

  /**
   * selection of columns for operation structural board
   *
   * @return Dataframe with the interest operation board columns' selection
   */

  def selectTablonColumns(): KAOCEomOperation = {
    val tablon: DataFrame = original.select(selectTablonFields: _*)
    this.wrap(tablon)
  }

  override def globalParameterSetter(): KAOCEomOperation = {
    this.globalParameter = setterDatasetConfiguration(config)
    this
  }
}
