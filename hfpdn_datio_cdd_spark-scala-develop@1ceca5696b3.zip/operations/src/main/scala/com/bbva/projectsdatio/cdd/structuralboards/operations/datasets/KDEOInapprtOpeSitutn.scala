package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KDEOInapprtOpeSitutn(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KDEOInapprtOpeSitutn] {

  val datasetParams : DatasetParams = KDEO_INAPPRT_OPE_SITUTN_CONSTANTS

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KDEOInapprtOpeSitutn = {
    copy(original = transformed)
  }
}
