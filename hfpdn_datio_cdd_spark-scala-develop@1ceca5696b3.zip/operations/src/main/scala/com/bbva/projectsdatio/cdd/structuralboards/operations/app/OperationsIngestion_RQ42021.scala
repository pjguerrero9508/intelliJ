package com.bbva.projectsdatio.cdd.structuralboards.operations.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GenericUtils, GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.bbva.projectsdatio.cdd.structuralboards.operations.datasets._
import com.datio.dataproc.sdk.api.context.RuntimeContext
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.commons.lang.exception.ExceptionUtils
import org.apache.spark.sql.{DataFrame, Row}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.stats.CDDExecutionStats

import scala.util.{Failure, Success, Try}

/**
 * Main file for Operation Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsOperations_RQ42021_Trait extends CDDStructuralBoardsApp {
  this: CDDStructuralBoardsApp =>

  val mainEntity: String = OPERATIONS_BOARD_TABLE_EOM_OPERATION
  val configId : String = "CDDOperationsBoard_RQ42021"
  val structuralBoard : String = "Operations"
  val boardTables: Seq[String] = OPERATIONS_BOARD_TABLES_RQ42021
  val defaultAverageKBPerRecord : Int = DEFAULT_AVERAGE_KB_PER_RECORD_BOARDS_OPERATIONS
  val defaultRepartitionBase : Int = DEFAULT_REPARTITION_BASE_BOARDS_OPERATIONS

  /**
   * Override trait run process method due to the necessity to set new Datasets from the
   * union of types of operations with operationsUnion method (KAOCUnionData and KSTMUnionData)
   * @param runtimeContext        RuntimeContext
   */
  override def runProcess(runtimeContext: RuntimeContext): Int = {
    this.logger.info(s"CDDStructuralboards: Init process $structuralBoard")
    val datioSparkSession: DatioSparkSession = DatioSparkSession.getOrCreate()
    val config = runtimeContext.getConfig.getConfig(configId)
    Try {
      // Get global parameter
      val globalParameterReaded: GlobalConfigurationReaded = setterGlobalConfigurationReadedParamsReader(config)
      val globalParameterTranslated: GlobalConfigurationTranslated =
        setterGlobalConfigurationReadedParamsTranslator(globalParameterReaded)
      val cddDataSetsToJoin: Map[String, CDDStructuralBoardsDataset[_]] =
        dataSetsMapper(globalParameterReaded, globalParameterTranslated, config, datioSparkSession)
      val unionDataset = operationsUnion(cddDataSetsToJoin, config, globalParameterReaded)
      val cddDatasetsIncludeUnions = cddDataSetsToJoin
        . +(OPERATIONS_BOARD_UNION_KAOC -> unionDataset._1.asInstanceOf[KAOCUnionData].globalParameterSetter())
        . +(OPERATIONS_BOARD_UNION_KSTM -> unionDataset._2.asInstanceOf[KSTMUnionData].globalParameterSetter())
      val tablon: DataFrame = joinTablon(cddDatasetsIncludeUnions, globalParameterReaded, globalParameterTranslated, datioSparkSession)
        .selectTablonColumns()
        .getDataFrame()
      logger.info(s"CDDStructuralboards: $structuralBoard structural board generated")
      writerCDDBoard(datioSparkSession, tablon, globalParameterReaded, globalParameterTranslated)
      /*
      setCompactorReportIntoProcessFinalReport(
        buildAndLaunchCompactor(
          setCompactorParams(datioSparkSession, globalParameterTranslated), datioSparkSession)
       */
    } match {
      case Success(_) =>
        logger.info(s"CDDStructuralboards: Process $structuralBoard successfully finished")
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        0
      case Failure(ex: Throwable) =>
        logger.info(s"CDDStructuralboards: Something went wrong during $structuralBoard process")
        logger.error(s"CDDStructuralboards: Input Args: ${config.toString}")
        logger.error(s"Exception: {}", ExceptionUtils.getStackTrace(ex))
        logger.warn(s"CDDExecutionStats: ${CDDExecutionStats.generateFinalReport()}")
        CDDExecutionStats
          .addUnKnownExceptionMessage(new Exception(ex),
            "OperationsIngestion",
            "runProcess")
        logger.info(s"CDDStructuralboards: Finished process $structuralBoard")
        1
    }
  }

  /**
   * This method generates, for the dataset informed in entityName param, a Tuple with its name in the first value
   * and the dataset that will be used in the board calculation in the second value. If emptyInitializeMode is set as "true",
   * the dataset that will be returned will have all it's values set to null
   * @param entityName: String
   * @param globalConfigurationReaded: GlobalConfigurationReaded
   * @param globalConfigurationTranslated: GlobalConfigurationTranslated
   * @param config: Config
   * @param emptyInitializeMode: Boolean
   * @return
   */
  def dataSetCollectionMapper(entityName: String,
                               globalConfigurationReaded: GlobalConfigurationReaded,
                               globalConfigurationTranslated: GlobalConfigurationTranslated,
                               config: Config,
                               datioSparkSession: DatioSparkSession,
                               emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])] = {

    logger.info(s"CDDStructuralboards: Read output schema")
    val emptyDataframe : DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row],
        globalConfigurationTranslated.datioOutputSchema.getStructType)
    logger.info(s"CDDStructuralboards: entityName $entityName")
    entityName match {
      case OPERATIONS_BOARD_TABLE_EOM_OPERATION =>
        Some(OPERATIONS_BOARD_TABLE_EOM_OPERATION,
          KAOCEomOperation(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL =>
        Some(OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL,
          KAOCEomAssetsLiabOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL =>
        Some(OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL,
          KSTMAssetsLiabOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_INAPPRT_OPE_SITUTN =>
        Some(OPERATIONS_BOARD_TABLE_INAPPRT_OPE_SITUTN,
          KDEOInapprtOpeSitutn(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_REGULATORY_INFO_OL =>
        Some(OPERATIONS_BOARD_TABLE_REGULATORY_INFO_OL,
          KREIRegulatoryInfoOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL =>
        Some(OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL,
          KCTKCreditRiskOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_EOM_DOM_INTERVENERS_OL =>
        Some(OPERATIONS_BOARD_TABLE_EOM_DOM_INTERVENERS_OL,
          KAOCEomDomIntervenersOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL_HOLD =>
        Some(OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL_HOLD,
          KCTKCreditRiskOlHold(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_REGLTY_INFO_OL_HOLD =>
        Some(OPERATIONS_BOARD_TABLE_REGLTY_INFO_OL_HOLD,
          KREIRegltyInfoOlHold(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_FINANCIAL_ATRB_OL =>
        Some(OPERATIONS_BOARD_TABLE_FINANCIAL_ATRB_OL,
          KSLBFinancialAtrbOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_EOM_OUT_OF_BAL_ITEM_OL =>
        Some(OPERATIONS_BOARD_TABLE_EOM_OUT_OF_BAL_ITEM_OL,
          KAOCEomOutOfBalItemOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case OPERATIONS_BOARD_TABLE_S_OFF_BALANCE_ITEMS_OL =>
        Some(OPERATIONS_BOARD_TABLE_S_OFF_BALANCE_ITEMS_OL,
          KSTMSOffBalanceItemsOl(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case _ => None
  }
}

  /**
   * This method join with all tables required for operation board
   *
   * @param dataSetMap   All case class of tables
   * @param globalConfigurationReaded: GlobalConfigurationReaded
   * @param globalConfigurationTranslated: GlobalConfigurationTranslated
   * @return KAOCEomOperation with operation board
   */
  def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                 globalConfigurationReaded: GlobalConfigurationReaded,
                 globalConfigurationTranslated: GlobalConfigurationTranslated,
                 datioSparkSession: DatioSparkSession): KAOCEomOperation = {
    logger.info(s"CDDStructuralboards: Init method joinTablon")
    dataSetMap(mainEntity).asInstanceOf[KAOCEomOperation].globalParameterSetter()
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL))         // Table Join 7
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_REGULATORY_INFO_OL))     // Table Join 5
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_INAPPRT_OPE_SITUTN))     // Table Join 4
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_REGLTY_INFO_OL_HOLD))    // Table Join 6
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_EOM_DOM_INTERVENERS_OL)) // Table Join 2
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL_HOLD))    // Table Join 8
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_FINANCIAL_ATRB_OL))      // Table Join 9
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(OPERATIONS_BOARD_UNION_KAOC))
      .join(dataSetMap(OPERATIONS_BOARD_UNION_KSTM))
  }

  /**
   * Union dor assets kiability a operation level and out of balance items, both for kaoc and kstm
   * @param dataSetMap: Map[String, CDDStructuralBoardsDataset[_]]
   * @param config: Config
   * @param globalParameter: GlobalConfigurationReaded
   * @return
   */
  def operationsUnion(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                      config: Config, globalParameter: GlobalConfigurationReaded):
  (CDDStructuralBoardsDataset[_], CDDStructuralBoardsDataset[_]) = {
    val outputSchema: DatioSchema = SchemaReaderBoards.readSchema(globalParameter.fullNameSchemaBoard)
    val unionKaocData: DataFrame = GenericUtils
      .unionData(
        dataSetMap(OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL).getDataFrame(),
        dataSetMap(OPERATIONS_BOARD_TABLE_EOM_OUT_OF_BAL_ITEM_OL).getDataFrame(),
        dataSetMap(OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL).asInstanceOf[KAOCEomAssetsLiabOl].globalParameterSetter().getJoinFields.toList,
        outputSchema)(isSoft = FALSE_VALUE)
    logger.info(s"CDDStructuralboards: kaoc tables union performed")
    val unionKstmData: DataFrame = GenericUtils
      .unionData(
        dataSetMap(OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL).getDataFrame(),
        dataSetMap(OPERATIONS_BOARD_TABLE_S_OFF_BALANCE_ITEMS_OL).getDataFrame(),
        dataSetMap(OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL).asInstanceOf[KSTMAssetsLiabOl].globalParameterSetter().getJoinFields.toList,
        outputSchema)(isSoft = FALSE_VALUE)
    logger.info(s"CDDStructuralboards: kstm tables union performed")
    (KAOCUnionData(unionKaocData, config).globalParameterSetter(), KSTMUnionData(unionKstmData, config).globalParameterSetter())
  }
}

class StructuralboardsOperations_RQ42021 extends StructuralboardsOperations_RQ42021_Trait
