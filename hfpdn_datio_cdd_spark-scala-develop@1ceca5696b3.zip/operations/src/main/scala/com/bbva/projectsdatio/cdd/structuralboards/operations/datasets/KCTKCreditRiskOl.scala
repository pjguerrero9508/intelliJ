package com.bbva.projectsdatio.cdd.structuralboards.operations.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KCTKCreditRiskOl(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KCTKCreditRiskOl] {

  val datasetParams : DatasetParams = KCTK_CREDIT_RISK_OL_CONSTANTS

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KCTKCreditRiskOl = {
    copy(original = transformed)
  }
}
