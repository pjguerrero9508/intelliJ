package com.bbva.projectsdatio.cdd.structuralboards.operations.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.bbva.projectsdatio.cdd.structuralboards.operations.datasets._
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Row}

/**
 * Main file for Operation Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsOperations_R302_Trait extends StructuralboardsOperations_RQ22021_Trait {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDOperationsBoard_R302"
  override val boardTables: Seq[String] = OPERATIONS_BOARD_TABLES_302

  /**
   * This method join with all tables required for operation board
   *
   * @param dataSetMap   All case class of tables
   * @return KAOCEomOperation with operation board
   */
  override def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                          globalConfigurationReaded: GlobalConfigurationReaded,
                          globalConfigurationTranslated: GlobalConfigurationTranslated,
                          datioSparkSession: DatioSparkSession): KAOCEomOperation = {
    logger.info(s"CDDStructuralboards: Init method joinTablon")
    dataSetMap(mainEntity).asInstanceOf[KAOCEomOperation].globalParameterSetter()
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_CREDIT_RISK_OL))         // Table Join 7
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_REGULATORY_INFO_OL))     // Table Join 5
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_INAPPRT_OPE_SITUTN))     // Table Join 4
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_EOM_ASSETS_LIAB_OL))     // Table Join 1
      .join(dataSetMap(OPERATIONS_BOARD_TABLE_S_ASSETS_LIAB_OL))       // Table Join 3
  }
}

class StructuralboardsOperations_R302 extends StructuralboardsOperations_R302_Trait
