package com.bbva.projectsdatio.cdd.structuralboards.guarantees.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets._
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Row}

/**
 * Main file for Guarantees Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsGuarantees_RQ42023_Trait extends CDDStructuralBoardsApp {
  this: CDDStructuralBoardsApp =>

  val mainEntity: String = GUARANTEE_BOARD_TABLE_GUARANTEES
  val configId: String = "CDDGuaranteesBoard_RQ42023"
  val structuralBoard: String = "Guarantees"
  val boardTables: Seq[String] = GUARANTEE_BOARD_TABLES_RQ42023
  val defaultAverageKBPerRecord: Int = DEFAULT_AVERAGE_KB_PER_RECORD_BOARDS_GUARANTEES
  val defaultRepartitionBase: Int = DEFAULT_REPARTITION_BASE_BOARDS_GUARANTEES

  /**
   * This method generates, for the dataset informed in entityName param, a Tuple with its name in the first value
   * and the dataset that will be used in the board calculation in the second value. If emptyInitializeMode is set as "true",
   * the dataset that will be returned will have all it's values set to null
   *
   * @param entityName                    : String
   * @param globalConfigurationReaded     : GlobalConfigurationReaded
   * @param globalConfigurationTranslated : GlobalConfigurationTranslated
   * @param config                        : Config
   * @param emptyInitializeMode           : Boolean
   * @return
   */
  def dataSetCollectionMapper(entityName: String,
                              globalConfigurationReaded: GlobalConfigurationReaded,
                              globalConfigurationTranslated: GlobalConfigurationTranslated,
                              config: Config,
                              datioSparkSession: DatioSparkSession,
                              emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])] = {

    logger.info(s"CDDStructuralboards: Read output schema")
    val emptyDataframe: DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row],
        globalConfigurationTranslated.datioOutputSchema.getStructType)
    logger.info(s"CDDStructuralboards: entityName $entityName")
    entityName match {
      case GUARANTEE_BOARD_TABLE_GUARANTEES =>
        Some(GUARANTEE_BOARD_TABLE_GUARANTEES,
          KGUGGuarantees(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case GUARANTEE_BOARD_TABLE_ADJUDICATIONS =>
        Some(GUARANTEE_BOARD_TABLE_ADJUDICATIONS,
          KGUGAdjudications(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case GUARANTEE_BOARD_TABLE_ASSETS =>
        Some(GUARANTEE_BOARD_TABLE_ASSETS,
          KGUGAssets(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case GUARANTEE_BOARD_TABLE_VALUATIONS =>
        Some(GUARANTEE_BOARD_TABLE_VALUATIONS,
          KGUGValuations(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case _ => None
    }
  }

  /**
   * This method join with all tables required for guarantees board
   *
   * @param dataSetMap All case class of tables
   * @return KGUGGuarantees with guarantees board
   */
  def joinTablon(dataSetMap: Map[String, CDDStructuralBoardsDataset[_]],
                 globalConfigurationReaded: GlobalConfigurationReaded,
                 globalConfigurationTranslated: GlobalConfigurationTranslated,
                 datioSparkSession: DatioSparkSession): KGUGGuarantees = {
    logger.info(s"CDDStructuralboards: Init method joinTablon")
    dataSetMap(mainEntity).asInstanceOf[KGUGGuarantees].globalParameterSetter()
      .join(dataSetMap(GUARANTEE_BOARD_TABLE_ASSETS)) // Join 1
      .join(dataSetMap(GUARANTEE_BOARD_TABLE_VALUATIONS)) // Join 2
      .checkpoint(datioSparkSession, globalConfigurationTranslated.checkpointTempPath + VAL_SLASH + System.currentTimeMillis())
      .join(dataSetMap(GUARANTEE_BOARD_TABLE_ADJUDICATIONS)) // Join 3
  }
}

class StructuralboardsGuarantees_RQ42023 extends StructuralboardsGuarantees_RQ42023_Trait
