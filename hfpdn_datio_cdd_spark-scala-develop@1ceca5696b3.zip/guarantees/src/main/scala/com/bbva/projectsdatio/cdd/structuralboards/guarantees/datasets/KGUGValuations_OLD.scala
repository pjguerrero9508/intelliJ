package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.JavaConverters._

case class KGUGValuations_OLD(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KGUGValuations_OLD] {

  val datasetParams: DatasetParams = KGUG_VALUATIONS_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("gf_appraisal_date", "gf_appraisal_amount")

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_GUARANTEE_ASSET_ID, config)
  lazy val guaranteeAssetId: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_GUARANTEE_ASSET_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE, config)
  lazy val appraisalDate: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID, config)
  lazy val currencyId: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT, config)
  lazy val appraisalAmount: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_FIRST, config)
  lazy val appraisalDateFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_FIRST, config)
  lazy val currencyIdFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_FIRST, config)
  lazy val appraisalAmountFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_LAST, config)
  lazy val appraisalDateLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_LAST, config)
  lazy val currencyIdLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_LAST, config)
  lazy val appraisalAmountLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_LAST)

  override def applyEmpty(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): KGUGValuations_OLD = {
    val relevantColumns: Seq[String] = config.getStringList(datasetParams.dataSetRelevantFields).asScala
    val appraisalDateType: DataType = outputSchema.getStructType.filter(f => f.name.equals(appraisalDateFirst)).head.dataType
    val appraisalAmountType: DataType = outputSchema.getStructType.filter(f => f.name.equals(appraisalAmountFirst)).head.dataType
    val schemaFields = outputSchema.getStructType.filter(f => relevantColumns.contains(f.name))
      .+:(StructField(appraisalDate, appraisalDateType, TRUE_VALUE))
      .+:(StructField(appraisalAmount, appraisalAmountType, TRUE_VALUE))
    // Excepcion a DatioSchema ya que es un esquema construido dinamicamente
    val schemaOfEmptyDataFrame: StructType = StructType(
      schemaFields
    )
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaOfEmptyDataFrame)
    KGUGValuations_OLD(df, config)
  }

  override def dataSetTransformations(outputSchema: DatioSchema): KGUGValuations_OLD = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.calculateAppraisal()
  }

  override def dataSetEmptyTransformations(): KGUGValuations_OLD = {
    val renamedData = super.dataSetEmptyTransformations()
    renamedData.calculateAppraisalEmpty()
  }

  /**
   * Creates six columns with the information of the first and last appraisal, setting last appraisal information
   * to null if there is only one appraisal
   *
   * @return Dataframe with the new columns
   */

  def calculateAppraisal(): KGUGValuations_OLD = {
    val calculateFirstAppraisal = Window.partitionBy(guaranteeAssetId)
      .orderBy(col(appraisalDate))

    val calculateLastAppraisal = Window.partitionBy(guaranteeAssetId)
      .orderBy(col(appraisalDate))
      .rowsBetween(Window.currentRow, Window.unboundedFollowing)

    val firstLastAppraisal: DataFrame = original
      .withColumn(appraisalDateFirst, first(col(appraisalDate)).over(calculateFirstAppraisal))
      .withColumn(currencyIdFirst, first(col(currencyId)).over(calculateFirstAppraisal))
      .withColumn(appraisalAmountFirst, first(col(appraisalAmount)).over(calculateFirstAppraisal))
      .withColumn(appraisalDateLast, last(col(appraisalDate)).over(calculateLastAppraisal))
      .withColumn(currencyIdLast, last(col(currencyId)).over(calculateLastAppraisal))
      .withColumn(appraisalAmountLast, last(col(appraisalAmount)).over(calculateLastAppraisal))
      // Fields where appraisalDate is the first date for each partition
      .where(col(appraisalDateFirst) === col(appraisalDate))
      .drop(appraisalDate, currencyId, appraisalAmount)

    // Set the information of the last appraisal to null if there is only a single one appraisal
    val transformed: DataFrame = firstLastAppraisal
      .withColumn(currencyIdLast, when(col(appraisalDateLast) === col(appraisalDateFirst), lit(NULL_VALUE))
        .otherwise(col(currencyIdLast)))
      .withColumn(appraisalAmountLast, when(col(appraisalDateLast) === col(appraisalDateFirst), lit(NULL_VALUE))
        .otherwise(col(appraisalAmountLast)))
      .withColumn(appraisalDateLast, when(col(appraisalDateLast) === col(appraisalDateFirst), lit(NULL_VALUE))
        .otherwise(col(appraisalDateLast)))

    wrap(transformed)
  }

  /**
   * Creates six columns with the information of the first and last appraisal, setting last appraisal information
   * to null if there is only one appraisal
   *
   * @return Dataframe with the new columns
   */

  def calculateAppraisalEmpty(): KGUGValuations_OLD = {

    val firstLastAppraisal: DataFrame = original
      .withColumn(appraisalDateFirst, col(appraisalDate))
      .withColumn(currencyIdFirst, col(currencyId))
      .withColumn(appraisalAmountFirst, col(appraisalAmount))
      .withColumn(appraisalDateLast, col(appraisalDate))
      .withColumn(currencyIdLast, col(currencyId))
      .withColumn(appraisalAmountLast, col(appraisalAmount))
      .drop(appraisalDate, currencyId, appraisalAmount)

    // Set the information of the last appraisal to null if there is only a single one appraisal
    val transformed: DataFrame = firstLastAppraisal
      .withColumn(currencyIdLast, col(currencyIdLast))
      .withColumn(appraisalAmountLast, col(appraisalAmountLast))
      .withColumn(appraisalDateLast, col(appraisalDateLast))

    wrap(transformed)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KGUGValuations_OLD = {
    copy(original = transformed)
  }
}
