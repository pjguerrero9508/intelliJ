package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.validation.TechnicalValidation
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.Config
import org.apache.parquet.format.DecimalType
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.JavaConverters._
import org.apache.spark.sql.expressions.Window

case class KGUGValuations(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KGUGValuations] {

  val datasetParams: DatasetParams = KGUG_VALUATIONS_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("gf_appraisal_date",
    "gf_appraisal_amount", "gf_ctvl_appraisal_amount", "g_countervalued_currency_id",
    "gf_appraiser_company_name", "gf_force_sale_est_val_amount", "gf_appraisal_id")

  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_GUARANTEE_ASSET_ID, config)
  lazy val guaranteeAssetId: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_GUARANTEE_ASSET_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE, config)
  lazy val appraisalDate: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID, config)
  lazy val currencyId: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT, config)
  lazy val appraisalAmount: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_APPRAISAL_AMOUNT, config)
  lazy val ctvlAppraisalAmount: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_APPRAISAL_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_CURRENCY_ID, config)
  lazy val ctvlCurrencyId: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_CURRENCY_ID)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_COMPANY_NAME, config)
  lazy val appraisalCompanyName: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_COMPANY_NAME)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_FORCE_SALE_AMOUNT, config)
  lazy val forceSaleEstAmount: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_FORCE_SALE_AMOUNT)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_FIRST, config)
  lazy val appraisalDateFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_FIRST, config)
  lazy val currencyIdFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_FIRST, config)
  lazy val appraisalAmountFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_APPRAISAL_AMOUNT_FIRST, config)
  lazy val ctvlAppraisalAmountFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_APPRAISAL_AMOUNT_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_CURRENCY_ID_FIRST, config)
  lazy val ctvlCurrencyIdFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_CURRENCY_ID_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_COMPANY_NAME_FIRST, config)
  lazy val appraisalCompanyNameFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_COMPANY_NAME_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_FORCE_SALE_AMOUNT_FIRST, config)
  lazy val forceSaleEstAmountFirst: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_FORCE_SALE_AMOUNT_FIRST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_LAST, config)
  lazy val appraisalDateLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_DATE_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_LAST, config)
  lazy val currencyIdLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CURRENCY_ID_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_LAST, config)
  lazy val appraisalAmountLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_AMOUNT_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_APPRAISAL_AMOUNT_LAST, config)
  lazy val ctvlAppraisalAmountLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_APPRAISAL_AMOUNT_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_CURRENCY_ID_LAST, config)
  lazy val ctvlCurrencyIdLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_CTVL_CURRENCY_ID_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_COMPANY_NAME_LAST, config)
  lazy val appraisalCompanyNameLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_APPRAISAL_COMPANY_NAME_LAST)
  TechnicalValidation.configStringParamValidator(CONF_COLUMNS_KGUG_VALUATIONS_FORCE_SALE_AMOUNT_LAST, config)
  lazy val forceSaleEstAmountLast: String = config.getString(CONF_COLUMNS_KGUG_VALUATIONS_FORCE_SALE_AMOUNT_LAST)
  lazy val appraisalId: String = "gf_appraisal_id"


  override def applyEmpty(datioSparkSession: DatioSparkSession, outputSchema: DatioSchema): KGUGValuations = {
    val relevantColumns: Seq[String] = config.getStringList(datasetParams.dataSetRelevantFields).asScala
    val appraisalDateType: DataType = outputSchema
      .getStructType.filter(f => f.name.equals(appraisalDateFirst)).head.dataType
    val appraisalAmountType: DataType = outputSchema
      .getStructType.filter(f => f.name.equals(appraisalAmountFirst)).head.dataType
    //val currencyIdType: DataType = outputSchema
    //  .getStructType.filter(f => f.name.equals(currencyIdFirst)).head.dataType
    val ctvlAppraisalAmountType: DataType = outputSchema
      .getStructType.filter(f => f.name.equals(ctvlAppraisalAmountFirst)).head.dataType
    val ctvlCurrencyIdType: DataType = outputSchema
      .getStructType.filter(f => f.name.equals(ctvlCurrencyIdFirst)).head.dataType
    val appraisalCompanyNameType: DataType = outputSchema
      .getStructType.filter(f => f.name.equals(appraisalCompanyNameFirst)).head.dataType
    val forceSaleEstAmountType: DataType = outputSchema
      .getStructType.filter(f => f.name.equals(forceSaleEstAmountFirst)).head.dataType
    val schemaFields = outputSchema.getStructType.filter(f => relevantColumns.contains(f.name))
      .+:(StructField(appraisalDate, appraisalDateType, TRUE_VALUE))
      .+:(StructField(appraisalAmount, appraisalAmountType, TRUE_VALUE))
    //.+:(StructField(currencyId, currencyIdType, TRUE_VALUE))
    //.+:(StructField(ctvlAppraisalAmount, ctvlAppraisalAmountType, TRUE_VALUE))
    //.+:(StructField(ctvlCurrencyId, ctvlCurrencyIdType, TRUE_VALUE))
    //.+:(StructField(appraisalCompanyName, appraisalCompanyNameType, TRUE_VALUE))
    //.+:(StructField(forceSaleEstAmount, forceSaleEstAmountType, TRUE_VALUE))
    //Excepcion a DatioSchema ya que es un esquema construido dinamicamente
    val schemaOfEmptyDataFrame: StructType = StructType(schemaFields)
    val emptyRdd: RDD[Row] = datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row]
    val df: DataFrame = datioSparkSession.getSparkSession.createDataFrame(emptyRdd, schemaOfEmptyDataFrame)
    KGUGValuations(df, config)
  }

  override def dataSetTransformations(outputSchema: DatioSchema): KGUGValuations = {
    val cleanedData = super.dataSetTransformations(outputSchema)
    cleanedData.calculateAppraisal()
  }

  override def dataSetEmptyTransformations(): KGUGValuations = {
    val renamedData = super.dataSetEmptyTransformations()
    renamedData.calculateAppraisalEmpty()
  }

  /**
   * Creates six columns with the information of the first and last appraisal, setting first appraisal information
   * to the next appraisal date in ascendent order information if the first appraisal date is the default value, same with the last appraisal information,
   * setting the information to the next date information in descendent order if the last appraisal date is the default value. If there's only
   * one row for a guarantee asset id, it will not take into account if the date is a default value.
   *
   * @return Dataframe with the new columns
   */

  def calculateAppraisal(): KGUGValuations = {
    val calculateFirstAppraisal = Window.partitionBy(guaranteeAssetId)
      .orderBy(col(appraisalDate))

    val calculateLastAppraisal = Window.partitionBy(guaranteeAssetId)
      .orderBy(col(appraisalDate).desc)

    val numberOfRows: DataFrame = original
      .groupBy(guaranteeAssetId).count()
      .withColumnRenamed("count", "numberOfRows")
      .withColumnRenamed(guaranteeAssetId, "guaranteeAssetId_count")

    val firstAppraisal: DataFrame = original
      .withColumn(appraisalDateFirst, first(col(appraisalDate)).over(calculateFirstAppraisal))
      .withColumn(currencyIdFirst, first(col(currencyId)).over(calculateFirstAppraisal))
      .withColumn(appraisalAmountFirst, first(col(appraisalAmount)).over(calculateFirstAppraisal))
      .withColumn(ctvlAppraisalAmountFirst, first(col(ctvlAppraisalAmount)).over(calculateFirstAppraisal))
      .withColumn(ctvlCurrencyIdFirst, first(col(ctvlCurrencyId)).over(calculateFirstAppraisal))
      .withColumn(appraisalCompanyNameFirst, first(col(appraisalCompanyName)).over(calculateFirstAppraisal))
      .withColumn(forceSaleEstAmountFirst, first(col(forceSaleEstAmount)).over(calculateFirstAppraisal))
      .withColumn("appraisalDateAfterFirst", lead(col(appraisalDate), 1).over(calculateFirstAppraisal))
      .withColumn("currencyIdAfterFirst", lead(col(currencyId), 1).over(calculateFirstAppraisal))
      .withColumn("appraisalAmountAfterFirst", lead(col(appraisalAmount), 1).over(calculateFirstAppraisal))
      .withColumn("ctvlAppraisalAmountAfterFirst", lead(col(ctvlAppraisalAmount), 1).over(calculateFirstAppraisal))
      .withColumn("ctvlCurrencyIdAfterFirst", lead(col(ctvlCurrencyId), 1).over(calculateFirstAppraisal))
      .withColumn("appraisalCompanyNameAfterFirst", lead(col(appraisalCompanyName), 1).over(calculateFirstAppraisal))
      .withColumn("forceSaleEstAmountAfterFirst", lead(col(forceSaleEstAmount), 1).over(calculateFirstAppraisal))
      .withColumn("g_countervalued_currency_id", typedLit[Option[String]](None))
      .withColumn("gf_appraiser_company_name", typedLit[Option[String]](None))
      .withColumn("gf_ctvl_appraisal_amount", typedLit[Option[String]](None).cast("decimal(20,2)"))
      .withColumn("gf_force_sale_est_val_amount", typedLit[Option[String]](None).cast("decimal(26,6)"))
      .where(col(appraisalDateFirst) === col(appraisalDate))
      .drop(appraisalDate, currencyId, appraisalAmount, appraisalId
       // ctvlAppraisalAmount, ctvlCurrencyId, appraisalCompanyName, forceSaleEstAmount
      )

    val lastAppraisal: DataFrame = original
      .withColumn(appraisalDateLast, first(col(appraisalDate)).over(calculateLastAppraisal))
      .withColumn(currencyIdLast, first(col(currencyId)).over(calculateLastAppraisal))
      .withColumn(appraisalAmountLast, first(col(appraisalAmount)).over(calculateLastAppraisal))
      .withColumn(ctvlAppraisalAmountLast, first(col(ctvlAppraisalAmount)).over(calculateLastAppraisal))
      .withColumn(ctvlCurrencyIdLast, first(col(ctvlCurrencyId)).over(calculateLastAppraisal))
      .withColumn(appraisalCompanyNameLast, first(col(appraisalCompanyName)).over(calculateLastAppraisal))
      .withColumn(forceSaleEstAmountLast, first(col(forceSaleEstAmount)).over(calculateLastAppraisal))
      .withColumn("appraisalDateBeforeLast", lead(col(appraisalDate), 1).over(calculateLastAppraisal))
      .withColumn("currencyIdBeforeLast", lead(col(currencyId), 1).over(calculateLastAppraisal))
      .withColumn("currencyIdBeforeLast", lead(col(currencyId), 1).over(calculateLastAppraisal))
      .withColumn("appraisalAmountBeforeLast", lead(col(appraisalAmount), 1).over(calculateLastAppraisal))
      .withColumn("ctvlAppraisalAmountBeforeLast", lead(col(ctvlAppraisalAmount), 1).over(calculateLastAppraisal))
      .withColumn("ctvlCurrencyIdBeforeLast", lead(col(ctvlCurrencyId), 1).over(calculateLastAppraisal))
      .withColumn("appraisalCompanyNameBeforeLast", lead(col(appraisalCompanyName), 1).over(calculateLastAppraisal))
      .withColumn("forceSaleEstAmountBeforeLast", lead(col(forceSaleEstAmount), 1).over(calculateLastAppraisal))
      .withColumnRenamed(guaranteeAssetId, "guaranteeAssetId_last")
      .where(col(appraisalDateLast) === col(appraisalDate))
      .drop(appraisalDate, currencyId, appraisalAmount,
        ctvlAppraisalAmount, ctvlCurrencyId, appraisalCompanyName, forceSaleEstAmount)

    val firstLastAppraisal: DataFrame = firstAppraisal
      .join(lastAppraisal,
        firstAppraisal.col(guaranteeAssetId) === lastAppraisal.col("guaranteeAssetId_last"))
      .drop("guaranteeAssetId_last")

    val firstLastAppraisalWithNumberOfRows = firstLastAppraisal
      .join(numberOfRows,
        firstLastAppraisal.col(guaranteeAssetId) === numberOfRows.col("guaranteeAssetId_count"))
      .drop("guaranteeAssetId_count")

    val transformed: DataFrame = firstLastAppraisalWithNumberOfRows
      .withColumn(currencyIdFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("currencyIdAfterFirst"))
        .otherwise(col(currencyIdFirst)))
      .withColumn(appraisalAmountFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("appraisalAmountAfterFirst"))
        .otherwise(col(appraisalAmountFirst)))
      .withColumn(ctvlAppraisalAmountFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("ctvlAppraisalAmountAfterFirst"))
        .otherwise(col(ctvlAppraisalAmountFirst)))
      .withColumn(ctvlCurrencyIdFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("ctvlCurrencyIdAfterFirst"))
        .otherwise(col(ctvlCurrencyIdFirst)))
      .withColumn(appraisalCompanyNameFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("appraisalCompanyNameAfterFirst"))
        .otherwise(col(appraisalCompanyNameFirst)))
      .withColumn(forceSaleEstAmountFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("forceSaleEstAmountAfterFirst"))
        .otherwise(col(forceSaleEstAmountFirst)))
      .withColumn(appraisalDateFirst, when(col(appraisalDateFirst) === lit(FIRST_DEFAULT_DATE) && col("numberOfRows") > 1, col("appraisalDateAfterFirst"))
        .otherwise(col(appraisalDateFirst)))
      .withColumn(currencyIdLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("currencyIdBeforeLast"))
        .otherwise(col(currencyIdLast)))
      .withColumn(appraisalAmountLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("appraisalAmountBeforeLast"))
        .otherwise(col(appraisalAmountLast)))
      .withColumn(ctvlAppraisalAmountLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("ctvlAppraisalAmountBeforeLast"))
        .otherwise(col(ctvlAppraisalAmountLast)))
      .withColumn(ctvlCurrencyIdLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("ctvlCurrencyIdBeforeLast"))
        .otherwise(col(ctvlCurrencyIdLast)))
      .withColumn(appraisalCompanyNameLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("appraisalCompanyNameBeforeLast"))
        .otherwise(col(appraisalCompanyNameLast)))
      .withColumn(forceSaleEstAmountLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("forceSaleEstAmountBeforeLast"))
        .otherwise(col(forceSaleEstAmountLast)))
      .withColumn(appraisalDateLast, when(col(appraisalDateLast) === lit(LAST_DEFAULT_DATE) && col("numberOfRows") > 1, col("appraisalDateBeforeLast"))
        .otherwise(col(appraisalDateLast)))
      .drop("currencyIdAfterFirst", "appraisalAmountAfterFirst", "ctvlAppraisalAmountAfterFirst", "ctvlCurrencyIdAfterFirst",
        "appraisalCompanyNameAfterFirst", "forceSaleEstAmountAfterFirst", "appraisalDateAfterFirst", "currencyIdBeforeLast",
        "appraisalAmountBeforeLast", "ctvlAppraisalAmountBeforeLast", "ctvlCurrencyIdBeforeLast", "appraisalCompanyNameBeforeLast",
        "forceSaleEstAmountBeforeLast", "appraisalDateBeforeLast", "numberOfRows")

    wrap(transformed)

  }

  /**
   * Creates six columns with the information of the first and last appraisal, setting last appraisal information
   * to null if there is only one appraisal
   *
   * @return Dataframe with the new columns
   */

  def calculateAppraisalEmpty(): KGUGValuations = {

    val firstLastAppraisal: DataFrame = original
      .withColumn(appraisalDateFirst, col(appraisalDate))
      .withColumn(currencyIdFirst, col(currencyId))
      .withColumn(appraisalAmountFirst, col(appraisalAmount))
      .withColumn(ctvlAppraisalAmountFirst, col(ctvlAppraisalAmount))
      .withColumn(ctvlCurrencyIdFirst, col(ctvlCurrencyId))
      .withColumn(appraisalCompanyNameFirst, col(appraisalCompanyName))
      .withColumn(forceSaleEstAmountFirst, col(forceSaleEstAmount))
      .withColumn(appraisalDateLast, col(appraisalDate))
      .withColumn(currencyIdLast, col(currencyId))
      .withColumn(appraisalAmountLast, col(appraisalAmount))
      .withColumn(ctvlAppraisalAmountLast, col(ctvlAppraisalAmount))
      .withColumn(ctvlCurrencyIdLast, col(ctvlCurrencyId))
      .withColumn(appraisalCompanyNameLast, col(appraisalCompanyName))
      .withColumn(forceSaleEstAmountLast, col(forceSaleEstAmount))
      .drop(appraisalDate, currencyId, appraisalAmount,
        //  ctvlAppraisalAmount, ctvlCurrencyId, appraisalCompanyName, forceSaleEstAmount
      )

    wrap(firstLastAppraisal)
  }

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KGUGValuations = {
    copy(original = transformed)
  }
}
