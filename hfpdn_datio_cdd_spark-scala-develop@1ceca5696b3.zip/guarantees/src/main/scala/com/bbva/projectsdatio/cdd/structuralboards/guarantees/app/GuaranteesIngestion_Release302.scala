package com.bbva.projectsdatio.cdd.structuralboards.guarantees.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.CDDStructuralBoardsApp

/**
 * Main file for Guarantees Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsGuarantees_R302_Trait extends StructuralboardsGuarantees_RQ22021_Trait {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDGuaranteesBoard_R302"

}

class StructuralboardsGuarantees_R302 extends StructuralboardsGuarantees_R302_Trait
