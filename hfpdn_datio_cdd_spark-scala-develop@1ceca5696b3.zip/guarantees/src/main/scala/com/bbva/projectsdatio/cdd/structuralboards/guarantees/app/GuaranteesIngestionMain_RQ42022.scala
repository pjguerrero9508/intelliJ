package com.bbva.projectsdatio.cdd.structuralboards.guarantees.app

import com.datio.dataproc.sdk.launcher.SparkLauncher
import org.slf4j.{Logger, LoggerFactory}

/**
 * Temporal workaround to launch a mainClass instead a processId in Dataproc
 * Remove when new runtime is available
 */
object GuaranteesIngestionMain_RQ42022 {

  val logger: Logger = LoggerFactory.getLogger(this.getClass)

  /**
   * Main for launch your implementation of SparkProcess
   * @param args(0) the path to the configuration file
   */
  def main(args: Array[String]): Unit = {
    // Check the parameters of the execution
    if (args.length == 0) {
      logger.error("Parameter configuration file path is mandatory. Exiting...")
      System.exit(1000)
    }
    // Launch SparkLauncher with the configuration and the ID of your process (getProcessId in your SparkProcess class)
    SparkLauncher.main(Array(args(0), "CDDGuaranteesBoard_RQ42022"))
  }
}
