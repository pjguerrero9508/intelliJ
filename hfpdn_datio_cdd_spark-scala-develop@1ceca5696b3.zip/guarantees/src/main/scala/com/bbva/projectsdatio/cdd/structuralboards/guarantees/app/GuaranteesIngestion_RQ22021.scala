package com.bbva.projectsdatio.cdd.structuralboards.guarantees.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{GUARANTEE_BOARD_TABLE_ADJUDICATIONS, GUARANTEE_BOARD_TABLE_ASSETS, GUARANTEE_BOARD_TABLE_GUARANTEES, GUARANTEE_BOARD_TABLE_VALUATIONS}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets.{KGUGAdjudications, KGUGAssets, KGUGGuarantees, KGUGValuations_OLD}
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Row}

/**
 * Main file for Guarantees Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsGuarantees_RQ22021_Trait extends StructuralboardsGuarantees_RQ42021_Trait {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDGuaranteesBoard_RQ22021"

  /**
   * This method generates, for the dataset informed in entityName param, a Tuple with its name in the first value
   * and the dataset that will be used in the board calculation in the second value. If emptyInitializeMode is set as "true",
   * the dataset that will be returned will have all it's values set to null
   * @param entityName: String
   * @param globalConfigurationReaded: GlobalConfigurationReaded
   * @param globalConfigurationTranslated: GlobalConfigurationTranslated
   * @param config: Config
   * @param emptyInitializeMode: Boolean
   * @return
   */
  override def dataSetCollectionMapper (entityName: String,
                                        globalConfigurationReaded: GlobalConfigurationReaded,
                                        globalConfigurationTranslated: GlobalConfigurationTranslated,
                                        config: Config,
                                        datioSparkSession: DatioSparkSession,
                                        emptyInitializeMode: Boolean = false): Option[(String, CDDStructuralBoardsDataset[_])] = {

    logger.info(s"CDDStructuralboards: Read output schema")
    val emptyDataframe : DataFrame = datioSparkSession.getSparkSession
      .createDataFrame(datioSparkSession.getSparkSession.sparkContext.emptyRDD[Row],
        globalConfigurationTranslated.datioOutputSchema.getStructType)
    logger.info(s"CDDStructuralboards: entityName $entityName")
    entityName match {
      case GUARANTEE_BOARD_TABLE_GUARANTEES =>
        Some(GUARANTEE_BOARD_TABLE_GUARANTEES,
          KGUGGuarantees(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case GUARANTEE_BOARD_TABLE_ADJUDICATIONS =>
        Some(GUARANTEE_BOARD_TABLE_ADJUDICATIONS,
          KGUGAdjudications(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case GUARANTEE_BOARD_TABLE_ASSETS =>
        Some(GUARANTEE_BOARD_TABLE_ASSETS,
          KGUGAssets(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case GUARANTEE_BOARD_TABLE_VALUATIONS =>
        Some(GUARANTEE_BOARD_TABLE_VALUATIONS,
          KGUGValuations_OLD(emptyDataframe, config)
            .getCustomizedDataSet(datioSparkSession, globalConfigurationTranslated.datioOutputSchema)(emptyInitializeMode))
      case _ => None
    }
  }
}

class StructuralboardsGuarantees_RQ22021 extends StructuralboardsGuarantees_RQ22021_Trait
