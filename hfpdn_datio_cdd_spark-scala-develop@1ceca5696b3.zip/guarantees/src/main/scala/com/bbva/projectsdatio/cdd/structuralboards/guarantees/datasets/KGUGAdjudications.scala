package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsDataset, DatasetParams}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

case class KGUGAdjudications(original: DataFrame, config: Config)
  extends CDDStructuralBoardsDataset[KGUGAdjudications] {

  val datasetParams : DatasetParams = KGUG_ADJUDICATIONS_CONSTANTS

  override val fieldsNotInOutput: Seq[String] = Seq("g_currency_id")
  override val fieldsNotInInput: Seq[String] = Seq("g_adjudication_amt_currency_id")

  /**
   * The function makes a copy of the input dataframe, renaming it
   *
   * @param transformed input dataframe
   * @return Input dataframe, renamed
   */

  def wrap(transformed: DataFrame): KGUGAdjudications = {
    copy(original = transformed)
  }
}
