package com.bbva.projectsdatio.cdd.structuralboards.guarantees.app

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.{CDDStructuralBoardsApp, CDDStructuralBoardsDataset}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.SchemaReaderBoards
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets._
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Row}

/**
 * Main file for Guarantees Boards process.
 * Implements SparkProcess which includes metrics and DatioSparkSession.
 *
 * Configuration for this class should be expressed in HOCON like this:
 *
 * StructuralboardsIngestion {
 * ...
 * }
 *
 */
// noinspection ScalaStyle
protected trait StructuralboardsGuarantees_RQ22022_Trait extends StructuralboardsGuarantees_RQ42021 {
  this: CDDStructuralBoardsApp =>

  override val configId : String = "CDDGuaranteesBoard_RQ22022"
  override val boardTables: Seq[String] = GUARANTEE_BOARD_TABLES_RQ22022

}

class StructuralboardsGuarantees_RQ22022 extends StructuralboardsGuarantees_RQ22022_Trait
