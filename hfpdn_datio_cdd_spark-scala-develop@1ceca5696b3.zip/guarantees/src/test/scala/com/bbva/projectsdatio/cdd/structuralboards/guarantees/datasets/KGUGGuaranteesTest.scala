package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.TestGuarantees
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils.TestUtils
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import com.typesafe.config.ConfigException

@RunWith(classOf[JUnitRunner])
class KGUGGuaranteesTest extends TestGuarantees {
  test("kgugGuarantees_wrap") {
    val instancia: KGUGGuarantees = KGUGGuarantees(testResources.kgugGuarantees_complete_input, testResources.config)
    val result: KGUGGuarantees = instancia.wrap(testResources.kgugGuarantees_complete_input)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kgugGuarantees_selectTablonColumns") {
    val result: DataFrame = KGUGGuarantees(testResources.ktae_guarantees_after_join, testResources.config).selectTablonColumns().getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ktae_guarantees_after_join_selected, FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("kgugGuarantees_selectTablonColumnsBadSelect") {
    assertThrows[AnalysisException] {
      KGUGGuarantees(testResources.ktae_guarantees_after_join, testResources.configBadSelect).selectTablonColumns().getDataFrame()
    }
  }

  test("kgugGuarantees_selectTablonColumnsMissSelect") {
    assertThrows[ConfigException.Missing] {
      KGUGGuarantees(testResources.ktae_guarantees_after_join, testResources.configMissSelect).selectTablonColumns().getDataFrame()
    }
  }
}
