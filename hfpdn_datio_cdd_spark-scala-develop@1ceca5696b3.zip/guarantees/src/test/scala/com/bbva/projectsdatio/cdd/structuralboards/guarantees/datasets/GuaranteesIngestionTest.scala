package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.app.CDDStructuralBoardsDataset
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant._
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.actions.FileSystemUtils
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.app.{StructuralboardsGuarantees_RQ22021, StructuralboardsGuarantees_RQ42021}
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.TestGuarantees
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils.TestUtils
import com.datio.dataproc.sdk.datiofilesystem.DatioFileSystem
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class GuaranteesIngestionTest extends TestGuarantees {

  test("guaranteesIngestion_joinTablon_RQ22021") {
    val kgugGuarantees = KGUGGuarantees(testResources.kgugGuarantees_customized_testing, testResources.config).globalParameterSetter()
    val kgugAssets = KGUGAssets(testResources.kgugAssets_customized_testing, testResources.config).globalParameterSetter()
    val kgugValuations = KGUGValuations_OLD(testResources.kgugValuations_customized_testing, testResources.config).globalParameterSetter()
    val kgugAdjudications = KGUGAdjudications(testResources.kgugAdjudications_customized_testing, testResources.config).globalParameterSetter()
    val datasetMap: Map[String,CDDStructuralBoardsDataset[_]] = Map(
      GUARANTEE_BOARD_TABLE_GUARANTEES -> kgugGuarantees,
      GUARANTEE_BOARD_TABLE_ASSETS -> kgugAssets,
      GUARANTEE_BOARD_TABLE_VALUATIONS -> kgugValuations,
      GUARANTEE_BOARD_TABLE_ADJUDICATIONS -> kgugAdjudications
    )
    val result: DataFrame = (new StructuralboardsGuarantees_RQ22021).joinTablon(datasetMap,
      testResources.globalReaded, testResources.globalTranslated, datioSparkSession).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ktae_guarantees_after_join, FALSE_VALUE) shouldBe true
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }
  test("guaranteesIngestion_joinTablon_RQ42021") {
    val kgugGuarantees = KGUGGuarantees(testResources.kgugGuarantees_customized_testing, testResources.config).globalParameterSetter()
    val kgugAssets = KGUGAssets(testResources.kgugAssets_customized_testing, testResources.config).globalParameterSetter()
    val kgugValuations = KGUGValuations(testResources.kgugValuations_RQ42021_customized_testing, testResources.config_RQ42021).globalParameterSetter()
    val kgugAdjudications = KGUGAdjudications(testResources.kgugAdjudications_customized_testing, testResources.config).globalParameterSetter()
    val datasetMap: Map[String,CDDStructuralBoardsDataset[_]] = Map(
      GUARANTEE_BOARD_TABLE_GUARANTEES -> kgugGuarantees,
      GUARANTEE_BOARD_TABLE_ASSETS -> kgugAssets,
      GUARANTEE_BOARD_TABLE_VALUATIONS -> kgugValuations,
      GUARANTEE_BOARD_TABLE_ADJUDICATIONS -> kgugAdjudications
    )
    val result: DataFrame = (new StructuralboardsGuarantees_RQ42021).joinTablon(datasetMap,
      testResources.globalReaded, testResources.globalTranslated, datioSparkSession).getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.ktae_guarantees_RQ42021_after_join, FALSE_VALUE) shouldBe true
    val dfs = DatioFileSystem.get()
    FileSystemUtils.delete(dfs, testResources.config.getString(CONF_TEMPORAL_PATH))
  }

  test("guaranteesIngestion_dataSetCollectorMapper_KGUGAdjudicationsEmpty") {
    val testInputEntityName : String = GUARANTEE_BOARD_TABLE_ADJUDICATIONS
    val result = (new StructuralboardsGuarantees_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KGUGAdjudications])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("guaranteesIngestion_dataSetCollectorMapper_KGUGAssetsEmpty") {
    val testInputEntityName : String = GUARANTEE_BOARD_TABLE_ASSETS
    val result = (new StructuralboardsGuarantees_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KGUGAssets])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  /*
  test("guaranteesIngestion_dataSetCollectorMapper_KGUGValuations_RQ22021_Empty") {
    val testInputEntityName : String = GUARANTEE_BOARD_TABLE_VALUATIONS
    val result = (new StructuralboardsGuarantees_RQ22021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslated,
      testResources.config,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KGUGValuations])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }

  test("guaranteesIngestion_dataSetCollectorMapper_KGUGValuations_RQ42021_Empty") {
    val testInputEntityName : String = GUARANTEE_BOARD_TABLE_VALUATIONS
    val result = (new StructuralboardsGuarantees_RQ42021).dataSetCollectionMapper(testInputEntityName,
      testResources.globalReaded,
      testResources.globalTranslatedValuations,
      testResources.config_RQ42021,
      datioSparkSession,
      TRUE_VALUE)
    assert(result.get._2.isInstanceOf[KGUGValuations_RQ42021])
    assert(result.get._2.getDataFrame().count().equals(0.toLong))
  }
   */
}
