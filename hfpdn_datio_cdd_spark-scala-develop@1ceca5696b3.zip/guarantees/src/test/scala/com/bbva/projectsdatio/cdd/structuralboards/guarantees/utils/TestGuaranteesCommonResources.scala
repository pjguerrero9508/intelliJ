package com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.{GlobalConfigurationReaded, GlobalConfigurationTranslated}
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession

class TestGuaranteesCommonResources(datioSparkSession: DatioSparkSession) extends TestGuaranteesDataframes(datioSparkSession) with TestGuaranteesConfigs {

    //CONSTANTS
    val emptyString: String = ""

    //PATHS
    lazy val schemaPath: String = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
    lazy val schemaPath_RQ42021: String = "src/test/resources/schemas/guarantees/t_ktae_guarantee_RQ42021_struc_board.json"
    lazy val checkpointPath: String = "src/test/resources/data/guaranteesIngestion/temporal/checkpoint"

    //CONFIGURATIONS
    val globalReaded : GlobalConfigurationReaded =
        GlobalConfigurationReaded(dateIngestion = "2021-04-01",
            dateColumnName = "gf_cutoff_date",
            dateColumnValue = "2021-04-12",
            entificColumnName = "g_entific_id",
            entificColumnValue = "ES",
            auditColumnName = "gf_audit_date",
            averageKBPerRecord = 1,
            fullNameSchemaBoard = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json",
            pathTemporal = "",
            pathOutputBoard = "",
            repartitionBase = 1,
            notInformedDatasets = Seq.empty[String])
    val globalTranslated : GlobalConfigurationTranslated =
        GlobalConfigurationTranslated(datioOutputSchema = ktae_guarantees_after_join_testing_datio_schema,
            checkpointTempPath = checkpointPath,
            backupTempPath = "",
            actualPrincipalPath = "",
            actualPrincipalPathWithPartitions = "")
    val globalTranslatedValuations : GlobalConfigurationTranslated =
        GlobalConfigurationTranslated(datioOutputSchema = ktae_guarantees_valuations_datio_schema,
            checkpointTempPath = checkpointPath,
            backupTempPath = "",
            actualPrincipalPath = "",
            actualPrincipalPathWithPartitions = "")
}
