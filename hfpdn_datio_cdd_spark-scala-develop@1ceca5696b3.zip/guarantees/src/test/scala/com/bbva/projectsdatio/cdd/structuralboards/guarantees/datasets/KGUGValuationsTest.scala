package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.TestGuarantees
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils.TestUtils
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KGUGValuationsTest extends TestGuarantees{

  test("kgugValuations_wrap") {
    val instancia: KGUGValuations_OLD = KGUGValuations_OLD(testResources.kgugValuations_complete_input, testResources.config)
    val result: KGUGValuations_OLD = instancia.wrap(testResources.kgugValuations_complete_input)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

  test("kgugValuations_calculateAppraisal") {
    val result: DataFrame = KGUGValuations_OLD(testResources.kgugValuations_complete_input, testResources.config).calculateAppraisal().getDataFrame()
    TestUtils.assertDataFrameEquals(result, testResources.kgugValuations_customized_testing, FALSE_VALUE) shouldBe TRUE_VALUE
  }

  test("kgugValuations_calculateAppraisalBadFields") {
    assertThrows[ParamNotInformedException] {
      KGUGValuations_OLD(testResources.kgugValuations_complete_input, testResources.rootConfigBadFields).calculateAppraisal().getDataFrame()
    }
  }

  test("kgugValuations_calculateAppraisalMissFields") {
    assertThrows[ParamNotInformedException] {
      KGUGValuations_OLD(testResources.kgugValuations_complete_input, testResources.rootConfigMissFields).calculateAppraisal().getDataFrame()
    }
  }

  test("kgugValuations_calculateAppraisalEmpty") {
    val result: DataFrame = KGUGValuations_OLD(testResources.kgugValuations_complete_input, testResources.config).calculateAppraisal().getDataFrame()
    val empty_result: DataFrame = KGUGValuations_OLD(testResources.kgugValuations_complete_input, testResources.config).calculateAppraisalEmpty().getDataFrame()
    empty_result.schema == result.schema shouldBe true
  }

  test("kgugValuations_generateEmptyDataSet") {
    val result: DataFrame = KGUGValuations_OLD(testResources.testingEmptyDataFrame, testResources.config)
      .applyEmpty(datioSparkSession, testResources.ktae_guarantees_output_testing_datio_schema).calculateAppraisalEmpty().getDataFrame()
    val expectedSize = 0
    var expectedSchema : StructType = new StructType()
    expectedSchema = expectedSchema.add("g_first_appraisal_currency_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_guarantee_asset_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_last_appraisal_currency_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_first_appraisal_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_first_appraising_date", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_last_appraisal_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_last_appraisal_date", StringType, TRUE_VALUE)
    val resultSchema : StructType = StructType.apply(result.schema.sortBy(_.name))
    assert(expectedSchema.simpleString.equals(resultSchema.simpleString))
    assert(result.count().equals(expectedSize.toLong))
  }
}
