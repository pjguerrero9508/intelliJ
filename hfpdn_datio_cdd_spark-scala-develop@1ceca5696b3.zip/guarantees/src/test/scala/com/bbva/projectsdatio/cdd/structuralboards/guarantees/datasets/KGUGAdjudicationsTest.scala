package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.TestGuarantees
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KGUGAdjudicationsTest extends TestGuarantees {
  test("kgugAdjudications_wrap") {
    val instancia: KGUGAdjudications = KGUGAdjudications(testResources.kgugAdjudications_complete_input, testResources.config)
    val result: KGUGAdjudications = instancia.wrap(testResources.kgugAdjudications_complete_input)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
