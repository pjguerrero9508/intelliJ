package com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils

import java.io.File

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.NULL_VALUE
import com.datio.dataproc.sdk.datiosparksession.DatioSparkSession
import com.datio.dataproc.sdk.schema.DatioSchema
import com.typesafe.config.{Config, ConfigFactory}
import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Column, DataFrame}

object TestUtils extends LazyLogging {
  def loadCSV(datioSparkSession: DatioSparkSession, path: String): DataFrame = {
    datioSparkSession.read.
      option("header", "true")
      .csv(getResourcesPath("data/" + path))
  }

  /**
   * This method read a csv with schema and head
   *
   * @param datioSparkSession  DatioSparkSession
   * @param path   path of data
   * @param schemaPath schema of data
   * @return DataFrame read
   */
  def loadCSVwithSchema(datioSparkSession: DatioSparkSession, path: String, schemaPath: String): DataFrame = {
    datioSparkSession.read
      .option("header", "true")
      .option("delimiter", "|")
      .datioSchema(DatioSchema.getBuilder.fromString(schemaPath).build())
      .csv(getResourcesPath("data/" + path))
  }

  def getResourcesPath(resource: String): String = getClass.getClassLoader.getResource(resource).getFile

  def getConfigTest(confFile: String, confStruct: String): Config = {
    ConfigFactory.parseFile(new File(getResourcesPath(confFile)))
      .getConfig(confStruct)
  }

  def getConfigRunProcessTest(confFile: String): Config = {
    ConfigFactory.parseFile(new File(getResourcesPath(confFile)))
  }

  /**
   * Compares if two DataFrames are equal.
   * This approach correctly handles cases where the DataFrames may have duplicate rows, rows in different orders, and/or columns in different orders.
   * 1. Check two schemas are equal
   * 2. Check the number of rows are equal
   * 3. Check there is no unequal rows
   *
   * @param a                     DataFrame one.
   * @param b                     DataFrame two.
   * @param isRelaxed             Boolean set true if dataFrame has to be sorted before compare.
   * @param requiredCompareSchema Boolean if is necessary compare tow schemas. Default true.
   * @return Boolean if dataFrames are equal.
   */
  def assertDataFrameEquals(a: DataFrame, b: DataFrame, isRelaxed: Boolean, requiredCompareSchema: Boolean = true): Boolean = {
    logger.info(s"CDD: TestsStructuralBoards: assertDataFrameEquals - Init method")
    try {
      a.rdd.cache
      b.rdd.cache
      // 1. Check the equality of two schemas
      if (requiredCompareSchema) {
        if (!compareSchemas(a, b)) return false
      }
      // 2. Check the number of rows in two dfs
      if (a.count() != b.count()) {
        logger.warn(s"CDD: TestsStructuralBoards: assertDataFrameEquals - Different number of lines A:" + a.count() + " B:" + b.count())
        a.show(truncate = false)
        b.show(truncate = false)
        return false
      }
      // 3. Check there is no unequal rows
      val aColumns: Array[String] = a.columns
      val bColumns: Array[String] = b.columns
      // To correctly handles cases where the DataFrames may have columns in different orders
      scala.util.Sorting.quickSort(aColumns)
      scala.util.Sorting.quickSort(bColumns)
      val aSeq: Seq[Column] = aColumns.map(col(_))
      val bSeq: Seq[Column] = bColumns.map(col(_))
      var a_prime: DataFrame = NULL_VALUE
      var b_prime: DataFrame = NULL_VALUE

      if (isRelaxed) {
        a_prime = a
        b_prime = b
      } else {
        // To correctly handles cases where the DataFrames may have duplicate rows and/or rows in different orders
        a_prime = a.sort(aSeq: _*).groupBy(aSeq: _*).count()
        b_prime = b.sort(aSeq: _*).groupBy(bSeq: _*).count()
      }
      val c1: Long = a_prime.except(b_prime).count()
      val c2: Long = b_prime.except(a_prime).count()

      if (c1 != c2 || c1 != 0 || c2 != 0) {
        logger.warn(s"CDD: TestsStructuralBoards: assertDataFrameEquals - Different rows")
        a.show(truncate = false)
        b.show(truncate = false)
        return false
      }
    } finally {
      a.rdd.unpersist()
      b.rdd.unpersist()
    }
    logger.info(s"CDD: TestsStructuralBoards: assertDataFrameEquals - Exit method whit true value")
    true
  }

  /**
   * Compares if two DataFrames are equal schemas.
   *
   * @param a DataFrame one.
   * @param b DataFrame two.
   * @return Boolean if dataFrames are equal.
   */
  def compareSchemas(a: DataFrame, b: DataFrame): Boolean = {

    if (!a.schema.toString().equalsIgnoreCase(b.schema.toString)) {
      logger.warn(s"CDD: TestsStructuralBoards: assertDataFrameEquals - Different schemas:")
      a.printSchema()
      b.printSchema()
      false
    } else {
      true
    }
  }

  /**
   * Compares if two StructType are equal without metadata
   *
   * @param a StructType one.
   * @param b StructType two.
   * @return Boolean if StructType are equal.
   */
  def compareStructType(a: StructType, b: StructType): Boolean = {

    val s1 = a.fields.map(f => (f.name, f.dataType, f.nullable))
    val s2 = b.fields.map(f => (f.name, f.dataType, f.nullable))

    if (s1.diff(s2).isEmpty) {
      true
    } else {
      logger.warn(s"CDD: TestsStructuralBoards: compareStructType - Different StructType:")
      logger.warn(s"CDD: TestsStructuralBoards: compareStructType - StructType 1: $s1")
      logger.warn(s"CDD: TestsStructuralBoards: compareStructType - StructType 2: $s2")
      false
    }
  }
}
