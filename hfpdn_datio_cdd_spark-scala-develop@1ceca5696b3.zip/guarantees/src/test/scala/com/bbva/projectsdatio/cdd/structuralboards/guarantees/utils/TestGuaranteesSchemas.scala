package com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.datio.dataproc.sdk.schema.{DatioSchema, DatioSchemaForTesting}
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import org.mockito.Mockito.spy

trait TestGuaranteesSchemas {

  //SCHEMAS
  lazy val testingDataSchema: StructType = StructType(List(
    StructField("String",    DataTypes.StringType, TRUE_VALUE),
    StructField("Int",       DataTypes.IntegerType, TRUE_VALUE),
    StructField("Double",    DataTypes.DoubleType, TRUE_VALUE),
    StructField("Date",      DataTypes.DateType, TRUE_VALUE),
    StructField("Timestamp", DataTypes.TimestampType, TRUE_VALUE)
  ))

  lazy val kgugGuarantees_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //joinColsAsset ¿Puede ser nulo?
    StructField("g_t_kgug_guarantees_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kgugGuarantees_customized_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //joinColsAsset ¿Puede ser nulo?
    StructField("g_t_kgug_guarantees_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kgugValuations_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_appraisal_date",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_currency_id",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_appraisal_amount",                        DataTypes.StringType, TRUE_VALUE),
    //No tiene sentido mas campos en este df, horizontalizado
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kgugValuations_calculations_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_first_appraising_date",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    //No tiene sentido mas campos en este df, horizontalizado
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kgugValuations_RQ42021_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_appraisal_date",                          DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_currency_id",                              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_appraisal_amount",                        DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_countervalued_currency_id",                DataTypes.StringType, TRUE_VALUE),
    StructField("gf_appraiser_company_name",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_force_sale_est_val_amount",               DataTypes.StringType, TRUE_VALUE),
    //No tiene sentido mas campos en este df, horizontalizado
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kgugValuations_RQ42021_calculations_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_ctvl_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_countervalued_currency_id",                DataTypes.StringType, TRUE_VALUE),
    StructField("gf_appraiser_company_name",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_force_sale_est_val_amount",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraising_date",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_first_aprsl_amount",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_aprsl_ctval_curncy_id",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_aprsr_company_name",                DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_frcdsale_estvl_amount",             DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_last_aprsl_amount",              DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_aprsl_ctval_curncy_id",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_aprsr_company_name",                 DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_frcdsale_estvl_amount",              DataTypes.StringType, TRUE_VALUE),
    //No tiene sentido mas campos en este df, horizontalizado
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kgugAssets_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_asset_id",                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_assets_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                          DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kgugAssets_customized_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_asset_id",                   DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_assets_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                         DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                           DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                          DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val kgugAdjudication_complete_input_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_adjudication_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_not_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_to_rename",     DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kgugAdjudication_customized_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_adjudication_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                               DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_entific_id",                                 DataTypes.StringType, TRUE_VALUE), //PK
    StructField("gf_audit_date",                                DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_guarantees_after_join_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_guarantees_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraising_date",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_guarantees_valuations_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_guarantees_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraising_date",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",                DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_first_aprsl_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_aprsl_ctval_curncy_id",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_aprsr_company_name",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_frcdsale_estvl_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_guarantees_output_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_guarantee_asset_id",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_renamed",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_currency_id",                          DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraising_date",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",          DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_renamed", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                           DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_guarantees_RQ42021_after_join_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                             DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_guarantee_asset_id",                       DataTypes.StringType, TRUE_VALUE), //PK
    StructField("g_t_kgug_guarantees_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_initialized",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_renamed",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_initialized",       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_appraisal_amount",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_countervalued_currency_id",                   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_appraiser_company_name",           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_force_sale_est_val_amount",       DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraising_date",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_first_aprsl_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_aprsl_ctval_curncy_id",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_aprsr_company_name",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_frcdsale_estvl_amount",                  DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                     DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_last_aprsl_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_aprsl_ctval_curncy_id",                   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_aprsr_company_name",                   DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_frcdsale_estvl_amount",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant",             DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_renamed",     DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_initialized", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                             DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_audit_date",                              DataTypes.StringType, TRUE_VALUE)
  ))

  lazy val ktae_guarantees_RQ42021_output_testing_schema: StructType = StructType(List(
    StructField("g_guarantee_id",                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_guarantee_asset_id",                   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant",           DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_guarantees_relevant_renamed",   DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_assets_relevant_renamed",       DataTypes.StringType, TRUE_VALUE),
    StructField("g_currency_id",                          DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_appraisal_amount",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_countervalued_currency_id",            DataTypes.StringType, TRUE_VALUE),
    StructField("gf_appraiser_company_name",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_force_sale_est_val_amount",           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraising_date",               DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_appraisal_currency_id",          DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_appraisal_amount",              DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_first_aprsl_amount",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_first_aprsl_ctval_curncy_id",          DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_aprsr_company_name",            DataTypes.StringType, TRUE_VALUE),
    StructField("gf_first_frcdsale_estvl_amount",         DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_date",                 DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_appraisal_currency_id",           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_appraisal_amount",               DataTypes.StringType, TRUE_VALUE),
    StructField("gf_ctvl_ast_last_aprsl_amount",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_last_aprsl_ctval_curncy_id",           DataTypes.StringType, TRUE_VALUE),
    StructField("gf_last_aprsr_company_name",             DataTypes.StringType, TRUE_VALUE),

    StructField("gf_last_frcdsale_estvl_amount",          DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant",         DataTypes.StringType, TRUE_VALUE),
    StructField("g_t_kgug_adjudication_relevant_renamed", DataTypes.StringType, TRUE_VALUE),
    StructField("gf_cutoff_date",                         DataTypes.StringType, TRUE_VALUE),
    StructField("g_entific_id",                           DataTypes.StringType, TRUE_VALUE)
  ))
  lazy val kgugGuarantees_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugGuarantees_complete_input_testing_schema))
  lazy val kgugGuarantees_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugGuarantees_customized_testing_schema))
  lazy val kgugValuations_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugValuations_complete_input_testing_schema))
  lazy val kgugValuations_calculations_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugValuations_calculations_testing_schema))
  lazy val kgugAssets_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugAssets_complete_input_testing_schema))
  lazy val kgugAssets_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugAssets_customized_testing_schema))
  lazy val kgugAdjudication_complete_input_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugAdjudication_complete_input_testing_schema))
  lazy val kgugAdjudication_customized_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(kgugAdjudication_customized_testing_schema))
  lazy val ktae_guarantees_after_join_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_guarantees_after_join_testing_schema))
  lazy val ktae_guarantees_valuations_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_guarantees_valuations_testing_schema))
  lazy val ktae_guarantees_output_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_guarantees_output_testing_schema))
  lazy val ktae_guarantees_RQ42021_output_testing_datio_schema: DatioSchema = spy(new DatioSchemaForTesting(ktae_guarantees_RQ42021_output_testing_schema))
}
