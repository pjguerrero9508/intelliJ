package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.exceptions.ParamNotInformedException
import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.{FALSE_VALUE, TRUE_VALUE}
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.TestGuarantees
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils.TestUtils
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KGUGValuations_RQ42021Test extends TestGuarantees{

  test("kgugValuations_RQ42021_wrap") {
    val instancia: KGUGValuations = KGUGValuations(testResources.kgugValuations_RQ42021_complete_input, testResources.config_RQ42021)
    val result: KGUGValuations = instancia.wrap(testResources.kgugValuations_RQ42021_complete_input)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }

 // test("kgugValuations_RQ42021_calculateAppraisal") {
 //   val result: DataFrame = KGUGValuations(testResources.kgugValuations_RQ42021_complete_input, testResources.config_RQ42021)
 //     .calculateAppraisal().getDataFrame()
 //   TestUtils.assertDataFrameEquals(result, testResources.kgugValuations_RQ42021_customized_testing, FALSE_VALUE) shouldBe TRUE_VALUE
 // }

  test("kgugValuations_RQ42021_calculateAppraisalBadFields") {
    assertThrows[ParamNotInformedException] {
      KGUGValuations(testResources.kgugValuations_RQ42021_complete_input, testResources.rootConfigBadFields)
        .calculateAppraisal().getDataFrame()
    }
  }

  test("kgugValuations_RQ42021_calculateAppraisalMissFields") {
    assertThrows[ParamNotInformedException] {
      KGUGValuations(testResources.kgugValuations_RQ42021_complete_input, testResources.rootConfigMissFields)
        .calculateAppraisal().getDataFrame()
    }
  }

 // test("kgugValuations_RQ42021_calculateAppraisalEmpty") {
 //   val result: DataFrame = KGUGValuations(testResources.kgugValuations_RQ42021_complete_input, testResources.config_RQ42021)
 //     .calculateAppraisal().getDataFrame()
 //   val empty_result: DataFrame = KGUGValuations(testResources.kgugValuations_RQ42021_complete_input, testResources.config_RQ42021)
 //     .calculateAppraisalEmpty().getDataFrame()
 //   empty_result.schema == result.schema shouldBe true
 // }

  test("kgugValuations_RQ42021_generateEmptyDataSet") {
    val result: DataFrame = KGUGValuations(testResources.testingEmptyDataFrame, testResources.config_RQ42021)
      .applyEmpty(datioSparkSession, testResources.ktae_guarantees_RQ42021_output_testing_datio_schema).calculateAppraisalEmpty().getDataFrame()
    var expectedSchema : StructType = new StructType()
    expectedSchema = expectedSchema.add("g_first_appraisal_currency_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_guarantee_asset_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_last_appraisal_currency_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_first_appraisal_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_first_appraising_date", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_last_appraisal_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_last_appraisal_date", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_ctvl_ast_first_aprsl_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_ctvl_ast_last_aprsl_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_first_aprsl_ctval_curncy_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("g_last_aprsl_ctval_curncy_id", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_first_aprsr_company_name", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_last_aprsr_company_name", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_first_frcdsale_estvl_amount", StringType, TRUE_VALUE)
    expectedSchema = expectedSchema.add("gf_last_frcdsale_estvl_amount", StringType, TRUE_VALUE)
    val resultSchema : StructType = StructType.apply(result.schema.sortBy(_.name))
    TestUtils.compareStructType(resultSchema,expectedSchema)
  }
}
