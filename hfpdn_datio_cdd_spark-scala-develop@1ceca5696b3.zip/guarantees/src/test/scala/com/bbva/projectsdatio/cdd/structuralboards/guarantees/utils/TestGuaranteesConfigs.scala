package com.bbva.projectsdatio.cdd.structuralboards.guarantees.utils

import com.typesafe.config.{Config, ConfigFactory}

trait TestGuaranteesConfigs {

  //CONSTANTS
  val confStruct: String = "CDDGuaranteesBoard"

  lazy val ktaeGuaranteesBoardRoot_complete : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 2
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_default : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = "coso"
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_notInformedAllButRoot : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = "coso"
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  notInformedDataSets = "t_kgug_adjudications;t_kgug_assets;t_kgug_valuations"
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_notInformedKgugAdjudications : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = "coso"
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  notInformedDataSets = "t_kgug_adjudications"
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_notInformedKgugAdjudicationsAndKgugAssets : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = "coso"
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  notInformedDataSets = "t_kgug_adjudications;t_kgug_assets"
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_badCutoff : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-13-40"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 2
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_badCutoffType : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "aaaaaaa"
      |  entificColumnName = "g_entific_id"
      |  entificColumnValue = "GL"
      |  auditColumnName = "gf_audit_date"
      |  averageKBPerRecord = 2
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val ktaeGuaranteesBoardRoot_missParam : String =
    """CDDGuaranteesBoard {
      |  dateIngestion = "2020-08-20"
      |  dateColumnName = "gf_cutoff_date"
      |  dateColumnValue = "2020-07-31"
      |  averageKBPerRecord = 2
      |  schemaPath = "src/test/resources/schemas/guarantees/t_ktae_guarantee_struc_board.json"
      |  repartitionBase = 3
      |  notInformedDataSets = ""
      |
      |  paths = {
      |    temporalPath = "src/test/resources/data/guaranteesIngestion/temporal"
      |    pathTablonOutputPrincipal = "src/test/resources/data/guaranteesIngestion/principal"
      |  }"""

  lazy val kgugGuarantees_correct : String =
    """| kgugGuarantees = {
      |    dataPath = "src/test/resources/data/kgugGuarantees/parquet/"
      |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_guarantees.json"
      |    relevantFields = ["g_guarantee_id",
      |      "g_guarantee_asset_id",
      |      "g_t_kgug_guarantees_relevant",
      |      "g_t_kgug_guarantees_relevant_renamed",
      |      "g_t_kgug_guarantees_relevant_initialized"]
      |
      |    selectTablonFields = ["g_guarantee_id",
      |       "g_guarantee_asset_id",
      |       "g_t_kgug_guarantees_relevant",
      |       "g_t_kgug_guarantees_relevant_renamed",
      |       "g_t_kgug_assets_relevant",
      |       "g_t_kgug_assets_relevant_renamed",
      |       "gf_first_appraising_date",
      |       "g_first_appraisal_currency_id",
      |       "gf_first_appraisal_amount",
      |       "gf_last_appraisal_date",
      |       "g_last_appraisal_currency_id",
      |       "gf_last_appraisal_amount",
      |       "g_t_kgug_adjudication_relevant",
      |       "g_t_kgug_adjudication_relevant_renamed"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
      |  }"""

  lazy val kgugGuarantees_badSelect : String =
    """| kgugGuarantees = {
       |    dataPath = "src/test/resources/data/kgugGuarantees/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_guarantees.json"
       |    relevantFields = ["g_guarantee_id",
       |      "g_guarantee_asset_id",
       |      "g_t_kgug_guarantees_relevant",
       |      "g_t_kgug_guarantees_relevant_renamed",
       |      "g_t_kgug_guarantees_relevant_initialized"]
       |
       |    selectTablonFields = ["g_guarantee_id",
       |       "g_guarantee_asset_id",
       |       "g_t_kgug_guarantees_relevant",
       |       "g_t_kgug_guarantees_relevant_renamed",
       |       "g_t_kgug_assets_relevant",
       |       "g_t_kgug_assets_relevant_renamed",
       |       "gf_first_appraising_date",
       |       "g_first_appraisal_currency_id",
       |       "gf_first_appraisal_amount",
       |       "gf_last_appraisal_date",
       |       "g_last_appraisal_currency_id",
       |       "gf_last_appraisal_amount",
       |       "g_t_kgug_adjudication_relevant",
       |       "g_t_kgug_adjudication_relevant_renamed",
       |       "aaaaaaaaaaaaaa"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kgugGuarantees_badJoinFields : String =
    """| kgugGuarantees = {
       |    dataPath = "src/test/resources/data/kgugGuarantees/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_guarantees.json"
       |    relevantFields = ["g_guarantee_id",
       |      "g_guarantee_asset_id",
       |      "g_t_kgug_guarantees_relevant",
       |      "g_t_kgug_guarantees_relevant_renamed",
       |      "g_t_kgug_guarantees_relevant_initialized"]
       |
       |    selectTablonFields = ["g_guarantee_id",
       |       "g_guarantee_asset_id",
       |       "g_t_kgug_guarantees_relevant",
       |       "g_t_kgug_guarantees_relevant_renamed",
       |       "g_t_kgug_assets_relevant",
       |       "g_t_kgug_assets_relevant_renamed",
       |       "gf_first_appraising_date",
       |       "g_first_appraisal_currency_id",
       |       "gf_first_appraisal_amount",
       |       "gf_last_appraisal_date",
       |       "g_last_appraisal_currency_id",
       |       "gf_last_appraisal_amount",
       |       "g_t_kgug_adjudication_relevant",
       |       "g_t_kgug_adjudication_relevant_renamed"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kgugGuarantees_missSelect : String =
    """|   kgugGuarantees = {
       |    dataPath = "src/test/resources/data/kgugGuarantees/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_guarantees.json"
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kgugAdjudications_correct : String =
    """|  kgugAdjudications = {
       |    dataPath = "src/test/resources/data/kgugAdjudications/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_adjudications.json"
       |    relevantFields = ["g_guarantee_id",
       |      "g_t_kgug_adjudication_relevant",
       |      "g_t_kgug_adjudication_relevant_renamed",
       |      "g_t_kgug_adjudication_relevant_initialized"]
       |    joinFields = ["g_guarantee_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kgugAssets_correct : String =
    """| kgugAssets = {
       |    dataPath = "src/test/resources/data/kgugAssets/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_assets.json"
       |    relevantFields = ["g_guarantee_asset_id",
       |      "g_t_kgug_assets_relevant",
       |      "g_t_kgug_assets_relevant_renamed",
       |      "g_t_kgug_assets_relevant_initialized"]
       |    joinFields = ["g_guarantee_asset_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
      |  }"""

  lazy val kgugValuations_correct : String =
    """|  kgugValuations = {
      |    dataPath = "src/test/resources/data/kgugValuations/parquet/"
      |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_valuations.json"
      |    relevantFields = ["g_guarantee_asset_id",
      |      "gf_appraisal_date",
      |      "g_currency_id",
      |      "gf_appraisal_amount"]
      |    fields = {
      |      guaranteeAssetId = "g_guarantee_asset_id"
      |      appraisalDate = "gf_appraisal_date"
      |      currencyId = "g_currency_id"
      |      appraisalAmount = "gf_appraisal_amount"
      |      appraisalDateFirst = "gf_first_appraising_date"
      |      currencyIdFirst = "g_first_appraisal_currency_id"
      |      appraisalAmountFirst = "gf_first_appraisal_amount"
      |      appraisalDateLast = "gf_last_appraisal_date"
      |      currencyIdLast = "g_last_appraisal_currency_id"
      |      appraisalAmountLast = "gf_last_appraisal_amount"
      |    }
       |    joinFields = ["g_guarantee_asset_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
      |  }"""
  lazy val kgugValuations_RQ42021_correct : String =
    """|  kgugValuations = {
       |    dataPath = "src/test/resources/data/kgugValuations/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_valuations.json"
       |    relevantFields = ["g_guarantee_asset_id",
       |      "gf_appraisal_date",
       |      "g_currency_id",
       |      "gf_appraisal_amount",
       |      "gf_ctvl_appraisal_amount",
       |      "g_countervalued_currency_id",
       |      "gf_appraiser_company_name",
       |      "gf_force_sale_est_val_amount"]
       |    fields = {
       |		  guaranteeAssetId = "g_guarantee_asset_id"
       |		  appraisalDate = "gf_appraisal_date"
       |		  currencyId = "g_currency_id"
       |		  appraisalAmount = "gf_appraisal_amount"
       |		  ctvlAppraisalAmount = "gf_ctvl_appraisal_amount"
       |		  ctvlCurrencyId = "g_countervalued_currency_id"
       |		  appraisalCompanyName = "gf_appraiser_company_name"
       |		  forceSaleEstAmount = "gf_force_sale_est_val_amount"
       |		  appraisalDateFirst = "gf_first_appraising_date"
       |		  currencyIdFirst = "g_first_appraisal_currency_id"
       |		  appraisalAmountFirst = "gf_first_appraisal_amount"
       |		  ctvlAppraisalAmountFirst = "gf_ctvl_ast_first_aprsl_amount"
       |		  ctvlCurrencyIdFirst = "g_first_aprsl_ctval_curncy_id"
       |		  appraisalCompanyNameFirst = "gf_first_aprsr_company_name"
       |		  forceSaleEstAmountFirst = "gf_first_frcdsale_estvl_amount"
       |		  appraisalDateLast = "gf_last_appraisal_date"
       |		  currencyIdLast = "g_last_appraisal_currency_id"
       |		  appraisalAmountLast = "gf_last_appraisal_amount"
       |		  ctvlAppraisalAmountLast = "gf_ctvl_ast_last_aprsl_amount"
       |		  ctvlCurrencyIdLast = "g_last_aprsl_ctval_curncy_id"
       |		  appraisalCompanyNameLast = "gf_last_aprsr_company_name"
       |		  forceSaleEstAmountLast = "gf_last_frcdsale_estvl_amount"
       |    }
       |    joinFields = ["g_guarantee_asset_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kgugValuations_badFields : String =
    """|  kgugValuations = {
       |    dataPath = "src/test/resources/data/kgugValuations/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_valuations.json"
       |    relevantFields = ["g_guarantee_asset_id",
       |      "gf_appraisal_date",
       |      "g_currency_id",
       |      "gf_appraisal_amount"]
       |    fields = {
       |      guaranteeAssetId = "g_entific_id"
       |      appraisalDate = "gf_appraisal_date"
       |      currencyId = "g_currency_id"
       |      appraisalAmount = "gf_appraisal_amount"
       |      appraisalDateFirst = "gf_first_appraising_date"
       |      currencyIdFirst = "g_first_appraisal_currency_id"
       |      appraisalAmountFirst = "gf_first_appraisal_amount"
       |      appraisalDateLast = "gf_last_appraisal_date"
       |      currencyIdLast = "g_last_appraisal_currency_id"
       |      appraisalAmountLast = "gf_last_appraisal_amount"
       |    }
       |    joinFields = ["g_guarantee_asset_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  lazy val kgugValuations_missFields : String =
    """|  kgugValuations = {
       |    dataPath = "src/test/resources/data/kgugValuations/parquet/"
       |    schemaPath = "src/test/resources/schemas/guarantees/RQ42021/t_kgug_valuations.json"
       |    relevantFields = ["g_guarantee_asset_id",
       |      "gf_appraisal_date",
       |      "g_currency_id",
       |      "gf_appraisal_amount"]
       |    fields = {
       |      guaranteeAssetId = "g_guarantee_asset_id"
       |      appraisalDate = "gf_appraisal_date"
       |      currencyId = "g_currency_id"
       |      appraisalAmount = "gf_appraisal_amount"
       |      appraisalDateLast = "gf_last_appraisal_date"
       |      currencyIdLast = "g_last_appraisal_currency_id"
       |      appraisalAmountLast = "gf_last_appraisal_amount"
       |    }
       |    joinFields = ["g_guarantee_asset_id"]
       |    previousFilterAppliedFields = ["gf_cutoff_date",
       |      "g_entific_id"]
       |  }"""

  //CONFIG FILES
  lazy val rootConfig: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfig_RQ42021: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_RQ42021_correct.stripMargin + """
                                                               |}
                                                               |""".stripMargin)

  lazy val rootConfigMissSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_missSelect.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadSelect: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_badSelect.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigDefault: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_default.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
     |}
     |""".stripMargin)

  lazy val rootConfigNotInformedAllButRoot: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_notInformedAllButRoot.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigEmptyKgugAdjudications: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_notInformedKgugAdjudications.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigEmptyKgugAdjudicationsAndKgugAssets: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_notInformedKgugAdjudicationsAndKgugAssets.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigMissParam: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_missParam.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadCutoffDate: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_badCutoff.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadCutoffDateType: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_badCutoffType.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
     |}
     |""".stripMargin)

  lazy val rootConfigBadJoinFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_badJoinFields.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_correct.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigBadFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_badFields.stripMargin + """
      |}
      |""".stripMargin)

  lazy val rootConfigMissFields: Config = ConfigFactory.parseString(
    """""".stripMargin + ktaeGuaranteesBoardRoot_complete.stripMargin + """
      """.stripMargin + kgugGuarantees_correct.stripMargin + """
      """.stripMargin + kgugAdjudications_correct.stripMargin + """
      """.stripMargin + kgugAssets_correct.stripMargin + """
      """.stripMargin + kgugValuations_missFields.stripMargin + """
      |}
      |""".stripMargin)

  lazy val config: Config = rootConfig.getConfig(confStruct)
  lazy val config_RQ42021: Config = rootConfig_RQ42021.getConfig(confStruct)
  lazy val configDefault: Config = rootConfigDefault.getConfig(confStruct)
  lazy val configBadSelect: Config = rootConfigBadSelect.getConfig(confStruct)
  lazy val configMissSelect: Config = rootConfigMissSelect.getConfig(confStruct)
  lazy val configMissParam: Config = rootConfigMissParam.getConfig(confStruct)
  lazy val configBadCutoffDate: Config = rootConfigBadCutoffDate.getConfig(confStruct)
  lazy val configBadJoinFields: Config = rootConfigBadJoinFields.getConfig(confStruct)
  lazy val configBadCutoffDateType: Config = rootConfigBadCutoffDateType.getConfig(confStruct)
  lazy val configNotInformedAllButRoot: Config = rootConfigNotInformedAllButRoot.getConfig(confStruct)
  lazy val configEmptyKgugAdjudications: Config = rootConfigEmptyKgugAdjudications.getConfig(confStruct)
  lazy val configEmptyKgugAdjudicationsAndKgugAssets: Config = rootConfigEmptyKgugAdjudicationsAndKgugAssets.getConfig(confStruct)

}
