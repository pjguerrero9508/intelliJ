package com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets

import com.bbva.projectsdatio.cdd.structuralboards.commons.utils.Constant.TRUE_VALUE
import com.bbva.projectsdatio.cdd.structuralboards.guarantees.TestGuarantees
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class KGUGAssetsTest extends TestGuarantees {
  test("kgugAssets_wrap") {
    val instancia: KGUGAssets = KGUGAssets(testResources.kgugAssets_complete_input_testing, testResources.config)
    val result: KGUGAssets = instancia.wrap(testResources.kgugAssets_complete_input_testing)
    (result == instancia && result.getClass == instancia.getClass) shouldBe TRUE_VALUE
  }
}
