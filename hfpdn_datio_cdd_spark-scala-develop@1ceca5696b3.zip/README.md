
# CDD - Structural Boards

This project generates structural boards from the information of different CDD tables, by applying filters or 
transformations to some of them, and then joining them all. Also, it manages the generation of backups and their 
deletion when it is not necessary to keep them in the HDFS, and a restore backup method on principal path.

It consists of five modules: 
* **Contracts**: It manages all the steps for building contract structural board from its CDD input tables.

* **Operations**: It manages all the steps for building operation structural board from its CDD input tables.

* **Customers**: It manages all the steps for building customer structural board from its CDD input tables.

* **Guarantees**: It manages all the steps for building guarantee structural board from its CDD input tables.

* **Commons**: It manages the common functions between the different boards, such as reading and writing the different 
tables; or managing the creation, restore and deletion of backups when necessary.

Here you can find more information about the modules:
1. [Contracts Board](doc/contracts.md)
2. [Operations Board](doc/operations.md)
3. [Customers Board](doc/customers.md)
4. [Guarantees Board](doc/guarantees.md)
5. [Commons Components](doc/commons.md)
