Guarantees app
====

###**SUMMARY**

This part of the project is the brain, here you can find all the logic to build guarantee structural board. This 
application receives the following parameters: 
* **O_DATE:** it must be the actual date, in yyyy-MM-dd format. As an example: O_DATE=2020-08-21

* **GF_CUTOFF_DATE:** it **must be the last day of the previous month in yyyy-MM-dd format**. Data is partitioned by this 
column in HDFS, so this refers to one of those partitions. As an example: GF_CUTOFF_DATE=2020-07-31

* **G_ENTIFIC_ID:** it must be the geography whose data you want to load, must be two characters. Data is partitioned by 
this column in HDFS, so this refers to one of those partitions. As an example: G_ENTIFIC_ID=GL

* **AVERAGE_PER_RECORD:** this parameter is optional. It is the average weight in kb expected per record in final board, 
it must be an integer value. As an example: AVERAGE_PER_RECORD=2

* **REPARTITION:** this parameter is optional. It is a factor to multiply the number of partitions in which divide 
DataFrames in the process, it must be an integer value. As an example: REPARTITION=3

* **NOT_INFORMED_DATASETS:** this parameter is optional. It is the sequence of entities that will not be informed when the board is being calculated.
It should be set as a string with the name of the "not informed" datasets using ";" as a separator character.
By default, the board will be calculated using every data set in the "BUILD BOARD" section of this document.
As an example: NOT_INFORMED_DATASETS=t_kgug_adjudications;t_kgug_assets;t_kgug_valuations

The configuration file used to manage guarantee structural board ingestion is "tablonGarantias.conf". In this way, it is 
necessary to inform the following parameters in the configuration file: 
* **dateIngestion:** it refers to the execution date, it takes the value of the parameter "O_DATE" given to the 
application, which must be informed. The application checks if it is a valid date value.

* **entificColumnName:** it is the name of the geography partition in HDFS.

* **entificColumnValue:** it is the value of the geography partition in HDFS. This parameter takes the value of the 
parameter "G_ENTIFIC_ID" given to the application, which must be informed. 

* **dateColumnName:** it is the name of the cutoff date partition in HDFS.

* **dateColumnValue:** it is the value of the cutoff date partition in HDFS. This parameter takes the value of the
parameter "GF_CUTOFF_DATE" given to the application, which must be informed. The application checks if it is a valid 
date value.

* **auditColumnName:** it is the name of the column that will be set with the audit date, calculated just before writing 
the board in parquet format.

* **averageKBPerRecord:** it is the average weight in kb expected per record in final board. This parameter takes the 
value of the parameter "AVERAGE_PER_RECORD" given to the application. It has the value 2 by default.

* **schemaPath:** it is the path and file where is located the schema of guarantee structural board.

* **repartitionBase:** it refers to a factor to multiply the number of partitions the application will use to work with 
the DataFrames, which **is really important for optimize the process and should be established based on the volume of 
records to process**. This parameter takes the value of the parameter "REPARTITION" given to the application. It has the 
value 3 by default.

* **notInformedDataSets:** It is the sequence of entities that will not be informed when the board is being calculated.
It should be set as a string with the name of the "not informed" datasets using ";" as a separator character. For every
entity of this param, the process will calculate the board initializing the value of the columns that are obtained from the
"not informed" dataset with null value. By default, the board will be calculated using every data set in the "BUILD BOARD" section of this document. 
It allows all the values in the "BUILD BOARD" section of this document except t_kgug_guarantees, which is always mandatory.

As an example of guarantee structural board configuration file: 
````
CDDGuaranteesBoard {
  dateIngestion = ${?O_DATE}
  dateColumnName = "gf_cutoff_date"
  dateColumnValue = ${?GF_CUTOFF_DATE}
  entificColumnName = "g_entific_id"
  entificColumnValue = ${?G_ENTIFIC_ID}
  auditColumnName = "gf_audit_date"
  averageKBPerRecord = ${?AVERAGE_PER_RECORD}
  schemaPath = "/data/master/ktae/schemas/current/t_ktae_guarantee_struc_board.json"
  repartitionBase = ${?REPARTITION}
  notInformedDataSets = ${?NOT_INFORMED_DATASETS}
  ...
````
Given to the application the following parameters as an example:
````
  O_DATE=2020-08-21
  GF_CUTOFF_DATE=2020-07-31
  G_ENTIFIC_ID=GL
  REPARTITION=3
  AVERAGE_PER_RECORD=2
  NOT_INFORMED_DATASETS=t_kgug_adjudications;t_kgug_assets;t_kgug_valuations
````

Moreover, in this file you can find two important paths, such as:
* **temporalPath:** this is the main directory where data is saved when the checkpoint function is called. Then the 
process reads the saved data and continues building the board. It is also the main path where is made the temporal 
backup of board existing data, which is restored in case of failure in guarantee structural board ingestion.

* **pathTablonOutputPrincipal:** this is the main directory without partitions where daily ingestion is done, saving 
every month status.
````
  paths = {
    temporalPath = "/data/master/ktae/data/datatmp/t_ktae_guarantee_struc_board"
    pathTablonOutputPrincipal = "/data/master/ktae/data/t_ktae_guarantee_struc_board.json"
  }
````

Another important thing you need to know is the paths where input data is located. We have partitioned this in different 
directories and you can find it in the HDFS inside each UUAA folder. Data is partitioned by different fields for each input entity (usually gf_cutoff_date and g_entific_id). 
If only some of those partitions must be read, use previousFilterAppliedFields param. It is mandatory that the partitions that must be filtered are
allways in the "head" partitions levels. As parquet files are read, no schema is needed for input tables. As an example, for t_kgug_guarantees data:
````
  kgugGuarantees = {
    dataPath = "/data/master/kgug/data/t_kgug_guarantees"
    ...
  }
````

###**BUILD BOARD**
Guarantee structural board is build from the following CDD tables, from which one it retrieves the necessary fields: 
* t_kgug_guarantees (Mandatory)
* t_kgug_assets (Optional)
* t_kgug_adjudications (Optional)
* t_kgug_valuations (Optional)

If any of those necessary fields is not found in its corresponding dataset, it will be initialized with null values. In order to initialize
this field correctly, it must be one of the output schema fields, if not, an Exception will be thrown. If a field is initialized, a warning 
trace will be set in the log file: 
“CDDStructuralBoards: initializeNotInformedColumns - The columns that need to be initialized are ArrayBuffer()” containing the columns initialized.

Some transformations are performed on these input tables. Whenever the application read any table, first of all we apply 
a select statement to take only the relevant fields and avoid work with huge useless data. Relevant fields are indicated
by the block "relevantFields" in configuration file for each input table. There is one table with other transformation 
that must be applied before build guarantee structural board:  
* **Common transformation: Select fields:** as an example, for t_kgug_guarantees data:
    ````
     kgugGuarantees = {
       dataPath = "/data/master/kgug/data/t_kgug_guarantees"
       relevantFields = ["gf_cutoff_date",
         "g_guarantee_id",
         "g_guarantee_type",
         "gf_beginning_guarantee_date",
         "gf_end_guarantee_date",
         "g_currency_id",
         "g_gntee_valuation_method_type",
         ...
       ]
    previousFilterAppliedFields = ["gf_cutoff_date",
      "g_entific_id"]
       ...
     }
    ````
  
* **KGUGValuations:** we need to generate six new fields ("gf_first_appraising_date","gf_first_appraisal_amount",
"g_first_appraisal_currency_id", "gf_last_appraisal_date", "gf_last_appraisal_amount" and "g_last_appraisal_currency_id")
with the information of the first and last appraisal, filtering by the field "gf_appraisal_date". Additionally, if a 
property has only been appraised one time, the fields with information from the last appraisal will be left blank.
    ````
    Read com.bbva.projectsdatio.cdd.structuralboards.guarantees.datasets.KGUGValuations
    ````
    The columns needed to perform this operation must be informed in configuration file in block "fields" as follows:
    ````
     kgugValuations = {
       dataPath = "/data/master/kgug/data/t_kgug_valuations"
       relevantFields = ["g_guarantee_asset_id",
       	  "gf_appraisal_date",
       	  "g_currency_id",
       	  "gf_appraisal_amount",
       	  "g_countervalued_currency_id",
             "gf_appraiser_company_name",
             "gf_ctvl_appraisal_amount",
             "gf_force_sale_est_val_amount"]
           fields = {
              guaranteeAssetId = "g_guarantee_asset_id"
              appraisalDate = "gf_appraisal_date"
              currencyId = "g_currency_id"
              appraisalAmount = "gf_appraisal_amount"
              appraisalDateFirst = "gf_first_appraising_date"
              currencyIdFirst = "g_first_appraisal_currency_id"
              appraisalAmountFirst = "gf_first_appraisal_amount"
              appraisalDateLast = "gf_last_appraisal_date"
              currencyIdLast = "g_last_appraisal_currency_id"
              appraisalAmountLast = "gf_last_appraisal_amount"
           }
           joinFields = ["g_guarantee_asset_id"]
           previousFilterAppliedFields = ["gf_cutoff_date",
             "g_entific_id"]
     }
    ````
  
Other important procedures performed during guarantee structural board building process are the following:  

* **Join and Select Relevant Columns:** 
Once all the transformations and previous procedures have been done, the join of the tables is performed, being 
"t_kgug_guarantees" the table on which add the information from all others, this means it is the "left" table. After 
joining, a select of the final columns of guarantee structural board is made, these columns are informed in the 
configuration file inside "kgugGuarantees" in "selectTablonFields" block, and the block "fields" contains the fields
necessary to perform all joins. As follows:
    ````
     kgugGuarantees = {
       dataPath = "/data/master/kgug/data/t_kgug_guarantees/g_entific_id="${?G_ENTIFIC_ID}"/gf_cutoff_date="${?GF_CUTOFF_DATE}
       relevantFields = ["gf_cutoff_date",
         "g_guarantee_id",
         "g_guarantee_type",
         "gf_beginning_guarantee_date",
         ...
       ]
   
       selectTablonFields = ["gf_cutoff_date",
         "g_guarantee_id",
         "g_guarantee_type",
         "gf_beginning_guarantee_date",
         "gf_end_guarantee_date",
         "g_currency_id",
         ...
       ]
    previousFilterAppliedFields = ["gf_cutoff_date",
      "g_entific_id"]
     }
    ````
  
    The order chosen to perform the joins is based on the following criteria: starting from t_kgug_guarantees table, 
    joins are performed, for those tables that do not contain the "g_guarantee_id" field, first with the 
    tables that contribute with less columns to the board and last the ones that contribute with more number of columns.
    These joins are perform using the columns "gf_cutoff_date" and "g_guarantee_asset_id".
    
    Finally is perform a join with the table "t_kgug_adjudications", which is the last remaining table, using the 
    columns "gf_cutoff_date" and "g_guarantee_id", which are also the primary keys of guarantee structural board.
    
* **Checkpoint:** To increase the performance of the process, the checkpoint method writes an intermediate table in a 
temporal HDFS path during board building. This method allows the process to have a checkpoint from which retrieve data 
if a memory overflow failure happens, facilitating the process to finish correctly.
    
* **Write the board:** before writing, the column "gf_audit_date" must be added to the DataFrame, which is set with
current_timestamp() function. When you have guarantee structural board joined and the relevant fields selected, it 
validates the data schema with the one provided in "schemaGuarantee" parameter. Then it writes the board in the 
corresponding partition of the path "pathTablonOutputPrincipal", given by "g_entific_id" and "gf_cutoff_date" parameters 
and its values. Writing is done by "overwrite", so data from different ingestion will not appear on the same partition. 
In this way, each partition will contain only the most recent information, being the data ingested on the last day of 
each month. To increase the performance, **it splits guarantees structural board in 128mb files**.

* **Deleting paths:** to finish all the process, temporal paths generated during temporal backup and checkpoint method 
are deleted. 

You can find the logic of this process in com/bbva/projectsdatio/cdd/structuralboards/guarantees/app/GuaranteesIngestion.scala

For more info, click [here](https://docs.google.com/document/d/1JT_vEeu_8SIpGnzf0OTsNtkfLZk7-e7r55DHHka1ibA)

For functional information, click [here](https://docs.google.com/spreadsheets/d/14s0hBN_9lXK7GJ_kGOa0krlQjg3k58t-sgjEjTrYPVg#gid=199736486)

You can find the Technical Designs [here](https://drive.google.com/drive/folders/1lsfTBs3eOXL7qwB8i9r953XGkFwcEbIk)
