Commons app and process
=====

##**SUMMARY**

In this document you can find all the commons application and process for this project. To manage these applications, we 
use the corresponding configuration file.

##**BACKUP MANAGER**

Here is where the temporal backup of structural boards is managed. This temporal backup process is called during 
structural boards' generation process, so it takes the necessary parameters from each structural boards configuration 
file. To do this, we have two methods:
* **doTemporalBackup:** with this method we create a temporal backup of existing information of structural board before
starting the new ingestion, if there is data for actual "g_entific_id" and "gf_cutoff_date" partition.

* **restoreTemporalBackup:** this method is only called when the daily ingestion fails, it restores the previously 
created temporal backup in "pathTablonOutputPrincipal" corresponding path partition. If there is no data for actual 
"g_entific_id" and "gf_cutoff_date" partition, no backup will be restore as there is no backup created.

The temporary backup created is deleted at the end of the structural board generation process.

You can find the logic of this process in com/bbva/projectsdatio/cdd/structuralboards/commons/appManager/BackupManager.scala

##**HISTORIFICADOR**

This application manages the historification process of structural boards or any other tables. This application receives 
the following parameters: 
* **PATH_PRINCIPAL:** it must be the main directory without partitions where daily ingestion is done. It is the 
directory from where to read the data to historify it. The path must be a string. As an example: 
PATH_PRINCIPAL=/data/master/ktae/data/t_ktae_contract_struc_board

* **PATH_HISTORICAL:** this is the main directory without partitions where to historify the data from principal path. 
The path must be a string. As an example: PATH_HISTORICAL=/data/master/ktae/data/t_ktae_contract_struc_board_histo

* **COLUMNS_NAME:** it must be the name of the partitioning fields of the principal table, with its respective order.
This parameter must be a string, so partitioning fields must be given concatenating the names and separating them by the 
character ";". It is important to introduce all the partitioning fields in correct order because they will be used to 
indicate the partitioning fields in the historical table. As an example: COLUMNS_NAME=g_entific_id;gf_cutoff_date

* **COLUMNS_VALUE:** it must be the value of the partitioning fields of the principal table, with its respective order, 
of the information you want to historify. This parameter must be a string, so values of partitioning fields must be 
given concatenating the values and separating them by the character ";". It is important to keep partitioning fields 
order. As an example: COLUMNS_NAME=GL;2020-02-29. If no filter will be applied to any column, set it as _. As an example: COLUMNS_NAME=_;2020-02-29. 

* **APPLY_FILTER:** this parameter indicates if data must be filtered for a particular partitioning field value or not. If 
in a partitioning field position it values "Y", the process will apply a filter in the corresponding partitioning field 
with the value given; if it values "N" in that position, no filter will be applied for that partition column. This 
parameter must be a string, so values of partitioning fields must be given concatenating the values and separating them 
by the character ";". It is important to keep partitioning fields order. As an example of filtering the gf_cutoff_date 
column and not the g_entific_id column (it will work with all geographies): APPLY_FILTER=N;Y. As an example of filtering
all columns: APPLY_FILTER=Y;Y

* **AUDIT_COLUMN_NAME:** this parameter is optional. It must be the name of the audit date of the table, it will be used 
as a partitioning field of the historical table, being the last one. It must be a string. 
As an example: AUDIT_COLUMN_NAME=gf_audit_date

* **SCHEMA_PATH:** it is the path and file where is located the schema of the historical table. The path must be a 
string. As an example: SCHEMA_PATH=/data/master/ktae/schemas/current/t_ktae_contract_struc_board_histo.json

* **AVERAGE_PER_RECORD:** this parameter is optional. It is the average weight in kb expected per record in final table, 
it must be an integer value. As an example: AVERAGE_PER_RECORD=8

* **FAIL_IF_NULL_DF:** this parameter is optional. Depending on its value is 0 or 1, process will fail or not when 
filtered DataFrame has no rows, it must be an integer value. As an example: FAIL_IF_NULL_DF=1

* **REPARTITION:** this parameter is optional. It is a factor to multiply the number of partitions in which divide 
DataFrames in the process, it must be an integer value. As an example: REPARTITION=1

The configuration file used to manage this application is "historificador.conf". In this way, the parameters 
"pathTablonPrincipal", "pathTablonHistorical", "columnsName", "columnsValue", "applyFilter", "auditColumnName" and 
"schemaPath" in the configuration file must be informed. The other parameters are optionals, because they have a default
value; you should inform them if you want a different value from the default one. The configuration file contains 
the following parameters:
* **pathTablonPrincipal:** this is the main directory without partitions where daily ingestion is done. It is the 
directory from where to read the data. This parameter takes the value of the parameter "PATH_PRINCIPAL" given to the 
application, which must be informed.

* **pathTablonHistorical:** this is the main directory without partitions where to historify the data from principal path.
This parameter takes the value of the parameter "PATH_HISTORICAL" given to the application, which must be informed.

* **columnsName:** these are the names of the partition fields of the principal table in HDFS. This parameter takes the 
value of the parameter "COLUMNS_NAME" given to the application, which must be informed.

* **columnsValue:** these are the values of the partition fields of the principal table for which you want to apply the 
filter. This parameter takes the value of the parameter "COLUMNS_VALUE" given to the application, which must be informed.

* **applyFilter:** this parameter indicates if must be applied a filter on a partitioning field or not, depending on if
the corresponding value is "Y" or "N" for each partition column. This parameter takes the value of the parameter 
"COLUMNS_VALUE" given to the application, which must be informed. If for a partition column the corresponding value 
is "N", it will work with all of its partitions.

* **auditColumnName:** it is the name of the audit date column of the principal table, and also the name of the new 
partitioning field for the historical table. It takes the value of the parameter "AUDIT_COLUMN_NAME" given to the 
application, and it has the value "gf_audit_date" by default.

* **schemaPath:** it is the path and file where is located the schema of the historical table. This parameter takes the 
value of the parameter "SCHEMA_PATH" given to the application, which must be informed.

* **repartitionBase:** it refers to a factor to multiply the number of partitions the application will use to work with 
the DataFrames, which **is really important for optimize the process and should be established based on the volume of 
records to process**. This parameter takes the value of the parameter "REPARTITION" given to the application. It has the
value 1 by default.

* **averageKBPerRecord:** it is the average weight in kb expected per record. This parameter takes the value of the 
parameter "AVERAGE_PER_RECORD" given to the application. It has the value 8 by default.

* **failIfNullDf:** this parameter indicates the decision to be made in case the filtered DataFrame has no records. If 
this parameter is 0, the process ends successfully but it do not write anything in the HDFS; if this parameter is 1, the 
process will show an exception and it will fail. This parameter takes the value of the parameter "FAIL_IF_NULL_DF" 
given to the application. It has the value 1 by default.

As an example for historify contract structural board, configuration file: 
````
CDDHistorificador {
  paths = {
    pathTablonPrincipal = ${?PATH_PRINCIPAL}
    pathTablonHistorical = ${?PATH_HISTORICAL}
  }
  partitionFeature = {
    columnsName = ${COLUMNS_NAME}
    columnsValue = ${?COLUMNS_VALUE}
    applyFilter = ${?APPLY_FILTER}
  }
  schemaPath = ${?SCHEMA_PATH}
  auditColumnName = ${?AUDIT_COLUMN_NAME}
  repartitionBase = ${?REPARTITION}
  averageKBPerRecord = ${?AVERAGE_PER_RECORD}
  failIfNullDf = ${?FAIL_IF_NULL_DF}
}
````
Given to the application the following parameters as an example:
````
  PATH_PRINCIPAL=/data/master/ktae/data/t_ktae_contract_struc_board
  PATH_HISTORICAL=/data/master/ktae/data/t_ktae_contract_struc_board_histo
  COLUMNS_NAME=g_entific_id;gf_cutoff_date
  COLUMNS_VALUE=GL;2020-02-29
  APPLY_FILTER=Y;Y
  SCHEMA_PATH=/data/master/ktae/schemas/current/t_ktae_contract_struc_board_histo.json
  AUDIT_COLUMN_NAME=gf_audit_date
  REPARTITION=1
  AVERAGE_PER_RECORD=8
  FAIL_IF_NULL_DF=1
````
If you want to work with all geographies partitions, you could use the following parameters values:
````
  COLUMNS_NAME=g_entific_id;gf_cutoff_date
  COLUMNS_VALUE=_;2020-02-29
  APPLY_FILTER=N;Y
````
As an example for tables with a single partition, you could use the following parameters values:
````
  COLUMNS_NAME=gf_cutoff_date
  COLUMNS_VALUE=2020-02-29
  APPLY_FILTER=Y
````

The application reads the data from the main path "pathTablonPrincipal" and filters the DataFrame by the columns 
"columnsName" using the values "columnsValue" if its corresponding value for each one of them of the parameter 
"applyFilter" is "Y"; and works with all its partition values if it is "N". Also, the application validates if the given
column names in "columnsName" and "auditColumnName" parameters exist in read dataFrame.

After that, the process validates if filtered dataFrame is empty or not. If "failIfNullDf" value is 1, the process will
be interrupted. If filtered dataFrame is empty, "columnsValue" parameter should be checked, because the filter value of 
the columns may be wrong.

Then it writes the filtered DataFrame in the "pathTablonHistorical" by an "append", validating the data schema with the 
one provided in "schemaPath" parameter; and partitioning data by the columns given in parameter "columnsName" and the 
column given in parameter "auditColumnName".

This process validates that the "columnsName", "columnsValue" and "applyFilter" parameters have the same number of 
elements, differentiated by the character ";". These parameters can have one or two elements, since the process is 
restricted to tables with a maximum of two partitioning fields.

You can find the logic of this application in com/bbva/projectsdatio/cdd/structuralboards/commons/app/Historificador.scala

Also, take the testAT section of this tool to review specific use cases and working examples of input-execution-expected tests.
Those testAt can be found in: testAT/src/test/resources/features/Historificador.feature and are related to
functional description in [this spreadsheet](https://docs.google.com/spreadsheets/d/1550zPnAKlRXUxwfhFeEORXoRGsk9Lb784n_BHDAkSz8/edit#gid=0)

##**CLEAN BOARDS**

This application manages the cleaner process of structural boards or any other tables, deleting cutoff date HDFS
partitions that exceed persistence limit time. This application receives the following parameters:                                                                                       
* **O_DATE:** it must be the actual execution date, in yyyy-MM-dd format. As an example: O_DATE=2020-06-13.

* **PERSISTENCE_MONTHS_LIMIT:** it must be the persistence limit time of data in HDFS, in months. It is required to 
determine the partitions to be removed from HDFS. It must be an integer. As an example: PERSISTENCE_MONTHS_LIMIT=60

* **CLEAN_PATH:** this is the main directory without partitions from where to delete old information. The path must be a 
string. As an example: CLEAN_PATH=/data/master/ktae/data/t_ktae_contract_struc_board

* **DATE_PARTITION_NAME:** it must be the name of the date partition field. As an example: 
DATE_PARTITION_NAME=gf_cutoff_date

* **DATE_FORMAT:** it must be the format of the date value in the date partition field in HDFS. This is used to compare
the date given in "O_DATE" parameter with the date partition value, transforming it into the "O_DATE" parameter format.
It must be a string. As an example, if the partition field value is 20200531, the parameter must be: DATE_FORMAT=yyyyMMdd

The configuration file used to manage this application is "cleanBoards.conf" which contains the following parameters and
all of them must be correctly informed:
* **dateIngestion:** it refers to the execution date in yyyy-MM-dd format. This parameter takes the value of the 
parameter "O_DATE" given to the application. The application checks if it is a valid date value.

* **path:** this is the main directory without partitions where to search for old data partitions and delete them. This 
parameter takes the value of the parameter "CLEAN_PATH" given to the application. 

* **persistenceLimit:** it refers to data persistence months limit in HDFS, necessary for determinate which partitions
must be deleted (includes limit dates). This parameter takes the value of the parameter "PERSISTENCE_MONTHS_LIMIT" given to the application. 

* **datePartitionName:** it refers to the name of the date partition field. This parameter takes the value of the 
parameter "DATE_PARTITION_NAME" given to the application. 

* **dateFormat:** it must be the format of the date value in the date partition field in HDFS. This parameter takes the 
value of the parameter "DATE_FORMAT" given to the application, which must be informed.

As an example for clean contract structural board principal path partitions, configuration file: 
````
CDDCleanBoards {
  dateIngestion = ${?O_DATE}
  path =  ${?CLEAN_PATH}
  persistenceLimit = ${?PERSISTENCE_MONTHS_LIMIT}
  partitionFeature = {
    datePartitionName = ${?DATE_PARTITION_NAME}
    dateFormat = ${?DATE_FORMAT}
  }
````
Given to the application the following parameters as an example:
````
  O_DATE=2020-06-03
  PERSISTENCE_MONTHS_LIMIT=60
  CLEAN_PATH=/data/master/ktae/data/t_ktae_contract_struc_board
  DATE_PARTITION_NAME=gf_cutoff_date
  DATE_FORMAT=yyyy-MM-dd
````
As an example for tables with a single partition, you could use the following parameters values:
````
  DATE_PARTITION_NAME=gf_cutoff_date
  DATE_FORMAT=yyyy-MM-dd
````

For each one of datePartitionName path level directories, the application checks if the difference in months between that date partition value, 
parsed with given "dateFormat" parameter into "yyyy-MM-dd" format, and "dateIngestion" is higher than persistence limit 
time, given by "persistenceLimit" parameter. If this happens, that date partition will be deleted.

You must take into account that the cleaner process is performed every time the application is executed, it means that 
the day of the month is not taken into account to perform data deletion, it is used to compare month differences.
This parameter takes the inclusive diference with the last day of the limit month. 
For example an entity with the following partitions tree:
````
t_example_base_path
;-gf_cutoff_date=2021-05-07
;-gf_cutoff_date=2021-05-31
;-gf_cutoff_date=2021-06-07
````

When executed:
````
  O_DATE=2021-09-07
  PERSISTENCE_MONTHS_LIMIT=5
  ...
````
No partition will be deleted.

But when executed:
````
  O_DATE=2021-09-07
  PERSISTENCE_MONTHS_LIMIT=4
  ...
````
Both gf_cutoff_date=2021-05-07 and gf_cutoff_date=2021-05-31 (limit) partitions will be deleted.

You can find the logic of this application in com/bbva/projectsdatio/cdd/structuralboards/commons/app/CleanBoards.scala

Also, take the testAT section of this tool to review specific use cases and working examples of input-execution-expected tests.
Those testAt can be found in: testAT/src/test/resources/features/CleanBoard.feature and are related to
functional description in [this spreadsheet](https://docs.google.com/spreadsheets/d/1550zPnAKlRXUxwfhFeEORXoRGsk9Lb784n_BHDAkSz8/edit#gid=1306842461)

##**RESTORE**

This application manages the restore process of structural boards or any other tables. This application receives the 
following parameters: 
* **PATH_PRINCIPAL:** it must be the main directory without partitions where daily ingestion is done. It is the 
directory where to restore the data. The path must be a string. As an example: 
PATH_PRINCIPAL=/data/master/ktae/data/t_ktae_contract_struc_board

* **PATH_HISTORICAL:** this is the main directory without partitions where is the historified data from principal 
path and from where to restore the data. The path must be a string. As an example: 
PATH_HISTORICAL=/data/master/ktae/data/t_ktae_contract_struc_board_histo

* **HIST_COLUMNS_NAME:** it must be the name of the partitioning fields of the historical table, with its respective order.
This parameter must be a string, so partitioning fields must be given concatenating the names and separating them by the 
character ";". It is important to introduce all the partitioning fields in correct order. As an example: 
COLUMNS_NAME=g_entific_id;gf_cutoff_date;gf_audit_date

* **HIST_COLUMNS_VALUE:** it must be the value of the partitioning fields of the historical table, with its respective order, 
of the information you want to historify. This parameter must be a string, so values of partitioning fields must be 
given concatenating the values and separating them by the character ";". It is important to keep partitioning fields 
order and that values are correctly informed, because will be applied a filter of the partition columns by these values. 
As an example: COLUMNS_NAME=GL;2020-02-29;2020-03-15 14:40:22.167

* **PRINC_COLUMNS_NAME:** it must be the name of the partitioning fields of the principal table, with its respective order.
This parameter must be a string, so partitioning fields must be given concatenating the names and separating them by the 
character ";". It is important to introduce all the partitioning fields in correct order. As an example: 
COLUMNS_NAME=g_entific_id;gf_cutoff_date

* **PRINC_COLUMNS_VALUE:** it must be the value of the partitioning fields of the principal table, with its respective order, 
of the information you want to historify. This parameter must be a string, so values of partitioning fields must be 
given concatenating the values and separating them by the character ";". It is important to keep partitioning fields 
order and that values are correctly informed. 
As an example: COLUMNS_NAME=GL;2020-02-29

* **AVERAGE_PER_RECORD:** this parameter is optional. It is the average weight in kb expected per record in final table, 
it must be an integer value. As an example: AVERAGE_PER_RECORD=8

* **FAIL_IF_NO_DATA:** this parameter is optional. Depending on its value is 0 or 1, process will fail or not when 
filtered DataFrame has no rows, it must be an integer value. As an example: FAIL_IF_NO_DATA=1

* **REPARTITION:** this parameter is optional. It is a factor to multiply the number of partitions in which divide 
DataFrames in the process, it must be an integer value. As an example: REPARTITION=1

The configuration file used to manage this application is "restore.conf". In this way, the parameters 
"pathTablonPrincipal", "pathTablonHistorical", "columnsName" and "columnsValue" in the configuration file must be 
informed. The other parameters are optionals, because they have a default value; you should inform them if you want a 
different value from the default one. The configuration file contains the following parameters:
* **pathTablonPrincipal:** this is the main directory without partitions where to restore the data. It is the directory 
where delete the malformed data and write the data restored. This parameter takes the value of the parameter 
"PATH_PRINCIPAL" given to the application, which must be informed.

* **pathTablonHistorical:** this is the main directory without partitions from where to read the data from historical 
path to restore it in the principal path. This parameter takes the value of the parameter "PATH_HISTORICAL" given to the 
application, which must be informed.

* **columnsHistoricalName:** these are the names of the partition fields of the historical table in HDFS. This parameter takes the 
value of the parameter "HIST_COLUMNS_NAME" given to the application, which must be informed.

* **columnsHistoricalValue:** these are the values of the partition fields of the historical table for which you want to apply the 
filter. This parameter takes the value of the parameter "HIST_COLUMNS_VALUE" given to the application, which must be informed.
It is important to inform correctly each partition value and in the correct order, because a filter will be applied by 
"columnsHistoricalName" with "columnsHistoricalValue" value.

* **columnsPrincipalName:** these are the names of the partition fields of the principal table in HDFS. This parameter takes the 
value of the parameter "PRINC_COLUMNS_NAME" given to the application, which must be informed.

* **columnsPrincipalValue:** these are the values of the partition fields of the principal table for which you want to apply the 
filter. This parameter takes the value of the parameter "PRINC_COLUMNS_VALUE" given to the application, which must be informed.
It is important to inform correctly each partition value and in the correct order.

* **repartitionBase:** it refers to a factor to multiply the number of partitions the application will use to work with 
the DataFrames, which **is really important for optimize the process and should be established based on the volume of 
records to process**. This parameter takes the value of the parameter "REPARTITION" given to the application. It has the
value 1 by default.

* **averageKBPerRecord:** it is the average weight in kb expected per record. This parameter takes the value of the 
parameter "AVERAGE_PER_RECORD" given to the application. It has the value 8 by default.

* **failIfNoDataToRestore:** this parameter indicates the decision to be made in case the filtered dataframe have no 
records. If this parameter is 0, the process ends successfully but it do not write anything in the HDFS; if this 
parameter is 1, the process will show an exception and it will fail. This parameter takes the value of the parameter 
"FAIL_IF_NO_DATA" given to the application. It has the value 1 by default.

As an example for restore data in contract structural board from historical path, configuration file: 
````
CDDRestore {
  paths = {
    pathTablonPrincipal = ${?PATH_PRINCIPAL}
    pathTablonHistorical = ${?PATH_HISTORICAL}
  }
  partitionFeature = {
    columnsHistoricalName = ${COLUMNS_HIS_NAME}
    columnsHistoricalValue = ${COLUMNS_HIS_VALUE}
    columnsPrincipalName = ${COLUMNS_PRINC_NAME}
    columnsPrincipalValue = ${COLUMNS_PRINC_VALUE}
  }
  repartitionBase = ${?REPARTITION}
  averageKBPerRecord = ${?AVERAGE_PER_RECORD}
  failIfNoDataToRestore = ${?FAIL_IF_NO_DATA}
}
````
Given to the application the following parameters as an example:
````
  PATH_PRINCIPAL=/data/master/ktae/data/t_ktae_contract_struc_board
  PATH_HISTORICAL=/data/master/ktae/data/t_ktae_contract_struc_board_histo
  COLUMNS_HIS_NAME=g_entific_id;gf_cutoff_date;gf_audit_date
  COLUMNS_HIS_VALUE=GL;2020-02-29;2020-03-15 14:40:22.167
  COLUMNS_PRINC_NAME=g_entific_id;gf_cutoff_date
  COLUMNS_PRINC_VALUE=GL;2020-02-29
  REPARTITION=1
  AVERAGE_PER_RECORD=8
  FAIL_IF_NO_DATA=1
````
As an example for principal tables with a single partition, you could use the following parameters values:
````
  COLUMNS_HIS_NAME=gf_cutoff_date;gf_audit_date
  COLUMNS_HIS_VALUE=2020-02-29;2020-03-15 14:40:22.167
  COLUMNS_PRINC_NAME=gf_cutoff_date
  COLUMNS_PRINC_VALUE=2020-02-29
````

The application reads the data from the main path "pathTablonHistorical" and filters the DataFrame by the columns 
"columnsHistoricalName" using the values "columnsHistoricalValue" respectively. The application applies the respective filter for all the 
partitioning fields of the table. Also, the application validates if the given column names in "columnsName" parameter 
exist in read dataFrame.

After that, the process validates if filtered dataFrame is empty or not. If "failIfNoDataToRestore" value is 1, the 
process will be interrupted. If filtered dataFrame is empty, "columnsHistoricalValue" parameter should be checked, because the 
filter value of the columns may be wrong.

The process deletes the existing information for the given parameter "columnsPrincipalName" and "columnsPrincipalValue" in principal path, 
not taking into account the audit date partition column. In this way it only deletes a single partition in principal 
table. Then it writes the filtered DataFrame in "pathTablonPrincipal" by an "append", partitioning by the columns given in 
parameters "columnsName" except for the audit date column.

This process validates that the "columnsPrincipalName" and "columnsPrincipalValue" parameters have the same number of elements, 
differentiated by the character ";".

You can find the logic of this application in com/bbva/projectsdatio/cdd/structuralboards/commons/app/Restore.scala

Also, take the testAT section of this tool to review specific use cases and working examples of input-execution-expected tests.
Those testAt can be found in: testAT/src/test/resources/features/Restore.feature and are related to
functional description in [this spreadsheet](https://docs.google.com/spreadsheets/d/1550zPnAKlRXUxwfhFeEORXoRGsk9Lb784n_BHDAkSz8/edit#gid=1894583707)

##**OTHER IMPORTANT FILES**

Other important files in this directory is the Constant file, where you can find all the constants declared and the 
objects that let you read, validate and write data such as ReadUtils, TechnicalValidation and WriteUtils. They are 
located in com/bbva/projectsdatio/cdd/structuralboards/commons/utils , ../commons/validation and ../commons/exceptions

For more info, click [here](https://docs.google.com/document/d/1ecn5MobYXGtYe9hBWneHDfi-dCVXYZi6nWjPPLN51ZU)

You can find the Technical Designs [here](https://drive.google.com/drive/folders/1lsfTBs3eOXL7qwB8i9r953XGkFwcEbIk)
