Contracts app
====

##**SUMMARY**

This part of the project is the brain, here you can find all the logic to build contract structural board. This 
application receives the following parameters: 
* **O_DATE:** it must be the actual date, in yyyy-MM-dd format. As an example: O_DATE=2020-03-25

* **GF_CUTOFF_DATE:** it **must be the last day of the previous month in yyyy-MM-dd format**. Data is partitioned by this 
column in HDFS, so this refers to one of those partitions. As an example: GF_CUTOFF_DATE=2020-02-29

* **G_ENTIFIC_ID:** it must be the geography whose data you want to load, must be two characters. Data is partitioned by 
this column in HDFS, so this refers to one of those partitions. As an example: G_ENTIFIC_ID=GL

* **AVERAGE_PER_RECORD:** this parameter is optional. It is the average weight in kb expected per record in final board, 
it must be an integer value. As an example: AVERAGE_PER_RECORD=8

* **REPARTITION:** this parameter is optional. It is a factor to multiply the number of partitions in which divide 
DataFrames in the process, it must be an integer value. As an example: REPARTITION=3

* **NOT_INFORMED_DATASETS:** this parameter is optional. It is the sequence of entities that will not be informed when the board is being calculated.
It should be set as a string with the name of the "not informed" datasets using ";" as a separator character.
By default, the board will be calculated using every data set in the "BUILD BOARD" section of this document.
As an example: NOT_INFORMED_DATASETS=t_kctk_credit_risk;t_ksan_eom_renumerations;t_ksan_eom_instlmnt_plan;t_ksan_eom_domestic_interveners

The configuration file used to manage contract structural board ingestion is "tablonContratos.conf". In this way, it is 
necessary to inform the following parameters in the configuration file: 
* **dateIngestion:** it refers to the execution date, it takes the value of the parameter "O_DATE" given to the 
application, which must be informed. The application checks if it is a valid date value.

* **entificColumnName:** it is the name of the geography partition in HDFS.

* **entificColumnValue:** it is the value of the geography partition in HDFS. This parameter takes the value of the 
parameter "G_ENTIFIC_ID" given to the application, which must be informed. 

* **dateColumnName:** it is the name of the cutoff date partition in HDFS.

* **dateColumnValue:** it is the value of the cutoff date partition in HDFS. This parameter takes the value of the
parameter "GF_CUTOFF_DATE" given to the application, which must be informed. The application checks if it is a valid 
date value.

* **auditColumnName:** it is the name of the column that will be set with the audit date, calculated just before writing 
the board in parquet format.

* **averageKBPerRecord:** it is the average weight in kb expected per record in final board. This parameter takes the 
value of the parameter "AVERAGE_PER_RECORD" given to the application. It has the value 8 by default.

* **schemaPath:** it is the path and file where is located the schema of contract structural board.

* **repartitionBase:** it refers to a factor to multiply the number of partitions the application will use to work with 
the DataFrames, which **is really important for optimize the process and should be established based on the volume of 
records to process**. This parameter takes the value of the parameter "REPARTITION" given to the application. It has the 
value 3 by default.

* **notInformedDataSets:** It is the sequence of entities that will not be informed when the board is being calculated.
It should be set as a string with the name of the "not informed" datasets using ";" as a separator character. For every
entity of this param, the process will calculate the board initializing the value of the columns that are obtained from the
"not informed" dataset with null value. By default, the board will be calculated using every data set in the "BUILD BOARD" section of this document. 
It allows all the values in the "BUILD BOARD" section of this document except t_ksan_eom_contract, which is always mandatory.

As an example of contract structural board configuration file: 
````
CDDContractsBoard {
  dateIngestion = ${?O_DATE}
  dateColumnName = "gf_cutoff_date"
  dateColumnValue = ${?GF_CUTOFF_DATE}
  entificColumnName = "g_entific_id"
  entificColumnValue = ${?G_ENTIFIC_ID}
  auditColumnName = "gf_audit_date"
  averageKBPerRecord = ${?AVERAGE_PER_RECORD}
  schemaPath = "/data/master/ktae/schemas/current/t_ktae_contract_struc_board.json"
  repartitionBase = ${?REPARTITION}
  notInformedDataSets = ${?NOT_INFORMED_DATASETS}
  ...
````
Given to the application the following parameters as an example:
````
  O_DATE=2020-03-25
  GF_CUTOFF_DATE=2020-02-29
  G_ENTIFIC_ID=GL
  REPARTITION=3
  AVERAGE_PER_RECORD=8
  NOT_INFORMED_DATASETS=t_kctk_credit_risk;t_ksan_eom_renumerations;t_ksan_eom_instlmnt_plan;t_ksan_eom_domestic_interveners
````

Moreover, in this file you can find two important paths, such as:
* **temporalPath:** this is the main directory where data is saved when the checkpoint function is called. Then the 
process reads the saved data and continues building the board. It is also the main path where is made the temporal 
backup of board existing data, which is restored in case of failure in contract structural board ingestion.

* **pathTablonOutputPrincipal:** this is the main directory without partitions where daily ingestion is done, saving 
every month status.
````
  paths = {
    temporalPath = "/data/master/ktae/data/datatmp/t_ktae_contract_struc_board"
    pathTablonOutputPrincipal = "/data/master/ktae/data/t_ktae_contract_struc_board.json"
  }
````

Another important thing you need to know is the paths where input data is located. We have partitioned this in different 
directories and you can find it in the HDFS inside each UUAA folder. Data is partitioned by different fields for each input entity (usually gf_cutoff_date and g_entific_id). 
If only some of those partitions must be read, use previousFilterAppliedFields param. It is mandatory that the partitions that must be filtered are
allways in the "head" partitions levels. As parquet files are read, no schema is needed for input tables. As an example, for t_kbtq_eom_customer data:
````
  ksanEmContract = {
    dataPath = "/data/master/ksan/data/t_ksan_eom_contract"
    ...
  }
````

##**BUILD BOARD**

Contract structural board is build from the following CDD tables, from which one it retrieves the necessary fields: 
* t_ksan_eom_contract (Mandatory)
* t_ksan_eom_assets_liabilities (Optional)
* t_ksan_eom_out_of_bal_items (Optional)
* t_ksan_eom_internal_depo (Optional)
* t_ksan_eom_cont_segmentation (Optional)
* t_ksan_eom_domestic_interveners (Optional)
* t_ksan_eom_instlmnt_plan (Optional)
* t_ksan_eom_renumerations (Optional)
* t_krei_regulatory_information (Optional)
* t_kctk_credit_risk (Optional)
* t_kctk_risk_scoring_atrb (Optional)
* t_kdeo_inapprt_cont_situtn (Optional)
* t_kstm_s_assets_liabilities (Optional)
* t_kstm_s_internal_depo (Optional)
* t_kstm_s_off_balance_items (Optional)

If any of those necessary fields is not found in its corresponding dataset, it will be initialized with null values. In order to initialize
this field correctly, it must be one of the output schema fields, if not, an Exception will be thrown. If a field is initialized, a warning 
trace will be set in the log file: 
“CDDStructuralBoards: initializeNotInformedColumns - The columns that need to be initialized are ArrayBuffer()” containing the columns initialized.

Some transformations are performed on these input tables. Whenever the application read any table, first of all we apply 
a select statement to take only the relevant fields and avoid work with huge useless data. Relevant fields are indicated
by the block "relevantFields" in configuration file for each input table. There are 3 tables with other transformations 
that must be applied before build contract structural board:  
* **Common transformation: Select fields:** as an example, for t_ksan_eom_contract data:
    ````
     ksanEomContract = {
       dataPath = "/data/master/ksan/data/t_ksan_eom_contract"
       relevantFields = ["gf_cutoff_date",
         "gf_local_contract_number_id",
         "g_entity_id",
         "g_contract_id",
         "g_currency_id",
         "gf_initial_main_amount",
         "gf_contract_register_date",
         ...
       ]
       ...
     }
    ````
  
* **KSANEomRenumerations:** we need to get the maximum value for "gf_new_contract_init_date" and apply a filter to 
get only the record with maximum contract init date. Then we drop the "gf_new_contract_init_date_new" column.
    ````
     Read com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets.KSANEomRenumerations
    ````
    
* **KSANEomDomesticInterveners:** we need to apply a filter by 'Y' value in field "g_main_customer_type", drop this field
and rename the field "g_customer_id" as "g_main_holder_customer_id".
    ````
     Read com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets.KSANEomDomesticInterveners
    ````  
    
* **KSANEomIntallmentPlan:** we need to generate nine new fields ("gf_nxt_instlmt_int_bc_amount","gf_nxt_instlmt_tot_bc_amount",
"gf_nxt_instlmt_amort_bc_amount", "gf_pv_instlmt_int_bc_amount", "gf_pv_instlmt_tot_bc_amount", "gf_pv_instlmt_amort_bc_amount",
"gf_lst_instlmt_int_bc_amount", "gf_lst_instlmt_tot_bc_amount", "gf_lst_instlmt_amort_bc_amount") with the last, next
and previous amount of "gf_instlmt_interest_bc_amount","gf_instlmt_total_bc_amount","gf_instlmt_principal_bc_amount".
Finally we filter data where "gf_installment_maturity_date" belongs to the current month.
    
    ````
     Read com.bbva.projectsdatio.cdd.structuralboards.contracts.datasets.KSANEomIntallmentPlan
    ````   
  
Other important procedures performed during contract structural board building process are the following:  
  
* **Union Process:** Before doing the joins of the tables, it is necessary to keep in mind that there are two sets of
tables that contain information of contracts that belong to disjoint universes. In this way, the union of the tables of 
each block in one is performed, keeping the information of the common and non-common columns of these input tables. In 
the resulting DataFrame appears the common and non-common columns of the tables of the set. For each contract, you will 
have the information of the columns of the table from which it comes; and the columns that come from the tables in which
it does not appear will be set as null. 

    The two set of tables on which the union is performed are the following:
    * "t_ksan_eom_assets_liabilities", "t_ksan_eom_out_of_bal_items" and "t_ksan_eom_internal_depo"
    
    * "t_kstm_s_assets_liabilities", "t_kstm_s_off_balance_items" and "t_kstm_s_internal_depo"
  
    After performing the union, it is validated that a contract does not appear more than once in the resulting table, since 
    it should only be in a single input table. If it appears in more than one, the process stops and an exception is thrown.
    The only allowed exception is duplicates between Domestic and Markets "Sub"Boards that will show a log in case of duplicate registries,
    but won't stop the execution
    ````
     Read com.bbva.projectsdatio.cdd.structuralboards.contracts.app.StructuralboardsContractsTrait.contractsUnion(...)
    ````   
  
* **Join and Select Relevant Columns:** 
Once all the transformations and previous procedures have been done, the join of the tables is performed, being 
"t_ksan_eom_contract" the table on which add the information from all others, this means it is the "left" table. After 
joining, a select of the final columns of contract structural board is made, these columns are informed in the 
configuration file inside "ksanEomContract" in "selectTablonFields" block, and the block "fields" contains the fields
necessary to perform all joins. As follows:
    ````
     ksanEomContract = {
       dataPath = "/data/master/ksan/data/t_ksan_eom_contract/g_entific_id=${?G_ENTIFIC_ID}/gf_cutoff_date=${?GF_CUTOFF_DATE}"
       relevantFields = ["gf_cutoff_date",
         "gf_local_contract_number_id",
         "g_entity_id",
         ...
       ]
       selectTablonFields = ["gf_cutoff_date",
         "gf_local_contract_number_id",
         "g_management_breakdown_type",
         "g_contract_id",
         "g_cont_main_holder_cust_id",
         "g_entity_id",
         ...
       ]
        previousFilterAppliedFields = ["gf_cutoff_date",
          "g_entific_id"]
        fields = {
          finalBoardPks = ["gf_local_contract_number_id"]
        }
     }
    ````
    The order chosen to perform the joins is based on the following criteria: starting from t_ksan_eom_contract table, 
    joins are performed, for those tables that do not contain the "g_management_breakdown_type" field, first with the 
    tables that contribute with less columns to the board and last the ones that contribute with more number of columns.
    These joins are perform using the columns "gf_cutoff_date" and "gf_local_contract_number_id", which exist in all
    tables. 
    
    Finally is perform a join with the table "t_krei_regulatory_information", using the columns "gf_cutoff_date" and 
    "gf_local_contract_number_id", and then those with the field "g_management_breakdown_type", using the columns 
    "gf_cutoff_date", "gf_local_contract_number_id"; which are the primary keys of contract structural board.
    
    Once contract structural board is created and the final columns selected, null values in "g_management_breakdown_type" 
    column of the final board are initialized to a default value.
    
* **Checkpoint:** To increase the performance of the process, the checkpoint method writes an intermediate table in a 
temporal HDFS path during board building. This method allows the process to have a checkpoint from which retrieve data 
if a memory overflow failure happens, facilitating the process to finish correctly.
    
* **Write the board:** before writing, the column "gf_audit_date" must be added to the DataFrame, which is set with
current_timestamp() function. When you have contract structural board joined and the relevant fields selected, it 
validates the data schema with the one provided in "schemaContract" parameter. Then it writes the board in the 
corresponding partition of the path "pathTablonOutputPrincipal", given by "g_entific_id" and "gf_cutoff_date" parameters 
and its values. Writing is done by "overwrite", so data from different ingestion will not appear on the same partition. 
In this way, each partition will contain only the most recent information, being the data ingested on the last day of 
each month. To increase the performance, **it splits contract structural board in 128mb files**.

* **Deleting paths:** to finish all the process, temporal paths generated during temporal backup and checkpoint method 
are deleted. 

You can find the logic of this process in com/bbva/projectsdatio/cdd/structuralboards/contracts/app/ContractsIngestion.scala

For more info, click [here](https://docs.google.com/document/d/1JT_vEeu_8SIpGnzf0OTsNtkfLZk7-e7r55DHHka1ibA)

For functional information, click [here](https://docs.google.com/spreadsheets/d/14s0hBN_9lXK7GJ_kGOa0krlQjg3k58t-sgjEjTrYPVg#gid=206939155)

You can find the Technical Designs [here](https://drive.google.com/drive/folders/1lsfTBs3eOXL7qwB8i9r953XGkFwcEbIk)
